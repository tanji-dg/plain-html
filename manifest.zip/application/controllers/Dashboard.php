<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}

	public function opsHome() {
		$this->load->view('dashboard/ops_home');
	}

	public function opsAr() {
		$this->load->view('dashboard/ops_ar');
	}

	public function opsBooking() {
		$this->load->view('dashboard/ops_booking');
	}

	public function opsCollection() {
		$this->load->view('dashboard/ops_collection');
	}

	public function opsAyda() {
		$this->load->view('dashboard/ops_ayda');
	}

	public function opsNcl() {
		$this->load->view('dashboard/ops_ncl');
	}

	public function opsSdm() {
		$this->load->view('dashboard/ops_sdm');
	}

	public function opsUnhealtyMonitoring() {
		$this->load->view('dashboard/ops_unhealty');
	}


}
