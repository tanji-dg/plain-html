<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}

	public function index() {
		$this->load->view('auth/login');
	}

	public function daftar() {
		$this->load->view('auth/daftar');
	}

	public function lupapassword() {
		$this->load->view('auth/lupapassword');
	}

	public function validate_old() {

		$noabsen = $this->input->post('noabsen');
		$password = $this->input->post('password');

		$pengacak = "P@ssw0rdM4r5";
		$pass = md5($pengacak. md5($password).$pengacak) ;

		$query = "
			SELECT 
				a.iduser,
				a.nmuser,
				a.userlevel,
				a.kdcab,
				b.kdarea,
				b.kdwil,
				a.pwd,
				a.flagpassword,
				b.wilayah,
				b.areacab,
				b.nmcab,
				a.flaginfo,
				a.kdpt,
				b.wilayah,
				b.areacab,
				b.nmcab,
				coalesce(c.ttlakses,0) as ttlakses ,
				coalesce(d.ttlakses,0) as ttlaksespusat,
				coalesce(d.userlevelpusat,0) as userlevelpusat,
				a.mnubrm,
				a.mnupusat,
				a.mnumfin,
				a.mnumec,
				a.mnugriya,
				a.mnumikro,
				a.mnumobil,
				a.mnuaudit,
				a.mnumts,
				coalesce(b.kdlokasi,'00') as kdlokasimts,
				a.flagaproved,
				d.flagdir,
				a.mnubudget,
				a.mnubod,
				a.mnumaster,
				a.mnumkt,
				a.mnucomp,
				a.nik
			FROM 
				user_akses a 
				LEFT JOIN raw_area b ON a.kdcab=b.kdcab 
				LEFT JOIN (SELECT iduser,COUNT(1) AS ttlakses FROM user_aksesdetil WHERE iduser = '$noabsen' GROUP BY iduser) c ON a.iduser=c.iduser
				LEFT JOIN (SELECT iduserpusat,userlevelpusat,flagdir,COUNT(1) AS ttlakses FROM user_aksesdetilpusat WHERE iduserpusat='$noabsen' GROUP BY iduserpusat,userlevelpusat,flagdir) d ON a.iduser=d.iduserpusat	
			WHERE 
				a.iduser = '$noabsen' 
				AND a.pwd = '$pass' 
				AND a.flagaktif = 1;";

		$result = $this->db->query($query);

		if($result->num_rows() > 0) {
			$user = $result->row_array();
			$userdata = array(
				"iduser" => $user['iduser'],
				"nmuser" => $user['nmuser'],
				"userlevel" => $user['userlevel'],
				"nik" => $user['nik'],
			);
			$this->session->set_userdata($userdata);

			$message = array(true);

		} else {

			$message = array(false);

		}

		echo json_encode($message);
	}

	public function logout() {
		session_destroy();

		redirect('login');
	}

	public function validate() {

		$iduser = $this->input->post('noabsen');
		$password = $this->input->post('password');
		$pengacak = "P@ssw0rdM4r5";
		$pass = md5($pengacak.md5($password).$pengacak) ;
		$pengacakToken = "M4n1f3st";
		$tanggal = date("Y-m-d");
		$token = md5($pengacakToken.md5($iduser.$pass.$tanggal).$pengacakToken);

		$ip = "";
		if(!empty($_SERVER['HTTP_CLIENT_IP'])){
	      $ip=$_SERVER['HTTP_CLIENT_IP'];
	    }
	    elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
	      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	    }
	    else{
	      $ip=$_SERVER['REMOTE_ADDR'];
	    }
		$browser = $this->Global_model->getBrowser();

		$data = array(
			
			"iduser"=>$iduser,
			"pwd"=>$pass,
			"token"=> $token,
			"key"=> "4a987c6ad6d499bd499e407bb3655965",
			"compname"=>gethostbyaddr($_SERVER['REMOTE_ADDR']),
			"ipaddress"=> $ip,
			"browser"=> $browser['name'],
			"sourcelogin"=>"0"
			
		);

		$login = $this->Global_model->sendApi("POST","http://192.168.77.112:8081/login/auth",$data);

		if($login->status == '200') {
			$data = $login->data[0];
			$userdata = array(
				"iduser" => $data->iduser,
				"nmuser" => $data->nmuser,
				"userlevel" => $data->userlevel,
				"nik" => $data->nik,
				"kdpt" => $data->kdpt,
				"telp" => $data->telp,
			);
			$this->session->set_userdata($userdata);

			$message = array("status"=>true,"message"=>$login->message,"code"=>$login->status);

		} else {

			$message = array("status"=>false,"message"=>$login->message,"code"=>$login->status);

		}

		echo json_encode($message);


	}


}
