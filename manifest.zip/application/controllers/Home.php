<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public $data;
	public function __construct()
	{
		parent::__construct();
	}

	public function index() {
		if(empty($this->session->userdata('iduser'))){
			redirect('login');
		} else {
			$iduser = $this->session->userdata('iduser');

			$data["head"] = array();
			$data["sub"] = array();

			$query = "SELECT a.nodeid,b.parentid,b.name,b.type,b.url,b.icon FROM trx_user_menu a LEFT JOIN manifest_menu b ON a.nodeid = b.nodeid WHERE a.iduser = '$iduser';";

			$result = $this->db->query($query)->result_array();

			$data['list_menu'] = $result;

			$this->_render_page('/template/default',$data);
		}
	}

	public function _render_page($view, $data=null, $returnhtml=false) {
		$this->viewdata = (empty($data)) ? $this->data: $data;

		$view_html = $this->load->view($view, $this->viewdata, $returnhtml);

		if ($returnhtml) return $view_html;
	}

	public function session_check() {
		$session = @$this->session->userdata('iduser');
		if(empty($session)){
			session_destroy();
			header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
			header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
			header("Cache-Control: post-check=0, pre-check=0", false);
			header("Pragma: no-cache");
			$message = array(true);
		} else {
			$message = array(false);
		}
		echo json_encode($message);
	}

	public function clear_session() {
		session_destroy();
		header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");

		$message = array(true);
		echo json_encode($message);
	}

	public function homePage() {
		$this->load->view('template/home');
	}

}
