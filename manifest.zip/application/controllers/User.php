<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('auth/login');
	}

	public function daftar()
	{
		$this->load->view('auth/daftar');
	}

	public function lupapassword()
	{
		$this->load->view('auth/lupapassword');
	}


}
