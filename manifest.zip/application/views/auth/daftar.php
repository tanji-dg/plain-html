<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mandala Financial System</title>

    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/png/manifest-logo-only.png" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/themes/lite-blue.min.css" rel="stylesheet">
</head>
<div class="auth-layout-wrap" style="background-color: #1F1B24;">
    <div class="auth-content">
        <div class="card o-hidden">
            <div class="row">
                
                <div class="col-md-6 text-center" >
                    <div class="auth-right" style="padding:0px 15px !important;">
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/png/manifest-logo.png" alt="" style="width:100%; height:100%;"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-4">
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/mandala-only.jpeg" alt="" style="width:25%; height:25%;"></div>
                        <br>
                        <h1 class="mb-3 text-18 text-center">Pendaftaran</h1>
                        <form action="">
                            <div class="form-group">
                                <label for="username">No Absen</label>
                                <input class="form-control form-control-rounded" id="noabsen" type="text">
                            </div>
                            <div class="form-group">
                                <label for="username">Nama Lengkap</label>
                                <input class="form-control form-control-rounded" id="nama" type="text">
                            </div>
                            <div class="form-group">
                                <label for="email">Email address</label>
                                <input class="form-control form-control-rounded" id="email" type="email">
                            </div>
                            <div class="form-group">
                                <label for="password">Kode Cabang</label>
                                <input class="form-control form-control-rounded" id="kdcab" type="text">
                            </div>
                            <div class="form-group">
                                <label for="repassword">Jabatan</label>
                                <select class="form-control form-control-rounded" id="jabatan">
                                    <option value="">Silahkan pilih jabatan anda</option>
                                    <option value="1">PUSAT</option>
                                    <option value="2">REGIONAL</option>
                                    <option value="3">PINCAB</option>
                                    <option value="4">HEAD SALES</option>
                                    <option value="5">KORWIL</option>
                                    <option value="6">KMAX</option>
                                    <option value="7">CRS</option>
                                </select>
                            </div>
                            <button class="btn btn-primary btn-block btn-rounded mt-3">Sign Up</button>
                            <div class="mt-3 text-center"><a class="text-muted" href="<?php echo base_url();?>auth">
                                <u>Batal</u></a></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>