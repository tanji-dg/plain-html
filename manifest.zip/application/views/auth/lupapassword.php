<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mandala Financial System</title>

    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/png/manifest-logo-only.png" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/themes/lite-blue.min.css" rel="stylesheet">
</head>
<div class="auth-layout-wrap" style="background-color: #1F1B24;">
    <div class="auth-content">
        <div class="card o-hidden">
            <div class="row">
                <div class="col-md-6 text-center" >
                    <div class="auth-right" style="padding:0px 15px !important;">
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/png/manifest-logo.png" alt="" style="width:100%; height:100%;"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-4">
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/mandala-only.jpeg" alt="" style="width:25%; height:25%;"></div>
                        <br>
                        <h1 class="mb-3 text-18 text-center">Lupa Password</h1>
                        <form action="">
                            <div class="form-group">
                                <label for="email">No Absen</label>
                                <input class="form-control form-control-rounded" id="email" type="email">
                            </div>
                            <button class="btn btn-primary btn-block btn-rounded mt-3">Reset Password</button>
                        </form>
                        <div class="mt-3 text-center"><a class="text-muted" href="<?php echo base_url();?>auth">
                                <u>Sign in</u></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>