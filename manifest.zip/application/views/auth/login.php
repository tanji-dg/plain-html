<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mandala Financial System</title>

    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/png/manifest-logo-only.png" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/themes/lite-blue.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/sweetalert2.min.css" />
</head>
<div class="auth-layout-wrap" style="background-color: #1F1B24;">
    <div class="auth-content">
        <div class="card o-hidden">
            <div class="row">
                <div class="col-md-6 text-center" >
                    <div class="auth-right" style="padding:0px 15px !important;">
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/png/manifest-logo.png" alt="" style="width:100%; height:100%;"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-4">
                        
                        <div class="auth-logo text-center"><img src="<?php echo base_url();?>assets/images/logo/mandala-only.jpeg" alt="" style="width:25%; height:25%;"></div>
                        <br>
                        <h1 class="mb-3 text-18 text-center">Sign In</h1>
                        <h1 class="mb-3 text-14 text-center">Belum punya akun? Silahkan <a class="text-muted" href="<?php echo base_url();?>daftar"><u>Daftar</u></a></h1>
                        <form id="sign_in_form">
                            <div class="form-group">
                                <label for="email">No Absen</label>
                                <input class="form-control form-control-rounded" id="noabsen" name="noabsen" type="text">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input class="form-control form-control-rounded" id="password" name="password" type="password">
                            </div>
                            <button id="sign_in_button" class="btn btn-rounded btn-primary btn-block mt-2">Sign In</button>
                        </form>
                        <div class="mt-3 text-center"><a class="text-muted" href="<?php echo base_url();?>lupapassword">
                                <u>Lupa Password?</u></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url();?>assets/js/plugins/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/sweetalert2.min.js"></script>
<script type="text/javascript">
      $(document).ready(function(){
        handleSignInFormSubmit();

      })

      var handleSignInFormSubmit = function() {
        $('#sign_in_button').click(function(e) {
            e.preventDefault();
            var btn = $(this);
            var form = $(this).closest('form');
            var noabsen = $('#noabsen').val();
            var password = $('#password').val();

            form.validate({
                rules: {
                    noabsen: {
                        required: true,
                    },
                    password: {
                        required: true
                    }
                },
                messages: {
                    noabsen: {
                        required: "No Absen tidak boleh kosong."
                    },
                    password: {
                        required: "Password tidak boleh kosong.",
                    }
        },
            });

            if (!form.valid()) {
                return;
            }

            
            swal({
              title: 'Loading...',
              text: '',
              showConfirmButton: false
            });
            swal.showLoading();

            btn.attr('disabled', true);

            $.ajax({
                url: '<?php echo base_url()?>validate',
                type: 'POST',
                data: {
                  noabsen : noabsen,
                  password : password
                },
                error: function (data) {
                    swal({
                      type: 'error',
                      title: 'Error!',
                      text: 'Something went wrong!',
                      confirmButtonText: 'Dismiss',
                      buttonsStyling: false,
                      confirmButtonClass: 'btn btn-lg btn-danger'
                    });
                    btn.attr('disabled', false);
                },
                success: function (data) {
                    btn.attr('disabled', false);
                    var obj = JSON.parse(data);
                    console.log(obj)
                    if (obj['status']) {
                        swal({
                          type: 'success',
                          title: 'Success!',
                          text: obj['message'],
                          timer: 2000,
                          showConfirmButton: false
                        }).catch(function(timeout){
                            window.location.replace('<?php echo base_url();?>');
                        });
                    } else {
                        swal({
                          type: 'error',
                          title: 'Error!',
                          text: obj['message'],
                          confirmButtonText: 'Dismiss',
                          buttonsStyling: false,
                          confirmButtonClass: 'btn btn-lg btn-danger'
                        });
                    }
                }
            });
        });
    }
    </script>