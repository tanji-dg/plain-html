<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsCollection')">Collection</a></li>
        </ul>
    </div>

    <div class="row">

    	<div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>

        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>

        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>

    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Collection (Relaksasi & Non Relaksasi)</h1>

    <div class="row">

    	<div class="col-lg-6 col-sm-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Komposisi Turun - Rp.</div>
                    <div id="echartPie1" style="height: 100%;min-height:200px;"></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-sm-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Komposisi Turun - Konsumen</div>
                    <div id="echartPie2" style="height: 100%;min-height:200px;"></div>
                </div>
            </div>
        </div>
    	
    </div>

   <div class="row">

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Collection - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Jenis</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Collection - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Jenis</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <div class="row">
   		<div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Collection Non Relaksasi</div>
                    <div id="echartBar1" style="height: 100%;min-height:250px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
   		<div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Collection Relaksasi</div>
                    <div id="echartBar2" style="height: 100%;min-height:250px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Collection Per Regional</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollRegRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollRegKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollCluRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollCluKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollCabRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollCabKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollCabParetoRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollCabParetoKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Collection Per Produk</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableCollProdukRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableCollProdukKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Turun</th>
                                    <th scope="col" style="text-align: right;">Tertagih</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Collection Vintage</h1>

    <div class="row">
    	<div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Collection Vintage</div>
                    <div class="table-responsive">
                        <table id="tableCollVin" class="table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col" colspan="12" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col">Periode Collection</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                    <th scope="col">202201</th>
                                </tr>
                                <tr>
                                    <th scope="col">Periode Booking</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
    	<div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Collection Vintage Per Produk</div>
                    <div class="table-responsive">
                        <table id="tableCollVinProduk" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" colspan="2"></th>
                                    <th scope="col" colspan="12" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col" colspan="2">Periode Collection</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                    <th scope="col">202201</th>
                                </tr>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col">Periode Booking</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">

    	<div class="col-lg-12 col-sm-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Collection - Cara Pembayaran</div>
                    <div id="echartPie3" style="height: 100%;min-height:600px;"></div>
                </div>
            </div>
        </div>

    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.");
        }
    }
}

function formatPersen(data){
    var num = data * 100;

    return num.toFixed(2);
}


$(document).ready(function () {
	$('#tableCollRp').DataTable({
        "data":[
		    {
		        "jenis": "1.NON RELAKSASI",
		        "TURUN": 509079420267,
		        "TERTAGIH": 432055285551,
		        "PERSEN": 84.87
		    },
		    {
		        "jenis": "2.RElAKSASI",
		        "TURUN": 75636747534,
		        "TERTAGIH": 41358032234,
		        "PERSEN": 54.68
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollKon').DataTable({
        "data":[
		    {
		        "jenis": "1.NON RELAKSASI",
		        "TURUN": 509079420267,
		        "TERTAGIH": 432055285551,
		        "PERSEN": 84.87
		    },
		    {
		        "jenis": "2.RElAKSASI",
		        "TURUN": 75636747534,
		        "TERTAGIH": 41358032234,
		        "PERSEN": 54.68
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollRegRp').DataTable({
        "data":[
		    {
		        "regional": "SUMATERA 5",
		        "TURUN": 17533716000,
		        "TERTAGIH": 16301990000,
		        "PERSEN": 92.98
		    },
		    {
		        "regional": "SULAWESI 2",
		        "TURUN": 49543663824,
		        "TERTAGIH": 44043572308,
		        "PERSEN": 88.9
		    },
		    {
		        "regional": "SULAWESI 4",
		        "TURUN": 29169050550,
		        "TERTAGIH": 25601569550,
		        "PERSEN": 87.77
		    },
		    {
		        "regional": "ACEH 1",
		        "TURUN": 23493513000,
		        "TERTAGIH": 19924069000,
		        "PERSEN": 84.81
		    },
		    {
		        "regional": "SULAWESI 3",
		        "TURUN": 57832793000,
		        "TERTAGIH": 48753620000,
		        "PERSEN": 84.3
		    },
		    {
		        "regional": "ACEH 2",
		        "TURUN": 14591091000,
		        "TERTAGIH": 12274521000,
		        "PERSEN": 84.12
		    },
		    {
		        "regional": "MAPA",
		        "TURUN": 20361777500,
		        "TERTAGIH": 17041203500,
		        "PERSEN": 83.69
		    },
		    {
		        "regional": "SULAWESI 1",
		        "TURUN": 70179094992,
		        "TERTAGIH": 58640360992,
		        "PERSEN": 83.56
		    },
		    {
		        "regional": "KALIMANTAN 2",
		        "TURUN": 18753413000,
		        "TERTAGIH": 15555323000,
		        "PERSEN": 82.95
		    },
		    {
		        "regional": "NUSA TENGGARA",
		        "TURUN": 5125441000,
		        "TERTAGIH": 4190383000,
		        "PERSEN": 81.76
		    },
		    {
		        "regional": "SUMATERA 3",
		        "TURUN": 21625337500,
		        "TERTAGIH": 17448574500,
		        "PERSEN": 80.69
		    },
		    {
		        "regional": "JAWA BARAT 1",
		        "TURUN": 22847168000,
		        "TERTAGIH": 18432695500,
		        "PERSEN": 80.68
		    },
		    {
		        "regional": "JAWA BARAT 2",
		        "TURUN": 28496460500,
		        "TERTAGIH": 22758956000,
		        "PERSEN": 79.87
		    },
		    {
		        "regional": "SUMATERA 6",
		        "TURUN": 20973583000,
		        "TERTAGIH": 16614563000,
		        "PERSEN": 79.22
		    },
		    {
		        "regional": "KALIMANTAN 1",
		        "TURUN": 22728453500,
		        "TERTAGIH": 17630651500,
		        "PERSEN": 77.57
		    },
		    {
		        "regional": "SUMATERA 4",
		        "TURUN": 30913223000,
		        "TERTAGIH": 23820841000,
		        "PERSEN": 77.06
		    },
		    {
		        "regional": "JAWA BARAT 3",
		        "TURUN": 33295138635,
		        "TERTAGIH": 25419515135,
		        "PERSEN": 76.35
		    },
		    {
		        "regional": "SULAWESI 5",
		        "TURUN": 46856447900,
		        "TERTAGIH": 34117395900,
		        "PERSEN": 72.81
		    },
		    {
		        "regional": "SUMATERA 2",
		        "TURUN": 7941098500,
		        "TERTAGIH": 5742985500,
		        "PERSEN": 72.32
		    },
		    {
		        "regional": "JAWA TIMUR",
		        "TURUN": 13013252400,
		        "TERTAGIH": 9204518400,
		        "PERSEN": 70.73
		    },
		    {
		        "regional": "JAWA TENGAH",
		        "TURUN": 29442451000,
		        "TERTAGIH": 19896009000,
		        "PERSEN": 67.58
		    }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollRegKon').DataTable({
        "data":[
		    {
		        "regional": "SUMATERA 5",
		        "TURUN": 17533716000,
		        "TERTAGIH": 16301990000,
		        "PERSEN": 92.98
		    },
		    {
		        "regional": "SULAWESI 2",
		        "TURUN": 49543663824,
		        "TERTAGIH": 44043572308,
		        "PERSEN": 88.9
		    },
		    {
		        "regional": "SULAWESI 4",
		        "TURUN": 29169050550,
		        "TERTAGIH": 25601569550,
		        "PERSEN": 87.77
		    },
		    {
		        "regional": "ACEH 1",
		        "TURUN": 23493513000,
		        "TERTAGIH": 19924069000,
		        "PERSEN": 84.81
		    },
		    {
		        "regional": "SULAWESI 3",
		        "TURUN": 57832793000,
		        "TERTAGIH": 48753620000,
		        "PERSEN": 84.3
		    },
		    {
		        "regional": "ACEH 2",
		        "TURUN": 14591091000,
		        "TERTAGIH": 12274521000,
		        "PERSEN": 84.12
		    },
		    {
		        "regional": "MAPA",
		        "TURUN": 20361777500,
		        "TERTAGIH": 17041203500,
		        "PERSEN": 83.69
		    },
		    {
		        "regional": "SULAWESI 1",
		        "TURUN": 70179094992,
		        "TERTAGIH": 58640360992,
		        "PERSEN": 83.56
		    },
		    {
		        "regional": "KALIMANTAN 2",
		        "TURUN": 18753413000,
		        "TERTAGIH": 15555323000,
		        "PERSEN": 82.95
		    },
		    {
		        "regional": "NUSA TENGGARA",
		        "TURUN": 5125441000,
		        "TERTAGIH": 4190383000,
		        "PERSEN": 81.76
		    },
		    {
		        "regional": "SUMATERA 3",
		        "TURUN": 21625337500,
		        "TERTAGIH": 17448574500,
		        "PERSEN": 80.69
		    },
		    {
		        "regional": "JAWA BARAT 1",
		        "TURUN": 22847168000,
		        "TERTAGIH": 18432695500,
		        "PERSEN": 80.68
		    },
		    {
		        "regional": "JAWA BARAT 2",
		        "TURUN": 28496460500,
		        "TERTAGIH": 22758956000,
		        "PERSEN": 79.87
		    },
		    {
		        "regional": "SUMATERA 6",
		        "TURUN": 20973583000,
		        "TERTAGIH": 16614563000,
		        "PERSEN": 79.22
		    },
		    {
		        "regional": "KALIMANTAN 1",
		        "TURUN": 22728453500,
		        "TERTAGIH": 17630651500,
		        "PERSEN": 77.57
		    },
		    {
		        "regional": "SUMATERA 4",
		        "TURUN": 30913223000,
		        "TERTAGIH": 23820841000,
		        "PERSEN": 77.06
		    },
		    {
		        "regional": "JAWA BARAT 3",
		        "TURUN": 33295138635,
		        "TERTAGIH": 25419515135,
		        "PERSEN": 76.35
		    },
		    {
		        "regional": "SULAWESI 5",
		        "TURUN": 46856447900,
		        "TERTAGIH": 34117395900,
		        "PERSEN": 72.81
		    },
		    {
		        "regional": "SUMATERA 2",
		        "TURUN": 7941098500,
		        "TERTAGIH": 5742985500,
		        "PERSEN": 72.32
		    },
		    {
		        "regional": "JAWA TIMUR",
		        "TURUN": 13013252400,
		        "TERTAGIH": 9204518400,
		        "PERSEN": 70.73
		    },
		    {
		        "regional": "JAWA TENGAH",
		        "TURUN": 29442451000,
		        "TERTAGIH": 19896009000,
		        "PERSEN": 67.58
		    }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollCluRp').DataTable({
        "data":[
		    {
		        "nmcluster": "BUTON",
		        "TURUN": 7378524000,
		        "TERTAGIH": 6917480000,
		        "PERSEN": 93.75
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TURUN": 9747004500,
		        "TERTAGIH": 8727274000,
		        "PERSEN": 89.54
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TURUN": 5525568000,
		        "TERTAGIH": 4912202000,
		        "PERSEN": 88.9
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TURUN": 5690998000,
		        "TERTAGIH": 5048951000,
		        "PERSEN": 88.72
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TURUN": 3324083000,
		        "TERTAGIH": 2939069000,
		        "PERSEN": 88.42
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TURUN": 10413565000,
		        "TERTAGIH": 9082336000,
		        "PERSEN": 87.22
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TURUN": 15390634500,
		        "TERTAGIH": 13300600000,
		        "PERSEN": 86.42
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TURUN": 21790526550,
		        "TERTAGIH": 18684089550,
		        "PERSEN": 85.74
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TURUN": 6868343000,
		        "TERTAGIH": 5860893000,
		        "PERSEN": 85.33
		    },
		    {
		        "nmcluster": "AMBON",
		        "TURUN": 16276609500,
		        "TERTAGIH": 13818424500,
		        "PERSEN": 84.9
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TURUN": 4909757000,
		        "TERTAGIH": 4152810000,
		        "PERSEN": 84.58
		    },
		    {
		        "nmcluster": "SOLO",
		        "TURUN": 6129218000,
		        "TERTAGIH": 5161243500,
		        "PERSEN": 84.21
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TURUN": 5257606000,
		        "TERTAGIH": 4401390000,
		        "PERSEN": 83.71
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TURUN": 37474347889,
		        "TERTAGIH": 31029948889,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TURUN": 9275902000,
		        "TERTAGIH": 7675531000,
		        "PERSEN": 82.75
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TURUN": 5125441000,
		        "TERTAGIH": 4190383000,
		        "PERSEN": 81.76
		    },
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TURUN": 9446734500,
		        "TERTAGIH": 7660487000,
		        "PERSEN": 81.09
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TURUN": 2323635500,
		        "TERTAGIH": 1859657000,
		        "PERSEN": 80.03
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TURUN": 11941654500,
		        "TERTAGIH": 9516329000,
		        "PERSEN": 79.69
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TURUN": 9435769000,
		        "TERTAGIH": 7508726000,
		        "PERSEN": 79.58
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TURUN": 10367371000,
		        "TERTAGIH": 8190349000,
		        "PERSEN": 79
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TURUN": 9613957000,
		        "TERTAGIH": 7589743000,
		        "PERSEN": 78.95
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TURUN": 4085168000,
		        "TERTAGIH": 3222779000,
		        "PERSEN": 78.89
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TURUN": 2828251000,
		        "TERTAGIH": 2225414000,
		        "PERSEN": 78.69
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TURUN": 8847429000,
		        "TERTAGIH": 6950661000,
		        "PERSEN": 78.56
		    },
		    {
		        "nmcluster": "JOGYA",
		        "TURUN": 4167007000,
		        "TERTAGIH": 3199726000,
		        "PERSEN": 76.79
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TURUN": 24635581631,
		        "TERTAGIH": 18832541131,
		        "PERSEN": 76.44
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TURUN": 10066542000,
		        "TERTAGIH": 7676013000,
		        "PERSEN": 76.25
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TURUN": 8659557004,
		        "TERTAGIH": 6586974004,
		        "PERSEN": 76.07
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TURUN": 3815596400,
		        "TERTAGIH": 2865248900,
		        "PERSEN": 75.09
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TURUN": 5216043000,
		        "TERTAGIH": 3889599000,
		        "PERSEN": 74.57
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TURUN": 13100163500,
		        "TERTAGIH": 9705421500,
		        "PERSEN": 74.09
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TURUN": 3673589500,
		        "TERTAGIH": 2696979500,
		        "PERSEN": 73.42
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TURUN": 9840652000,
		        "TERTAGIH": 7113614000,
		        "PERSEN": 72.29
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TURUN": 3113868000,
		        "TERTAGIH": 2207507000,
		        "PERSEN": 70.89
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TURUN": 8521285500,
		        "TERTAGIH": 5435859500,
		        "PERSEN": 63.79
		    },
		    {
		        "nmcluster": "MANADO",
		        "TURUN": 19524158900,
		        "TERTAGIH": 11300466900,
		        "PERSEN": 57.88
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TURUN": 10624940500,
		        "TERTAGIH": 6099180000,
		        "PERSEN": 57.4
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TURUN": 3200431000,
		        "TERTAGIH": 1782633000,
		        "PERSEN": 55.7
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableCollCluKon').DataTable({
        "data":[
		    {
		        "nmcluster": "BUTON",
		        "TURUN": 7378524000,
		        "TERTAGIH": 6917480000,
		        "PERSEN": 93.75
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TURUN": 9747004500,
		        "TERTAGIH": 8727274000,
		        "PERSEN": 89.54
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TURUN": 5525568000,
		        "TERTAGIH": 4912202000,
		        "PERSEN": 88.9
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TURUN": 5690998000,
		        "TERTAGIH": 5048951000,
		        "PERSEN": 88.72
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TURUN": 3324083000,
		        "TERTAGIH": 2939069000,
		        "PERSEN": 88.42
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TURUN": 10413565000,
		        "TERTAGIH": 9082336000,
		        "PERSEN": 87.22
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TURUN": 15390634500,
		        "TERTAGIH": 13300600000,
		        "PERSEN": 86.42
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TURUN": 21790526550,
		        "TERTAGIH": 18684089550,
		        "PERSEN": 85.74
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TURUN": 6868343000,
		        "TERTAGIH": 5860893000,
		        "PERSEN": 85.33
		    },
		    {
		        "nmcluster": "AMBON",
		        "TURUN": 16276609500,
		        "TERTAGIH": 13818424500,
		        "PERSEN": 84.9
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TURUN": 4909757000,
		        "TERTAGIH": 4152810000,
		        "PERSEN": 84.58
		    },
		    {
		        "nmcluster": "SOLO",
		        "TURUN": 6129218000,
		        "TERTAGIH": 5161243500,
		        "PERSEN": 84.21
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TURUN": 5257606000,
		        "TERTAGIH": 4401390000,
		        "PERSEN": 83.71
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TURUN": 37474347889,
		        "TERTAGIH": 31029948889,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TURUN": 9275902000,
		        "TERTAGIH": 7675531000,
		        "PERSEN": 82.75
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TURUN": 5125441000,
		        "TERTAGIH": 4190383000,
		        "PERSEN": 81.76
		    },
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TURUN": 9446734500,
		        "TERTAGIH": 7660487000,
		        "PERSEN": 81.09
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TURUN": 2323635500,
		        "TERTAGIH": 1859657000,
		        "PERSEN": 80.03
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TURUN": 11941654500,
		        "TERTAGIH": 9516329000,
		        "PERSEN": 79.69
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TURUN": 9435769000,
		        "TERTAGIH": 7508726000,
		        "PERSEN": 79.58
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TURUN": 10367371000,
		        "TERTAGIH": 8190349000,
		        "PERSEN": 79
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TURUN": 9613957000,
		        "TERTAGIH": 7589743000,
		        "PERSEN": 78.95
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TURUN": 4085168000,
		        "TERTAGIH": 3222779000,
		        "PERSEN": 78.89
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TURUN": 2828251000,
		        "TERTAGIH": 2225414000,
		        "PERSEN": 78.69
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TURUN": 8847429000,
		        "TERTAGIH": 6950661000,
		        "PERSEN": 78.56
		    },
		    {
		        "nmcluster": "JOGYA",
		        "TURUN": 4167007000,
		        "TERTAGIH": 3199726000,
		        "PERSEN": 76.79
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TURUN": 24635581631,
		        "TERTAGIH": 18832541131,
		        "PERSEN": 76.44
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TURUN": 10066542000,
		        "TERTAGIH": 7676013000,
		        "PERSEN": 76.25
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TURUN": 8659557004,
		        "TERTAGIH": 6586974004,
		        "PERSEN": 76.07
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TURUN": 3815596400,
		        "TERTAGIH": 2865248900,
		        "PERSEN": 75.09
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TURUN": 5216043000,
		        "TERTAGIH": 3889599000,
		        "PERSEN": 74.57
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TURUN": 13100163500,
		        "TERTAGIH": 9705421500,
		        "PERSEN": 74.09
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TURUN": 3673589500,
		        "TERTAGIH": 2696979500,
		        "PERSEN": 73.42
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TURUN": 9840652000,
		        "TERTAGIH": 7113614000,
		        "PERSEN": 72.29
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TURUN": 3113868000,
		        "TERTAGIH": 2207507000,
		        "PERSEN": 70.89
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TURUN": 8521285500,
		        "TERTAGIH": 5435859500,
		        "PERSEN": 63.79
		    },
		    {
		        "nmcluster": "MANADO",
		        "TURUN": 19524158900,
		        "TERTAGIH": 11300466900,
		        "PERSEN": 57.88
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TURUN": 10624940500,
		        "TERTAGIH": 6099180000,
		        "PERSEN": 57.4
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TURUN": 3200431000,
		        "TERTAGIH": 1782633000,
		        "PERSEN": 55.7
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableCollCabRp').DataTable({
        "data":[
		    {
		        "cabang": "DOMPU",
		        "TURUN": 581065000,
		        "TERTAGIH": 569631000,
		        "PERSEN": 98.03
		    },
		    {
		        "cabang": "KELAPA",
		        "TURUN": 1092745500,
		        "TERTAGIH": 1062039500,
		        "PERSEN": 97.19
		    },
		    {
		        "cabang": "TOBOALI",
		        "TURUN": 1329139000,
		        "TERTAGIH": 1285998000,
		        "PERSEN": 96.75
		    },
		    {
		        "cabang": "PANGKALANBUN",
		        "TURUN": 483281000,
		        "TERTAGIH": 464005000,
		        "PERSEN": 96.01
		    },
		    {
		        "cabang": "KOBA",
		        "TURUN": 1217045500,
		        "TERTAGIH": 1167271500,
		        "PERSEN": 95.91
		    },
		    {
		        "cabang": "EREKE",
		        "TURUN": 1038747000,
		        "TERTAGIH": 990396000,
		        "PERSEN": 95.35
		    },
		    {
		        "cabang": "MAKALE",
		        "TURUN": 2394569500,
		        "TERTAGIH": 2281426500,
		        "PERSEN": 95.28
		    },
		    {
		        "cabang": "UJUNG GADING",
		        "TURUN": 1816523500,
		        "TERTAGIH": 1728459500,
		        "PERSEN": 95.15
		    },
		    {
		        "cabang": "TUNGKAL",
		        "TURUN": 374953000,
		        "TERTAGIH": 356273000,
		        "PERSEN": 95.02
		    },
		    {
		        "cabang": "CIAWI",
		        "TURUN": 1231025500,
		        "TERTAGIH": 1168441500,
		        "PERSEN": 94.92
		    },
		    {
		        "cabang": "BELINYU",
		        "TURUN": 1591779000,
		        "TERTAGIH": 1509890000,
		        "PERSEN": 94.86
		    },
		    {
		        "cabang": "TOPPOYO",
		        "TURUN": 2716667000,
		        "TERTAGIH": 2569975000,
		        "PERSEN": 94.6
		    },
		    {
		        "cabang": "BUTON",
		        "TURUN": 4142300000,
		        "TERTAGIH": 3916074000,
		        "PERSEN": 94.54
		    },
		    {
		        "cabang": "BERAU",
		        "TURUN": 3233797500,
		        "TERTAGIH": 3051961500,
		        "PERSEN": 94.38
		    },
		    {
		        "cabang": "SALAKAN",
		        "TURUN": 3443572000,
		        "TERTAGIH": 3249029000,
		        "PERSEN": 94.35
		    },
		    {
		        "cabang": "PASANGKAYU",
		        "TURUN": 2598152000,
		        "TERTAGIH": 2448385000,
		        "PERSEN": 94.24
		    },
		    {
		        "cabang": "LANGSA ACEH",
		        "TURUN": 1019432000,
		        "TERTAGIH": 959077000,
		        "PERSEN": 94.08
		    },
		    {
		        "cabang": "SOPPENG",
		        "TURUN": 1672983000,
		        "TERTAGIH": 1573838000,
		        "PERSEN": 94.07
		    },
		    {
		        "cabang": "BELITUNG",
		        "TURUN": 2654395500,
		        "TERTAGIH": 2495795500,
		        "PERSEN": 94.03
		    },
		    {
		        "cabang": "PARUNG",
		        "TURUN": 1454464500,
		        "TERTAGIH": 1361553500,
		        "PERSEN": 93.61
		    },
		    {
		        "cabang": "ULEE GLEE",
		        "TURUN": 804644000,
		        "TERTAGIH": 753212000,
		        "PERSEN": 93.61
		    },
		    {
		        "cabang": "SUNGAI LIAT",
		        "TURUN": 1270905000,
		        "TERTAGIH": 1189086000,
		        "PERSEN": 93.56
		    },
		    {
		        "cabang": "MASAMBA",
		        "TURUN": 2854600000,
		        "TERTAGIH": 2668265000,
		        "PERSEN": 93.47
		    },
		    {
		        "cabang": "SIMPANG PEMATANG",
		        "TURUN": 735645000,
		        "TERTAGIH": 686872000,
		        "PERSEN": 93.37
		    },
		    {
		        "cabang": "BANGKALA",
		        "TURUN": 2204788000,
		        "TERTAGIH": 2057355000,
		        "PERSEN": 93.31
		    },
		    {
		        "cabang": "IDIE",
		        "TURUN": 3679869000,
		        "TERTAGIH": 3426973000,
		        "PERSEN": 93.13
		    },
		    {
		        "cabang": "LASUSUA",
		        "TURUN": 692620000,
		        "TERTAGIH": 644548000,
		        "PERSEN": 93.06
		    },
		    {
		        "cabang": "DONGGALA",
		        "TURUN": 2270829500,
		        "TERTAGIH": 2112180500,
		        "PERSEN": 93.01
		    },
		    {
		        "cabang": "RAWAJITU",
		        "TURUN": 1082056000,
		        "TERTAGIH": 1002617000,
		        "PERSEN": 92.66
		    },
		    {
		        "cabang": "PALANGKARAYA",
		        "TURUN": 2043243000,
		        "TERTAGIH": 1891876000,
		        "PERSEN": 92.59
		    },
		    {
		        "cabang": "BATU SANGKAR",
		        "TURUN": 1257502000,
		        "TERTAGIH": 1160650000,
		        "PERSEN": 92.3
		    },
		    {
		        "cabang": "LEUWILIANG",
		        "TURUN": 2537148500,
		        "TERTAGIH": 2340528000,
		        "PERSEN": 92.25
		    },
		    {
		        "cabang": "BARRU",
		        "TURUN": 1604521500,
		        "TERTAGIH": 1479479500,
		        "PERSEN": 92.21
		    },
		    {
		        "cabang": "SUNGAI LILIN",
		        "TURUN": 2427487000,
		        "TERTAGIH": 2236482000,
		        "PERSEN": 92.13
		    },
		    {
		        "cabang": "MANGKUTANA",
		        "TURUN": 2452822000,
		        "TERTAGIH": 2259583000,
		        "PERSEN": 92.12
		    },
		    {
		        "cabang": "BOEPINANG",
		        "TURUN": 1538005000,
		        "TERTAGIH": 1416299000,
		        "PERSEN": 92.09
		    },
		    {
		        "cabang": "LHOKSUKON",
		        "TURUN": 998775000,
		        "TERTAGIH": 919489000,
		        "PERSEN": 92.06
		    },
		    {
		        "cabang": "JEBUS",
		        "TURUN": 918804000,
		        "TERTAGIH": 843258000,
		        "PERSEN": 91.78
		    },
		    {
		        "cabang": "SABAK",
		        "TURUN": 779836000,
		        "TERTAGIH": 714964000,
		        "PERSEN": 91.68
		    },
		    {
		        "cabang": "BUNTA",
		        "TURUN": 2005620000,
		        "TERTAGIH": 1837708000,
		        "PERSEN": 91.63
		    },
		    {
		        "cabang": "BIREUEN",
		        "TURUN": 2568512000,
		        "TERTAGIH": 2353081000,
		        "PERSEN": 91.61
		    },
		    {
		        "cabang": "RAHA",
		        "TURUN": 2197477000,
		        "TERTAGIH": 2011010000,
		        "PERSEN": 91.51
		    },
		    {
		        "cabang": "JAILOLO",
		        "TURUN": 4295497500,
		        "TERTAGIH": 3928189500,
		        "PERSEN": 91.45
		    },
		    {
		        "cabang": "TENGGARONG",
		        "TURUN": 1603573000,
		        "TERTAGIH": 1464233000,
		        "PERSEN": 91.31
		    },
		    {
		        "cabang": "TULANG BAWANG",
		        "TURUN": 940382000,
		        "TERTAGIH": 858481000,
		        "PERSEN": 91.29
		    },
		    {
		        "cabang": "BELOPA",
		        "TURUN": 2738986024,
		        "TERTAGIH": 2498574008,
		        "PERSEN": 91.22
		    },
		    {
		        "cabang": "TORAJA",
		        "TURUN": 3563607800,
		        "TERTAGIH": 3250280800,
		        "PERSEN": 91.21
		    },
		    {
		        "cabang": "BOYOLALI",
		        "TURUN": 1054224000,
		        "TERTAGIH": 961579000,
		        "PERSEN": 91.21
		    },
		    {
		        "cabang": "BOGOR",
		        "TURUN": 2386113500,
		        "TERTAGIH": 2174905500,
		        "PERSEN": 91.15
		    },
		    {
		        "cabang": "PANGKEP",
		        "TURUN": 2354870000,
		        "TERTAGIH": 2145203000,
		        "PERSEN": 91.1
		    },
		    {
		        "cabang": "KOLAKA",
		        "TURUN": 4098258000,
		        "TERTAGIH": 3729409000,
		        "PERSEN": 91
		    },
		    {
		        "cabang": "SENGKANG",
		        "TURUN": 2914759000,
		        "TERTAGIH": 2642436000,
		        "PERSEN": 90.66
		    },
		    {
		        "cabang": "MENTOK",
		        "TURUN": 1295564000,
		        "TERTAGIH": 1173367000,
		        "PERSEN": 90.57
		    },
		    {
		        "cabang": "TOBELO",
		        "TURUN": 1688376000,
		        "TERTAGIH": 1529048000,
		        "PERSEN": 90.56
		    },
		    {
		        "cabang": "BELTIM",
		        "TURUN": 1667771500,
		        "TERTAGIH": 1510100000,
		        "PERSEN": 90.55
		    },
		    {
		        "cabang": "TENTENA",
		        "TURUN": 2018810000,
		        "TERTAGIH": 1827847000,
		        "PERSEN": 90.54
		    },
		    {
		        "cabang": "SIJUNGJUNG",
		        "TURUN": 1422765000,
		        "TERTAGIH": 1287350000,
		        "PERSEN": 90.48
		    },
		    {
		        "cabang": "LABUAN BAJO",
		        "TURUN": 716786000,
		        "TERTAGIH": 648246000,
		        "PERSEN": 90.44
		    },
		    {
		        "cabang": "BANGKA",
		        "TURUN": 4495567000,
		        "TERTAGIH": 4065184500,
		        "PERSEN": 90.43
		    },
		    {
		        "cabang": "TANGGEUNG",
		        "TURUN": 1278126500,
		        "TERTAGIH": 1155550500,
		        "PERSEN": 90.41
		    },
		    {
		        "cabang": "TOILI",
		        "TURUN": 2495973000,
		        "TERTAGIH": 2256037000,
		        "PERSEN": 90.39
		    },
		    {
		        "cabang": "BUKITTINGGI",
		        "TURUN": 1174762000,
		        "TERTAGIH": 1061619000,
		        "PERSEN": 90.37
		    },
		    {
		        "cabang": "ALUE BILIE",
		        "TURUN": 1067158000,
		        "TERTAGIH": 963722000,
		        "PERSEN": 90.31
		    },
		    {
		        "cabang": "BAYUNG LENCIR",
		        "TURUN": 2795327000,
		        "TERTAGIH": 2522942000,
		        "PERSEN": 90.26
		    },
		    {
		        "cabang": "NAMLEA",
		        "TURUN": 2500071500,
		        "TERTAGIH": 2256359500,
		        "PERSEN": 90.25
		    },
		    {
		        "cabang": "TERNATE",
		        "TURUN": 4200588000,
		        "TERTAGIH": 3790507000,
		        "PERSEN": 90.24
		    },
		    {
		        "cabang": "AMBON",
		        "TURUN": 5851645000,
		        "TERTAGIH": 5278846000,
		        "PERSEN": 90.21
		    },
		    {
		        "cabang": "PALOPO",
		        "TURUN": 4774370500,
		        "TERTAGIH": 4304163500,
		        "PERSEN": 90.15
		    },
		    {
		        "cabang": "MOROWALI",
		        "TURUN": 3859307000,
		        "TERTAGIH": 3478095000,
		        "PERSEN": 90.12
		    },
		    {
		        "cabang": "DAYA MURNI",
		        "TURUN": 565167000,
		        "TERTAGIH": 509349000,
		        "PERSEN": 90.12
		    },
		    {
		        "cabang": "TOLI TOLI",
		        "TURUN": 1669420000,
		        "TERTAGIH": 1504104000,
		        "PERSEN": 90.1
		    },
		    {
		        "cabang": "KARANGANYAR",
		        "TURUN": 1196554000,
		        "TERTAGIH": 1077797000,
		        "PERSEN": 90.08
		    },
		    {
		        "cabang": "SANGATTA",
		        "TURUN": 2656219000,
		        "TERTAGIH": 2388655000,
		        "PERSEN": 89.93
		    },
		    {
		        "cabang": "BULUKUMBA",
		        "TURUN": 4118308003,
		        "TERTAGIH": 3679692003,
		        "PERSEN": 89.35
		    },
		    {
		        "cabang": "MALILI",
		        "TURUN": 2620465000,
		        "TERTAGIH": 2340850000,
		        "PERSEN": 89.33
		    },
		    {
		        "cabang": "WONOGIRI",
		        "TURUN": 1247419000,
		        "TERTAGIH": 1114272000,
		        "PERSEN": 89.33
		    },
		    {
		        "cabang": "SIGLI",
		        "TURUN": 1411096000,
		        "TERTAGIH": 1255614000,
		        "PERSEN": 88.98
		    },
		    {
		        "cabang": "MALINO",
		        "TURUN": 1020883000,
		        "TERTAGIH": 908322000,
		        "PERSEN": 88.97
		    },
		    {
		        "cabang": "TANAH GROGOT",
		        "TURUN": 1422867500,
		        "TERTAGIH": 1264813500,
		        "PERSEN": 88.89
		    },
		    {
		        "cabang": "KAPUAS",
		        "TURUN": 360255000,
		        "TERTAGIH": 319787000,
		        "PERSEN": 88.77
		    },
		    {
		        "cabang": "CIREBON",
		        "TURUN": 1612944500,
		        "TERTAGIH": 1431286500,
		        "PERSEN": 88.74
		    },
		    {
		        "cabang": "GOWA 2",
		        "TURUN": 4919381000,
		        "TERTAGIH": 4357677000,
		        "PERSEN": 88.58
		    },
		    {
		        "cabang": "MUARA ENIM",
		        "TURUN": 1480168000,
		        "TERTAGIH": 1305007000,
		        "PERSEN": 88.17
		    },
		    {
		        "cabang": "MOLIBAGU",
		        "TURUN": 668037000,
		        "TERTAGIH": 588712000,
		        "PERSEN": 88.13
		    },
		    {
		        "cabang": "BANJAR",
		        "TURUN": 1337628500,
		        "TERTAGIH": 1177562500,
		        "PERSEN": 88.03
		    },
		    {
		        "cabang": "RUTENG",
		        "TURUN": 836440000,
		        "TERTAGIH": 735947000,
		        "PERSEN": 87.99
		    },
		    {
		        "cabang": "BELITANG",
		        "TURUN": 595250000,
		        "TERTAGIH": 522700000,
		        "PERSEN": 87.81
		    },
		    {
		        "cabang": "ACEH",
		        "TURUN": 3309828000,
		        "TERTAGIH": 2903376000,
		        "PERSEN": 87.72
		    },
		    {
		        "cabang": "MARTAPURA KAL",
		        "TURUN": 2113932000,
		        "TERTAGIH": 1854043000,
		        "PERSEN": 87.71
		    },
		    {
		        "cabang": "PASAMAN",
		        "TURUN": 868106000,
		        "TERTAGIH": 760904000,
		        "PERSEN": 87.65
		    },
		    {
		        "cabang": "PUNGGALUKU",
		        "TURUN": 2176196000,
		        "TERTAGIH": 1905856000,
		        "PERSEN": 87.58
		    },
		    {
		        "cabang": "BABAT TOMAN",
		        "TURUN": 1057105000,
		        "TERTAGIH": 924622000,
		        "PERSEN": 87.47
		    },
		    {
		        "cabang": "KOTABUMI",
		        "TURUN": 884242000,
		        "TERTAGIH": 773151000,
		        "PERSEN": 87.44
		    },
		    {
		        "cabang": "PENDOLO",
		        "TURUN": 1253445000,
		        "TERTAGIH": 1093493000,
		        "PERSEN": 87.24
		    },
		    {
		        "cabang": "MEULABOH",
		        "TURUN": 4420607000,
		        "TERTAGIH": 3849293000,
		        "PERSEN": 87.08
		    },
		    {
		        "cabang": "MASOHI",
		        "TURUN": 2884644000,
		        "TERTAGIH": 2509225000,
		        "PERSEN": 86.99
		    },
		    {
		        "cabang": "WAISARISSA",
		        "TURUN": 1834441000,
		        "TERTAGIH": 1592407000,
		        "PERSEN": 86.81
		    },
		    {
		        "cabang": "TANGERANG",
		        "TURUN": 2662910004,
		        "TERTAGIH": 2311474004,
		        "PERSEN": 86.8
		    },
		    {
		        "cabang": "WAY KANAN",
		        "TURUN": 1217320000,
		        "TERTAGIH": 1056139000,
		        "PERSEN": 86.76
		    },
		    {
		        "cabang": "ENREKANG",
		        "TURUN": 1290608000,
		        "TERTAGIH": 1118415000,
		        "PERSEN": 86.66
		    },
		    {
		        "cabang": "SURABAYA",
		        "TURUN": 882171000,
		        "TERTAGIH": 764162000,
		        "PERSEN": 86.62
		    },
		    {
		        "cabang": "JENEPONTO",
		        "TURUN": 3922749500,
		        "TERTAGIH": 3395708500,
		        "PERSEN": 86.56
		    },
		    {
		        "cabang": "BUNGKU",
		        "TURUN": 6382912000,
		        "TERTAGIH": 5521795000,
		        "PERSEN": 86.51
		    },
		    {
		        "cabang": "WAY JEPARA",
		        "TURUN": 959765000,
		        "TERTAGIH": 827732000,
		        "PERSEN": 86.24
		    },
		    {
		        "cabang": "UNAAHA",
		        "TURUN": 2637026000,
		        "TERTAGIH": 2265671000,
		        "PERSEN": 85.92
		    },
		    {
		        "cabang": "PINRANG",
		        "TURUN": 3227347000,
		        "TERTAGIH": 2768063000,
		        "PERSEN": 85.77
		    },
		    {
		        "cabang": "SELAYAR",
		        "TURUN": 1901534000,
		        "TERTAGIH": 1630033000,
		        "PERSEN": 85.72
		    },
		    {
		        "cabang": "KOTA FAJAR",
		        "TURUN": 2945831000,
		        "TERTAGIH": 2520657000,
		        "PERSEN": 85.57
		    },
		    {
		        "cabang": "MAMUJU",
		        "TURUN": 2030688000,
		        "TERTAGIH": 1737467000,
		        "PERSEN": 85.56
		    },
		    {
		        "cabang": "CILEUNGSI",
		        "TURUN": 4306347000,
		        "TERTAGIH": 3680379500,
		        "PERSEN": 85.46
		    },
		    {
		        "cabang": "BANGKO",
		        "TURUN": 1132354000,
		        "TERTAGIH": 967561000,
		        "PERSEN": 85.45
		    },
		    {
		        "cabang": "KOTOBARU",
		        "TURUN": 2398164000,
		        "TERTAGIH": 2048385000,
		        "PERSEN": 85.41
		    },
		    {
		        "cabang": "PRINGSEWU",
		        "TURUN": 1374930000,
		        "TERTAGIH": 1173457000,
		        "PERSEN": 85.35
		    },
		    {
		        "cabang": "KOTARAYA",
		        "TURUN": 1966269000,
		        "TERTAGIH": 1675146000,
		        "PERSEN": 85.19
		    },
		    {
		        "cabang": "MARISA",
		        "TURUN": 2604626000,
		        "TERTAGIH": 2217360000,
		        "PERSEN": 85.13
		    },
		    {
		        "cabang": "SAMPIT",
		        "TURUN": 1693209000,
		        "TERTAGIH": 1441258000,
		        "PERSEN": 85.12
		    },
		    {
		        "cabang": "KUALA SIMPANG",
		        "TURUN": 4194262000,
		        "TERTAGIH": 3570351000,
		        "PERSEN": 85.12
		    },
		    {
		        "cabang": "PARIGI",
		        "TURUN": 2466124000,
		        "TERTAGIH": 2098690000,
		        "PERSEN": 85.1
		    },
		    {
		        "cabang": "BANDUNG",
		        "TURUN": 2017268000,
		        "TERTAGIH": 1716125000,
		        "PERSEN": 85.07
		    },
		    {
		        "cabang": "SIAU",
		        "TURUN": 847179500,
		        "TERTAGIH": 720329000,
		        "PERSEN": 85.03
		    },
		    {
		        "cabang": "JAYAPURA",
		        "TURUN": 946562000,
		        "TERTAGIH": 803902000,
		        "PERSEN": 84.93
		    },
		    {
		        "cabang": "MAROS",
		        "TURUN": 4622288000,
		        "TERTAGIH": 3914117000,
		        "PERSEN": 84.68
		    },
		    {
		        "cabang": "BANDAR JAYA",
		        "TURUN": 853987000,
		        "TERTAGIH": 723044000,
		        "PERSEN": 84.67
		    },
		    {
		        "cabang": "CIBINONG",
		        "TURUN": 3369278000,
		        "TERTAGIH": 2850287000,
		        "PERSEN": 84.6
		    },
		    {
		        "cabang": "POSO",
		        "TURUN": 3456861000,
		        "TERTAGIH": 2918475000,
		        "PERSEN": 84.43
		    },
		    {
		        "cabang": "LADONGI",
		        "TURUN": 1437668000,
		        "TERTAGIH": 1211436000,
		        "PERSEN": 84.26
		    },
		    {
		        "cabang": "METRO",
		        "TURUN": 1513761000,
		        "TERTAGIH": 1268588000,
		        "PERSEN": 83.8
		    },
		    {
		        "cabang": "JATIBARANG",
		        "TURUN": 1887255000,
		        "TERTAGIH": 1579094500,
		        "PERSEN": 83.67
		    },
		    {
		        "cabang": "ENDE",
		        "TURUN": 458442000,
		        "TERTAGIH": 382284000,
		        "PERSEN": 83.39
		    },
		    {
		        "cabang": "TUGUMULYO",
		        "TURUN": 864255000,
		        "TERTAGIH": 720504000,
		        "PERSEN": 83.37
		    },
		    {
		        "cabang": "AMPANA",
		        "TURUN": 1798789500,
		        "TERTAGIH": 1499017500,
		        "PERSEN": 83.33
		    },
		    {
		        "cabang": "SORONG",
		        "TURUN": 837713000,
		        "TERTAGIH": 696759000,
		        "PERSEN": 83.17
		    },
		    {
		        "cabang": "BLANG PIDIE",
		        "TURUN": 1963926000,
		        "TERTAGIH": 1632153000,
		        "PERSEN": 83.11
		    },
		    {
		        "cabang": "PALU 2",
		        "TURUN": 5622315000,
		        "TERTAGIH": 4667391000,
		        "PERSEN": 83.02
		    },
		    {
		        "cabang": "MAGELANG",
		        "TURUN": 1328425000,
		        "TERTAGIH": 1102159000,
		        "PERSEN": 82.97
		    },
		    {
		        "cabang": "MAKASSAR 3",
		        "TURUN": 9252683500,
		        "TERTAGIH": 7677155500,
		        "PERSEN": 82.97
		    },
		    {
		        "cabang": "LAHAT",
		        "TURUN": 3131644000,
		        "TERTAGIH": 2597367000,
		        "PERSEN": 82.94
		    },
		    {
		        "cabang": "LUBUKBASUNG",
		        "TURUN": 1162490000,
		        "TERTAGIH": 964041000,
		        "PERSEN": 82.93
		    },
		    {
		        "cabang": "KAYU AGUNG",
		        "TURUN": 1041947000,
		        "TERTAGIH": 863616000,
		        "PERSEN": 82.88
		    },
		    {
		        "cabang": "LIWA",
		        "TURUN": 1017992000,
		        "TERTAGIH": 842011000,
		        "PERSEN": 82.71
		    },
		    {
		        "cabang": "GRESIK",
		        "TURUN": 843858000,
		        "TERTAGIH": 696983500,
		        "PERSEN": 82.59
		    },
		    {
		        "cabang": "CIMAHI",
		        "TURUN": 2744500500,
		        "TERTAGIH": 2263782000,
		        "PERSEN": 82.48
		    },
		    {
		        "cabang": "YOGYAKARTA",
		        "TURUN": 1447496000,
		        "TERTAGIH": 1193722000,
		        "PERSEN": 82.47
		    },
		    {
		        "cabang": "TOMPE",
		        "TURUN": 1313564000,
		        "TERTAGIH": 1081227000,
		        "PERSEN": 82.31
		    },
		    {
		        "cabang": "TARAKAN",
		        "TURUN": 1026762500,
		        "TERTAGIH": 844862000,
		        "PERSEN": 82.28
		    },
		    {
		        "cabang": "PARE-PARE",
		        "TURUN": 3131160000,
		        "TERTAGIH": 2568861000,
		        "PERSEN": 82.04
		    },
		    {
		        "cabang": "MAKASSAR",
		        "TURUN": 8856970389,
		        "TERTAGIH": 7261840389,
		        "PERSEN": 81.99
		    },
		    {
		        "cabang": "BEKASI",
		        "TURUN": 8343687000,
		        "TERTAGIH": 6830804000,
		        "PERSEN": 81.87
		    },
		    {
		        "cabang": "SIDRAP",
		        "TURUN": 3484751000,
		        "TERTAGIH": 2849617500,
		        "PERSEN": 81.77
		    },
		    {
		        "cabang": "PRABUMULIH",
		        "TURUN": 1437143000,
		        "TERTAGIH": 1172599000,
		        "PERSEN": 81.59
		    },
		    {
		        "cabang": "KENDARI",
		        "TURUN": 7063106500,
		        "TERTAGIH": 5761953500,
		        "PERSEN": 81.58
		    },
		    {
		        "cabang": "BUOL",
		        "TURUN": 2464371000,
		        "TERTAGIH": 2008882000,
		        "PERSEN": 81.52
		    },
		    {
		        "cabang": "PEMATANG SIANTAR",
		        "TURUN": 2665839000,
		        "TERTAGIH": 2172866000,
		        "PERSEN": 81.51
		    },
		    {
		        "cabang": "GOWA",
		        "TURUN": 6834261000,
		        "TERTAGIH": 5569319000,
		        "PERSEN": 81.49
		    },
		    {
		        "cabang": "KASIPUTE",
		        "TURUN": 2147647050,
		        "TERTAGIH": 1748917050,
		        "PERSEN": 81.43
		    },
		    {
		        "cabang": "BINJAI",
		        "TURUN": 1017022000,
		        "TERTAGIH": 825735000,
		        "PERSEN": 81.19
		    },
		    {
		        "cabang": "TASIKMALAYA",
		        "TURUN": 2017159000,
		        "TERTAGIH": 1634977000,
		        "PERSEN": 81.05
		    },
		    {
		        "cabang": "MAKASSAR 2",
		        "TURUN": 7611052000,
		        "TERTAGIH": 6163957000,
		        "PERSEN": 80.99
		    },
		    {
		        "cabang": "BANJARAN",
		        "TURUN": 1744968500,
		        "TERTAGIH": 1410222500,
		        "PERSEN": 80.82
		    },
		    {
		        "cabang": "SAMARINDA",
		        "TURUN": 2690285500,
		        "TERTAGIH": 2170768500,
		        "PERSEN": 80.69
		    },
		    {
		        "cabang": "BATU LICIN",
		        "TURUN": 2346358000,
		        "TERTAGIH": 1891178500,
		        "PERSEN": 80.6
		    },
		    {
		        "cabang": "TAHUNA",
		        "TURUN": 1578437500,
		        "TERTAGIH": 1270699500,
		        "PERSEN": 80.5
		    },
		    {
		        "cabang": "PAYAKUMBUH",
		        "TURUN": 891819000,
		        "TERTAGIH": 716800000,
		        "PERSEN": 80.38
		    },
		    {
		        "cabang": "TAKENGON",
		        "TURUN": 2812991000,
		        "TERTAGIH": 2260818000,
		        "PERSEN": 80.37
		    },
		    {
		        "cabang": "BONE",
		        "TURUN": 3906620100,
		        "TERTAGIH": 3131006100,
		        "PERSEN": 80.15
		    },
		    {
		        "cabang": "SRAGEN",
		        "TURUN": 965135000,
		        "TERTAGIH": 773308500,
		        "PERSEN": 80.12
		    },
		    {
		        "cabang": "PATROL",
		        "TURUN": 1494540000,
		        "TERTAGIH": 1188783000,
		        "PERSEN": 79.54
		    },
		    {
		        "cabang": "BOALEMO",
		        "TURUN": 2255248000,
		        "TERTAGIH": 1789344000,
		        "PERSEN": 79.34
		    },
		    {
		        "cabang": "TAKALAR",
		        "TURUN": 4605890500,
		        "TERTAGIH": 3648119500,
		        "PERSEN": 79.21
		    },
		    {
		        "cabang": "CIKARANG",
		        "TURUN": 2850560000,
		        "TERTAGIH": 2245645000,
		        "PERSEN": 78.78
		    },
		    {
		        "cabang": "TALAUD",
		        "TURUN": 1672545000,
		        "TERTAGIH": 1315255000,
		        "PERSEN": 78.64
		    },
		    {
		        "cabang": "SUMEDANG",
		        "TURUN": 1651679500,
		        "TERTAGIH": 1293465500,
		        "PERSEN": 78.31
		    },
		    {
		        "cabang": "RUMBIA",
		        "TURUN": 1067862000,
		        "TERTAGIH": 833528000,
		        "PERSEN": 78.06
		    },
		    {
		        "cabang": "BANJARMASIN",
		        "TURUN": 5170949000,
		        "TERTAGIH": 4034664000,
		        "PERSEN": 78.03
		    },
		    {
		        "cabang": "GORONTALO",
		        "TURUN": 5557651500,
		        "TERTAGIH": 4327874000,
		        "PERSEN": 77.87
		    },
		    {
		        "cabang": "KADIPATEN",
		        "TURUN": 1681917500,
		        "TERTAGIH": 1306709000,
		        "PERSEN": 77.69
		    },
		    {
		        "cabang": "PROBOLINGGO",
		        "TURUN": 751590500,
		        "TERTAGIH": 582615500,
		        "PERSEN": 77.52
		    },
		    {
		        "cabang": "TULUNGAGUNG",
		        "TURUN": 760406000,
		        "TERTAGIH": 589013500,
		        "PERSEN": 77.46
		    },
		    {
		        "cabang": "POLMAS",
		        "TURUN": 1738757000,
		        "TERTAGIH": 1345329000,
		        "PERSEN": 77.37
		    },
		    {
		        "cabang": "SAMARINDA SEBERANG",
		        "TURUN": 1755314000,
		        "TERTAGIH": 1357906500,
		        "PERSEN": 77.36
		    },
		    {
		        "cabang": "SERANG",
		        "TURUN": 1944336000,
		        "TERTAGIH": 1504195000,
		        "PERSEN": 77.36
		    },
		    {
		        "cabang": "MAJENE",
		        "TURUN": 1733849500,
		        "TERTAGIH": 1338563500,
		        "PERSEN": 77.2
		    },
		    {
		        "cabang": "KOTABARU",
		        "TURUN": 1378891500,
		        "TERTAGIH": 1062873500,
		        "PERSEN": 77.08
		    },
		    {
		        "cabang": "BANTAENG",
		        "TURUN": 2286983000,
		        "TERTAGIH": 1760042000,
		        "PERSEN": 76.96
		    },
		    {
		        "cabang": "BLITAR",
		        "TURUN": 1608818500,
		        "TERTAGIH": 1236866000,
		        "PERSEN": 76.88
		    },
		    {
		        "cabang": "MOROTAI",
		        "TURUN": 210649000,
		        "TERTAGIH": 161561000,
		        "PERSEN": 76.7
		    },
		    {
		        "cabang": "SINJAI",
		        "TURUN": 1759833000,
		        "TERTAGIH": 1340814000,
		        "PERSEN": 76.19
		    },
		    {
		        "cabang": "PALU",
		        "TURUN": 10581901000,
		        "TERTAGIH": 8051777000,
		        "PERSEN": 76.09
		    },
		    {
		        "cabang": "PARIAMAN",
		        "TURUN": 1207105000,
		        "TERTAGIH": 916650000,
		        "PERSEN": 75.94
		    },
		    {
		        "cabang": "NAGAN",
		        "TURUN": 1380578000,
		        "TERTAGIH": 1047878000,
		        "PERSEN": 75.9
		    },
		    {
		        "cabang": "PENAJAM",
		        "TURUN": 972517000,
		        "TERTAGIH": 737950000,
		        "PERSEN": 75.88
		    },
		    {
		        "cabang": "UJUNG BERUNG",
		        "TURUN": 1288318000,
		        "TERTAGIH": 976892000,
		        "PERSEN": 75.83
		    },
		    {
		        "cabang": "KALIANDA",
		        "TURUN": 2070085000,
		        "TERTAGIH": 1568634000,
		        "PERSEN": 75.78
		    },
		    {
		        "cabang": "INDRALAYA",
		        "TURUN": 1601018000,
		        "TERTAGIH": 1205097000,
		        "PERSEN": 75.27
		    },
		    {
		        "cabang": "ARGA MAKMUR",
		        "TURUN": 1133514000,
		        "TERTAGIH": 851492000,
		        "PERSEN": 75.12
		    },
		    {
		        "cabang": "PELABUHAN RATU",
		        "TURUN": 2965603500,
		        "TERTAGIH": 2221037500,
		        "PERSEN": 74.89
		    },
		    {
		        "cabang": "MANOKWARI",
		        "TURUN": 2300893000,
		        "TERTAGIH": 1722118000,
		        "PERSEN": 74.85
		    },
		    {
		        "cabang": "GARUT",
		        "TURUN": 2352792000,
		        "TERTAGIH": 1758761000,
		        "PERSEN": 74.75
		    },
		    {
		        "cabang": "SUKABUMI",
		        "TURUN": 1953137500,
		        "TERTAGIH": 1452715000,
		        "PERSEN": 74.38
		    },
		    {
		        "cabang": "CIANJUR",
		        "TURUN": 3014785000,
		        "TERTAGIH": 2242404500,
		        "PERSEN": 74.38
		    },
		    {
		        "cabang": "SOLOK",
		        "TURUN": 1436677000,
		        "TERTAGIH": 1065655000,
		        "PERSEN": 74.17
		    },
		    {
		        "cabang": "MASBAGIK",
		        "TURUN": 2029988000,
		        "TERTAGIH": 1504781000,
		        "PERSEN": 74.13
		    },
		    {
		        "cabang": "SOLO",
		        "TURUN": 1665886000,
		        "TERTAGIH": 1234287000,
		        "PERSEN": 74.09
		    },
		    {
		        "cabang": "PANTON LABU",
		        "TURUN": 1520002000,
		        "TERTAGIH": 1125935000,
		        "PERSEN": 74.07
		    },
		    {
		        "cabang": "LUBUK LINGGAU",
		        "TURUN": 1328290000,
		        "TERTAGIH": 974868000,
		        "PERSEN": 73.39
		    },
		    {
		        "cabang": "CILEDUG",
		        "TURUN": 1941334000,
		        "TERTAGIH": 1416606000,
		        "PERSEN": 72.97
		    },
		    {
		        "cabang": "KARAWANG",
		        "TURUN": 5484908000,
		        "TERTAGIH": 3974881000,
		        "PERSEN": 72.47
		    },
		    {
		        "cabang": "JEMBER",
		        "TURUN": 1625552500,
		        "TERTAGIH": 1177577500,
		        "PERSEN": 72.44
		    },
		    {
		        "cabang": "KUNINGAN",
		        "TURUN": 1324456500,
		        "TERTAGIH": 957499500,
		        "PERSEN": 72.29
		    },
		    {
		        "cabang": "SIDOARJO",
		        "TURUN": 1296446500,
		        "TERTAGIH": 936786500,
		        "PERSEN": 72.26
		    },
		    {
		        "cabang": "MALANG",
		        "TURUN": 1446371900,
		        "TERTAGIH": 1039369400,
		        "PERSEN": 71.86
		    },
		    {
		        "cabang": "WONOSOBO",
		        "TURUN": 2024689000,
		        "TERTAGIH": 1453504000,
		        "PERSEN": 71.79
		    },
		    {
		        "cabang": "PONTIANAK",
		        "TURUN": 432276000,
		        "TERTAGIH": 310211000,
		        "PERSEN": 71.76
		    },
		    {
		        "cabang": "MARTAPURA",
		        "TURUN": 411081000,
		        "TERTAGIH": 294114000,
		        "PERSEN": 71.55
		    },
		    {
		        "cabang": "KOTA AGUNG",
		        "TURUN": 901341000,
		        "TERTAGIH": 640576000,
		        "PERSEN": 71.07
		    },
		    {
		        "cabang": "PANGANDARAN",
		        "TURUN": 2497164000,
		        "TERTAGIH": 1768984000,
		        "PERSEN": 70.84
		    },
		    {
		        "cabang": "BACAN",
		        "TURUN": 798639000,
		        "TERTAGIH": 560842000,
		        "PERSEN": 70.22
		    },
		    {
		        "cabang": "JAMPANG",
		        "TURUN": 1162032000,
		        "TERTAGIH": 813436500,
		        "PERSEN": 70
		    },
		    {
		        "cabang": "SUBANG",
		        "TURUN": 1612843500,
		        "TERTAGIH": 1126370500,
		        "PERSEN": 69.84
		    },
		    {
		        "cabang": "SEKAYU",
		        "TURUN": 798258000,
		        "TERTAGIH": 557120000,
		        "PERSEN": 69.79
		    },
		    {
		        "cabang": "SUMBAWA",
		        "TURUN": 502720000,
		        "TERTAGIH": 349494000,
		        "PERSEN": 69.52
		    },
		    {
		        "cabang": "TUAL",
		        "TURUN": 2071567000,
		        "TERTAGIH": 1436302000,
		        "PERSEN": 69.33
		    },
		    {
		        "cabang": "BOROKO",
		        "TURUN": 856092000,
		        "TERTAGIH": 593039000,
		        "PERSEN": 69.27
		    },
		    {
		        "cabang": "TEBO",
		        "TURUN": 811426000,
		        "TERTAGIH": 561291000,
		        "PERSEN": 69.17
		    },
		    {
		        "cabang": "JAMBI",
		        "TURUN": 1673462000,
		        "TERTAGIH": 1154177000,
		        "PERSEN": 68.97
		    },
		    {
		        "cabang": "CURUP",
		        "TURUN": 1009423000,
		        "TERTAGIH": 690429000,
		        "PERSEN": 68.4
		    },
		    {
		        "cabang": "PLEIHARI",
		        "TURUN": 1413612000,
		        "TERTAGIH": 965989000,
		        "PERSEN": 68.33
		    },
		    {
		        "cabang": "LAMPUNG",
		        "TURUN": 4670717000,
		        "TERTAGIH": 3190679000,
		        "PERSEN": 68.31
		    },
		    {
		        "cabang": "PEKALONGAN",
		        "TURUN": 777742000,
		        "TERTAGIH": 529979000,
		        "PERSEN": 68.14
		    },
		    {
		        "cabang": "MEDAN",
		        "TURUN": 1759461000,
		        "TERTAGIH": 1196396000,
		        "PERSEN": 68
		    },
		    {
		        "cabang": "LUWUK",
		        "TURUN": 2762710000,
		        "TERTAGIH": 1872726000,
		        "PERSEN": 67.79
		    },
		    {
		        "cabang": "RATAHAN",
		        "TURUN": 3920179400,
		        "TERTAGIH": 2632669400,
		        "PERSEN": 67.16
		    },
		    {
		        "cabang": "MUARA TEWEH",
		        "TURUN": 2508166500,
		        "TERTAGIH": 1681391500,
		        "PERSEN": 67.04
		    },
		    {
		        "cabang": "BENGKULU",
		        "TURUN": 806303000,
		        "TERTAGIH": 539114000,
		        "PERSEN": 66.86
		    },
		    {
		        "cabang": "PARUNGKUDA",
		        "TURUN": 2726479000,
		        "TERTAGIH": 1820277500,
		        "PERSEN": 66.76
		    },
		    {
		        "cabang": "BOJONEGORO",
		        "TURUN": 597606500,
		        "TERTAGIH": 398511500,
		        "PERSEN": 66.68
		    },
		    {
		        "cabang": "LHOKSEUMAWE",
		        "TURUN": 3987093000,
		        "TERTAGIH": 2656961000,
		        "PERSEN": 66.64
		    },
		    {
		        "cabang": "BALIKPAPAN",
		        "TURUN": 2959801000,
		        "TERTAGIH": 1963962000,
		        "PERSEN": 66.35
		    },
		    {
		        "cabang": "PALEMBANG",
		        "TURUN": 5738182000,
		        "TERTAGIH": 3801697000,
		        "PERSEN": 66.25
		    },
		    {
		        "cabang": "CILACAP",
		        "TURUN": 1388952500,
		        "TERTAGIH": 919546500,
		        "PERSEN": 66.2
		    },
		    {
		        "cabang": "SAUMLAKI",
		        "TURUN": 1134241000,
		        "TERTAGIH": 745285000,
		        "PERSEN": 65.71
		    },
		    {
		        "cabang": "BETUNG",
		        "TURUN": 2197725000,
		        "TERTAGIH": 1434365000,
		        "PERSEN": 65.27
		    },
		    {
		        "cabang": "TANJUNG",
		        "TURUN": 1838713500,
		        "TERTAGIH": 1197365000,
		        "PERSEN": 65.12
		    },
		    {
		        "cabang": "WONOSARI",
		        "TURUN": 1391086000,
		        "TERTAGIH": 903845000,
		        "PERSEN": 64.97
		    },
		    {
		        "cabang": "BALARAJA",
		        "TURUN": 2110967000,
		        "TERTAGIH": 1354699000,
		        "PERSEN": 64.17
		    },
		    {
		        "cabang": "PADANG",
		        "TURUN": 2047305000,
		        "TERTAGIH": 1305140000,
		        "PERSEN": 63.75
		    },
		    {
		        "cabang": "PEKANBARU",
		        "TURUN": 2340569500,
		        "TERTAGIH": 1466788500,
		        "PERSEN": 62.67
		    },
		    {
		        "cabang": "KEBUMEN",
		        "TURUN": 670044000,
		        "TERTAGIH": 416555000,
		        "PERSEN": 62.17
		    },
		    {
		        "cabang": "MADIUN",
		        "TURUN": 934646500,
		        "TERTAGIH": 577153500,
		        "PERSEN": 61.75
		    },
		    {
		        "cabang": "TEMANGGUNG",
		        "TURUN": 2769206000,
		        "TERTAGIH": 1705991000,
		        "PERSEN": 61.61
		    },
		    {
		        "cabang": "MANADO",
		        "TURUN": 5671022000,
		        "TERTAGIH": 3463792000,
		        "PERSEN": 61.08
		    },
		    {
		        "cabang": "BARABAI",
		        "TURUN": 1377843000,
		        "TERTAGIH": 826221000,
		        "PERSEN": 59.96
		    },
		    {
		        "cabang": "TANJUNG BINTANG",
		        "TURUN": 1118331000,
		        "TERTAGIH": 659705000,
		        "PERSEN": 58.99
		    },
		    {
		        "cabang": "BUNGO",
		        "TURUN": 1170088000,
		        "TERTAGIH": 678655000,
		        "PERSEN": 58
		    },
		    {
		        "cabang": "KOTAMOBAGU",
		        "TURUN": 1712076000,
		        "TERTAGIH": 991889000,
		        "PERSEN": 57.93
		    },
		    {
		        "cabang": "SEMARANG",
		        "TURUN": 4333223000,
		        "TERTAGIH": 2496120000,
		        "PERSEN": 57.6
		    },
		    {
		        "cabang": "TEGAL",
		        "TURUN": 1680822000,
		        "TERTAGIH": 968233000,
		        "PERSEN": 57.6
		    },
		    {
		        "cabang": "PURWAKARTA",
		        "TURUN": 3650079631,
		        "TERTAGIH": 2100831631,
		        "PERSEN": 57.56
		    },
		    {
		        "cabang": "BATURAJA",
		        "TURUN": 1059103000,
		        "TERTAGIH": 606706000,
		        "PERSEN": 57.28
		    },
		    {
		        "cabang": "PURWOKERTO",
		        "TURUN": 1668394000,
		        "TERTAGIH": 940263000,
		        "PERSEN": 56.36
		    },
		    {
		        "cabang": "BAWEN",
		        "TURUN": 2393263500,
		        "TERTAGIH": 1342742000,
		        "PERSEN": 56.11
		    },
		    {
		        "cabang": "KEDIRI",
		        "TURUN": 1486269500,
		        "TERTAGIH": 791165500,
		        "PERSEN": 53.23
		    },
		    {
		        "cabang": "MOJOKERTO",
		        "TURUN": 779515000,
		        "TERTAGIH": 414314000,
		        "PERSEN": 53.15
		    },
		    {
		        "cabang": "PATI",
		        "TURUN": 1439890000,
		        "TERTAGIH": 762106000,
		        "PERSEN": 52.93
		    },
		    {
		        "cabang": "BITUNG",
		        "TURUN": 6722645500,
		        "TERTAGIH": 3484995000,
		        "PERSEN": 51.84
		    },
		    {
		        "cabang": "PANGKALAN BRANDAN",
		        "TURUN": 158207000,
		        "TERTAGIH": 81200000,
		        "PERSEN": 51.33
		    },
		    {
		        "cabang": "TOMOHON",
		        "TURUN": 1498236000,
		        "TERTAGIH": 727121500,
		        "PERSEN": 48.53
		    },
		    {
		        "cabang": "BULI",
		        "TURUN": 98723000,
		        "TERTAGIH": 24169000,
		        "PERSEN": 24.48
		    },
		    {
		        "cabang": "CINERE",
		        "TURUN": 10000,
		        "TERTAGIH": 0,
		        "PERSEN": 0
		    },
		    {
		        "cabang": "SOROLANGON",
		        "TURUN": 0,
		        "TERTAGIH": 0,
		        "PERSEN": null
		    },
		    {
		        "cabang": "MUARA BULIAN",
		        "TURUN": 0,
		        "TERTAGIH": 0,
		        "PERSEN": null
		    }
		],
        "columns": [
            { "data": "cabang" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableCollCabKon').DataTable({
        "data":[
		    {
		        "cabang": "DOMPU",
		        "TURUN": 581065000,
		        "TERTAGIH": 569631000,
		        "PERSEN": 98.03
		    },
		    {
		        "cabang": "KELAPA",
		        "TURUN": 1092745500,
		        "TERTAGIH": 1062039500,
		        "PERSEN": 97.19
		    },
		    {
		        "cabang": "TOBOALI",
		        "TURUN": 1329139000,
		        "TERTAGIH": 1285998000,
		        "PERSEN": 96.75
		    },
		    {
		        "cabang": "PANGKALANBUN",
		        "TURUN": 483281000,
		        "TERTAGIH": 464005000,
		        "PERSEN": 96.01
		    },
		    {
		        "cabang": "KOBA",
		        "TURUN": 1217045500,
		        "TERTAGIH": 1167271500,
		        "PERSEN": 95.91
		    },
		    {
		        "cabang": "EREKE",
		        "TURUN": 1038747000,
		        "TERTAGIH": 990396000,
		        "PERSEN": 95.35
		    },
		    {
		        "cabang": "MAKALE",
		        "TURUN": 2394569500,
		        "TERTAGIH": 2281426500,
		        "PERSEN": 95.28
		    },
		    {
		        "cabang": "UJUNG GADING",
		        "TURUN": 1816523500,
		        "TERTAGIH": 1728459500,
		        "PERSEN": 95.15
		    },
		    {
		        "cabang": "TUNGKAL",
		        "TURUN": 374953000,
		        "TERTAGIH": 356273000,
		        "PERSEN": 95.02
		    },
		    {
		        "cabang": "CIAWI",
		        "TURUN": 1231025500,
		        "TERTAGIH": 1168441500,
		        "PERSEN": 94.92
		    },
		    {
		        "cabang": "BELINYU",
		        "TURUN": 1591779000,
		        "TERTAGIH": 1509890000,
		        "PERSEN": 94.86
		    },
		    {
		        "cabang": "TOPPOYO",
		        "TURUN": 2716667000,
		        "TERTAGIH": 2569975000,
		        "PERSEN": 94.6
		    },
		    {
		        "cabang": "BUTON",
		        "TURUN": 4142300000,
		        "TERTAGIH": 3916074000,
		        "PERSEN": 94.54
		    },
		    {
		        "cabang": "BERAU",
		        "TURUN": 3233797500,
		        "TERTAGIH": 3051961500,
		        "PERSEN": 94.38
		    },
		    {
		        "cabang": "SALAKAN",
		        "TURUN": 3443572000,
		        "TERTAGIH": 3249029000,
		        "PERSEN": 94.35
		    },
		    {
		        "cabang": "PASANGKAYU",
		        "TURUN": 2598152000,
		        "TERTAGIH": 2448385000,
		        "PERSEN": 94.24
		    },
		    {
		        "cabang": "LANGSA ACEH",
		        "TURUN": 1019432000,
		        "TERTAGIH": 959077000,
		        "PERSEN": 94.08
		    },
		    {
		        "cabang": "SOPPENG",
		        "TURUN": 1672983000,
		        "TERTAGIH": 1573838000,
		        "PERSEN": 94.07
		    },
		    {
		        "cabang": "BELITUNG",
		        "TURUN": 2654395500,
		        "TERTAGIH": 2495795500,
		        "PERSEN": 94.03
		    },
		    {
		        "cabang": "PARUNG",
		        "TURUN": 1454464500,
		        "TERTAGIH": 1361553500,
		        "PERSEN": 93.61
		    },
		    {
		        "cabang": "ULEE GLEE",
		        "TURUN": 804644000,
		        "TERTAGIH": 753212000,
		        "PERSEN": 93.61
		    },
		    {
		        "cabang": "SUNGAI LIAT",
		        "TURUN": 1270905000,
		        "TERTAGIH": 1189086000,
		        "PERSEN": 93.56
		    },
		    {
		        "cabang": "MASAMBA",
		        "TURUN": 2854600000,
		        "TERTAGIH": 2668265000,
		        "PERSEN": 93.47
		    },
		    {
		        "cabang": "SIMPANG PEMATANG",
		        "TURUN": 735645000,
		        "TERTAGIH": 686872000,
		        "PERSEN": 93.37
		    },
		    {
		        "cabang": "BANGKALA",
		        "TURUN": 2204788000,
		        "TERTAGIH": 2057355000,
		        "PERSEN": 93.31
		    },
		    {
		        "cabang": "IDIE",
		        "TURUN": 3679869000,
		        "TERTAGIH": 3426973000,
		        "PERSEN": 93.13
		    },
		    {
		        "cabang": "LASUSUA",
		        "TURUN": 692620000,
		        "TERTAGIH": 644548000,
		        "PERSEN": 93.06
		    },
		    {
		        "cabang": "DONGGALA",
		        "TURUN": 2270829500,
		        "TERTAGIH": 2112180500,
		        "PERSEN": 93.01
		    },
		    {
		        "cabang": "RAWAJITU",
		        "TURUN": 1082056000,
		        "TERTAGIH": 1002617000,
		        "PERSEN": 92.66
		    },
		    {
		        "cabang": "PALANGKARAYA",
		        "TURUN": 2043243000,
		        "TERTAGIH": 1891876000,
		        "PERSEN": 92.59
		    },
		    {
		        "cabang": "BATU SANGKAR",
		        "TURUN": 1257502000,
		        "TERTAGIH": 1160650000,
		        "PERSEN": 92.3
		    },
		    {
		        "cabang": "LEUWILIANG",
		        "TURUN": 2537148500,
		        "TERTAGIH": 2340528000,
		        "PERSEN": 92.25
		    },
		    {
		        "cabang": "BARRU",
		        "TURUN": 1604521500,
		        "TERTAGIH": 1479479500,
		        "PERSEN": 92.21
		    },
		    {
		        "cabang": "SUNGAI LILIN",
		        "TURUN": 2427487000,
		        "TERTAGIH": 2236482000,
		        "PERSEN": 92.13
		    },
		    {
		        "cabang": "MANGKUTANA",
		        "TURUN": 2452822000,
		        "TERTAGIH": 2259583000,
		        "PERSEN": 92.12
		    },
		    {
		        "cabang": "BOEPINANG",
		        "TURUN": 1538005000,
		        "TERTAGIH": 1416299000,
		        "PERSEN": 92.09
		    },
		    {
		        "cabang": "LHOKSUKON",
		        "TURUN": 998775000,
		        "TERTAGIH": 919489000,
		        "PERSEN": 92.06
		    },
		    {
		        "cabang": "JEBUS",
		        "TURUN": 918804000,
		        "TERTAGIH": 843258000,
		        "PERSEN": 91.78
		    },
		    {
		        "cabang": "SABAK",
		        "TURUN": 779836000,
		        "TERTAGIH": 714964000,
		        "PERSEN": 91.68
		    },
		    {
		        "cabang": "BUNTA",
		        "TURUN": 2005620000,
		        "TERTAGIH": 1837708000,
		        "PERSEN": 91.63
		    },
		    {
		        "cabang": "BIREUEN",
		        "TURUN": 2568512000,
		        "TERTAGIH": 2353081000,
		        "PERSEN": 91.61
		    },
		    {
		        "cabang": "RAHA",
		        "TURUN": 2197477000,
		        "TERTAGIH": 2011010000,
		        "PERSEN": 91.51
		    },
		    {
		        "cabang": "JAILOLO",
		        "TURUN": 4295497500,
		        "TERTAGIH": 3928189500,
		        "PERSEN": 91.45
		    },
		    {
		        "cabang": "TENGGARONG",
		        "TURUN": 1603573000,
		        "TERTAGIH": 1464233000,
		        "PERSEN": 91.31
		    },
		    {
		        "cabang": "TULANG BAWANG",
		        "TURUN": 940382000,
		        "TERTAGIH": 858481000,
		        "PERSEN": 91.29
		    },
		    {
		        "cabang": "BELOPA",
		        "TURUN": 2738986024,
		        "TERTAGIH": 2498574008,
		        "PERSEN": 91.22
		    },
		    {
		        "cabang": "TORAJA",
		        "TURUN": 3563607800,
		        "TERTAGIH": 3250280800,
		        "PERSEN": 91.21
		    },
		    {
		        "cabang": "BOYOLALI",
		        "TURUN": 1054224000,
		        "TERTAGIH": 961579000,
		        "PERSEN": 91.21
		    },
		    {
		        "cabang": "BOGOR",
		        "TURUN": 2386113500,
		        "TERTAGIH": 2174905500,
		        "PERSEN": 91.15
		    },
		    {
		        "cabang": "PANGKEP",
		        "TURUN": 2354870000,
		        "TERTAGIH": 2145203000,
		        "PERSEN": 91.1
		    },
		    {
		        "cabang": "KOLAKA",
		        "TURUN": 4098258000,
		        "TERTAGIH": 3729409000,
		        "PERSEN": 91
		    },
		    {
		        "cabang": "SENGKANG",
		        "TURUN": 2914759000,
		        "TERTAGIH": 2642436000,
		        "PERSEN": 90.66
		    },
		    {
		        "cabang": "MENTOK",
		        "TURUN": 1295564000,
		        "TERTAGIH": 1173367000,
		        "PERSEN": 90.57
		    },
		    {
		        "cabang": "TOBELO",
		        "TURUN": 1688376000,
		        "TERTAGIH": 1529048000,
		        "PERSEN": 90.56
		    },
		    {
		        "cabang": "BELTIM",
		        "TURUN": 1667771500,
		        "TERTAGIH": 1510100000,
		        "PERSEN": 90.55
		    },
		    {
		        "cabang": "TENTENA",
		        "TURUN": 2018810000,
		        "TERTAGIH": 1827847000,
		        "PERSEN": 90.54
		    },
		    {
		        "cabang": "SIJUNGJUNG",
		        "TURUN": 1422765000,
		        "TERTAGIH": 1287350000,
		        "PERSEN": 90.48
		    },
		    {
		        "cabang": "LABUAN BAJO",
		        "TURUN": 716786000,
		        "TERTAGIH": 648246000,
		        "PERSEN": 90.44
		    },
		    {
		        "cabang": "BANGKA",
		        "TURUN": 4495567000,
		        "TERTAGIH": 4065184500,
		        "PERSEN": 90.43
		    },
		    {
		        "cabang": "TANGGEUNG",
		        "TURUN": 1278126500,
		        "TERTAGIH": 1155550500,
		        "PERSEN": 90.41
		    },
		    {
		        "cabang": "TOILI",
		        "TURUN": 2495973000,
		        "TERTAGIH": 2256037000,
		        "PERSEN": 90.39
		    },
		    {
		        "cabang": "BUKITTINGGI",
		        "TURUN": 1174762000,
		        "TERTAGIH": 1061619000,
		        "PERSEN": 90.37
		    },
		    {
		        "cabang": "ALUE BILIE",
		        "TURUN": 1067158000,
		        "TERTAGIH": 963722000,
		        "PERSEN": 90.31
		    },
		    {
		        "cabang": "BAYUNG LENCIR",
		        "TURUN": 2795327000,
		        "TERTAGIH": 2522942000,
		        "PERSEN": 90.26
		    },
		    {
		        "cabang": "NAMLEA",
		        "TURUN": 2500071500,
		        "TERTAGIH": 2256359500,
		        "PERSEN": 90.25
		    },
		    {
		        "cabang": "TERNATE",
		        "TURUN": 4200588000,
		        "TERTAGIH": 3790507000,
		        "PERSEN": 90.24
		    },
		    {
		        "cabang": "AMBON",
		        "TURUN": 5851645000,
		        "TERTAGIH": 5278846000,
		        "PERSEN": 90.21
		    },
		    {
		        "cabang": "PALOPO",
		        "TURUN": 4774370500,
		        "TERTAGIH": 4304163500,
		        "PERSEN": 90.15
		    },
		    {
		        "cabang": "MOROWALI",
		        "TURUN": 3859307000,
		        "TERTAGIH": 3478095000,
		        "PERSEN": 90.12
		    },
		    {
		        "cabang": "DAYA MURNI",
		        "TURUN": 565167000,
		        "TERTAGIH": 509349000,
		        "PERSEN": 90.12
		    },
		    {
		        "cabang": "TOLI TOLI",
		        "TURUN": 1669420000,
		        "TERTAGIH": 1504104000,
		        "PERSEN": 90.1
		    },
		    {
		        "cabang": "KARANGANYAR",
		        "TURUN": 1196554000,
		        "TERTAGIH": 1077797000,
		        "PERSEN": 90.08
		    },
		    {
		        "cabang": "SANGATTA",
		        "TURUN": 2656219000,
		        "TERTAGIH": 2388655000,
		        "PERSEN": 89.93
		    },
		    {
		        "cabang": "BULUKUMBA",
		        "TURUN": 4118308003,
		        "TERTAGIH": 3679692003,
		        "PERSEN": 89.35
		    },
		    {
		        "cabang": "MALILI",
		        "TURUN": 2620465000,
		        "TERTAGIH": 2340850000,
		        "PERSEN": 89.33
		    },
		    {
		        "cabang": "WONOGIRI",
		        "TURUN": 1247419000,
		        "TERTAGIH": 1114272000,
		        "PERSEN": 89.33
		    },
		    {
		        "cabang": "SIGLI",
		        "TURUN": 1411096000,
		        "TERTAGIH": 1255614000,
		        "PERSEN": 88.98
		    },
		    {
		        "cabang": "MALINO",
		        "TURUN": 1020883000,
		        "TERTAGIH": 908322000,
		        "PERSEN": 88.97
		    },
		    {
		        "cabang": "TANAH GROGOT",
		        "TURUN": 1422867500,
		        "TERTAGIH": 1264813500,
		        "PERSEN": 88.89
		    },
		    {
		        "cabang": "KAPUAS",
		        "TURUN": 360255000,
		        "TERTAGIH": 319787000,
		        "PERSEN": 88.77
		    },
		    {
		        "cabang": "CIREBON",
		        "TURUN": 1612944500,
		        "TERTAGIH": 1431286500,
		        "PERSEN": 88.74
		    },
		    {
		        "cabang": "GOWA 2",
		        "TURUN": 4919381000,
		        "TERTAGIH": 4357677000,
		        "PERSEN": 88.58
		    },
		    {
		        "cabang": "MUARA ENIM",
		        "TURUN": 1480168000,
		        "TERTAGIH": 1305007000,
		        "PERSEN": 88.17
		    },
		    {
		        "cabang": "MOLIBAGU",
		        "TURUN": 668037000,
		        "TERTAGIH": 588712000,
		        "PERSEN": 88.13
		    },
		    {
		        "cabang": "BANJAR",
		        "TURUN": 1337628500,
		        "TERTAGIH": 1177562500,
		        "PERSEN": 88.03
		    },
		    {
		        "cabang": "RUTENG",
		        "TURUN": 836440000,
		        "TERTAGIH": 735947000,
		        "PERSEN": 87.99
		    },
		    {
		        "cabang": "BELITANG",
		        "TURUN": 595250000,
		        "TERTAGIH": 522700000,
		        "PERSEN": 87.81
		    },
		    {
		        "cabang": "ACEH",
		        "TURUN": 3309828000,
		        "TERTAGIH": 2903376000,
		        "PERSEN": 87.72
		    },
		    {
		        "cabang": "MARTAPURA KAL",
		        "TURUN": 2113932000,
		        "TERTAGIH": 1854043000,
		        "PERSEN": 87.71
		    },
		    {
		        "cabang": "PASAMAN",
		        "TURUN": 868106000,
		        "TERTAGIH": 760904000,
		        "PERSEN": 87.65
		    },
		    {
		        "cabang": "PUNGGALUKU",
		        "TURUN": 2176196000,
		        "TERTAGIH": 1905856000,
		        "PERSEN": 87.58
		    },
		    {
		        "cabang": "BABAT TOMAN",
		        "TURUN": 1057105000,
		        "TERTAGIH": 924622000,
		        "PERSEN": 87.47
		    },
		    {
		        "cabang": "KOTABUMI",
		        "TURUN": 884242000,
		        "TERTAGIH": 773151000,
		        "PERSEN": 87.44
		    },
		    {
		        "cabang": "PENDOLO",
		        "TURUN": 1253445000,
		        "TERTAGIH": 1093493000,
		        "PERSEN": 87.24
		    },
		    {
		        "cabang": "MEULABOH",
		        "TURUN": 4420607000,
		        "TERTAGIH": 3849293000,
		        "PERSEN": 87.08
		    },
		    {
		        "cabang": "MASOHI",
		        "TURUN": 2884644000,
		        "TERTAGIH": 2509225000,
		        "PERSEN": 86.99
		    },
		    {
		        "cabang": "WAISARISSA",
		        "TURUN": 1834441000,
		        "TERTAGIH": 1592407000,
		        "PERSEN": 86.81
		    },
		    {
		        "cabang": "TANGERANG",
		        "TURUN": 2662910004,
		        "TERTAGIH": 2311474004,
		        "PERSEN": 86.8
		    },
		    {
		        "cabang": "WAY KANAN",
		        "TURUN": 1217320000,
		        "TERTAGIH": 1056139000,
		        "PERSEN": 86.76
		    },
		    {
		        "cabang": "ENREKANG",
		        "TURUN": 1290608000,
		        "TERTAGIH": 1118415000,
		        "PERSEN": 86.66
		    },
		    {
		        "cabang": "SURABAYA",
		        "TURUN": 882171000,
		        "TERTAGIH": 764162000,
		        "PERSEN": 86.62
		    },
		    {
		        "cabang": "JENEPONTO",
		        "TURUN": 3922749500,
		        "TERTAGIH": 3395708500,
		        "PERSEN": 86.56
		    },
		    {
		        "cabang": "BUNGKU",
		        "TURUN": 6382912000,
		        "TERTAGIH": 5521795000,
		        "PERSEN": 86.51
		    },
		    {
		        "cabang": "WAY JEPARA",
		        "TURUN": 959765000,
		        "TERTAGIH": 827732000,
		        "PERSEN": 86.24
		    },
		    {
		        "cabang": "UNAAHA",
		        "TURUN": 2637026000,
		        "TERTAGIH": 2265671000,
		        "PERSEN": 85.92
		    },
		    {
		        "cabang": "PINRANG",
		        "TURUN": 3227347000,
		        "TERTAGIH": 2768063000,
		        "PERSEN": 85.77
		    },
		    {
		        "cabang": "SELAYAR",
		        "TURUN": 1901534000,
		        "TERTAGIH": 1630033000,
		        "PERSEN": 85.72
		    },
		    {
		        "cabang": "KOTA FAJAR",
		        "TURUN": 2945831000,
		        "TERTAGIH": 2520657000,
		        "PERSEN": 85.57
		    },
		    {
		        "cabang": "MAMUJU",
		        "TURUN": 2030688000,
		        "TERTAGIH": 1737467000,
		        "PERSEN": 85.56
		    },
		    {
		        "cabang": "CILEUNGSI",
		        "TURUN": 4306347000,
		        "TERTAGIH": 3680379500,
		        "PERSEN": 85.46
		    },
		    {
		        "cabang": "BANGKO",
		        "TURUN": 1132354000,
		        "TERTAGIH": 967561000,
		        "PERSEN": 85.45
		    },
		    {
		        "cabang": "KOTOBARU",
		        "TURUN": 2398164000,
		        "TERTAGIH": 2048385000,
		        "PERSEN": 85.41
		    },
		    {
		        "cabang": "PRINGSEWU",
		        "TURUN": 1374930000,
		        "TERTAGIH": 1173457000,
		        "PERSEN": 85.35
		    },
		    {
		        "cabang": "KOTARAYA",
		        "TURUN": 1966269000,
		        "TERTAGIH": 1675146000,
		        "PERSEN": 85.19
		    },
		    {
		        "cabang": "MARISA",
		        "TURUN": 2604626000,
		        "TERTAGIH": 2217360000,
		        "PERSEN": 85.13
		    },
		    {
		        "cabang": "SAMPIT",
		        "TURUN": 1693209000,
		        "TERTAGIH": 1441258000,
		        "PERSEN": 85.12
		    },
		    {
		        "cabang": "KUALA SIMPANG",
		        "TURUN": 4194262000,
		        "TERTAGIH": 3570351000,
		        "PERSEN": 85.12
		    },
		    {
		        "cabang": "PARIGI",
		        "TURUN": 2466124000,
		        "TERTAGIH": 2098690000,
		        "PERSEN": 85.1
		    },
		    {
		        "cabang": "BANDUNG",
		        "TURUN": 2017268000,
		        "TERTAGIH": 1716125000,
		        "PERSEN": 85.07
		    },
		    {
		        "cabang": "SIAU",
		        "TURUN": 847179500,
		        "TERTAGIH": 720329000,
		        "PERSEN": 85.03
		    },
		    {
		        "cabang": "JAYAPURA",
		        "TURUN": 946562000,
		        "TERTAGIH": 803902000,
		        "PERSEN": 84.93
		    },
		    {
		        "cabang": "MAROS",
		        "TURUN": 4622288000,
		        "TERTAGIH": 3914117000,
		        "PERSEN": 84.68
		    },
		    {
		        "cabang": "BANDAR JAYA",
		        "TURUN": 853987000,
		        "TERTAGIH": 723044000,
		        "PERSEN": 84.67
		    },
		    {
		        "cabang": "CIBINONG",
		        "TURUN": 3369278000,
		        "TERTAGIH": 2850287000,
		        "PERSEN": 84.6
		    },
		    {
		        "cabang": "POSO",
		        "TURUN": 3456861000,
		        "TERTAGIH": 2918475000,
		        "PERSEN": 84.43
		    },
		    {
		        "cabang": "LADONGI",
		        "TURUN": 1437668000,
		        "TERTAGIH": 1211436000,
		        "PERSEN": 84.26
		    },
		    {
		        "cabang": "METRO",
		        "TURUN": 1513761000,
		        "TERTAGIH": 1268588000,
		        "PERSEN": 83.8
		    },
		    {
		        "cabang": "JATIBARANG",
		        "TURUN": 1887255000,
		        "TERTAGIH": 1579094500,
		        "PERSEN": 83.67
		    },
		    {
		        "cabang": "ENDE",
		        "TURUN": 458442000,
		        "TERTAGIH": 382284000,
		        "PERSEN": 83.39
		    },
		    {
		        "cabang": "TUGUMULYO",
		        "TURUN": 864255000,
		        "TERTAGIH": 720504000,
		        "PERSEN": 83.37
		    },
		    {
		        "cabang": "AMPANA",
		        "TURUN": 1798789500,
		        "TERTAGIH": 1499017500,
		        "PERSEN": 83.33
		    },
		    {
		        "cabang": "SORONG",
		        "TURUN": 837713000,
		        "TERTAGIH": 696759000,
		        "PERSEN": 83.17
		    },
		    {
		        "cabang": "BLANG PIDIE",
		        "TURUN": 1963926000,
		        "TERTAGIH": 1632153000,
		        "PERSEN": 83.11
		    },
		    {
		        "cabang": "PALU 2",
		        "TURUN": 5622315000,
		        "TERTAGIH": 4667391000,
		        "PERSEN": 83.02
		    },
		    {
		        "cabang": "MAGELANG",
		        "TURUN": 1328425000,
		        "TERTAGIH": 1102159000,
		        "PERSEN": 82.97
		    },
		    {
		        "cabang": "MAKASSAR 3",
		        "TURUN": 9252683500,
		        "TERTAGIH": 7677155500,
		        "PERSEN": 82.97
		    },
		    {
		        "cabang": "LAHAT",
		        "TURUN": 3131644000,
		        "TERTAGIH": 2597367000,
		        "PERSEN": 82.94
		    },
		    {
		        "cabang": "LUBUKBASUNG",
		        "TURUN": 1162490000,
		        "TERTAGIH": 964041000,
		        "PERSEN": 82.93
		    },
		    {
		        "cabang": "KAYU AGUNG",
		        "TURUN": 1041947000,
		        "TERTAGIH": 863616000,
		        "PERSEN": 82.88
		    },
		    {
		        "cabang": "LIWA",
		        "TURUN": 1017992000,
		        "TERTAGIH": 842011000,
		        "PERSEN": 82.71
		    },
		    {
		        "cabang": "GRESIK",
		        "TURUN": 843858000,
		        "TERTAGIH": 696983500,
		        "PERSEN": 82.59
		    },
		    {
		        "cabang": "CIMAHI",
		        "TURUN": 2744500500,
		        "TERTAGIH": 2263782000,
		        "PERSEN": 82.48
		    },
		    {
		        "cabang": "YOGYAKARTA",
		        "TURUN": 1447496000,
		        "TERTAGIH": 1193722000,
		        "PERSEN": 82.47
		    },
		    {
		        "cabang": "TOMPE",
		        "TURUN": 1313564000,
		        "TERTAGIH": 1081227000,
		        "PERSEN": 82.31
		    },
		    {
		        "cabang": "TARAKAN",
		        "TURUN": 1026762500,
		        "TERTAGIH": 844862000,
		        "PERSEN": 82.28
		    },
		    {
		        "cabang": "PARE-PARE",
		        "TURUN": 3131160000,
		        "TERTAGIH": 2568861000,
		        "PERSEN": 82.04
		    },
		    {
		        "cabang": "MAKASSAR",
		        "TURUN": 8856970389,
		        "TERTAGIH": 7261840389,
		        "PERSEN": 81.99
		    },
		    {
		        "cabang": "BEKASI",
		        "TURUN": 8343687000,
		        "TERTAGIH": 6830804000,
		        "PERSEN": 81.87
		    },
		    {
		        "cabang": "SIDRAP",
		        "TURUN": 3484751000,
		        "TERTAGIH": 2849617500,
		        "PERSEN": 81.77
		    },
		    {
		        "cabang": "PRABUMULIH",
		        "TURUN": 1437143000,
		        "TERTAGIH": 1172599000,
		        "PERSEN": 81.59
		    },
		    {
		        "cabang": "KENDARI",
		        "TURUN": 7063106500,
		        "TERTAGIH": 5761953500,
		        "PERSEN": 81.58
		    },
		    {
		        "cabang": "BUOL",
		        "TURUN": 2464371000,
		        "TERTAGIH": 2008882000,
		        "PERSEN": 81.52
		    },
		    {
		        "cabang": "PEMATANG SIANTAR",
		        "TURUN": 2665839000,
		        "TERTAGIH": 2172866000,
		        "PERSEN": 81.51
		    },
		    {
		        "cabang": "GOWA",
		        "TURUN": 6834261000,
		        "TERTAGIH": 5569319000,
		        "PERSEN": 81.49
		    },
		    {
		        "cabang": "KASIPUTE",
		        "TURUN": 2147647050,
		        "TERTAGIH": 1748917050,
		        "PERSEN": 81.43
		    },
		    {
		        "cabang": "BINJAI",
		        "TURUN": 1017022000,
		        "TERTAGIH": 825735000,
		        "PERSEN": 81.19
		    },
		    {
		        "cabang": "TASIKMALAYA",
		        "TURUN": 2017159000,
		        "TERTAGIH": 1634977000,
		        "PERSEN": 81.05
		    },
		    {
		        "cabang": "MAKASSAR 2",
		        "TURUN": 7611052000,
		        "TERTAGIH": 6163957000,
		        "PERSEN": 80.99
		    },
		    {
		        "cabang": "BANJARAN",
		        "TURUN": 1744968500,
		        "TERTAGIH": 1410222500,
		        "PERSEN": 80.82
		    },
		    {
		        "cabang": "SAMARINDA",
		        "TURUN": 2690285500,
		        "TERTAGIH": 2170768500,
		        "PERSEN": 80.69
		    },
		    {
		        "cabang": "BATU LICIN",
		        "TURUN": 2346358000,
		        "TERTAGIH": 1891178500,
		        "PERSEN": 80.6
		    },
		    {
		        "cabang": "TAHUNA",
		        "TURUN": 1578437500,
		        "TERTAGIH": 1270699500,
		        "PERSEN": 80.5
		    },
		    {
		        "cabang": "PAYAKUMBUH",
		        "TURUN": 891819000,
		        "TERTAGIH": 716800000,
		        "PERSEN": 80.38
		    },
		    {
		        "cabang": "TAKENGON",
		        "TURUN": 2812991000,
		        "TERTAGIH": 2260818000,
		        "PERSEN": 80.37
		    },
		    {
		        "cabang": "BONE",
		        "TURUN": 3906620100,
		        "TERTAGIH": 3131006100,
		        "PERSEN": 80.15
		    },
		    {
		        "cabang": "SRAGEN",
		        "TURUN": 965135000,
		        "TERTAGIH": 773308500,
		        "PERSEN": 80.12
		    },
		    {
		        "cabang": "PATROL",
		        "TURUN": 1494540000,
		        "TERTAGIH": 1188783000,
		        "PERSEN": 79.54
		    },
		    {
		        "cabang": "BOALEMO",
		        "TURUN": 2255248000,
		        "TERTAGIH": 1789344000,
		        "PERSEN": 79.34
		    },
		    {
		        "cabang": "TAKALAR",
		        "TURUN": 4605890500,
		        "TERTAGIH": 3648119500,
		        "PERSEN": 79.21
		    },
		    {
		        "cabang": "CIKARANG",
		        "TURUN": 2850560000,
		        "TERTAGIH": 2245645000,
		        "PERSEN": 78.78
		    },
		    {
		        "cabang": "TALAUD",
		        "TURUN": 1672545000,
		        "TERTAGIH": 1315255000,
		        "PERSEN": 78.64
		    },
		    {
		        "cabang": "SUMEDANG",
		        "TURUN": 1651679500,
		        "TERTAGIH": 1293465500,
		        "PERSEN": 78.31
		    },
		    {
		        "cabang": "RUMBIA",
		        "TURUN": 1067862000,
		        "TERTAGIH": 833528000,
		        "PERSEN": 78.06
		    },
		    {
		        "cabang": "BANJARMASIN",
		        "TURUN": 5170949000,
		        "TERTAGIH": 4034664000,
		        "PERSEN": 78.03
		    },
		    {
		        "cabang": "GORONTALO",
		        "TURUN": 5557651500,
		        "TERTAGIH": 4327874000,
		        "PERSEN": 77.87
		    },
		    {
		        "cabang": "KADIPATEN",
		        "TURUN": 1681917500,
		        "TERTAGIH": 1306709000,
		        "PERSEN": 77.69
		    },
		    {
		        "cabang": "PROBOLINGGO",
		        "TURUN": 751590500,
		        "TERTAGIH": 582615500,
		        "PERSEN": 77.52
		    },
		    {
		        "cabang": "TULUNGAGUNG",
		        "TURUN": 760406000,
		        "TERTAGIH": 589013500,
		        "PERSEN": 77.46
		    },
		    {
		        "cabang": "POLMAS",
		        "TURUN": 1738757000,
		        "TERTAGIH": 1345329000,
		        "PERSEN": 77.37
		    },
		    {
		        "cabang": "SAMARINDA SEBERANG",
		        "TURUN": 1755314000,
		        "TERTAGIH": 1357906500,
		        "PERSEN": 77.36
		    },
		    {
		        "cabang": "SERANG",
		        "TURUN": 1944336000,
		        "TERTAGIH": 1504195000,
		        "PERSEN": 77.36
		    },
		    {
		        "cabang": "MAJENE",
		        "TURUN": 1733849500,
		        "TERTAGIH": 1338563500,
		        "PERSEN": 77.2
		    },
		    {
		        "cabang": "KOTABARU",
		        "TURUN": 1378891500,
		        "TERTAGIH": 1062873500,
		        "PERSEN": 77.08
		    },
		    {
		        "cabang": "BANTAENG",
		        "TURUN": 2286983000,
		        "TERTAGIH": 1760042000,
		        "PERSEN": 76.96
		    },
		    {
		        "cabang": "BLITAR",
		        "TURUN": 1608818500,
		        "TERTAGIH": 1236866000,
		        "PERSEN": 76.88
		    },
		    {
		        "cabang": "MOROTAI",
		        "TURUN": 210649000,
		        "TERTAGIH": 161561000,
		        "PERSEN": 76.7
		    },
		    {
		        "cabang": "SINJAI",
		        "TURUN": 1759833000,
		        "TERTAGIH": 1340814000,
		        "PERSEN": 76.19
		    },
		    {
		        "cabang": "PALU",
		        "TURUN": 10581901000,
		        "TERTAGIH": 8051777000,
		        "PERSEN": 76.09
		    },
		    {
		        "cabang": "PARIAMAN",
		        "TURUN": 1207105000,
		        "TERTAGIH": 916650000,
		        "PERSEN": 75.94
		    },
		    {
		        "cabang": "NAGAN",
		        "TURUN": 1380578000,
		        "TERTAGIH": 1047878000,
		        "PERSEN": 75.9
		    },
		    {
		        "cabang": "PENAJAM",
		        "TURUN": 972517000,
		        "TERTAGIH": 737950000,
		        "PERSEN": 75.88
		    },
		    {
		        "cabang": "UJUNG BERUNG",
		        "TURUN": 1288318000,
		        "TERTAGIH": 976892000,
		        "PERSEN": 75.83
		    },
		    {
		        "cabang": "KALIANDA",
		        "TURUN": 2070085000,
		        "TERTAGIH": 1568634000,
		        "PERSEN": 75.78
		    },
		    {
		        "cabang": "INDRALAYA",
		        "TURUN": 1601018000,
		        "TERTAGIH": 1205097000,
		        "PERSEN": 75.27
		    },
		    {
		        "cabang": "ARGA MAKMUR",
		        "TURUN": 1133514000,
		        "TERTAGIH": 851492000,
		        "PERSEN": 75.12
		    },
		    {
		        "cabang": "PELABUHAN RATU",
		        "TURUN": 2965603500,
		        "TERTAGIH": 2221037500,
		        "PERSEN": 74.89
		    },
		    {
		        "cabang": "MANOKWARI",
		        "TURUN": 2300893000,
		        "TERTAGIH": 1722118000,
		        "PERSEN": 74.85
		    },
		    {
		        "cabang": "GARUT",
		        "TURUN": 2352792000,
		        "TERTAGIH": 1758761000,
		        "PERSEN": 74.75
		    },
		    {
		        "cabang": "SUKABUMI",
		        "TURUN": 1953137500,
		        "TERTAGIH": 1452715000,
		        "PERSEN": 74.38
		    },
		    {
		        "cabang": "CIANJUR",
		        "TURUN": 3014785000,
		        "TERTAGIH": 2242404500,
		        "PERSEN": 74.38
		    },
		    {
		        "cabang": "SOLOK",
		        "TURUN": 1436677000,
		        "TERTAGIH": 1065655000,
		        "PERSEN": 74.17
		    },
		    {
		        "cabang": "MASBAGIK",
		        "TURUN": 2029988000,
		        "TERTAGIH": 1504781000,
		        "PERSEN": 74.13
		    },
		    {
		        "cabang": "SOLO",
		        "TURUN": 1665886000,
		        "TERTAGIH": 1234287000,
		        "PERSEN": 74.09
		    },
		    {
		        "cabang": "PANTON LABU",
		        "TURUN": 1520002000,
		        "TERTAGIH": 1125935000,
		        "PERSEN": 74.07
		    },
		    {
		        "cabang": "LUBUK LINGGAU",
		        "TURUN": 1328290000,
		        "TERTAGIH": 974868000,
		        "PERSEN": 73.39
		    },
		    {
		        "cabang": "CILEDUG",
		        "TURUN": 1941334000,
		        "TERTAGIH": 1416606000,
		        "PERSEN": 72.97
		    },
		    {
		        "cabang": "KARAWANG",
		        "TURUN": 5484908000,
		        "TERTAGIH": 3974881000,
		        "PERSEN": 72.47
		    },
		    {
		        "cabang": "JEMBER",
		        "TURUN": 1625552500,
		        "TERTAGIH": 1177577500,
		        "PERSEN": 72.44
		    },
		    {
		        "cabang": "KUNINGAN",
		        "TURUN": 1324456500,
		        "TERTAGIH": 957499500,
		        "PERSEN": 72.29
		    },
		    {
		        "cabang": "SIDOARJO",
		        "TURUN": 1296446500,
		        "TERTAGIH": 936786500,
		        "PERSEN": 72.26
		    },
		    {
		        "cabang": "MALANG",
		        "TURUN": 1446371900,
		        "TERTAGIH": 1039369400,
		        "PERSEN": 71.86
		    },
		    {
		        "cabang": "WONOSOBO",
		        "TURUN": 2024689000,
		        "TERTAGIH": 1453504000,
		        "PERSEN": 71.79
		    },
		    {
		        "cabang": "PONTIANAK",
		        "TURUN": 432276000,
		        "TERTAGIH": 310211000,
		        "PERSEN": 71.76
		    },
		    {
		        "cabang": "MARTAPURA",
		        "TURUN": 411081000,
		        "TERTAGIH": 294114000,
		        "PERSEN": 71.55
		    },
		    {
		        "cabang": "KOTA AGUNG",
		        "TURUN": 901341000,
		        "TERTAGIH": 640576000,
		        "PERSEN": 71.07
		    },
		    {
		        "cabang": "PANGANDARAN",
		        "TURUN": 2497164000,
		        "TERTAGIH": 1768984000,
		        "PERSEN": 70.84
		    },
		    {
		        "cabang": "BACAN",
		        "TURUN": 798639000,
		        "TERTAGIH": 560842000,
		        "PERSEN": 70.22
		    },
		    {
		        "cabang": "JAMPANG",
		        "TURUN": 1162032000,
		        "TERTAGIH": 813436500,
		        "PERSEN": 70
		    },
		    {
		        "cabang": "SUBANG",
		        "TURUN": 1612843500,
		        "TERTAGIH": 1126370500,
		        "PERSEN": 69.84
		    },
		    {
		        "cabang": "SEKAYU",
		        "TURUN": 798258000,
		        "TERTAGIH": 557120000,
		        "PERSEN": 69.79
		    },
		    {
		        "cabang": "SUMBAWA",
		        "TURUN": 502720000,
		        "TERTAGIH": 349494000,
		        "PERSEN": 69.52
		    },
		    {
		        "cabang": "TUAL",
		        "TURUN": 2071567000,
		        "TERTAGIH": 1436302000,
		        "PERSEN": 69.33
		    },
		    {
		        "cabang": "BOROKO",
		        "TURUN": 856092000,
		        "TERTAGIH": 593039000,
		        "PERSEN": 69.27
		    },
		    {
		        "cabang": "TEBO",
		        "TURUN": 811426000,
		        "TERTAGIH": 561291000,
		        "PERSEN": 69.17
		    },
		    {
		        "cabang": "JAMBI",
		        "TURUN": 1673462000,
		        "TERTAGIH": 1154177000,
		        "PERSEN": 68.97
		    },
		    {
		        "cabang": "CURUP",
		        "TURUN": 1009423000,
		        "TERTAGIH": 690429000,
		        "PERSEN": 68.4
		    },
		    {
		        "cabang": "PLEIHARI",
		        "TURUN": 1413612000,
		        "TERTAGIH": 965989000,
		        "PERSEN": 68.33
		    },
		    {
		        "cabang": "LAMPUNG",
		        "TURUN": 4670717000,
		        "TERTAGIH": 3190679000,
		        "PERSEN": 68.31
		    },
		    {
		        "cabang": "PEKALONGAN",
		        "TURUN": 777742000,
		        "TERTAGIH": 529979000,
		        "PERSEN": 68.14
		    },
		    {
		        "cabang": "MEDAN",
		        "TURUN": 1759461000,
		        "TERTAGIH": 1196396000,
		        "PERSEN": 68
		    },
		    {
		        "cabang": "LUWUK",
		        "TURUN": 2762710000,
		        "TERTAGIH": 1872726000,
		        "PERSEN": 67.79
		    },
		    {
		        "cabang": "RATAHAN",
		        "TURUN": 3920179400,
		        "TERTAGIH": 2632669400,
		        "PERSEN": 67.16
		    },
		    {
		        "cabang": "MUARA TEWEH",
		        "TURUN": 2508166500,
		        "TERTAGIH": 1681391500,
		        "PERSEN": 67.04
		    },
		    {
		        "cabang": "BENGKULU",
		        "TURUN": 806303000,
		        "TERTAGIH": 539114000,
		        "PERSEN": 66.86
		    },
		    {
		        "cabang": "PARUNGKUDA",
		        "TURUN": 2726479000,
		        "TERTAGIH": 1820277500,
		        "PERSEN": 66.76
		    },
		    {
		        "cabang": "BOJONEGORO",
		        "TURUN": 597606500,
		        "TERTAGIH": 398511500,
		        "PERSEN": 66.68
		    },
		    {
		        "cabang": "LHOKSEUMAWE",
		        "TURUN": 3987093000,
		        "TERTAGIH": 2656961000,
		        "PERSEN": 66.64
		    },
		    {
		        "cabang": "BALIKPAPAN",
		        "TURUN": 2959801000,
		        "TERTAGIH": 1963962000,
		        "PERSEN": 66.35
		    },
		    {
		        "cabang": "PALEMBANG",
		        "TURUN": 5738182000,
		        "TERTAGIH": 3801697000,
		        "PERSEN": 66.25
		    },
		    {
		        "cabang": "CILACAP",
		        "TURUN": 1388952500,
		        "TERTAGIH": 919546500,
		        "PERSEN": 66.2
		    },
		    {
		        "cabang": "SAUMLAKI",
		        "TURUN": 1134241000,
		        "TERTAGIH": 745285000,
		        "PERSEN": 65.71
		    },
		    {
		        "cabang": "BETUNG",
		        "TURUN": 2197725000,
		        "TERTAGIH": 1434365000,
		        "PERSEN": 65.27
		    },
		    {
		        "cabang": "TANJUNG",
		        "TURUN": 1838713500,
		        "TERTAGIH": 1197365000,
		        "PERSEN": 65.12
		    },
		    {
		        "cabang": "WONOSARI",
		        "TURUN": 1391086000,
		        "TERTAGIH": 903845000,
		        "PERSEN": 64.97
		    },
		    {
		        "cabang": "BALARAJA",
		        "TURUN": 2110967000,
		        "TERTAGIH": 1354699000,
		        "PERSEN": 64.17
		    },
		    {
		        "cabang": "PADANG",
		        "TURUN": 2047305000,
		        "TERTAGIH": 1305140000,
		        "PERSEN": 63.75
		    },
		    {
		        "cabang": "PEKANBARU",
		        "TURUN": 2340569500,
		        "TERTAGIH": 1466788500,
		        "PERSEN": 62.67
		    },
		    {
		        "cabang": "KEBUMEN",
		        "TURUN": 670044000,
		        "TERTAGIH": 416555000,
		        "PERSEN": 62.17
		    },
		    {
		        "cabang": "MADIUN",
		        "TURUN": 934646500,
		        "TERTAGIH": 577153500,
		        "PERSEN": 61.75
		    },
		    {
		        "cabang": "TEMANGGUNG",
		        "TURUN": 2769206000,
		        "TERTAGIH": 1705991000,
		        "PERSEN": 61.61
		    },
		    {
		        "cabang": "MANADO",
		        "TURUN": 5671022000,
		        "TERTAGIH": 3463792000,
		        "PERSEN": 61.08
		    },
		    {
		        "cabang": "BARABAI",
		        "TURUN": 1377843000,
		        "TERTAGIH": 826221000,
		        "PERSEN": 59.96
		    },
		    {
		        "cabang": "TANJUNG BINTANG",
		        "TURUN": 1118331000,
		        "TERTAGIH": 659705000,
		        "PERSEN": 58.99
		    },
		    {
		        "cabang": "BUNGO",
		        "TURUN": 1170088000,
		        "TERTAGIH": 678655000,
		        "PERSEN": 58
		    },
		    {
		        "cabang": "KOTAMOBAGU",
		        "TURUN": 1712076000,
		        "TERTAGIH": 991889000,
		        "PERSEN": 57.93
		    },
		    {
		        "cabang": "SEMARANG",
		        "TURUN": 4333223000,
		        "TERTAGIH": 2496120000,
		        "PERSEN": 57.6
		    },
		    {
		        "cabang": "TEGAL",
		        "TURUN": 1680822000,
		        "TERTAGIH": 968233000,
		        "PERSEN": 57.6
		    },
		    {
		        "cabang": "PURWAKARTA",
		        "TURUN": 3650079631,
		        "TERTAGIH": 2100831631,
		        "PERSEN": 57.56
		    },
		    {
		        "cabang": "BATURAJA",
		        "TURUN": 1059103000,
		        "TERTAGIH": 606706000,
		        "PERSEN": 57.28
		    },
		    {
		        "cabang": "PURWOKERTO",
		        "TURUN": 1668394000,
		        "TERTAGIH": 940263000,
		        "PERSEN": 56.36
		    },
		    {
		        "cabang": "BAWEN",
		        "TURUN": 2393263500,
		        "TERTAGIH": 1342742000,
		        "PERSEN": 56.11
		    },
		    {
		        "cabang": "KEDIRI",
		        "TURUN": 1486269500,
		        "TERTAGIH": 791165500,
		        "PERSEN": 53.23
		    },
		    {
		        "cabang": "MOJOKERTO",
		        "TURUN": 779515000,
		        "TERTAGIH": 414314000,
		        "PERSEN": 53.15
		    },
		    {
		        "cabang": "PATI",
		        "TURUN": 1439890000,
		        "TERTAGIH": 762106000,
		        "PERSEN": 52.93
		    },
		    {
		        "cabang": "BITUNG",
		        "TURUN": 6722645500,
		        "TERTAGIH": 3484995000,
		        "PERSEN": 51.84
		    },
		    {
		        "cabang": "PANGKALAN BRANDAN",
		        "TURUN": 158207000,
		        "TERTAGIH": 81200000,
		        "PERSEN": 51.33
		    },
		    {
		        "cabang": "TOMOHON",
		        "TURUN": 1498236000,
		        "TERTAGIH": 727121500,
		        "PERSEN": 48.53
		    },
		    {
		        "cabang": "BULI",
		        "TURUN": 98723000,
		        "TERTAGIH": 24169000,
		        "PERSEN": 24.48
		    },
		    {
		        "cabang": "CINERE",
		        "TURUN": 10000,
		        "TERTAGIH": 0,
		        "PERSEN": 0
		    },
		    {
		        "cabang": "SOROLANGON",
		        "TURUN": 0,
		        "TERTAGIH": 0,
		        "PERSEN": null
		    },
		    {
		        "cabang": "MUARA BULIAN",
		        "TURUN": 0,
		        "TERTAGIH": 0,
		        "PERSEN": null
		    }
		],
        "columns": [
            { "data": "cabang" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableCollCabParetoRp').DataTable({
        "data":[
		    {
		        "pareto": "NON PARETO",
		        "TURUN": 297827829108,
		        "TERTAGIH": 241674141092,
		        "PERSEN": 81.15
		    },
		    {
		        "pareto": "PARETO",
		        "TURUN": 286888338693,
		        "TERTAGIH": 231739176693,
		        "PERSEN": 80.78
		    }
		],
        "columns": [
            { "data": "pareto" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollCabParetoKon').DataTable({
        "data":[
		    {
		        "pareto": "NON PARETO",
		        "TURUN": 297827829108,
		        "TERTAGIH": 241674141092,
		        "PERSEN": 81.15
		    },
		    {
		        "pareto": "PARETO",
		        "TURUN": 286888338693,
		        "TERTAGIH": 231739176693,
		        "PERSEN": 80.78
		    }
		],
        "columns": [
            { "data": "pareto" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollProdukRp').DataTable({
        "data":[
		    {
		        "produk": "RETENTION",
		        "TURUN": 149478053700,
		        "TERTAGIH": 122384510000,
		        "PERSEN": 81.87456751719802
		    },
		    {
		        "produk": "AISI",
		        "TURUN": 296597313212,
		        "TERTAGIH": 240848418696,
		        "PERSEN": 81.20384371919373
		    },
		    {
		        "produk": "KPM",
		        "TURUN": 138640800889,
		        "TERTAGIH": 110176215089,
		        "PERSEN": 79.46882474893549
		    }
		],
        "columns": [
            { "data": "produk" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollProdukKon').DataTable({
        "data":[
		    {
		        "produk": null,
		        "TURUN": 93336,
		        "TERTAGIH": 73933,
		        "PERSEN": 79.2117
		    },
		    {
		        "produk": "AISI",
		        "TURUN": 164245,
		        "TERTAGIH": 113823,
		        "PERSEN": 69.3007
		    },
		    {
		        "produk": "KPM",
		        "TURUN": 110549,
		        "TERTAGIH": 67777,
		        "PERSEN": 61.3095
		    },
		    {
		        "produk": "RETENTION",
		        "TURUN": 111993,
		        "TERTAGIH": 65170,
		        "PERSEN": 58.1911
		    }
		],
        "columns": [
            { "data": "produk" },
            { "data": "TURUN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "TERTAGIH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN"},
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollVin').DataTable({
        "data":[
			{"PERIODE_BOOKING":"202101","202102":0.9915,"202103":0.9505,"202104":0.9522,"202105":0.9168,"202106":0.8879,"202107":0.8709,"202108":0.8379,"202109":0.8257,"202110":0.8182,"202111":0.8079,"202112":0.8051,"202201":0.755 },
			{"PERIODE_BOOKING":"202102","202102":0.9997,"202103":0.9832,"202104":0.9734,"202105":0.9442,"202106":0.9103,"202107":0.8827,"202108":0.8696,"202109":0.8341,"202110":0.8209,"202111":0.8148,"202112":0.8096,"202201":0.7616},
			{"PERIODE_BOOKING":"202103","202102":0     ,"202103":0     ,"202104":0.9944,"202105":0.973 ,"202106":0.9398,"202107":0.914 ,"202108":0.8881,"202109":0.8695,"202110":0.8371,"202111":0.815 ,"202112":0.8165,"202201":0.7733},
			{"PERIODE_BOOKING":"202104","202102":0     ,"202103":0     ,"202104":0.9999,"202105":0.9956,"202106":0.9735,"202107":0.9441,"202108":0.9171,"202109":0.89  ,"202110":0.8718,"202111":0.8365,"202112":0.8229,"202201":0.7845},
			{"PERIODE_BOOKING":"202105","202102":0     ,"202103":0     ,"202104":0     ,"202105":0.9998,"202106":0.9956,"202107":0.9763,"202108":0.9518,"202109":0.9237,"202110":0.9002,"202111":0.8772,"202112":0.8525,"202201":0.8024},
			{"PERIODE_BOOKING":"202106","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":1     ,"202107":0.9932,"202108":0.9726,"202109":0.9442,"202110":0.9193,"202111":0.8925,"202112":0.8767,"202201":0.8183},
			{"PERIODE_BOOKING":"202107","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0.999 ,"202108":0.9933,"202109":0.9757,"202110":0.9503,"202111":0.9253,"202112":0.9063,"202201":0.8623},
			{"PERIODE_BOOKING":"202108","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0.9994,"202109":0.9944,"202110":0.9787,"202111":0.9555,"202112":0.934 ,"202201":0.8854},
			{"PERIODE_BOOKING":"202109","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":1     ,"202110":0.9941,"202111":0.9789,"202112":0.9592,"202201":0.9159},
			{"PERIODE_BOOKING":"202110","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":1     ,"202111":0.9951,"202112":0.9779,"202201":0.9381},
			{"PERIODE_BOOKING":"202111","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0.9997,"202112":0.9945,"202201":0.9684},
			{"PERIODE_BOOKING":"202112","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0     ,"202112":0.9997,"202201":0.9924}
		],
        "columns": [
            { "data": "PERIODE_BOOKING" },
            { "data": "202102", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202103", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202104", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202105", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202106", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202107", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202108", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202109", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202110", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202111", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202112", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202201", render: function ( data, type, row ) { return formatPersen(data); } },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCollVinProduk').DataTable({
        "data":[
			{"PRODUK":"AISI","PERIODE_BOOKING":"202101","202102":0.9915,"202103":0.9505,"202104":0.9522,"202105":0.9168,"202106":0.8879,"202107":0.8709,"202108":0.8379,"202109":0.8257,"202110":0.8182,"202111":0.8079,"202112":0.8051,"202201":0.755 },
			{"PRODUK":"AISI","PERIODE_BOOKING":"202102","202102":0.9997,"202103":0.9832,"202104":0.9734,"202105":0.9442,"202106":0.9103,"202107":0.8827,"202108":0.8696,"202109":0.8341,"202110":0.8209,"202111":0.8148,"202112":0.8096,"202201":0.7616},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202103","202102":0     ,"202103":0     ,"202104":0.9944,"202105":0.973 ,"202106":0.9398,"202107":0.914 ,"202108":0.8881,"202109":0.8695,"202110":0.8371,"202111":0.815 ,"202112":0.8165,"202201":0.7733},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202104","202102":0     ,"202103":0     ,"202104":0.9999,"202105":0.9956,"202106":0.9735,"202107":0.9441,"202108":0.9171,"202109":0.89  ,"202110":0.8718,"202111":0.8365,"202112":0.8229,"202201":0.7845},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202105","202102":0     ,"202103":0     ,"202104":0     ,"202105":0.9998,"202106":0.9956,"202107":0.9763,"202108":0.9518,"202109":0.9237,"202110":0.9002,"202111":0.8772,"202112":0.8525,"202201":0.8024},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202106","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":1     ,"202107":0.9932,"202108":0.9726,"202109":0.9442,"202110":0.9193,"202111":0.8925,"202112":0.8767,"202201":0.8183},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202107","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0.999 ,"202108":0.9933,"202109":0.9757,"202110":0.9503,"202111":0.9253,"202112":0.9063,"202201":0.8623},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202108","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0.9994,"202109":0.9944,"202110":0.9787,"202111":0.9555,"202112":0.934 ,"202201":0.8854},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202109","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":1     ,"202110":0.9941,"202111":0.9789,"202112":0.9592,"202201":0.9159},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202110","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":1     ,"202111":0.9951,"202112":0.9779,"202201":0.9381},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202111","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0.9997,"202112":0.9945,"202201":0.9684},
			{"PRODUK":"AISI","PERIODE_BOOKING":"202112","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0     ,"202112":0.9997,"202201":0.9924},

			{"PRODUK":"KPM","PERIODE_BOOKING":"202101","202102":0.9915,"202103":0.9505,"202104":0.9522,"202105":0.9168,"202106":0.8879,"202107":0.8709,"202108":0.8379,"202109":0.8257,"202110":0.8182,"202111":0.8079,"202112":0.8051,"202201":0.755 },
			{"PRODUK":"KPM","PERIODE_BOOKING":"202102","202102":0.9997,"202103":0.9832,"202104":0.9734,"202105":0.9442,"202106":0.9103,"202107":0.8827,"202108":0.8696,"202109":0.8341,"202110":0.8209,"202111":0.8148,"202112":0.8096,"202201":0.7616},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202103","202102":0     ,"202103":0     ,"202104":0.9944,"202105":0.973 ,"202106":0.9398,"202107":0.914 ,"202108":0.8881,"202109":0.8695,"202110":0.8371,"202111":0.815 ,"202112":0.8165,"202201":0.7733},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202104","202102":0     ,"202103":0     ,"202104":0.9999,"202105":0.9956,"202106":0.9735,"202107":0.9441,"202108":0.9171,"202109":0.89  ,"202110":0.8718,"202111":0.8365,"202112":0.8229,"202201":0.7845},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202105","202102":0     ,"202103":0     ,"202104":0     ,"202105":0.9998,"202106":0.9956,"202107":0.9763,"202108":0.9518,"202109":0.9237,"202110":0.9002,"202111":0.8772,"202112":0.8525,"202201":0.8024},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202106","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":1     ,"202107":0.9932,"202108":0.9726,"202109":0.9442,"202110":0.9193,"202111":0.8925,"202112":0.8767,"202201":0.8183},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202107","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0.999 ,"202108":0.9933,"202109":0.9757,"202110":0.9503,"202111":0.9253,"202112":0.9063,"202201":0.8623},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202108","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0.9994,"202109":0.9944,"202110":0.9787,"202111":0.9555,"202112":0.934 ,"202201":0.8854},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202109","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":1     ,"202110":0.9941,"202111":0.9789,"202112":0.9592,"202201":0.9159},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202110","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":1     ,"202111":0.9951,"202112":0.9779,"202201":0.9381},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202111","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0.9997,"202112":0.9945,"202201":0.9684},
			{"PRODUK":"KPM","PERIODE_BOOKING":"202112","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0     ,"202112":0.9997,"202201":0.9924},

			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202101","202102":0.9915,"202103":0.9505,"202104":0.9522,"202105":0.9168,"202106":0.8879,"202107":0.8709,"202108":0.8379,"202109":0.8257,"202110":0.8182,"202111":0.8079,"202112":0.8051,"202201":0.755 },
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202102","202102":0.9997,"202103":0.9832,"202104":0.9734,"202105":0.9442,"202106":0.9103,"202107":0.8827,"202108":0.8696,"202109":0.8341,"202110":0.8209,"202111":0.8148,"202112":0.8096,"202201":0.7616},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202103","202102":0     ,"202103":0     ,"202104":0.9944,"202105":0.973 ,"202106":0.9398,"202107":0.914 ,"202108":0.8881,"202109":0.8695,"202110":0.8371,"202111":0.815 ,"202112":0.8165,"202201":0.7733},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202104","202102":0     ,"202103":0     ,"202104":0.9999,"202105":0.9956,"202106":0.9735,"202107":0.9441,"202108":0.9171,"202109":0.89  ,"202110":0.8718,"202111":0.8365,"202112":0.8229,"202201":0.7845},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202105","202102":0     ,"202103":0     ,"202104":0     ,"202105":0.9998,"202106":0.9956,"202107":0.9763,"202108":0.9518,"202109":0.9237,"202110":0.9002,"202111":0.8772,"202112":0.8525,"202201":0.8024},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202106","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":1     ,"202107":0.9932,"202108":0.9726,"202109":0.9442,"202110":0.9193,"202111":0.8925,"202112":0.8767,"202201":0.8183},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202107","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0.999 ,"202108":0.9933,"202109":0.9757,"202110":0.9503,"202111":0.9253,"202112":0.9063,"202201":0.8623},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202108","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0.9994,"202109":0.9944,"202110":0.9787,"202111":0.9555,"202112":0.934 ,"202201":0.8854},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202109","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":1     ,"202110":0.9941,"202111":0.9789,"202112":0.9592,"202201":0.9159},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202110","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":1     ,"202111":0.9951,"202112":0.9779,"202201":0.9381},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202111","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0.9997,"202112":0.9945,"202201":0.9684},
			{"PRODUK":"RETENTION","PERIODE_BOOKING":"202112","202102":0     ,"202103":0     ,"202104":0     ,"202105":0     ,"202106":0     ,"202107":0     ,"202108":0     ,"202109":0     ,"202110":0     ,"202111":0     ,"202112":0.9997,"202201":0.9924}
		],
        "columns": [
            { "data": "PRODUK" },
            { "data": "PERIODE_BOOKING" },
            { "data": "202102", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202103", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202104", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202105", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202106", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202107", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202108", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202109", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202110", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202111", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202112", render: function ( data, type, row ) { return formatPersen(data); } },
            { "data": "202201", render: function ( data, type, row ) { return formatPersen(data); } },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });


});

</script>

<script type="text/javascript">
    "use strict";

$(document).ready(function () {

  var echartElemPie1 = document.getElementById('echartPie1');

  if (echartElemPie1) {
    var echartPie1 = echarts.init(echartElemPie1);
    echartPie1.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['40%','70%'],
        data: [{
		        "name": "1.NON RELAKSASI",
		        "value": 509079420267
		    },
		    {
		        "name": "2.RElAKSASI",
		        "value": 75636747534
		    }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie1.resize();
      }, 500);
    });
  } 

  var echartElemPie2 = document.getElementById('echartPie2');

  if (echartElemPie2) {
    var echartPie2 = echarts.init(echartElemPie2);
    echartPie2.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['40%','70%'],
        data: [{
		        "name": "1.NON RELAKSASI",
		        "value": 509079420267
		    },
		    {
		        "name": "2.RElAKSASI",
		        "value": 75636747534
		    }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie2.resize();
      }, 500);
    });
  } 

  var echartElemBar1 = document.getElementById('echartBar1');

  if (echartElemBar1) {
    var echartBar1 = echarts.init(echartElemBar1);
    echartBar1.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Tertagih', 'Turun', 'Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['202201','202202'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: '',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Tertagih',
        data: [432055285551,72780702400],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Turun',
        data: [509079420267,459405522217],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [84.87,15.84],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar1.resize();
      }, 500);
    });
  }

  var echartElemBar2 = document.getElementById('echartBar2');

  if (echartElemBar2) {
    var echartBar2 = echarts.init(echartElemBar2);
    echartBar2.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Tertagih', 'Turun', 'Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['202201','202202'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: '',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Tertagih',
        data: [41358032234,4742600131],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Turun',
        data: [75636747534,66962395434],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [54.68,7.08 ],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar2.resize();
      }, 500);
    });
  }

  var echartElemPie3 = document.getElementById('echartPie3');

  if (echartElemPie3) {
    var echartPie3 = echarts.init(echartElemPie3);
    echartPie3.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: '60%',
        data: [
		    {
		        "name": "KASIR",
		        "value": 254136
		    },
		    {
		        "name": "KOLEKTOR",
		        "value": 121991
		    },
		    {
		        "name": "INDOMARET",
		        "value": 60772
		    },
		    {
		        "name": "ALFAMART",
		        "value": 56468
		    },
		    {
		        "name": "POS",
		        "value": 19226
		    },
		    {
		        "name": "SHOPEE",
		        "value": 4936
		    },
		    {
		        "name": "TOKOPEDIA",
		        "value": 3198
		    },
		    {
		        "name": "COUNTER",
		        "value": 2950
		    },
		    {
		        "name": "DANA",
		        "value": 2266
		    },
		    {
		        "name": "LINKAJA",
		        "value": 1347
		    },
		    {
		        "name": "KIOS BANK",
		        "value": 106
		    },
		    {
		        "name": "VIRTUAL ACCOUNT",
		        "value": 49
		    }
		],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie3.resize();
      }, 500);
    });
  } 

});
</script>

