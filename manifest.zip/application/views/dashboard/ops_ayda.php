<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsAyda')">AYDA</a></li>
        </ul>
    </div>

    <div class="row">
    	<div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>    

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Stock TB</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Laporan TB - Per Regional</div>
                    <div class="table-responsive">
                        <table id="tableRekapTBReg" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Saldo Awal</th>
                                    <th scope="col" style="text-align: right;">Penambahan</th>
                                    <th scope="col" style="text-align: right;">Penyelesaian</th>
                                    <th scope="col" style="text-align: right;">Saldo Akhir</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Laporan TB - Per Area</div>
                    <div class="table-responsive">
                        <table id="tableRekapTBClu" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Area</th>
                                    <th scope="col" style="text-align: right;">Saldo Awal</th>
                                    <th scope="col" style="text-align: right;">Penambahan</th>
                                    <th scope="col" style="text-align: right;">Penyelesaian</th>
                                    <th scope="col" style="text-align: right;">Saldo Akhir</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Laporan TB - Per Cabang</div>
                    <div class="table-responsive">
                        <table id="tableRekapTBCab" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Saldo Awal</th>
                                    <th scope="col" style="text-align: right;">Penambahan</th>
                                    <th scope="col" style="text-align: right;">Penyelesaian</th>
                                    <th scope="col" style="text-align: right;">Saldo Akhir</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Umur TB</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Umur TB - Per Regional</div>
                    <div class="table-responsive">
                        <table id="tableRekapUmurTBReg" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">1 Bulan</th>
                                    <th scope="col" style="text-align: right;">2 Bulan</th>
                                    <th scope="col" style="text-align: right;">3 Bulan</th>
                                    <th scope="col" style="text-align: right;">>3 Bulan</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Umur TB - Per Area</div>
                    <div class="table-responsive">
                        <table id="tableRekapUmurTBClu" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Area</th>
                                    <th scope="col" style="text-align: right;">1 Bulan</th>
                                    <th scope="col" style="text-align: right;">2 Bulan</th>
                                    <th scope="col" style="text-align: right;">3 Bulan</th>
                                    <th scope="col" style="text-align: right;">>3 Bulan</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Rekap Umur TB - Per Cabang</div>
                    <div class="table-responsive">
                        <table id="tableRekapUmurTBCab" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">1 Bulan</th>
                                    <th scope="col" style="text-align: right;">2 Bulan</th>
                                    <th scope="col" style="text-align: right;">3 Bulan</th>
                                    <th scope="col" style="text-align: right;">>3 Bulan</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1."); 
        }
    }
}

$(document).ready(function () {
    $('#tableRekapTBReg').DataTable({
        "data":[
            {
                "regional": "SULAWESI 5",
                "saldo_awal": 155,
                "penambahan": 63,
                "penyelesaian": 57,
                "saldo_akhir": 161
            },
            {
                "regional": "KALIMANTAN 2",
                "saldo_awal": 26,
                "penambahan": 11,
                "penyelesaian": 10,
                "saldo_akhir": 27
            },
            {
                "regional": "KALIMANTAN 1",
                "saldo_awal": 65,
                "penambahan": 35,
                "penyelesaian": 38,
                "saldo_akhir": 62
            },
            {
                "regional": "MAPA",
                "saldo_awal": 170,
                "penambahan": 46,
                "penyelesaian": 79,
                "saldo_akhir": 137
            },
            {
                "regional": "NUSA TENGGARA",
                "saldo_awal": 23,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 27
            },
            {
                "regional": "JAWA BARAT 3",
                "saldo_awal": 20,
                "penambahan": 71,
                "penyelesaian": 45,
                "saldo_akhir": 46
            },
            {
                "regional": "JAWA BARAT 1",
                "saldo_awal": 68,
                "penambahan": 60,
                "penyelesaian": 62,
                "saldo_akhir": 66
            },
            {
                "regional": "JAWA BARAT 2",
                "saldo_awal": 26,
                "penambahan": 43,
                "penyelesaian": 37,
                "saldo_akhir": 32
            },
            {
                "regional": "JAWA TENGAH",
                "saldo_awal": 58,
                "penambahan": 28,
                "penyelesaian": 36,
                "saldo_akhir": 50
            },
            {
                "regional": "JAWA TIMUR",
                "saldo_awal": 12,
                "penambahan": 3,
                "penyelesaian": 5,
                "saldo_akhir": 10
            },
            {
                "regional": "SUMATERA 6",
                "saldo_awal": 108,
                "penambahan": 47,
                "penyelesaian": 60,
                "saldo_akhir": 95
            },
            {
                "regional": "SUMATERA 4",
                "saldo_awal": 48,
                "penambahan": 57,
                "penyelesaian": 56,
                "saldo_akhir": 49
            },
            {
                "regional": "SUMATERA 3",
                "saldo_awal": 80,
                "penambahan": 47,
                "penyelesaian": 37,
                "saldo_akhir": 90
            },
            {
                "regional": "SUMATERA 2",
                "saldo_awal": 9,
                "penambahan": 11,
                "penyelesaian": 6,
                "saldo_akhir": 14
            },
            {
                "regional": "ACEH 1",
                "saldo_awal": 45,
                "penambahan": 24,
                "penyelesaian": 37,
                "saldo_akhir": 32
            },
            {
                "regional": "ACEH 2",
                "saldo_awal": 59,
                "penambahan": 32,
                "penyelesaian": 28,
                "saldo_akhir": 63
            },
            {
                "regional": "SULAWESI 1",
                "saldo_awal": 71,
                "penambahan": 117,
                "penyelesaian": 128,
                "saldo_akhir": 60
            },
            {
                "regional": "SULAWESI 2",
                "saldo_awal": 96,
                "penambahan": 87,
                "penyelesaian": 62,
                "saldo_akhir": 121
            },
            {
                "regional": "SULAWESI 3",
                "saldo_awal": 167,
                "penambahan": 105,
                "penyelesaian": 118,
                "saldo_akhir": 154
            },
            {
                "regional": "SULAWESI 4",
                "saldo_awal": 125,
                "penambahan": 28,
                "penyelesaian": 45,
                "saldo_akhir": 108
            },
            {
                "regional": "SUMATERA 5",
                "saldo_awal": 4,
                "penambahan": 7,
                "penyelesaian": 4,
                "saldo_akhir": 7
            }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "saldo_awal", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penambahan", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penyelesaian", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "saldo_akhir", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRekapTBClu').DataTable({
        "data":[
            {
                "nmcluster": "MANADO",
                "saldo_awal": 48,
                "penambahan": 37,
                "penyelesaian": 30,
                "saldo_akhir": 55
            },
            {
                "nmcluster": "-",
                "saldo_awal": 455,
                "penambahan": 318,
                "penyelesaian": 292,
                "saldo_akhir": 481
            },
            {
                "nmcluster": "MALUKU UTARA",
                "saldo_awal": 80,
                "penambahan": 5,
                "penyelesaian": 8,
                "saldo_akhir": 77
            },
            {
                "nmcluster": "PAPUA",
                "saldo_awal": 29,
                "penambahan": 14,
                "penyelesaian": 13,
                "saldo_akhir": 30
            },
            {
                "nmcluster": "GORONTALO",
                "saldo_awal": 27,
                "penambahan": 21,
                "penyelesaian": 19,
                "saldo_akhir": 29
            },
            {
                "nmcluster": "TANGERANG RAYA",
                "saldo_awal": 7,
                "penambahan": 18,
                "penyelesaian": 10,
                "saldo_akhir": 15
            },
            {
                "nmcluster": "BEKASI RAYA",
                "saldo_awal": 13,
                "penambahan": 53,
                "penyelesaian": 35,
                "saldo_akhir": 31
            },
            {
                "nmcluster": "BOGOR RAYA",
                "saldo_awal": 31,
                "penambahan": 20,
                "penyelesaian": 25,
                "saldo_akhir": 26
            },
            {
                "nmcluster": "BANDUNG RAYA",
                "saldo_awal": 1,
                "penambahan": 10,
                "penyelesaian": 11,
                "saldo_akhir": 0
            },
            {
                "nmcluster": "PRIANGAN RAYA",
                "saldo_awal": 10,
                "penambahan": 14,
                "penyelesaian": 7,
                "saldo_akhir": 17
            },
            {
                "nmcluster": "SUKABUMI RAYA",
                "saldo_awal": 37,
                "penambahan": 40,
                "penyelesaian": 37,
                "saldo_akhir": 40
            },
            {
                "nmcluster": "PANTURA RAYA",
                "saldo_awal": 15,
                "penambahan": 19,
                "penyelesaian": 19,
                "saldo_akhir": 15
            },
            {
                "nmcluster": "SOLO",
                "saldo_awal": 11,
                "penambahan": 8,
                "penyelesaian": 12,
                "saldo_akhir": 7
            },
            {
                "nmcluster": "WONOSOBO",
                "saldo_awal": 29,
                "penambahan": 6,
                "penyelesaian": 16,
                "saldo_akhir": 19
            },
            {
                "nmcluster": "KEDIRI RAYA",
                "saldo_awal": 8,
                "penambahan": 0,
                "penyelesaian": 3,
                "saldo_akhir": 5
            },
            {
                "nmcluster": "LAMPUNG RAYA",
                "saldo_awal": 52,
                "penambahan": 28,
                "penyelesaian": 14,
                "saldo_akhir": 66
            },
            {
                "nmcluster": "LAMPUNG TENGAH",
                "saldo_awal": 29,
                "penambahan": 9,
                "penyelesaian": 17,
                "saldo_akhir": 21
            },
            {
                "nmcluster": "LAMPUNG TIMUR",
                "saldo_awal": 27,
                "penambahan": 10,
                "penyelesaian": 29,
                "saldo_akhir": 8
            },
            {
                "nmcluster": "SUMSEL RAYA",
                "saldo_awal": 20,
                "penambahan": 19,
                "penyelesaian": 23,
                "saldo_akhir": 16
            },
            {
                "nmcluster": "SUMSEL ATAS",
                "saldo_awal": 12,
                "penambahan": 17,
                "penyelesaian": 11,
                "saldo_akhir": 18
            },
            {
                "nmcluster": "SUMSEL BAWAH",
                "saldo_awal": 14,
                "penambahan": 19,
                "penyelesaian": 21,
                "saldo_akhir": 12
            },
            {
                "nmcluster": "JAMBI ATAS",
                "saldo_awal": 26,
                "penambahan": 12,
                "penyelesaian": 0,
                "saldo_akhir": 38
            },
            {
                "nmcluster": "SUMBAR UTARA",
                "saldo_awal": 12,
                "penambahan": 11,
                "penyelesaian": 12,
                "saldo_akhir": 11
            },
            {
                "nmcluster": "SUMBAR TENGAH",
                "saldo_awal": 6,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 9
            },
            {
                "nmcluster": "ACEH TIMUR",
                "saldo_awal": 15,
                "penambahan": 12,
                "penyelesaian": 14,
                "saldo_akhir": 13
            },
            {
                "nmcluster": "ACEH BARAT 1",
                "saldo_awal": 34,
                "penambahan": 6,
                "penyelesaian": 7,
                "saldo_akhir": 33
            },
            {
                "nmcluster": "ACEH BARAT 2",
                "saldo_awal": 21,
                "penambahan": 17,
                "penyelesaian": 15,
                "saldo_akhir": 23
            },
            {
                "nmcluster": "MAKASSAR",
                "saldo_awal": 25,
                "penambahan": 76,
                "penyelesaian": 83,
                "saldo_akhir": 18
            },
            {
                "nmcluster": "KENDARI",
                "saldo_awal": 106,
                "penambahan": 24,
                "penyelesaian": 40,
                "saldo_akhir": 90
            },
            {
                "nmcluster": "BUTON",
                "saldo_awal": 19,
                "penambahan": 4,
                "penyelesaian": 5,
                "saldo_akhir": 18
            },
            {
                "nmcluster": "AMBON",
                "saldo_awal": 141,
                "penambahan": 32,
                "penyelesaian": 66,
                "saldo_akhir": 107
            },
            {
                "nmcluster": "SEMARANG",
                "saldo_awal": 7,
                "penambahan": 12,
                "penyelesaian": 1,
                "saldo_akhir": 18
            },
            {
                "nmcluster": "JOGYA",
                "saldo_awal": 11,
                "penambahan": 2,
                "penyelesaian": 7,
                "saldo_akhir": 6
            },
            {
                "nmcluster": "JAMBI BAWAH",
                "saldo_awal": 19,
                "penambahan": 6,
                "penyelesaian": 17,
                "saldo_akhir": 8
            },
            {
                "nmcluster": "ACEH RAYA",
                "saldo_awal": 20,
                "penambahan": 1,
                "penyelesaian": 10,
                "saldo_akhir": 11
            },
            {
                "nmcluster": "ACEH UTARA",
                "saldo_awal": 14,
                "penambahan": 20,
                "penyelesaian": 19,
                "saldo_akhir": 15
            },
            {
                "nmcluster": "BLITAR RAYA",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 1
            },
            {
                "nmcluster": "SIDOARJO RAYA",
                "saldo_awal": 2,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 4
            }
        ],
        "columns": [
            { "data": "nmcluster" },
            { "data": "saldo_awal", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penambahan", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penyelesaian", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "saldo_akhir", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRekapTBCab').DataTable({
        "data":[
            {
                "nmcab": "TOMOHON",
                "saldo_awal": 7,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "SAMARINDA",
                "saldo_awal": 2,
                "penambahan": 3,
                "penyelesaian": 5,
                "saldo_akhir": 0
            },
            {
                "nmcab": "KOTABARU",
                "saldo_awal": 7,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 5
            },
            {
                "nmcab": "TERNATE",
                "saldo_awal": 29,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 29
            },
            {
                "nmcab": "MANOKWARI",
                "saldo_awal": 17,
                "penambahan": 9,
                "penyelesaian": 10,
                "saldo_akhir": 16
            },
            {
                "nmcab": "ENDE",
                "saldo_awal": 7,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "TOBELO",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 5
            },
            {
                "nmcab": "MASBAGIK",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "RUTENG",
                "saldo_awal": 5,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 7
            },
            {
                "nmcab": "MARISA",
                "saldo_awal": 7,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 9
            },
            {
                "nmcab": "SORONG",
                "saldo_awal": 7,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 5
            },
            {
                "nmcab": "PALANGKARAYA",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 3
            },
            {
                "nmcab": "MUARA TEWEH",
                "saldo_awal": 5,
                "penambahan": 5,
                "penyelesaian": 5,
                "saldo_akhir": 5
            },
            {
                "nmcab": "SANGATTA",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TANGERANG",
                "saldo_awal": 4,
                "penambahan": 7,
                "penyelesaian": 7,
                "saldo_akhir": 4
            },
            {
                "nmcab": "SERANG",
                "saldo_awal": 1,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BALARAJA",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BEKASI",
                "saldo_awal": 2,
                "penambahan": 17,
                "penyelesaian": 13,
                "saldo_akhir": 6
            },
            {
                "nmcab": "CIKARANG",
                "saldo_awal": 0,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "CIBINONG",
                "saldo_awal": 6,
                "penambahan": 11,
                "penyelesaian": 0,
                "saldo_akhir": 17
            },
            {
                "nmcab": "SUMEDANG",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 0
            },
            {
                "nmcab": "GARUT",
                "saldo_awal": 2,
                "penambahan": 8,
                "penyelesaian": 2,
                "saldo_akhir": 8
            },
            {
                "nmcab": "SUKABUMI",
                "saldo_awal": 13,
                "penambahan": 10,
                "penyelesaian": 14,
                "saldo_akhir": 9
            },
            {
                "nmcab": "TANGGEUNG",
                "saldo_awal": 2,
                "penambahan": 8,
                "penyelesaian": 1,
                "saldo_akhir": 9
            },
            {
                "nmcab": "PARUNGKUDA",
                "saldo_awal": 2,
                "penambahan": 14,
                "penyelesaian": 10,
                "saldo_akhir": 6
            },
            {
                "nmcab": "PELABUHAN RATU",
                "saldo_awal": 5,
                "penambahan": 5,
                "penyelesaian": 3,
                "saldo_akhir": 7
            },
            {
                "nmcab": "CIAWI",
                "saldo_awal": 1,
                "penambahan": 2,
                "penyelesaian": 1,
                "saldo_akhir": 2
            },
            {
                "nmcab": "SUBANG",
                "saldo_awal": 5,
                "penambahan": 5,
                "penyelesaian": 5,
                "saldo_akhir": 5
            },
            {
                "nmcab": "KADIPATEN",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "KUNINGAN",
                "saldo_awal": 1,
                "penambahan": 2,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "WONOGIRI",
                "saldo_awal": 9,
                "penambahan": 1,
                "penyelesaian": 10,
                "saldo_akhir": 0
            },
            {
                "nmcab": "WONOSOBO",
                "saldo_awal": 7,
                "penambahan": 2,
                "penyelesaian": 6,
                "saldo_akhir": 3
            },
            {
                "nmcab": "PURWOKERTO",
                "saldo_awal": 7,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 7
            },
            {
                "nmcab": "SRAGEN",
                "saldo_awal": 0,
                "penambahan": 6,
                "penyelesaian": 2,
                "saldo_akhir": 4
            },
            {
                "nmcab": "MOJOKERTO",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "KEBUMEN",
                "saldo_awal": 3,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 2
            },
            {
                "nmcab": "LAMPUNG",
                "saldo_awal": 9,
                "penambahan": 21,
                "penyelesaian": 0,
                "saldo_akhir": 30
            },
            {
                "nmcab": "TULANG BAWANG",
                "saldo_awal": 5,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BANDAR JAYA",
                "saldo_awal": 13,
                "penambahan": 2,
                "penyelesaian": 13,
                "saldo_akhir": 2
            },
            {
                "nmcab": "WAY JEPARA",
                "saldo_awal": 4,
                "penambahan": 0,
                "penyelesaian": 4,
                "saldo_akhir": 0
            },
            {
                "nmcab": "RAWAJITU",
                "saldo_awal": 6,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "PALEMBANG",
                "saldo_awal": 13,
                "penambahan": 17,
                "penyelesaian": 21,
                "saldo_akhir": 9
            },
            {
                "nmcab": "BABAT TOMAN",
                "saldo_awal": 4,
                "penambahan": 0,
                "penyelesaian": 3,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BETUNG",
                "saldo_awal": 0,
                "penambahan": 13,
                "penyelesaian": 6,
                "saldo_akhir": 7
            },
            {
                "nmcab": "LAHAT",
                "saldo_awal": 5,
                "penambahan": 10,
                "penyelesaian": 9,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "saldo_awal": 6,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 7
            },
            {
                "nmcab": "TUNGKAL",
                "saldo_awal": 10,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 11
            },
            {
                "nmcab": "SABAK",
                "saldo_awal": 4,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 7
            },
            {
                "nmcab": "SOLOK",
                "saldo_awal": 3,
                "penambahan": 6,
                "penyelesaian": 3,
                "saldo_akhir": 6
            },
            {
                "nmcab": "LUBUKBASUNG",
                "saldo_awal": 3,
                "penambahan": 6,
                "penyelesaian": 3,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BUKITTINGGI",
                "saldo_awal": 5,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 7
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BINJAI",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "IDIE",
                "saldo_awal": 6,
                "penambahan": 3,
                "penyelesaian": 5,
                "saldo_akhir": 4
            },
            {
                "nmcab": "NAGAN",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BLANG PIDIE",
                "saldo_awal": 7,
                "penambahan": 5,
                "penyelesaian": 8,
                "saldo_akhir": 4
            },
            {
                "nmcab": "ARGA MAKMUR",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "PEKANBARU",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 1
            },
            {
                "nmcab": "MAKASSAR",
                "saldo_awal": 13,
                "penambahan": 25,
                "penyelesaian": 31,
                "saldo_akhir": 7
            },
            {
                "nmcab": "JENEPONTO",
                "saldo_awal": 3,
                "penambahan": 2,
                "penyelesaian": 3,
                "saldo_akhir": 2
            },
            {
                "nmcab": "MAMUJU",
                "saldo_awal": 4,
                "penambahan": 6,
                "penyelesaian": 2,
                "saldo_akhir": 8
            },
            {
                "nmcab": "PARIGI",
                "saldo_awal": 22,
                "penambahan": 9,
                "penyelesaian": 21,
                "saldo_akhir": 10
            },
            {
                "nmcab": "LUWUK",
                "saldo_awal": 9,
                "penambahan": 5,
                "penyelesaian": 6,
                "saldo_akhir": 8
            },
            {
                "nmcab": "PANGKEP",
                "saldo_awal": 3,
                "penambahan": 0,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "MANGKUTANA",
                "saldo_awal": 3,
                "penambahan": 4,
                "penyelesaian": 3,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BONE",
                "saldo_awal": 8,
                "penambahan": 4,
                "penyelesaian": 7,
                "saldo_akhir": 5
            },
            {
                "nmcab": "POLMAS",
                "saldo_awal": 5,
                "penambahan": 7,
                "penyelesaian": 4,
                "saldo_akhir": 8
            },
            {
                "nmcab": "ENREKANG",
                "saldo_awal": 3,
                "penambahan": 12,
                "penyelesaian": 1,
                "saldo_akhir": 14
            },
            {
                "nmcab": "MOROWALI",
                "saldo_awal": 4,
                "penambahan": 3,
                "penyelesaian": 1,
                "saldo_akhir": 6
            },
            {
                "nmcab": "KOTARAYA",
                "saldo_awal": 27,
                "penambahan": 0,
                "penyelesaian": 26,
                "saldo_akhir": 1
            },
            {
                "nmcab": "TOPPOYO",
                "saldo_awal": 4,
                "penambahan": 2,
                "penyelesaian": 4,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TOMPE",
                "saldo_awal": 8,
                "penambahan": 0,
                "penyelesaian": 8,
                "saldo_akhir": 0
            },
            {
                "nmcab": "MAROS",
                "saldo_awal": 14,
                "penambahan": 11,
                "penyelesaian": 14,
                "saldo_akhir": 11
            },
            {
                "nmcab": "MAJENE",
                "saldo_awal": 12,
                "penambahan": 1,
                "penyelesaian": 10,
                "saldo_akhir": 3
            },
            {
                "nmcab": "MALILI",
                "saldo_awal": 7,
                "penambahan": 4,
                "penyelesaian": 6,
                "saldo_akhir": 5
            },
            {
                "nmcab": "BUNGKU",
                "saldo_awal": 8,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 12
            },
            {
                "nmcab": "PALU 2",
                "saldo_awal": 18,
                "penambahan": 19,
                "penyelesaian": 17,
                "saldo_akhir": 20
            },
            {
                "nmcab": "MAKASSAR 3",
                "saldo_awal": 2,
                "penambahan": 8,
                "penyelesaian": 9,
                "saldo_akhir": 1
            },
            {
                "nmcab": "MALINO",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "MAKALE",
                "saldo_awal": 11,
                "penambahan": 2,
                "penyelesaian": 6,
                "saldo_akhir": 7
            },
            {
                "nmcab": "SELAYAR",
                "saldo_awal": 6,
                "penambahan": 4,
                "penyelesaian": 6,
                "saldo_akhir": 4
            },
            {
                "nmcab": "GOWA 2",
                "saldo_awal": 2,
                "penambahan": 10,
                "penyelesaian": 12,
                "saldo_akhir": 0
            },
            {
                "nmcab": "KASIPUTE",
                "saldo_awal": 22,
                "penambahan": 5,
                "penyelesaian": 0,
                "saldo_akhir": 27
            },
            {
                "nmcab": "EREKE",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "KENDARI",
                "saldo_awal": 19,
                "penambahan": 10,
                "penyelesaian": 18,
                "saldo_akhir": 11
            },
            {
                "nmcab": "MAKASSAR 2",
                "saldo_awal": 8,
                "penambahan": 18,
                "penyelesaian": 16,
                "saldo_akhir": 10
            },
            {
                "nmcab": "LADONGI",
                "saldo_awal": 10,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 14
            },
            {
                "nmcab": "KOLAKA",
                "saldo_awal": 9,
                "penambahan": 2,
                "penyelesaian": 3,
                "saldo_akhir": 8
            },
            {
                "nmcab": "PUNGGALUKU",
                "saldo_awal": 22,
                "penambahan": 0,
                "penyelesaian": 9,
                "saldo_akhir": 13
            },
            {
                "nmcab": "BOEPINANG",
                "saldo_awal": 12,
                "penambahan": 2,
                "penyelesaian": 3,
                "saldo_akhir": 11
            },
            {
                "nmcab": "PENAJAM",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "BOALEMO",
                "saldo_awal": 9,
                "penambahan": 8,
                "penyelesaian": 4,
                "saldo_akhir": 13
            },
            {
                "nmcab": "MARTAPURA KAL",
                "saldo_awal": 3,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 6
            },
            {
                "nmcab": "PLEIHARI",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 5,
                "saldo_akhir": 0
            },
            {
                "nmcab": "TANJUNG",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 0
            },
            {
                "nmcab": "BANJARMASIN",
                "saldo_awal": 18,
                "penambahan": 19,
                "penyelesaian": 21,
                "saldo_akhir": 16
            },
            {
                "nmcab": "NAMLEA",
                "saldo_awal": 22,
                "penambahan": 6,
                "penyelesaian": 9,
                "saldo_akhir": 19
            },
            {
                "nmcab": "KOTAMOBAGU",
                "saldo_awal": 6,
                "penambahan": 4,
                "penyelesaian": 6,
                "saldo_akhir": 4
            },
            {
                "nmcab": "MANADO",
                "saldo_awal": 16,
                "penambahan": 8,
                "penyelesaian": 10,
                "saldo_akhir": 14
            },
            {
                "nmcab": "JAYAPURA",
                "saldo_awal": 5,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 9
            },
            {
                "nmcab": "LABUAN BAJO",
                "saldo_awal": 10,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 10
            },
            {
                "nmcab": "GORONTALO",
                "saldo_awal": 7,
                "penambahan": 10,
                "penyelesaian": 15,
                "saldo_akhir": 2
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 2
            },
            {
                "nmcab": "BERAU",
                "saldo_awal": 5,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "CILEDUG",
                "saldo_awal": 0,
                "penambahan": 7,
                "penyelesaian": 1,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BOGOR",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 4,
                "saldo_akhir": 1
            },
            {
                "nmcab": "LEUWILIANG",
                "saldo_awal": 18,
                "penambahan": 7,
                "penyelesaian": 18,
                "saldo_akhir": 7
            },
            {
                "nmcab": "CILEUNGSI",
                "saldo_awal": 3,
                "penambahan": 11,
                "penyelesaian": 3,
                "saldo_akhir": 11
            },
            {
                "nmcab": "CIMAHI",
                "saldo_awal": 0,
                "penambahan": 3,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "CIANJUR",
                "saldo_awal": 10,
                "penambahan": 2,
                "penyelesaian": 4,
                "saldo_akhir": 8
            },
            {
                "nmcab": "PANGANDARAN",
                "saldo_awal": 1,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 1
            },
            {
                "nmcab": "CIREBON",
                "saldo_awal": 2,
                "penambahan": 7,
                "penyelesaian": 7,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TEGAL",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "PATROL",
                "saldo_awal": 4,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 4
            },
            {
                "nmcab": "YOGYAKARTA",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "SEMARANG",
                "saldo_awal": 5,
                "penambahan": 6,
                "penyelesaian": 0,
                "saldo_akhir": 11
            },
            {
                "nmcab": "BAWEN",
                "saldo_awal": 1,
                "penambahan": 4,
                "penyelesaian": 1,
                "saldo_akhir": 4
            },
            {
                "nmcab": "TEMANGGUNG",
                "saldo_awal": 5,
                "penambahan": 0,
                "penyelesaian": 5,
                "saldo_akhir": 0
            },
            {
                "nmcab": "MADIUN",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "KOTABUMI",
                "saldo_awal": 5,
                "penambahan": 2,
                "penyelesaian": 1,
                "saldo_akhir": 6
            },
            {
                "nmcab": "PRINGSEWU",
                "saldo_awal": 9,
                "penambahan": 1,
                "penyelesaian": 9,
                "saldo_akhir": 1
            },
            {
                "nmcab": "KOTA AGUNG",
                "saldo_awal": 11,
                "penambahan": 3,
                "penyelesaian": 3,
                "saldo_akhir": 11
            },
            {
                "nmcab": "RUMBIA",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 4,
                "saldo_akhir": 1
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "saldo_awal": 8,
                "penambahan": 4,
                "penyelesaian": 10,
                "saldo_akhir": 2
            },
            {
                "nmcab": "LIWA",
                "saldo_awal": 8,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 9
            },
            {
                "nmcab": "DAYA MURNI",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "INDRALAYA",
                "saldo_awal": 3,
                "penambahan": 2,
                "penyelesaian": 1,
                "saldo_akhir": 4
            },
            {
                "nmcab": "MARTAPURA",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "TOBOALI",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "JAMBI",
                "saldo_awal": 12,
                "penambahan": 8,
                "penyelesaian": 0,
                "saldo_akhir": 20
            },
            {
                "nmcab": "TEBO",
                "saldo_awal": 2,
                "penambahan": 4,
                "penyelesaian": 2,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BANGKO",
                "saldo_awal": 10,
                "penambahan": 2,
                "penyelesaian": 8,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BATU SANGKAR",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "KOTOBARU",
                "saldo_awal": 6,
                "penambahan": 2,
                "penyelesaian": 6,
                "saldo_akhir": 2
            },
            {
                "nmcab": "PANTON LABU",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "ACEH",
                "saldo_awal": 9,
                "penambahan": 0,
                "penyelesaian": 9,
                "saldo_akhir": 0
            },
            {
                "nmcab": "MEULABOH",
                "saldo_awal": 23,
                "penambahan": 5,
                "penyelesaian": 7,
                "saldo_akhir": 21
            },
            {
                "nmcab": "ALUE BILIE",
                "saldo_awal": 8,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "TAKENGON",
                "saldo_awal": 4,
                "penambahan": 9,
                "penyelesaian": 6,
                "saldo_akhir": 7
            },
            {
                "nmcab": "PARE-PARE",
                "saldo_awal": 8,
                "penambahan": 13,
                "penyelesaian": 8,
                "saldo_akhir": 13
            },
            {
                "nmcab": "PALU",
                "saldo_awal": 24,
                "penambahan": 33,
                "penyelesaian": 19,
                "saldo_akhir": 38
            },
            {
                "nmcab": "TORAJA",
                "saldo_awal": 8,
                "penambahan": 15,
                "penyelesaian": 0,
                "saldo_akhir": 23
            },
            {
                "nmcab": "TOLI TOLI",
                "saldo_awal": 7,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 6
            },
            {
                "nmcab": "MASAMBA",
                "saldo_awal": 4,
                "penambahan": 5,
                "penyelesaian": 2,
                "saldo_akhir": 7
            },
            {
                "nmcab": "PINRANG",
                "saldo_awal": 4,
                "penambahan": 3,
                "penyelesaian": 1,
                "saldo_akhir": 6
            },
            {
                "nmcab": "SIDRAP",
                "saldo_awal": 4,
                "penambahan": 6,
                "penyelesaian": 1,
                "saldo_akhir": 9
            },
            {
                "nmcab": "POSO",
                "saldo_awal": 6,
                "penambahan": 4,
                "penyelesaian": 4,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BUNTA",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "TAKALAR",
                "saldo_awal": 7,
                "penambahan": 8,
                "penyelesaian": 6,
                "saldo_akhir": 9
            },
            {
                "nmcab": "SOPPENG",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "BANTAENG",
                "saldo_awal": 3,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 5
            },
            {
                "nmcab": "TENTENA",
                "saldo_awal": 7,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 7
            },
            {
                "nmcab": "BUTON",
                "saldo_awal": 9,
                "penambahan": 0,
                "penyelesaian": 4,
                "saldo_akhir": 5
            },
            {
                "nmcab": "BATU LICIN",
                "saldo_awal": 17,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 18
            },
            {
                "nmcab": "MASOHI",
                "saldo_awal": 21,
                "penambahan": 7,
                "penyelesaian": 7,
                "saldo_akhir": 21
            },
            {
                "nmcab": "TUAL",
                "saldo_awal": 24,
                "penambahan": 0,
                "penyelesaian": 5,
                "saldo_akhir": 19
            },
            {
                "nmcab": "SAUMLAKI",
                "saldo_awal": 45,
                "penambahan": 8,
                "penyelesaian": 26,
                "saldo_akhir": 27
            },
            {
                "nmcab": "TAHUNA",
                "saldo_awal": 24,
                "penambahan": 0,
                "penyelesaian": 2,
                "saldo_akhir": 22
            },
            {
                "nmcab": "BITUNG",
                "saldo_awal": 11,
                "penambahan": 20,
                "penyelesaian": 8,
                "saldo_akhir": 23
            },
            {
                "nmcab": "SIAU",
                "saldo_awal": 7,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "RATAHAN",
                "saldo_awal": 8,
                "penambahan": 4,
                "penyelesaian": 6,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BOROKO",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "DOMPU",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "JAILOLO",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 4,
                "saldo_akhir": 1
            },
            {
                "nmcab": "SAMPIT",
                "saldo_awal": 4,
                "penambahan": 4,
                "penyelesaian": 1,
                "saldo_akhir": 7
            },
            {
                "nmcab": "PARUNG",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 1
            },
            {
                "nmcab": "KARAWANG",
                "saldo_awal": 6,
                "penambahan": 13,
                "penyelesaian": 15,
                "saldo_akhir": 4
            },
            {
                "nmcab": "PURWAKARTA",
                "saldo_awal": 2,
                "penambahan": 9,
                "penyelesaian": 4,
                "saldo_akhir": 7
            },
            {
                "nmcab": "CILACAP",
                "saldo_awal": 7,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 7
            },
            {
                "nmcab": "MALANG",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "KEDIRI",
                "saldo_awal": 4,
                "penambahan": 0,
                "penyelesaian": 3,
                "saldo_akhir": 1
            },
            {
                "nmcab": "KALIANDA",
                "saldo_awal": 11,
                "penambahan": 5,
                "penyelesaian": 11,
                "saldo_akhir": 5
            },
            {
                "nmcab": "KAYU AGUNG",
                "saldo_awal": 3,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "BATURAJA",
                "saldo_awal": 5,
                "penambahan": 2,
                "penyelesaian": 6,
                "saldo_akhir": 1
            },
            {
                "nmcab": "SEKAYU",
                "saldo_awal": 2,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 2
            },
            {
                "nmcab": "BANGKA",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 1
            },
            {
                "nmcab": "MENTOK",
                "saldo_awal": 1,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "LANGSA ACEH",
                "saldo_awal": 2,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 2
            },
            {
                "nmcab": "SIGLI",
                "saldo_awal": 11,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 11
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "saldo_awal": 6,
                "penambahan": 7,
                "penyelesaian": 5,
                "saldo_akhir": 8
            },
            {
                "nmcab": "KOTA FAJAR",
                "saldo_awal": 14,
                "penambahan": 12,
                "penyelesaian": 7,
                "saldo_akhir": 19
            },
            {
                "nmcab": "BIREUEN",
                "saldo_awal": 4,
                "penambahan": 4,
                "penyelesaian": 4,
                "saldo_akhir": 4
            },
            {
                "nmcab": "LHOKSUKON",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BENGKULU",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BUOL",
                "saldo_awal": 10,
                "penambahan": 5,
                "penyelesaian": 0,
                "saldo_akhir": 15
            },
            {
                "nmcab": "TOILI",
                "saldo_awal": 0,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "GOWA",
                "saldo_awal": 0,
                "penambahan": 15,
                "penyelesaian": 15,
                "saldo_akhir": 0
            },
            {
                "nmcab": "DONGGALA",
                "saldo_awal": 8,
                "penambahan": 9,
                "penyelesaian": 8,
                "saldo_akhir": 9
            },
            {
                "nmcab": "SALAKAN",
                "saldo_awal": 7,
                "penambahan": 5,
                "penyelesaian": 7,
                "saldo_akhir": 5
            },
            {
                "nmcab": "BACAN",
                "saldo_awal": 4,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "RAHA",
                "saldo_awal": 8,
                "penambahan": 4,
                "penyelesaian": 1,
                "saldo_akhir": 11
            },
            {
                "nmcab": "KAPUAS",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TARAKAN",
                "saldo_awal": 8,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 8
            },
            {
                "nmcab": "AMBON",
                "saldo_awal": 26,
                "penambahan": 11,
                "penyelesaian": 18,
                "saldo_akhir": 19
            },
            {
                "nmcab": "TENGGARONG",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 2,
                "saldo_akhir": 2
            },
            {
                "nmcab": "BANDUNG",
                "saldo_awal": 1,
                "penambahan": 2,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "BANJARAN",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "JAMPANG",
                "saldo_awal": 5,
                "penambahan": 1,
                "penyelesaian": 5,
                "saldo_akhir": 1
            },
            {
                "nmcab": "WONOSARI",
                "saldo_awal": 5,
                "penambahan": 1,
                "penyelesaian": 5,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BLITAR",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "saldo_awal": 5,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 5
            },
            {
                "nmcab": "WAY KANAN",
                "saldo_awal": 10,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 9
            },
            {
                "nmcab": "PRABUMULIH",
                "saldo_awal": 1,
                "penambahan": 4,
                "penyelesaian": 3,
                "saldo_akhir": 2
            },
            {
                "nmcab": "JEBUS",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 1
            },
            {
                "nmcab": "PASAMAN",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "PADANG",
                "saldo_awal": 5,
                "penambahan": 2,
                "penyelesaian": 4,
                "saldo_akhir": 3
            },
            {
                "nmcab": "KUALA SIMPANG",
                "saldo_awal": 5,
                "penambahan": 7,
                "penyelesaian": 5,
                "saldo_akhir": 7
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "saldo_awal": 4,
                "penambahan": 6,
                "penyelesaian": 7,
                "saldo_akhir": 3
            },
            {
                "nmcab": "SENGKANG",
                "saldo_awal": 9,
                "penambahan": 0,
                "penyelesaian": 8,
                "saldo_akhir": 1
            },
            {
                "nmcab": "AMPANA",
                "saldo_awal": 1,
                "penambahan": 5,
                "penyelesaian": 0,
                "saldo_akhir": 6
            },
            {
                "nmcab": "BARRU",
                "saldo_awal": 4,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 2
            },
            {
                "nmcab": "SINJAI",
                "saldo_awal": 0,
                "penambahan": 3,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "LASUSUA",
                "saldo_awal": 4,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "MOROTAI",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "WAISARISSA",
                "saldo_awal": 3,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TALAUD",
                "saldo_awal": 5,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 5
            },
            {
                "nmcab": "TASIKMALAYA",
                "saldo_awal": 6,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 6
            },
            {
                "nmcab": "JATIBARANG",
                "saldo_awal": 1,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "SIDOARJO",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "JEMBER",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "METRO",
                "saldo_awal": 0,
                "penambahan": 3,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "TUGUMULYO",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 0
            },
            {
                "nmcab": "BELINYU",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "MEDAN",
                "saldo_awal": 0,
                "penambahan": 3,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "PALOPO",
                "saldo_awal": 0,
                "penambahan": 4,
                "penyelesaian": 0,
                "saldo_akhir": 4
            },
            {
                "nmcab": "BELOPA",
                "saldo_awal": 3,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 1
            },
            {
                "nmcab": "UNAAHA",
                "saldo_awal": 8,
                "penambahan": 1,
                "penyelesaian": 7,
                "saldo_akhir": 2
            },
            {
                "nmcab": "UJUNG BERUNG",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 2,
                "saldo_akhir": 0
            },
            {
                "nmcab": "PATI",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "MUARA ENIM",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 3,
                "saldo_akhir": 0
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "saldo_awal": 0,
                "penambahan": 2,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "UJUNG GADING",
                "saldo_awal": 7,
                "penambahan": 5,
                "penyelesaian": 0,
                "saldo_akhir": 12
            },
            {
                "nmcab": "PARIAMAN",
                "saldo_awal": 1,
                "penambahan": 1,
                "penyelesaian": 1,
                "saldo_akhir": 1
            },
            {
                "nmcab": "SIJUNGJUNG",
                "saldo_awal": 3,
                "penambahan": 3,
                "penyelesaian": 3,
                "saldo_akhir": 3
            },
            {
                "nmcab": "BULUKUMBA",
                "saldo_awal": 1,
                "penambahan": 5,
                "penyelesaian": 0,
                "saldo_akhir": 6
            },
            {
                "nmcab": "MOLIBAGU",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BALIKPAPAN",
                "saldo_awal": 1,
                "penambahan": 2,
                "penyelesaian": 1,
                "saldo_akhir": 2
            },
            {
                "nmcab": "BARABAI",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 0
            },
            {
                "nmcab": "BOYOLALI",
                "saldo_awal": 2,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 3
            },
            {
                "nmcab": "MAGELANG",
                "saldo_awal": 3,
                "penambahan": 0,
                "penyelesaian": 2,
                "saldo_akhir": 1
            },
            {
                "nmcab": "SUNGAI LILIN",
                "saldo_awal": 0,
                "penambahan": 1,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BUNGO",
                "saldo_awal": 7,
                "penambahan": 0,
                "penyelesaian": 7,
                "saldo_akhir": 0
            },
            {
                "nmcab": "CURUP",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 0
            },
            {
                "nmcab": "BULI",
                "saldo_awal": 2,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 2
            },
            {
                "nmcab": "TANAH GROGOT",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "PASANGKAYU",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 0,
                "saldo_akhir": 1
            },
            {
                "nmcab": "BANGKALA",
                "saldo_awal": 1,
                "penambahan": 0,
                "penyelesaian": 1,
                "saldo_akhir": 0
            }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "saldo_awal", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penambahan", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "penyelesaian", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "saldo_akhir", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRekapUmurTBReg').DataTable({
        "data":[
          {
            "regional": "SULAWESI5",
            "1BULAN": 55,
            "2BULAN": 11,
            "3BULAN": 9,
            ">3BULAN": 86
          },
          {
            "regional": "KALIMANTAN2",
            "1BULAN": 7,
            "2BULAN": 5,
            "3BULAN": 2,
            ">3BULAN": 13
          },
          {
            "regional": "KALIMANTAN1",
            "1BULAN": 33,
            "2BULAN": 6,
            "3BULAN": 9,
            ">3BULAN": 14
          },
          {
            "regional": "MAPA",
            "1BULAN": 59,
            "2BULAN": 13,
            "3BULAN": 19,
            ">3BULAN": 46
          },
          {
            "regional": "NUSATENGGARA",
            "1BULAN": 4,
            "2BULAN": 1,
            "3BULAN": 3,
            ">3BULAN": 19
          },
          {
            "regional": "JAWABARAT3",
            "1BULAN": 45,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "regional": "JAWABARAT1",
            "1BULAN": 47,
            "2BULAN": 8,
            "3BULAN": 4,
            ">3BULAN": 7
          },
          {
            "regional": "JAWABARAT2",
            "1BULAN": 26,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "regional": "JAWATENGAH",
            "1BULAN": 32,
            "2BULAN": 7,
            "3BULAN": 2,
            ">3BULAN": 9
          },
          {
            "regional": "JAWATIMUR",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 5
          },
          {
            "regional": "SUMATERA6",
            "1BULAN": 47,
            "2BULAN": 9,
            "3BULAN": 4,
            ">3BULAN": 35
          },
          {
            "regional": "SUMATERA4",
            "1BULAN": 36,
            "2BULAN": 2,
            "3BULAN": 3,
            ">3BULAN": 8
          },
          {
            "regional": "SUMATERA3",
            "1BULAN": 58,
            "2BULAN": 7,
            "3BULAN": 8,
            ">3BULAN": 17
          },
          {
            "regional": "SUMATERA2",
            "1BULAN": 10,
            "2BULAN": 3,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "regional": "ACEH1",
            "1BULAN": 20,
            "2BULAN": 3,
            "3BULAN": 6,
            ">3BULAN": 3
          },
          {
            "regional": "ACEH2",
            "1BULAN": 30,
            "2BULAN": 3,
            "3BULAN": 9,
            ">3BULAN": 21
          },
          {
            "regional": "SULAWESI1",
            "1BULAN": 51,
            "2BULAN": 2,
            "3BULAN": 3,
            ">3BULAN": 4
          },
          {
            "regional": "SULAWESI2",
            "1BULAN": 89,
            "2BULAN": 14,
            "3BULAN": 11,
            ">3BULAN": 7
          },
          {
            "regional": "SULAWESI3",
            "1BULAN": 103,
            "2BULAN": 15,
            "3BULAN": 11,
            ">3BULAN": 25
          },
          {
            "regional": "SULAWESI4",
            "1BULAN": 29,
            "2BULAN": 10,
            "3BULAN": 11,
            ">3BULAN": 58
          },
          {
            "regional": "SUMATERA5",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "1BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "2BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": ">3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRekapUmurTBClu').DataTable({
        "data":[
          {
            "nmcluster": "MANADO",
            "1BULAN": 38,
            "2BULAN": 8,
            "3BULAN": 1,
            ">3BULAN": 8
          },
          {
            "nmcluster": "-",
            "1BULAN": 308,
            "2BULAN": 50,
            "3BULAN": 42,
            ">3BULAN": 81
          },
          {
            "nmcluster": "MALUKUUTARA",
            "1BULAN": 5,
            "2BULAN": 3,
            "3BULAN": 5,
            ">3BULAN": 64
          },
          {
            "nmcluster": "PAPUA",
            "1BULAN": 17,
            "2BULAN": 5,
            "3BULAN": 0,
            ">3BULAN": 8
          },
          {
            "nmcluster": "GORONTALO",
            "1BULAN": 12,
            "2BULAN": 0,
            "3BULAN": 3,
            ">3BULAN": 14
          },
          {
            "nmcluster": "TANGERANGRAYA",
            "1BULAN": 14,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "BEKASIRAYA",
            "1BULAN": 31,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "BOGORRAYA",
            "1BULAN": 20,
            "2BULAN": 4,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcluster": "BANDUNGRAYA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "PRIANGANRAYA",
            "1BULAN": 16,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "SUKABUMIRAYA",
            "1BULAN": 27,
            "2BULAN": 4,
            "3BULAN": 3,
            ">3BULAN": 6
          },
          {
            "nmcluster": "PANTURARAYA",
            "1BULAN": 10,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcluster": "SOLO",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "WONOSOBO",
            "1BULAN": 8,
            "2BULAN": 2,
            "3BULAN": 2,
            ">3BULAN": 7
          },
          {
            "nmcluster": "KEDIRIRAYA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 5
          },
          {
            "nmcluster": "LAMPUNGRAYA",
            "1BULAN": 30,
            "2BULAN": 8,
            "3BULAN": 4,
            ">3BULAN": 24
          },
          {
            "nmcluster": "LAMPUNGTENGAH",
            "1BULAN": 9,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 11
          },
          {
            "nmcluster": "LAMPUNGTIMUR",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "SUMSELRAYA",
            "1BULAN": 12,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 2
          },
          {
            "nmcluster": "SUMSELATAS",
            "1BULAN": 13,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 3
          },
          {
            "nmcluster": "SUMSELBAWAH",
            "1BULAN": 9,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 3
          },
          {
            "nmcluster": "JAMBIATAS",
            "1BULAN": 15,
            "2BULAN": 2,
            "3BULAN": 5,
            ">3BULAN": 16
          },
          {
            "nmcluster": "SUMBARUTARA",
            "1BULAN": 11,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "SUMBARTENGAH",
            "1BULAN": 7,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcluster": "ACEHTIMUR",
            "1BULAN": 12,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "ACEHBARAT1",
            "1BULAN": 15,
            "2BULAN": 0,
            "3BULAN": 9,
            ">3BULAN": 9
          },
          {
            "nmcluster": "ACEHBARAT2",
            "1BULAN": 8,
            "2BULAN": 3,
            "3BULAN": 0,
            ">3BULAN": 12
          },
          {
            "nmcluster": "MAKASSAR",
            "1BULAN": 15,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcluster": "KENDARI",
            "1BULAN": 25,
            "2BULAN": 8,
            "3BULAN": 10,
            ">3BULAN": 47
          },
          {
            "nmcluster": "BUTON",
            "1BULAN": 4,
            "2BULAN": 2,
            "3BULAN": 1,
            ">3BULAN": 11
          },
          {
            "nmcluster": "AMBON",
            "1BULAN": 42,
            "2BULAN": 8,
            "3BULAN": 19,
            ">3BULAN": 38
          },
          {
            "nmcluster": "SEMARANG",
            "1BULAN": 14,
            "2BULAN": 4,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "JOGYA",
            "1BULAN": 3,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcluster": "JAMBIBAWAH",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "ACEHRAYA",
            "1BULAN": 1,
            "2BULAN": 2,
            "3BULAN": 6,
            ">3BULAN": 2
          },
          {
            "nmcluster": "ACEHUTARA",
            "1BULAN": 14,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcluster": "BLITARRAYA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcluster": "SIDOARJORAYA",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          }
        ],
        "columns": [
            { "data": "nmcluster" },
            { "data": "1BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "2BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": ">3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRekapUmurTBCab').DataTable({
        "data":[
          {
            "nmcab": "TOMOHON",
            "1BULAN": 1,
            "2BULAN": 2,
            "3BULAN": 1,
            ">3BULAN": 4
          },
          {
            "nmcab": "SAMARINDA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KOTABARU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 3
          },
          {
            "nmcab": "TERNATE",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 3,
            ">3BULAN": 24
          },
          {
            "nmcab": "MANOKWARI",
            "1BULAN": 12,
            "2BULAN": 4,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "ENDE",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 3,
            ">3BULAN": 4
          },
          {
            "nmcab": "TOBELO",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 2
          },
          {
            "nmcab": "MASBAGIK",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "RUTENG",
            "1BULAN": 2,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "MARISA",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 6
          },
          {
            "nmcab": "SORONG",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 3
          },
          {
            "nmcab": "PALANGKARAYA",
            "1BULAN": 1,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MUARATEWEH",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SANGATTA",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TANGERANG",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SERANG",
            "1BULAN": 3,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BALARAJA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BEKASI",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CIKARANG",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CIBINONG",
            "1BULAN": 12,
            "2BULAN": 4,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "SUMEDANG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "GARUT",
            "1BULAN": 7,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SUKABUMI",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "TANGGEUNG",
            "1BULAN": 7,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PARUNGKUDA",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "PELABUHANRATU",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcab": "CIAWI",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SUBANG",
            "1BULAN": 2,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "KADIPATEN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KUNINGAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "WONOGIRI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "WONOSOBO",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PURWOKERTO",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 4
          },
          {
            "nmcab": "SRAGEN",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MOJOKERTO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "KEBUMEN",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LAMPUNG",
            "1BULAN": 21,
            "2BULAN": 7,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcab": "TULANGBAWANG",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 3
          },
          {
            "nmcab": "BANDARJAYA",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "WAYJEPARA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "RAWAJITU",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 6
          },
          {
            "nmcab": "PALEMBANG",
            "1BULAN": 9,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BABATTOMAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "BETUNG",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LAHAT",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BAYUNGLENCIR",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 2
          },
          {
            "nmcab": "TUNGKAL",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 3,
            ">3BULAN": 6
          },
          {
            "nmcab": "SABAK",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "SOLOK",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LUBUKBASUNG",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BUKITTINGGI",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "PANGKALANBRANDAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "BINJAI",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "IDIE",
            "1BULAN": 3,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "NAGAN",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 3,
            ">3BULAN": 0
          },
          {
            "nmcab": "BLANGPIDIE",
            "1BULAN": 2,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "ARGAMAKMUR",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PEKANBARU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAKASSAR",
            "1BULAN": 6,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "JENEPONTO",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAMUJU",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PARIGI",
            "1BULAN": 9,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LUWUK",
            "1BULAN": 3,
            "2BULAN": 3,
            "3BULAN": 2,
            ">3BULAN": 0
          },
          {
            "nmcab": "PANGKEP",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MANGKUTANA",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BONE",
            "1BULAN": 4,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "POLMAS",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "ENREKANG",
            "1BULAN": 12,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "MOROWALI",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 1
          },
          {
            "nmcab": "KOTARAYA",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TOPPOYO",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TOMPE",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAROS",
            "1BULAN": 11,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAJENE",
            "1BULAN": 1,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MALILI",
            "1BULAN": 4,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BUNGKU",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 8
          },
          {
            "nmcab": "PALU2",
            "1BULAN": 19,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "MAKASSAR3",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MALINO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAKALE",
            "1BULAN": 2,
            "2BULAN": 4,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SELAYAR",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "GOWA2",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KASIPUTE",
            "1BULAN": 6,
            "2BULAN": 3,
            "3BULAN": 3,
            ">3BULAN": 15
          },
          {
            "nmcab": "EREKE",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "KENDARI",
            "1BULAN": 10,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "MAKASSAR2",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcab": "LADONGI",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 8
          },
          {
            "nmcab": "KOLAKA",
            "1BULAN": 2,
            "2BULAN": 3,
            "3BULAN": 1,
            ">3BULAN": 2
          },
          {
            "nmcab": "PUNGGALUKU",
            "1BULAN": 0,
            "2BULAN": 2,
            "3BULAN": 3,
            ">3BULAN": 8
          },
          {
            "nmcab": "BOEPINANG",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 8
          },
          {
            "nmcab": "PENAJAM",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "BOALEMO",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 3
          },
          {
            "nmcab": "MARTAPURAKAL",
            "1BULAN": 3,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 1
          },
          {
            "nmcab": "PLEIHARI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TANJUNG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANJARMASIN",
            "1BULAN": 16,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "NAMLEA",
            "1BULAN": 6,
            "2BULAN": 7,
            "3BULAN": 2,
            ">3BULAN": 4
          },
          {
            "nmcab": "KOTAMOBAGU",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MANADO",
            "1BULAN": 7,
            "2BULAN": 4,
            "3BULAN": 0,
            ">3BULAN": 3
          },
          {
            "nmcab": "JAYAPURA",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 5
          },
          {
            "nmcab": "LABUANBAJO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 10
          },
          {
            "nmcab": "GORONTALO",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SAMARINDASEBERANG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "BERAU",
            "1BULAN": 3,
            "2BULAN": 1,
            "3BULAN": 2,
            ">3BULAN": 2
          },
          {
            "nmcab": "CILEDUG",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BOGOR",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LEUWILIANG",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CILEUNGSI",
            "1BULAN": 11,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CIMAHI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CIANJUR",
            "1BULAN": 3,
            "2BULAN": 2,
            "3BULAN": 2,
            ">3BULAN": 1
          },
          {
            "nmcab": "PANGANDARAN",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CIREBON",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TEGAL",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PATROL",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "YOGYAKARTA",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "SEMARANG",
            "1BULAN": 8,
            "2BULAN": 3,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BAWEN",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TEMANGGUNG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MADIUN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "KOTABUMI",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "PRINGSEWU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KOTAAGUNG",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 5
          },
          {
            "nmcab": "RUMBIA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TANJUNGBINTANG",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LIWA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 6
          },
          {
            "nmcab": "DAYAMURNI",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "INDRALAYA",
            "1BULAN": 2,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "MARTAPURA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "TOBOALI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "JAMBI",
            "1BULAN": 8,
            "2BULAN": 2,
            "3BULAN": 2,
            ">3BULAN": 8
          },
          {
            "nmcab": "TEBO",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANGKO",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BATUSANGKAR",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KOTOBARU",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PANTONLABU",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "ACEH",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MEULABOH",
            "1BULAN": 14,
            "2BULAN": 0,
            "3BULAN": 5,
            ">3BULAN": 2
          },
          {
            "nmcab": "ALUEBILIE",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 7
          },
          {
            "nmcab": "TAKENGON",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PARE-PARE",
            "1BULAN": 13,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PALU",
            "1BULAN": 33,
            "2BULAN": 4,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "TORAJA",
            "1BULAN": 15,
            "2BULAN": 0,
            "3BULAN": 8,
            ">3BULAN": 0
          },
          {
            "nmcab": "TOLITOLI",
            "1BULAN": 0,
            "2BULAN": 5,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "MASAMBA",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "PINRANG",
            "1BULAN": 3,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SIDRAP",
            "1BULAN": 6,
            "2BULAN": 3,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "POSO",
            "1BULAN": 4,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "BUNTA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "TAKALAR",
            "1BULAN": 8,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SOPPENG",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANTAENG",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 1
          },
          {
            "nmcab": "TENTENA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 2,
            ">3BULAN": 5
          },
          {
            "nmcab": "BUTON",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "BATULICIN",
            "1BULAN": 1,
            "2BULAN": 3,
            "3BULAN": 6,
            ">3BULAN": 8
          },
          {
            "nmcab": "MASOHI",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 6,
            ">3BULAN": 8
          },
          {
            "nmcab": "TUAL",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 4,
            ">3BULAN": 10
          },
          {
            "nmcab": "SAUMLAKI",
            "1BULAN": 13,
            "2BULAN": 0,
            "3BULAN": 6,
            ">3BULAN": 8
          },
          {
            "nmcab": "TAHUNA",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 21
          },
          {
            "nmcab": "BITUNG",
            "1BULAN": 20,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SIAU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 6
          },
          {
            "nmcab": "RATAHAN",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BOROKO",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 3
          },
          {
            "nmcab": "DOMPU",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "JAILOLO",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SAMPIT",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "PARUNG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "KARAWANG",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PURWAKARTA",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CILACAP",
            "1BULAN": 2,
            "2BULAN": 1,
            "3BULAN": 1,
            ">3BULAN": 3
          },
          {
            "nmcab": "MALANG",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KEDIRI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "KALIANDA",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KAYUAGUNG",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "BATURAJA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SEKAYU",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANGKA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MENTOK",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LANGSAACEH",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SIGLI",
            "1BULAN": 1,
            "2BULAN": 2,
            "3BULAN": 6,
            ">3BULAN": 2
          },
          {
            "nmcab": "PEMATANGSIANTAR",
            "1BULAN": 6,
            "2BULAN": 2,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "KOTAFAJAR",
            "1BULAN": 6,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 12
          },
          {
            "nmcab": "BIREUEN",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LHOKSUKON",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BENGKULU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BUOL",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 4,
            ">3BULAN": 6
          },
          {
            "nmcab": "TOILI",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "GOWA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "DONGGALA",
            "1BULAN": 9,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SALAKAN",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BACAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "RAHA",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 6
          },
          {
            "nmcab": "KAPUAS",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "TARAKAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 8
          },
          {
            "nmcab": "AMBON",
            "1BULAN": 11,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 7
          },
          {
            "nmcab": "TENGGARONG",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANDUNG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANJARAN",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "JAMPANG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "WONOSARI",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BLITAR",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SIMPANGPEMATANG",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "WAYKANAN",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 8
          },
          {
            "nmcab": "PRABUMULIH",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "JEBUS",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PASAMAN",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "PADANG",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "KUALASIMPANG",
            "1BULAN": 7,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LHOKSEUMAWE",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "SENGKANG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "AMPANA",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "BARRU",
            "1BULAN": 1,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SINJAI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LASUSUA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "MOROTAI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "WAISARISSA",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "TALAUD",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 4
          },
          {
            "nmcab": "TASIKMALAYA",
            "1BULAN": 6,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "JATIBARANG",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SIDOARJO",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "JEMBER",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "METRO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "TUGUMULYO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BELINYU",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MEDAN",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PALOPO",
            "1BULAN": 4,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BELOPA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "UNAAHA",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "UJUNGBERUNG",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PATI",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MUARAENIM",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "LUBUKLINGGAU",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "UJUNGGADING",
            "1BULAN": 7,
            "2BULAN": 4,
            "3BULAN": 1,
            ">3BULAN": 0
          },
          {
            "nmcab": "PARIAMAN",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SIJUNGJUNG",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BULUKUMBA",
            "1BULAN": 5,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "MOLIBAGU",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 1
          },
          {
            "nmcab": "BALIKPAPAN",
            "1BULAN": 2,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BARABAI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BOYOLALI",
            "1BULAN": 3,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "MAGELANG",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "SUNGAILILIN",
            "1BULAN": 1,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BUNGO",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "CURUP",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BULI",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 2
          },
          {
            "nmcab": "TANAHGROGOT",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "PASANGKAYU",
            "1BULAN": 0,
            "2BULAN": 1,
            "3BULAN": 0,
            ">3BULAN": 0
          },
          {
            "nmcab": "BANGKALA",
            "1BULAN": 0,
            "2BULAN": 0,
            "3BULAN": 0,
            ">3BULAN": 0
          }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "1BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "2BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": ">3BULAN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });
});
</script>