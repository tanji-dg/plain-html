<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsUnhealtyMonitoring')">Unhealty Monitoring</a></li>
        </ul>
    </div>

    <div class="row">

    	<div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>

        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>

        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>

    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Growth</h1>

    <div class="row">
        <div class="col-lg-4 col-sm-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Sales by Countries</div>
                    <div id="echartPie1" style="height: 300px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Prima</div>
                    <div class="table-responsive">
                        <table id="tableGrowthPrima" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Sehat</div>
                    <div class="table-responsive">
                        <table id="tableGrowthSehat" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Sakit</div>
                    <div class="table-responsive">
                        <table id="tableGrowthPrima" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Coll & NCL</h1>

    <div class="row">
        <div class="col-lg-4 col-sm-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Sales by Countries</div>
                    <div id="echartPie2" style="height: 300px;"></div>
                </div>
            </div>
        </div>
    </div>

    

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Prima</div>
                    <div class="table-responsive">
                        <table id="tableGrowthPrima" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Sehat</div>
                    <div class="table-responsive">
                        <table id="tableGrowthSehat" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Sakit</div>
                    <div class="table-responsive">
                        <table id="tableGrowthPrima" class="table">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Cabang</th>
                                    <th scope="col" colspan="12" style="text-align: center;">Periode</th>
                                </tr>
                                <tr> 
                                    <th scope="col">202101</th>
                                    <th scope="col">202102</th>
                                    <th scope="col">202103</th>
                                    <th scope="col">202104</th>
                                    <th scope="col">202105</th>
                                    <th scope="col">202106</th>
                                    <th scope="col">202107</th>
                                    <th scope="col">202108</th>
                                    <th scope="col">202109</th>
                                    <th scope="col">202110</th>
                                    <th scope="col">202111</th>
                                    <th scope="col">202112</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.");
        }
    }
}

function formatPersen(data){
    var num = data * 100;

    return num.toFixed(2);
}


$(document).ready(function () {

});
</script>
<script type="text/javascript">
    "use strict";

$(document).ready(function () {
  var echartElemPie1 = document.getElementById('echartPie1');

  if (echartElemPie1) {
    var echartPie1 = echarts.init(echartElemPie1);
    echartPie1.setOption({
      color: ['#62549c', '#7566b5', '#7d6cbb', '#8877bd', '#9181bd', '#6957af'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      series: [{
        name: 'Sales by Country',
        type: 'pie',
        radius: '60%',
        center: ['50%', '50%'],
        data: [{
          value: 535,
          name: 'USA'
        }, {
          value: 310,
          name: 'Brazil'
        }, {
          value: 234,
          name: 'France'
        }, {
          value: 155,
          name: 'BD'
        }, {
          value: 130,
          name: 'UK'
        }, {
          value: 348,
          name: 'India'
        }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie1.resize();
      }, 500);
    });
  }

  var echartElemPie2 = document.getElementById('echartPie2');

  if (echartElemPie2) {
    var echartPie2 = echarts.init(echartElemPie2);
    echartPie2.setOption({
      color: ['#62549c', '#7566b5', '#7d6cbb', '#8877bd', '#9181bd', '#6957af'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      series: [{
        name: 'Sales by Country',
        type: 'pie',
        radius: '60%',
        center: ['50%', '50%'],
        data: [{
          value: 535,
          name: 'USA'
        }, {
          value: 310,
          name: 'Brazil'
        }, {
          value: 234,
          name: 'France'
        }, {
          value: 155,
          name: 'BD'
        }, {
          value: 130,
          name: 'UK'
        }, {
          value: 348,
          name: 'India'
        }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie2.resize();
      }, 500);
    });
  }
});
</script>
