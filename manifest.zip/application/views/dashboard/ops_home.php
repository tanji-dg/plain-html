<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsHome')">Home</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>AR</h1>
    <div class="row">
        <!-- ICON BG-->

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Money-2"></i>
                    <p class="text-muted mt-5 mb-2">% Rp.</p>
                    <p class="text-primary text-24 line-height-1 m-0">98.3%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">4.86T</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">4.94T</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Add-User"></i>
                    <p class="text-muted mt-5 mb-2">% Konsumen</p>
                    <p class="text-primary text-24 line-height-1 m-0">97.9%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2"><?php echo $this->Global_model->shortNumber(524843);?></p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2"><?php echo $this->Global_model->shortNumber(535877);?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-4">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">AR Konsumen Per Produk</div>
                    <div id="echartPie" style="height: 100%;min-height:120px;"></div>
                </div>
            </div>
        </div>
        
        
    </div>


    <div class="separator-breadcrumb border-top"></div>

    <h1>Booking</h1>
    <div class="row">
        <!-- ICON BG-->

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Money-2"></i>
                    <p class="text-muted mt-5 mb-2">% Rp. - MTD</p>
                    <p class="text-primary text-24 line-height-1 m-0">89.7%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">462B</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">515B</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Add-User"></i>
                    <p class="text-muted mt-5 mb-2">% Konsumen - MTD</p>
                    <p class="text-primary text-24 line-height-1 m-0">89.9%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">37,195</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">41,356</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-4">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Per Produk rp. -MTD</div>
                    <div id="echartBar1" style="height: 100%;min-height:120px;"></div>
                </div>
            </div>
        </div>
        
        
    </div>

    <div class="row">
        <!-- ICON BG-->

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Money-2"></i>
                    <p class="text-muted mt-5 mb-2">% Rp. - YTD</p>
                    <p class="text-primary text-24 line-height-1 m-0">89.7%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">462B</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">515B</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-3 col-sm-3">
            <div class="card card-icon mb-4 mt-10" style="height:90%;">
                <div class="card-body text-center"><i class="i-Add-User"></i>
                    <p class="text-muted mt-5 mb-2">% Konsumen - YTD</p>
                    <p class="text-primary text-24 line-height-1 m-0">89.9%</p>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">37,195</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">41,356</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-4">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Per Produk rp. -YTD</div>
                    <div id="echartBar2" style="height: 100%;min-height:120px;"></div>
                </div>
            </div>
        </div>
        
        
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <h1>Collection</h1>
    <div class="row">
        <!-- ICON BG-->

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Financial" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">% Actual</p>
                        <p class="text-primary text-18 line-height-1 mb-2">80.96%</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center"><i class="i-Money-2" style="font-size:3rem !important;"></i>
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">% Budget</p>
                        <p class="text-primary text-18 line-height-1 mb-2">No Data</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-10 col-md-10">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Collection </div>
                    <div id="echartBar3" style="height: 100%;min-height:120px;"></div>
                </div>
            </div>
        </div>
        
        
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Collection Vintage Premature</div>
                    <div id="echartHeat1" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Collection Vintage Premature(Produk)</div>
                    <div id="echartHeat2" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Collection Vintage Premature - Total</div>
                    <div id="echartHeat3" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Collection Vintage Premature</div>
                    <div id="echartHeat4" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <h1>NCL - NET CREDIT LOSS</h1>

    <div class="row">
        <!-- ICON BG-->
        
        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4" style="height:90%;">
                <div class="card-body text-center">
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">% NCL</p>
                        <p class="text-primary text-18 line-height-1 mb-2">2.51%</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">% WO</p>
                        <p class="text-primary text-18 line-height-1 mb-2">2.15%</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">% Rugi TB</p>
                        <p class="text-primary text-18 line-height-1 mb-2">0.36%</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8 col-md-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend NCL</div>
                    <div id="echartBar4" style="height: 100%;min-height:120px;"></div>
                </div>
            </div>
        </div>
        
        
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <h1>Ratio & Produktivitas SDM</h1>

    <div class="row">
        <!-- ICON BG-->
        
        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content" style="max-width:100px !important;">
                        <p class="text-muted mt-2 mb-0 text-center">Actual Ratio</p>
                        <p class="text-primary text-18 line-height-1 mb-2 text-center">120</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Total</p>
                        <p class="text-primary text-18 line-height-1 mb-2">4,375</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content" style="max-width:100px !important;">
                        <p class="text-muted mt-2 mb-0">Budget Ratio</p>
                        <p class="text-primary text-18 line-height-1 mb-2">86</p>
                    </div>
                </div>
            </div>

            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body text-center">
                    <div class="content">
                        <p class="text-muted mt-2 mb-0">Total</p>
                        <p class="text-primary text-18 line-height-1 mb-2">6,258</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8 col-md-8">
            <div class="card mb-4"  style="height:215px;">
                <div class="card-body">
                    <div class="card-title">Produktivitas SDM</div>
                    <div class="table-responsive">
                        <table id="tableProduktivitasSdm"class="table">
                            <thead>
                                <tr>
                                    <th scope="col">SDM</th>
                                    <th scope="col" style="text-align: right;">Budget</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Variance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">Collection</td>
                                    <td style="text-align: right;">243.36</td>
                                    <td style="text-align: right;">0</td>
                                    <td style="text-align: right;">-243.36</td>
                                </tr>
                                <tr>
                                    <td scope="row">Operation</td>
                                    <td style="text-align: right;">235.86</td>
                                    <td style="text-align: right;">0</td>
                                    <td style="text-align: right;">-235.86</td>
                                </tr>
                                <tr>
                                    <td scope="row">Credit</td>
                                    <td style="text-align: right;">81.96</td>
                                    <td style="text-align: right;">68.47</td>
                                    <td style="text-align: right;">-13.49</td>
                                </tr>
                                <tr>
                                    <td scope="row">Sales</td>
                                    <td style="text-align: right;">71.52</td>
                                    <td style="text-align: right;">75.65</td>
                                    <td style="text-align: right;">4.12</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        
    </div>


</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

    function formatPrice(data){
        var num;
        var num1;
        if(data == null) { 
            return '-'; 
        } else { 
            num = Math.round(data);
            if(num.toString().length > 9) {
                num1 = num / 1000000000;
                return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
            } else if(num.toString().length > 6) {
                num1 = num / 1000000;
                return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
            } else if(num.toString().length > 3) {
                num1 = num / 1000;
                return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
            } else {
                return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.");
            }
        }
    }

    $(document).ready(function () {
        $('#tableProduktivitasSdm').DataTable({
            "searching":false,
            "paging":false,
            "sorting":false,
            "info":false
        })
});
</script>
<script type="text/javascript">
    "use strict";

$(document).ready(function () {

  var echartElemPie = document.getElementById('echartPie');

  if (echartElemPie) {
    var echartPie = echarts.init(echartElemPie);
    echartPie.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['40%','70%'],
        data: [{
          value: 151,
          name: 'RETENTION'
        }, {
          value: 212,
          name: 'AISI'
        }, {
          value: 162,
          name: 'KPM'
        }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie.resize();
      }, 500);
    });
  } 
  
  var echartElemBar1 = document.getElementById('echartBar1');

  if (echartElemBar1) {
    var echartBar1 = echarts.init(echartElemBar1);
    echartBar1.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target','Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['AISI', 'KPM', 'RETENTION'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [226, 113, 123],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [236, 166, 115],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [96.44, 67.91, 107.22],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar1.resize();
      }, 500);
    });
  }

  var echartElemBar2 = document.getElementById('echartBar2');

  if (echartElemBar2) {
    var echartBar2 = echarts.init(echartElemBar2);
    echartBar2.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target','Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['AISI', 'KPM', 'RETENTION'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [226, 113, 123],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [236, 166, 115],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [96.44, 67.91, 107.22],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar2.resize();
      }, 500);
    });
  }

  var echartElemBar3 = document.getElementById('echartBar3');

  if (echartElemBar3) {
    var echartBar3 = echarts.init(echartElemBar3);
    echartBar3.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Tertagih', 'Turun','Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['202201','202202'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Tertagih',
        data: [473,23],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Turun',
        data: [585,520],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [80.96,4.44],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar3.resize();
      }, 500);
    });
  }

  var echartElemHeat1 = document.getElementById('echartHeat1');

  if (echartElemHeat1) {
    var echartHeat1 = echarts.init(echartElemHeat1);
    echartHeat1.setOption({
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '50%',
        top: '10%'
      },
      xAxis: {
        type: 'category',
        data: ['202102','202103','202104','202105','202106','202107','202108','202109','202110','202111','202112','202201'],
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: ['202201'],
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 85,
        max: 100,
        calculable: true,
        orient: 'vertical',
        right: 'right',
        itemHeight: 110,
        inRange : {   
            color: ['#a50026', '#fee08b', '#006837'], //From smaller to bigger value ->
        }
      },
      series: [
        {
          name: 'Persen',
          type: 'heatmap',
          data: [[0, 0, 93.00],[1, 0, 91.26], [2, 0, 93.87], [3, 0, 93.15], [4, 0, 92.74], [5, 0, 92.68], [6, 0, 92.76], [7, 0, 92.62], [8, 0, 93.07], [9, 0, 93.52], [10, 0, 94.06], [11, 0, 92.79]],
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartHeat1.resize();
      }, 500);
    });
  } 

  var echartElemHeat2 = document.getElementById('echartHeat2');

  if (echartElemHeat2) {
    var echartHeat2 = echarts.init(echartElemHeat2);
    echartHeat2.setOption({
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '50%',
        top: '10%'
      },
      xAxis: {
        type: 'category',
        data: ['202102','202103','202104','202105','202106','202107','202108','202109','202110','202111','202112','202201'],
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: ['AISI','KPM','RETENTION'],
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 85,
        max: 100,
        calculable: true,
        orient: 'vertical',
        right: 'right',
        itemHeight: 110,
        inRange : {   
            color: ['#a50026', '#fee08b', '#006837'], //From smaller to bigger value ->
        }
      },
      series: [
        {
          name: 'Persen',
          type: 'heatmap',
          data: [
          [0, 0, 93.91],[1, 0, 92.88], [2, 0, 93.85], [3, 0, 93.57], [4, 0, 93.45], [5, 0, 93.13], [6, 0, 92.99], [7, 0, 92.84], [8, 0, 93.46], [9, 0, 94.21], [10, 0, 94.96], [11, 0, 94.49],
          [0, 1, 91.92],[1, 1, 90.60], [2, 1, 93.94], [3, 1, 92.71], [4, 1, 91.82], [5, 1, 91.91], [6, 1, 92.09], [7, 1, 91.77], [8, 1, 92.04], [9, 1, 92.42], [10, 1, 92.63], [11, 1, 90.56],
          [0, 2, 92.57],[1, 2, 89.97], [2, 2, 93.85], [3, 2, 92.98], [4, 2, 92.64], [5, 2, 92.88], [6, 2, 93.16], [7, 2, 93.26], [8, 2, 93.67], [9, 2, 93.79], [10, 2, 94.44], [11, 2, 92.93]
          ],
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartHeat2.resize();
      }, 500);
    });
  } 

  var echartElemHeat3 = document.getElementById('echartHeat3');

  if (echartElemHeat3) {
    var echartHeat3 = echarts.init(echartElemHeat3);
    echartHeat3.setOption({
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '50%',
        top: '10%'
      },
      xAxis: {
        type: 'category',
        data: ['202108','202109','202110','202111','202112','202201'],
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: ['202201'],
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 85,
        max: 100,
        calculable: true,
        orient: 'vertical',
        right: 'right',
        itemHeight: 110,
        inRange : {   
            color: ['#a50026', '#fee08b', '#006837'], //From smaller to bigger value ->
        }
      },
      series: [
        {
          name: 'Persen',
          type: 'heatmap',
          data: [[0, 0, 99.46],[1, 0, 98.60], [2, 0, 97.57], [3, 0, 96.58], [4, 0, 95.70], [5, 0, 92.79]],
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartHeat3.resize();
      }, 500);
    });
  } 

  var echartElemHeat4 = document.getElementById('echartHeat4');

  if (echartElemHeat4) {
    var echartHeat4 = echarts.init(echartElemHeat4);
    echartHeat4.setOption({
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '80%',
        top: '0%'
      },
      xAxis: {
        type: 'category',
        data: ['202108','202109','202110','202111','202112','202201'],
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: ['202107','202108','202109','202110','202111','202112'],
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 85,
        max: 100,
        calculable: true,
        orient: 'vertical',
        right: 'right',
        itemHeight: 110,
        inRange : {   
            color: ['#a50026', '#fee08b', '#006837'], //From smaller to bigger value ->
        }
      },
      series: [
        {
          name: 'Persen',
          type: 'heatmap',
          data: [
          [4, 0, 99.97],[5, 0, 99.23],
          [3, 1, 99.97],[4, 1, 99.45], [5, 1, 96.84],
          [2, 2, 100]  ,[3, 2, 99.51], [4, 2, 97.79], [5, 2, 93.81],
          [1, 3, 100]  ,[2, 3, 99.41], [3, 3, 97.89], [4, 3, 95.92], [5, 3, 91.59],
          [0, 4, 99.94],[1, 4, 99.44], [2, 4, 97.87], [3, 4, 95.55], [4, 4, 93.40], [5, 4, 88.54],
          [0, 5, 99.33],[1, 5, 97.57], [2, 5, 95.03], [3, 5, 92.53], [4, 5, 90.63], [5, 5, 86.23],
          ],
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartHeat4.resize();
      }, 500);
    });
  } 

  var echartElemBar4 = document.getElementById('echartBar4');

  if (echartElemBar4) {
    var echartBar4 = echarts.init(echartElemBar4);
    echartBar4.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['WO', 'Rugi TB','Total NCL']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['202201','202202','202203','202204','202205','202206','202207','202208','202209','202210','202211','202212'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'WO',
        data: [221],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Rugi TB',
        data: [36.7],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Total NCL',
        yAxisIndex: 1,
        data: [2.51],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar4.resize();
      }, 500);
    });
  }


});

  
</script>