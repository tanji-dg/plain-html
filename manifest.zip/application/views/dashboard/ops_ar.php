<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsAr')">AR</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend AR - Rp.</div>
                    <div id="echartBar1" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend AR - Konsumen</div>
                    <div id="echartBar2" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>AR (Produk, Wilayah, Pareto)</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">AR Per Produk - Rp.</div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">AISI</td>
                                    <td style="text-align: right;">3.06T</td>
                                    <td style="text-align: right;">3T</td>
                                    <td style="text-align: right;">99.2</td>
                                </tr>
                                <tr>
                                    <td scope="row">KPM</td>
                                    <td style="text-align: right;">968B</td>
                                    <td style="text-align: right;">907B</td>
                                    <td style="text-align: right;">93.7</td>
                                </tr>
                                <tr>
                                    <td scope="row">Retention</td>
                                    <td style="text-align: right;">952B</td>
                                    <td style="text-align: right;">953B</td>
                                    <td style="text-align: right;">100.1</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">AR Per Produk - Konsumen</div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">AISI</td>
                                    <td style="text-align: right;">212k</td>
                                    <td style="text-align: right;">212k</td>
                                    <td style="text-align: right;">99.9</td>
                                </tr>
                                <tr>
                                    <td scope="row">KPM</td>
                                    <td style="text-align: right;">170k</td>
                                    <td style="text-align: right;">162k</td>
                                    <td style="text-align: right;">95.1</td>
                                </tr>
                                <tr>
                                    <td scope="row">Retention</td>
                                    <td style="text-align: right;">153k</td>
                                    <td style="text-align: right;">151k</td>
                                    <td style="text-align: right;">98.3</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">AR Per Regional - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableArRegRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">AR Per Regional - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableArRegKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:280px;">
                <div class="card-body">
                    <div class="card-title">AR Per Cabang - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableArCabRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:280px;">
                <div class="card-body">
                    <div class="card-title">AR Per Cabang - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableArCabKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">AR Cabang Pareto - Rp.</div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">Pareto</td>
                                    <td style="text-align: right;">2.51T</td>
                                    <td style="text-align: right;">2.45T</td>
                                    <td style="text-align: right;">97.8</td>
                                </tr>
                                <tr>
                                    <td scope="row">Non Pareto</td>
                                    <td style="text-align: right;">2.43T</td>
                                    <td style="text-align: right;">2.4T</td>
                                    <td style="text-align: right;">98.8</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">AR Cabang Pareto - Konsumen</div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">Pareto</td>
                                    <td style="text-align: right;">283k</td>
                                    <td style="text-align: right;">276k</td>
                                    <td style="text-align: right;">97.6</td>
                                </tr>
                                <tr>
                                    <td scope="row">Non Pareto</td>
                                    <td style="text-align: right;">253k</td>
                                    <td style="text-align: right;">249k</td>
                                    <td style="text-align: right;">98.3</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>AR Per Bucket OD</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:350px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableBucketRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Bucket</th>
                                    <th scope="col" style="text-align: right;">Rupiah</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:350px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableBucketKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Bucket</th>
                                    <th scope="col" style="text-align: right;">Konsumen</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:420px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD Per Regional - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableBucketRegRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col" colspan="8" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col">Bucket</th>
                                    <th scope="col">Lancar</th>
                                    <th scope="col">OD1</th>
                                    <th scope="col">OD2</th>
                                    <th scope="col">OD3</th>
                                    <th scope="col">OD4</th>
                                    <th scope="col">OD5</th>
                                    <th scope="col">OD6</th>
                                    <th scope="col">ODLB6</th>
                                </tr>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:420px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD Per Regional - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableBucketRegKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col" colspan="8" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col">Bucket</th>
                                    <th scope="col">Lancar</th>
                                    <th scope="col">OD1</th>
                                    <th scope="col">OD2</th>
                                    <th scope="col">OD3</th>
                                    <th scope="col">OD4</th>
                                    <th scope="col">OD5</th>
                                    <th scope="col">OD6</th>
                                    <th scope="col">ODLB6</th>
                                </tr>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:420px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD Per Cabang - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableBucketCabRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col" colspan="8" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col">Bucket</th>
                                    <th scope="col">Lancar</th>
                                    <th scope="col">OD1</th>
                                    <th scope="col">OD2</th>
                                    <th scope="col">OD3</th>
                                    <th scope="col">OD4</th>
                                    <th scope="col">OD5</th>
                                    <th scope="col">OD6</th>
                                    <th scope="col">ODLB6</th>
                                </tr>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:420px;">
                <div class="card-body">
                    <div class="card-title">Bucket OD Per Cabang - Konsumen</div>
                    <div class="table-responsive">
                        <table id="tableBucketCabKon" class="table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col" colspan="8" style="text-align: center;">Persen</th>
                                </tr>
                                <tr> 
                                    <th scope="col">Bucket</th>
                                    <th scope="col">Lancar</th>
                                    <th scope="col">OD1</th>
                                    <th scope="col">OD2</th>
                                    <th scope="col">OD3</th>
                                    <th scope="col">OD4</th>
                                    <th scope="col">OD5</th>
                                    <th scope="col">OD6</th>
                                    <th scope="col">ODLB6</th>
                                </tr>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Rundown AR</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:340px;">
                <div class="card-body">
                    <div class="card-title">Rundown AR</div>
                    <div class="table-responsive">
                        <table id="tableRundownAr" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Keterangan</th>
                                    <th scope="col" style="text-align: right;">Konsumen</th>
                                    <th scope="col" style="text-align: right;">Rupiah</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Booking vs Rundown Per Regional (Konsumen)</div>
                    <div id="echartBarHorizontal1" style="height: 100%;min-height:250px;"></div>
                </div>
            </div>
        </div>

    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.");
        }
    }
}

$(document).ready(function () {
    $('#tableArRegRp').DataTable({
        "data":[
          {
            "regional": "SUMATERA 5",
            "TARGET": 197442803246.78622,
            "ACTUAL": 203889873166,
            "PERSEN": 103.3
          },
          {
            "regional": "SULAWESI 3",
            "TARGET": 553012418006.3607,
            "ACTUAL": 564730023689,
            "PERSEN": 102.1
          },
          {
            "regional": "JAWA BARAT 3",
            "TARGET": 279829987513.8186,
            "ACTUAL": 279016270872,
            "PERSEN": 99.7
          },
          {
            "regional": "SULAWESI 4",
            "TARGET": 233110239524.10358,
            "ACTUAL": 231624776335,
            "PERSEN": 99.4
          },
          {
            "regional": "ACEH 2",
            "TARGET": 133343006385.8134,
            "ACTUAL": 132295104699,
            "PERSEN": 99.2
          },
          {
            "regional": "KALIMANTAN 2",
            "TARGET": 133448299320.6095,
            "ACTUAL": 132346241830,
            "PERSEN": 99.2
          },
          {
            "regional": "SULAWESI 1",
            "TARGET": 647290546322.5994,
            "ACTUAL": 640688168091,
            "PERSEN": 99
          },
          {
            "regional": "NUSA TENGGARA",
            "TARGET": 32957590742.3087,
            "ACTUAL": 32554626163,
            "PERSEN": 98.8
          },
          {
            "regional": "JAWA BARAT 2",
            "TARGET": 228822514101.8653,
            "ACTUAL": 225883206958,
            "PERSEN": 98.7
          },
          {
            "regional": "JAWA BARAT 1",
            "TARGET": 181366043450.83688,
            "ACTUAL": 178100886531,
            "PERSEN": 98.2
          },
          {
            "regional": "KALIMANTAN 1",
            "TARGET": 172642438462.9172,
            "ACTUAL": 169350016613,
            "PERSEN": 98.1
          },
          {
            "regional": "SULAWESI 5",
            "TARGET": 338205496042.11475,
            "ACTUAL": 331334412403,
            "PERSEN": 98
          },
          {
            "regional": "ACEH 1",
            "TARGET": 221039382163.50464,
            "ACTUAL": 214910916572,
            "PERSEN": 97.2
          },
          {
            "regional": "MAPA",
            "TARGET": 146346044638.56522,
            "ACTUAL": 142153548558,
            "PERSEN": 97.1
          },
          {
            "regional": "SUMATERA 4",
            "TARGET": 284470566519.17255,
            "ACTUAL": 274882304924,
            "PERSEN": 96.6
          },
          {
            "regional": "JAWA TENGAH",
            "TARGET": 165293334421.5371,
            "ACTUAL": 159417733824,
            "PERSEN": 96.4
          },
          {
            "regional": "SULAWESI 2",
            "TARGET": 444219686465.2399,
            "ACTUAL": 425763468527,
            "PERSEN": 95.8
          },
          {
            "regional": "SUMATERA 6",
            "TARGET": 172056099586.7511,
            "ACTUAL": 163930530901,
            "PERSEN": 95.3
          },
          {
            "regional": "SUMATERA 3",
            "TARGET": 224179128168.33646,
            "ACTUAL": 212754520730,
            "PERSEN": 94.9
          },
          {
            "regional": "SUMATERA 2",
            "TARGET": 72476525157.8659,
            "ACTUAL": 67777926765,
            "PERSEN": 93.5
          },
          {
            "regional": "JAWA TIMUR",
            "TARGET": 79113114308.25949,
            "ACTUAL": 73477203988,
            "PERSEN": 92.9
          }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableArRegKon').DataTable({
        "data":[
            {
                "regional": "SUMATERA 5",
                "TARGET": 14528,
                "ACTUAL": 14676,
                "PERSEN": 101
            },
            {
                "regional": "SULAWESI 3",
                "TARGET": 56426,
                "ACTUAL": 56489,
                "PERSEN": 100.1
            },
            {
                "regional": "JAWA BARAT 2",
                "TARGET": 28999,
                "ACTUAL": 28859,
                "PERSEN": 99.5
            },
            {
                "regional": "KALIMANTAN 1",
                "TARGET": 20036,
                "ACTUAL": 19858,
                "PERSEN": 99.1
            },
            {
                "regional": "KALIMANTAN 2",
                "TARGET": 13548,
                "ACTUAL": 13430,
                "PERSEN": 99.1
            },
            {
                "regional": "NUSA TENGGARA",
                "TARGET": 5863,
                "ACTUAL": 5789,
                "PERSEN": 98.7
            },
            {
                "regional": "SULAWESI 4",
                "TARGET": 25557,
                "ACTUAL": 25196,
                "PERSEN": 98.6
            },
            {
                "regional": "JAWA BARAT 1",
                "TARGET": 23610,
                "ACTUAL": 23278,
                "PERSEN": 98.6
            },
            {
                "regional": "SULAWESI 1",
                "TARGET": 59496,
                "ACTUAL": 58589,
                "PERSEN": 98.5
            },
            {
                "regional": "SULAWESI 5",
                "TARGET": 34898,
                "ACTUAL": 34353,
                "PERSEN": 98.4
            },
            {
                "regional": "ACEH 2",
                "TARGET": 13347,
                "ACTUAL": 13110,
                "PERSEN": 98.2
            },
            {
                "regional": "SUMATERA 4",
                "TARGET": 26872,
                "ACTUAL": 26276,
                "PERSEN": 97.8
            },
            {
                "regional": "JAWA BARAT 3",
                "TARGET": 29892,
                "ACTUAL": 29193,
                "PERSEN": 97.7
            },
            {
                "regional": "ACEH 1",
                "TARGET": 20643,
                "ACTUAL": 20086,
                "PERSEN": 97.3
            },
            {
                "regional": "MAPA",
                "TARGET": 16570,
                "ACTUAL": 16060,
                "PERSEN": 96.9
            },
            {
                "regional": "SUMATERA 3",
                "TARGET": 21556,
                "ACTUAL": 20825,
                "PERSEN": 96.6
            },
            {
                "regional": "SUMATERA 6",
                "TARGET": 19808,
                "ACTUAL": 19063,
                "PERSEN": 96.2
            },
            {
                "regional": "SUMATERA 2",
                "TARGET": 6142,
                "ACTUAL": 5900,
                "PERSEN": 96.1
            },
            {
                "regional": "SULAWESI 2",
                "TARGET": 43785,
                "ACTUAL": 42082,
                "PERSEN": 96.1
            },
            {
                "regional": "JAWA TENGAH",
                "TARGET": 36649,
                "ACTUAL": 35118,
                "PERSEN": 95.8
            },
            {
                "regional": "JAWA TIMUR",
                "TARGET": 17652,
                "ACTUAL": 16613,
                "PERSEN": 94.1
            }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableArCabRp').DataTable({
        "data":[
            {
                "nmcab": "BELINYU",
                "PARETO": "T",
                "TARGET": 19959673767.911003,
                "ACTUAL": 21496396635,
                "PERSEN": 107.7
            },
            {
                "nmcab": "MOROWALI",
                "PARETO": "T",
                "TARGET": 34978477312.348,
                "ACTUAL": 37500537738,
                "PERSEN": 107.2
            },
            {
                "nmcab": "PELABUHAN RATU",
                "PARETO": "T",
                "TARGET": 25227738049.8788,
                "ACTUAL": 26923706522,
                "PERSEN": 106.7
            },
            {
                "nmcab": "BELITUNG",
                "PARETO": "T",
                "TARGET": 28482138936.9312,
                "ACTUAL": 30345566773,
                "PERSEN": 106.5
            },
            {
                "nmcab": "DOMPU",
                "PARETO": "T",
                "TARGET": 3823902067.6124,
                "ACTUAL": 4066582827,
                "PERSEN": 106.3
            },
            {
                "nmcab": "BUOL",
                "PARETO": "T",
                "TARGET": 22732243393.5776,
                "ACTUAL": 24053587842,
                "PERSEN": 105.8
            },
            {
                "nmcab": "LUWUK",
                "PARETO": "T",
                "TARGET": 20555426389.5694,
                "ACTUAL": 21643099376,
                "PERSEN": 105.3
            },
            {
                "nmcab": "BUNGKU",
                "PARETO": "T",
                "TARGET": 47987899015.9913,
                "ACTUAL": 50449847556,
                "PERSEN": 105.1
            },
            {
                "nmcab": "UNAAHA",
                "PARETO": "T",
                "TARGET": 22929984408.6711,
                "ACTUAL": 24008581767,
                "PERSEN": 104.7
            },
            {
                "nmcab": "BERAU",
                "PARETO": "Y",
                "TARGET": 20739810594.0792,
                "ACTUAL": 21659815329,
                "PERSEN": 104.4
            },
            {
                "nmcab": "KENDARI",
                "PARETO": "Y",
                "TARGET": 58898907060.023705,
                "ACTUAL": 60985491131,
                "PERSEN": 103.5
            },
            {
                "nmcab": "POSO",
                "PARETO": "Y",
                "TARGET": 30317683522.354004,
                "ACTUAL": 31259902086,
                "PERSEN": 103.1
            },
            {
                "nmcab": "BELTIM",
                "PARETO": "T",
                "TARGET": 19660978297.3116,
                "ACTUAL": 20250345089,
                "PERSEN": 103
            },
            {
                "nmcab": "BANGKA",
                "PARETO": "Y",
                "TARGET": 47339057461.632,
                "ACTUAL": 48706280691,
                "PERSEN": 102.9
            },
            {
                "nmcab": "GORONTALO",
                "PARETO": "Y",
                "TARGET": 52422967595.21361,
                "ACTUAL": 53772866085,
                "PERSEN": 102.6
            },
            {
                "nmcab": "KELAPA",
                "PARETO": "Y",
                "TARGET": 12796917152.1908,
                "ACTUAL": 13135303035,
                "PERSEN": 102.6
            },
            {
                "nmcab": "PALU",
                "PARETO": "Y",
                "TARGET": 110312615877.9288,
                "ACTUAL": 112710685686,
                "PERSEN": 102.2
            },
            {
                "nmcab": "TOBOALI",
                "PARETO": "T",
                "TARGET": 16789983036.901798,
                "ACTUAL": 17149199704,
                "PERSEN": 102.1
            },
            {
                "nmcab": "TOLI TOLI",
                "PARETO": "T",
                "TARGET": 17769342347.333797,
                "ACTUAL": 18150710407,
                "PERSEN": 102.1
            },
            {
                "nmcab": "CIMAHI",
                "PARETO": "Y",
                "TARGET": 23273414872.7664,
                "ACTUAL": 23750413834,
                "PERSEN": 102
            },
            {
                "nmcab": "SUMEDANG",
                "PARETO": "T",
                "TARGET": 13572816787.4144,
                "ACTUAL": 13846671953,
                "PERSEN": 102
            },
            {
                "nmcab": "PURWAKARTA",
                "PARETO": "T",
                "TARGET": 24562678480.684,
                "ACTUAL": 25064385575,
                "PERSEN": 102
            },
            {
                "nmcab": "MAGELANG",
                "PARETO": "T",
                "TARGET": 9918107985.175999,
                "ACTUAL": 10102048892,
                "PERSEN": 101.9
            },
            {
                "nmcab": "PALU 2",
                "PARETO": "Y",
                "TARGET": 63030977431.35999,
                "ACTUAL": 64132539487,
                "PERSEN": 101.7
            },
            {
                "nmcab": "TOMPE",
                "PARETO": "T",
                "TARGET": 14739444922.480598,
                "ACTUAL": 14980570046,
                "PERSEN": 101.6
            },
            {
                "nmcab": "CILEUNGSI",
                "PARETO": "Y",
                "TARGET": 42534220445.189,
                "ACTUAL": 43164045221,
                "PERSEN": 101.5
            },
            {
                "nmcab": "SALAKAN",
                "PARETO": "T",
                "TARGET": 30030605923.4892,
                "ACTUAL": 30478897221,
                "PERSEN": 101.5
            },
            {
                "nmcab": "KOBA",
                "PARETO": "T",
                "TARGET": 13486858122.279999,
                "ACTUAL": 13686844928,
                "PERSEN": 101.5
            },
            {
                "nmcab": "KOTA FAJAR",
                "PARETO": "T",
                "TARGET": 34513468600.818,
                "ACTUAL": 35032042247,
                "PERSEN": 101.5
            },
            {
                "nmcab": "SEMARANG",
                "PARETO": "Y",
                "TARGET": 22793944117.3536,
                "ACTUAL": 23102613309,
                "PERSEN": 101.4
            },
            {
                "nmcab": "PENDOLO",
                "PARETO": "T",
                "TARGET": 12291541620.2531,
                "ACTUAL": 12458175358,
                "PERSEN": 101.4
            },
            {
                "nmcab": "BIREUEN",
                "PARETO": "Y",
                "TARGET": 24750302892.1506,
                "ACTUAL": 25083977242,
                "PERSEN": 101.3
            },
            {
                "nmcab": "BEKASI",
                "PARETO": "Y",
                "TARGET": 72995473406.82,
                "ACTUAL": 73822459309,
                "PERSEN": 101.1
            },
            {
                "nmcab": "BANDUNG",
                "PARETO": "Y",
                "TARGET": 16722722387.636799,
                "ACTUAL": 16886494136,
                "PERSEN": 101
            },
            {
                "nmcab": "YOGYAKARTA",
                "PARETO": "T",
                "TARGET": 9236723913.6072,
                "ACTUAL": 9325076550,
                "PERSEN": 101
            },
            {
                "nmcab": "PANGANDARAN",
                "PARETO": "T",
                "TARGET": 18223882483.2927,
                "ACTUAL": 18405940781,
                "PERSEN": 101
            },
            {
                "nmcab": "MAKASSAR 3",
                "PARETO": "Y",
                "TARGET": 88695310685.845,
                "ACTUAL": 89529387068,
                "PERSEN": 100.9
            },
            {
                "nmcab": "SUNGAI LIAT",
                "PARETO": "Y",
                "TARGET": 15638520719.2668,
                "ACTUAL": 15775825451,
                "PERSEN": 100.9
            },
            {
                "nmcab": "BOEPINANG",
                "PARETO": "T",
                "TARGET": 13396857191.371,
                "ACTUAL": 13513305143,
                "PERSEN": 100.9
            },
            {
                "nmcab": "KOTARAYA",
                "PARETO": "T",
                "TARGET": 20768902704.0768,
                "ACTUAL": 20905132094,
                "PERSEN": 100.7
            },
            {
                "nmcab": "BARABAI",
                "PARETO": "T",
                "TARGET": 8257856099.1800995,
                "ACTUAL": 8318385678,
                "PERSEN": 100.7
            },
            {
                "nmcab": "MANOKWARI",
                "PARETO": "T",
                "TARGET": 15168365278.9014,
                "ACTUAL": 15271864716,
                "PERSEN": 100.7
            },
            {
                "nmcab": "BATU LICIN",
                "PARETO": "Y",
                "TARGET": 19309000147.334,
                "ACTUAL": 19443872515,
                "PERSEN": 100.7
            },
            {
                "nmcab": "JEBUS",
                "PARETO": "T",
                "TARGET": 9467422939.761002,
                "ACTUAL": 9525450319,
                "PERSEN": 100.6
            },
            {
                "nmcab": "TANGGEUNG",
                "PARETO": "T",
                "TARGET": 11632007011.8732,
                "ACTUAL": 11701165887,
                "PERSEN": 100.6
            },
            {
                "nmcab": "BAWEN",
                "PARETO": "T",
                "TARGET": 12776876604.3085,
                "ACTUAL": 12836636251,
                "PERSEN": 100.5
            },
            {
                "nmcab": "PENAJAM",
                "PARETO": "T",
                "TARGET": 6941925214.2836,
                "ACTUAL": 6959602722,
                "PERSEN": 100.3
            },
            {
                "nmcab": "GOWA",
                "PARETO": "Y",
                "TARGET": 62835636350.1372,
                "ACTUAL": 63034391875,
                "PERSEN": 100.3
            },
            {
                "nmcab": "TOILI",
                "PARETO": "T",
                "TARGET": 21904383422.9096,
                "ACTUAL": 21964501336,
                "PERSEN": 100.3
            },
            {
                "nmcab": "SANGATTA",
                "PARETO": "Y",
                "TARGET": 18345783594.9618,
                "ACTUAL": 18408690472,
                "PERSEN": 100.3
            },
            {
                "nmcab": "PARIGI",
                "PARETO": "T",
                "TARGET": 26979366875.023003,
                "ACTUAL": 27055446543,
                "PERSEN": 100.3
            },
            {
                "nmcab": "BACAN",
                "PARETO": "T",
                "TARGET": 4698039250.7009,
                "ACTUAL": 4701680144,
                "PERSEN": 100.1
            },
            {
                "nmcab": "MENTOK",
                "PARETO": "Y",
                "TARGET": 13821252812.6,
                "ACTUAL": 13818660541,
                "PERSEN": 100
            },
            {
                "nmcab": "GOWA 2",
                "PARETO": "Y",
                "TARGET": 48216150697.00081,
                "ACTUAL": 48222534375,
                "PERSEN": 100
            },
            {
                "nmcab": "MAKASSAR 2",
                "PARETO": "Y",
                "TARGET": 72440186972.6816,
                "ACTUAL": 72376798168,
                "PERSEN": 99.9
            },
            {
                "nmcab": "SRAGEN",
                "PARETO": "T",
                "TARGET": 5522900437.6,
                "ACTUAL": 5516889847,
                "PERSEN": 99.9
            },
            {
                "nmcab": "CIANJUR",
                "PARETO": "Y",
                "TARGET": 22756629280.7785,
                "ACTUAL": 22736808723,
                "PERSEN": 99.9
            },
            {
                "nmcab": "CIAWI",
                "PARETO": "T",
                "TARGET": 8671724998.3847,
                "ACTUAL": 8658099589,
                "PERSEN": 99.8
            },
            {
                "nmcab": "MASOHI",
                "PARETO": "Y",
                "TARGET": 20080792019.8965,
                "ACTUAL": 20021994386,
                "PERSEN": 99.7
            },
            {
                "nmcab": "JAILOLO",
                "PARETO": "Y",
                "TARGET": 33480623258.559998,
                "ACTUAL": 33375298735,
                "PERSEN": 99.7
            },
            {
                "nmcab": "JEMBER",
                "PARETO": "T",
                "TARGET": 9312726899.9394,
                "ACTUAL": 9282658041,
                "PERSEN": 99.7
            },
            {
                "nmcab": "WAISARISSA",
                "PARETO": "T",
                "TARGET": 12934287605.2485,
                "ACTUAL": 12882893301,
                "PERSEN": 99.6
            },
            {
                "nmcab": "SAMARINDA",
                "PARETO": "Y",
                "TARGET": 21041136539.3512,
                "ACTUAL": 20934044564,
                "PERSEN": 99.5
            },
            {
                "nmcab": "KARAWANG",
                "PARETO": "Y",
                "TARGET": 43162784243.3696,
                "ACTUAL": 42936789360,
                "PERSEN": 99.5
            },
            {
                "nmcab": "TAKALAR",
                "PARETO": "Y",
                "TARGET": 39847224049.148705,
                "ACTUAL": 39610598148,
                "PERSEN": 99.4
            },
            {
                "nmcab": "MEULABOH",
                "PARETO": "Y",
                "TARGET": 32084827087.2008,
                "ACTUAL": 31857352688,
                "PERSEN": 99.3
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "PARETO": "T",
                "TARGET": 28287994134.7728,
                "ACTUAL": 28062645261,
                "PERSEN": 99.2
            },
            {
                "nmcab": "ALUE BILIE",
                "PARETO": "T",
                "TARGET": 13515934204.5875,
                "ACTUAL": 13408559959,
                "PERSEN": 99.2
            },
            {
                "nmcab": "CIKARANG",
                "PARETO": "T",
                "TARGET": 24793598293.940098,
                "ACTUAL": 24605311348,
                "PERSEN": 99.2
            },
            {
                "nmcab": "MAKASSAR",
                "PARETO": "Y",
                "TARGET": 83241146130.7966,
                "ACTUAL": 82555898752,
                "PERSEN": 99.2
            },
            {
                "nmcab": "TALAUD",
                "PARETO": "T",
                "TARGET": 11421604910.175,
                "ACTUAL": 11319334679,
                "PERSEN": 99.1
            },
            {
                "nmcab": "TENTENA",
                "PARETO": "T",
                "TARGET": 16622832837.028801,
                "ACTUAL": 16473231347,
                "PERSEN": 99.1
            },
            {
                "nmcab": "PUNGGALUKU",
                "PARETO": "T",
                "TARGET": 16525463848.069,
                "ACTUAL": 16362165127,
                "PERSEN": 99
            },
            {
                "nmcab": "MAKALE",
                "PARETO": "T",
                "TARGET": 23447154823.2364,
                "ACTUAL": 23223008889,
                "PERSEN": 99
            },
            {
                "nmcab": "KOTABARU",
                "PARETO": "T",
                "TARGET": 10779938830.5179,
                "ACTUAL": 10672063511,
                "PERSEN": 99
            },
            {
                "nmcab": "PATROL",
                "PARETO": "T",
                "TARGET": 9907260954.0498,
                "ACTUAL": 9795877253,
                "PERSEN": 98.9
            },
            {
                "nmcab": "PINRANG",
                "PARETO": "T",
                "TARGET": 30207527890.823498,
                "ACTUAL": 29870201171,
                "PERSEN": 98.9
            },
            {
                "nmcab": "PRINGSEWU",
                "PARETO": "T",
                "TARGET": 11447827833.793,
                "ACTUAL": 11319722444,
                "PERSEN": 98.9
            },
            {
                "nmcab": "TERNATE",
                "PARETO": "Y",
                "TARGET": 31650247248.784203,
                "ACTUAL": 31294181005,
                "PERSEN": 98.9
            },
            {
                "nmcab": "PASANGKAYU",
                "PARETO": "T",
                "TARGET": 29728085914.175198,
                "ACTUAL": 29395195036,
                "PERSEN": 98.9
            },
            {
                "nmcab": "MALANG",
                "PARETO": "T",
                "TARGET": 8802291355.556,
                "ACTUAL": 8701243648,
                "PERSEN": 98.9
            },
            {
                "nmcab": "CIBINONG",
                "PARETO": "T",
                "TARGET": 26999196965.812,
                "ACTUAL": 26706032338,
                "PERSEN": 98.9
            },
            {
                "nmcab": "CIREBON",
                "PARETO": "Y",
                "TARGET": 16303252960.6277,
                "ACTUAL": 16104418011,
                "PERSEN": 98.8
            },
            {
                "nmcab": "BELOPA",
                "PARETO": "T",
                "TARGET": 24783768016.0424,
                "ACTUAL": 24483593707,
                "PERSEN": 98.8
            },
            {
                "nmcab": "SUNGAI LILIN",
                "PARETO": "T",
                "TARGET": 24840046021.658096,
                "ACTUAL": 24537073856,
                "PERSEN": 98.8
            },
            {
                "nmcab": "MAROS",
                "PARETO": "T",
                "TARGET": 43617337750.936005,
                "ACTUAL": 43049766102,
                "PERSEN": 98.7
            },
            {
                "nmcab": "PANGKEP",
                "PARETO": "T",
                "TARGET": 22886690938.054398,
                "ACTUAL": 22560224829,
                "PERSEN": 98.6
            },
            {
                "nmcab": "KOTOBARU",
                "PARETO": "Y",
                "TARGET": 23194238801.546497,
                "ACTUAL": 22865351572,
                "PERSEN": 98.6
            },
            {
                "nmcab": "AMBON",
                "PARETO": "Y",
                "TARGET": 44016094487.2322,
                "ACTUAL": 43411357989,
                "PERSEN": 98.6
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "PARETO": "T",
                "TARGET": 32610203057.642998,
                "ACTUAL": 32138641722,
                "PERSEN": 98.6
            },
            {
                "nmcab": "KASIPUTE",
                "PARETO": "T",
                "TARGET": 15385641440.907999,
                "ACTUAL": 15169494027,
                "PERSEN": 98.6
            },
            {
                "nmcab": "DONGGALA",
                "PARETO": "T",
                "TARGET": 29384005440.1752,
                "ACTUAL": 28950377499,
                "PERSEN": 98.5
            },
            {
                "nmcab": "TANGERANG",
                "PARETO": "Y",
                "TARGET": 26023621232.772896,
                "ACTUAL": 25611272438,
                "PERSEN": 98.4
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "PARETO": "T",
                "TARGET": 7419661905.054001,
                "ACTUAL": 7297555922,
                "PERSEN": 98.4
            },
            {
                "nmcab": "TANAH GROGOT",
                "PARETO": "T",
                "TARGET": 12343175311.8819,
                "ACTUAL": 12140313279,
                "PERSEN": 98.4
            },
            {
                "nmcab": "JATIBARANG",
                "PARETO": "Y",
                "TARGET": 14550997829.4417,
                "ACTUAL": 14308784669,
                "PERSEN": 98.3
            },
            {
                "nmcab": "BONE",
                "PARETO": "Y",
                "TARGET": 33833180687.9329,
                "ACTUAL": 33255480384,
                "PERSEN": 98.3
            },
            {
                "nmcab": "PALANGKARAYA",
                "PARETO": "Y",
                "TARGET": 15473809864.95,
                "ACTUAL": 15216619286,
                "PERSEN": 98.3
            },
            {
                "nmcab": "LUBUKBASUNG",
                "PARETO": "T",
                "TARGET": 14101797605.746601,
                "ACTUAL": 13854358869,
                "PERSEN": 98.2
            },
            {
                "nmcab": "PANTON LABU",
                "PARETO": "T",
                "TARGET": 11907481268.8474,
                "ACTUAL": 11682986346,
                "PERSEN": 98.1
            },
            {
                "nmcab": "AMPANA",
                "PARETO": "T",
                "TARGET": 15296904109.299599,
                "ACTUAL": 14999653228,
                "PERSEN": 98.1
            },
            {
                "nmcab": "LABUAN BAJO",
                "PARETO": "T",
                "TARGET": 4920624584.3401,
                "ACTUAL": 4826678216,
                "PERSEN": 98.1
            },
            {
                "nmcab": "BALIKPAPAN",
                "PARETO": "Y",
                "TARGET": 18671771344.012,
                "ACTUAL": 18309858499,
                "PERSEN": 98.1
            },
            {
                "nmcab": "ENDE",
                "PARETO": "T",
                "TARGET": 3162045822.0828,
                "ACTUAL": 3100461931,
                "PERSEN": 98.1
            },
            {
                "nmcab": "BLANG PIDIE",
                "PARETO": "T",
                "TARGET": 18557052065.5342,
                "ACTUAL": 18200700422,
                "PERSEN": 98.1
            },
            {
                "nmcab": "JENEPONTO",
                "PARETO": "T",
                "TARGET": 31811107895.751297,
                "ACTUAL": 31218281962,
                "PERSEN": 98.1
            },
            {
                "nmcab": "MASBAGIK",
                "PARETO": "T",
                "TARGET": 12140802509.456,
                "ACTUAL": 11905221837,
                "PERSEN": 98.1
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "PARETO": "T",
                "TARGET": 24847279188.110497,
                "ACTUAL": 24350769712,
                "PERSEN": 98
            },
            {
                "nmcab": "RATAHAN",
                "PARETO": "Y",
                "TARGET": 25450117800.522198,
                "ACTUAL": 24931695257,
                "PERSEN": 98
            },
            {
                "nmcab": "BOROKO",
                "PARETO": "T",
                "TARGET": 7822717455.0808,
                "ACTUAL": 7665288763,
                "PERSEN": 98
            },
            {
                "nmcab": "LAHAT",
                "PARETO": "Y",
                "TARGET": 28768117267.945698,
                "ACTUAL": 28162995949,
                "PERSEN": 97.9
            },
            {
                "nmcab": "KOLAKA",
                "PARETO": "Y",
                "TARGET": 31208430209.0666,
                "ACTUAL": 30545737883,
                "PERSEN": 97.9
            },
            {
                "nmcab": "MUARA TEWEH",
                "PARETO": "Y",
                "TARGET": 19252018253.904,
                "ACTUAL": 18850160671,
                "PERSEN": 97.9
            },
            {
                "nmcab": "JAMPANG",
                "PARETO": "T",
                "TARGET": 7512069814.648,
                "ACTUAL": 7345733040,
                "PERSEN": 97.8
            },
            {
                "nmcab": "BETUNG",
                "PARETO": "T",
                "TARGET": 24205283818.827,
                "ACTUAL": 23663287826,
                "PERSEN": 97.8
            },
            {
                "nmcab": "TOBELO",
                "PARETO": "T",
                "TARGET": 13533179729.3206,
                "ACTUAL": 13238663659,
                "PERSEN": 97.8
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "PARETO": "T",
                "TARGET": 11770055862.9516,
                "ACTUAL": 11507156312,
                "PERSEN": 97.8
            },
            {
                "nmcab": "BANJARMASIN",
                "PARETO": "Y",
                "TARGET": 39128878383.7384,
                "ACTUAL": 38245386301,
                "PERSEN": 97.7
            },
            {
                "nmcab": "TEGAL",
                "PARETO": "T",
                "TARGET": 9954260704.7226,
                "ACTUAL": 9729417818,
                "PERSEN": 97.7
            },
            {
                "nmcab": "KUNINGAN",
                "PARETO": "T",
                "TARGET": 11421768333.6719,
                "ACTUAL": 11155578330,
                "PERSEN": 97.7
            },
            {
                "nmcab": "BANTAENG",
                "PARETO": "T",
                "TARGET": 21606314945.1053,
                "ACTUAL": 21105450155,
                "PERSEN": 97.7
            },
            {
                "nmcab": "SUBANG",
                "PARETO": "T",
                "TARGET": 10852158457.0808,
                "ACTUAL": 10594149886,
                "PERSEN": 97.6
            },
            {
                "nmcab": "PLEIHARI",
                "PARETO": "T",
                "TARGET": 10607434632.264101,
                "ACTUAL": 10355911973,
                "PERSEN": 97.6
            },
            {
                "nmcab": "PARUNGKUDA",
                "PARETO": "Y",
                "TARGET": 18029804160.4413,
                "ACTUAL": 17594304415,
                "PERSEN": 97.6
            },
            {
                "nmcab": "BOYOLALI",
                "PARETO": "T",
                "TARGET": 6803433231.889999,
                "ACTUAL": 6639069779,
                "PERSEN": 97.6
            },
            {
                "nmcab": "UJUNG BERUNG",
                "PARETO": "T",
                "TARGET": 10963953151.3588,
                "ACTUAL": 10700286989,
                "PERSEN": 97.6
            },
            {
                "nmcab": "TAKENGON",
                "PARETO": "T",
                "TARGET": 22888754582.5694,
                "ACTUAL": 22337326042,
                "PERSEN": 97.6
            },
            {
                "nmcab": "PALOPO",
                "PARETO": "Y",
                "TARGET": 41552458392.1051,
                "ACTUAL": 40555437376,
                "PERSEN": 97.6
            },
            {
                "nmcab": "MOROTAI",
                "PARETO": "T",
                "TARGET": 1601099328.77,
                "ACTUAL": 1560919910,
                "PERSEN": 97.5
            },
            {
                "nmcab": "WONOSARI",
                "PARETO": "T",
                "TARGET": 7926847019.0746,
                "ACTUAL": 7726199174,
                "PERSEN": 97.5
            },
            {
                "nmcab": "KADIPATEN",
                "PARETO": "T",
                "TARGET": 13452949274.314701,
                "ACTUAL": 13120669266,
                "PERSEN": 97.5
            },
            {
                "nmcab": "BOGOR",
                "PARETO": "Y",
                "TARGET": 19147954005.3628,
                "ACTUAL": 18651203887,
                "PERSEN": 97.4
            },
            {
                "nmcab": "KUALA SIMPANG",
                "PARETO": "Y",
                "TARGET": 42759751904.579,
                "ACTUAL": 41651070985,
                "PERSEN": 97.4
            },
            {
                "nmcab": "TARAKAN",
                "PARETO": "T",
                "TARGET": 7389220591.7234,
                "ACTUAL": 7193968484,
                "PERSEN": 97.4
            },
            {
                "nmcab": "NAGAN",
                "PARETO": "T",
                "TARGET": 11782969845.1035,
                "ACTUAL": 11459123341,
                "PERSEN": 97.3
            },
            {
                "nmcab": "MOLIBAGU",
                "PARETO": "T",
                "TARGET": 5617841053.6784,
                "ACTUAL": 5464950461,
                "PERSEN": 97.3
            },
            {
                "nmcab": "RAWAJITU",
                "PARETO": "T",
                "TARGET": 9037074646.4442,
                "ACTUAL": 8791884292,
                "PERSEN": 97.3
            },
            {
                "nmcab": "TANJUNG",
                "PARETO": "T",
                "TARGET": 11811708938.524,
                "ACTUAL": 11494877104,
                "PERSEN": 97.3
            },
            {
                "nmcab": "PARE-PARE",
                "PARETO": "Y",
                "TARGET": 27682362686.252,
                "ACTUAL": 26904951742,
                "PERSEN": 97.2
            },
            {
                "nmcab": "SUMBAWA",
                "PARETO": "T",
                "TARGET": 3676664853.3543997,
                "ACTUAL": 3574815791,
                "PERSEN": 97.2
            },
            {
                "nmcab": "SIGLI",
                "PARETO": "T",
                "TARGET": 12593168782.3408,
                "ACTUAL": 12236743723,
                "PERSEN": 97.2
            },
            {
                "nmcab": "UJUNG GADING",
                "PARETO": "T",
                "TARGET": 21343212406.5312,
                "ACTUAL": 20735470670,
                "PERSEN": 97.2
            },
            {
                "nmcab": "BITUNG",
                "PARETO": "Y",
                "TARGET": 39070134088.6772,
                "ACTUAL": 37919523853,
                "PERSEN": 97.1
            },
            {
                "nmcab": "BANJARAN",
                "PARETO": "T",
                "TARGET": 13364204195.1232,
                "ACTUAL": 12975836408,
                "PERSEN": 97.1
            },
            {
                "nmcab": "RUTENG",
                "PARETO": "T",
                "TARGET": 5233550905.463,
                "ACTUAL": 5080865561,
                "PERSEN": 97.1
            },
            {
                "nmcab": "BANGKALA",
                "PARETO": "T",
                "TARGET": 21184024905.0587,
                "ACTUAL": 20557378488,
                "PERSEN": 97
            },
            {
                "nmcab": "WAY KANAN",
                "PARETO": "T",
                "TARGET": 10765874423.2028,
                "ACTUAL": 10446294661,
                "PERSEN": 97
            },
            {
                "nmcab": "SIAU",
                "PARETO": "T",
                "TARGET": 6578159113.2528,
                "ACTUAL": 6379230246,
                "PERSEN": 97
            },
            {
                "nmcab": "TUAL",
                "PARETO": "T",
                "TARGET": 11138072340.837101,
                "ACTUAL": 10796097379,
                "PERSEN": 96.9
            },
            {
                "nmcab": "PALEMBANG",
                "PARETO": "Y",
                "TARGET": 51931088649.6472,
                "ACTUAL": 50330182468,
                "PERSEN": 96.9
            },
            {
                "nmcab": "PADANG",
                "PARETO": "Y",
                "TARGET": 15881377159.3265,
                "ACTUAL": 15391374609,
                "PERSEN": 96.9
            },
            {
                "nmcab": "SAMPIT",
                "PARETO": "T",
                "TARGET": 15998641444.3624,
                "ACTUAL": 15484259196,
                "PERSEN": 96.8
            },
            {
                "nmcab": "IDIE",
                "PARETO": "Y",
                "TARGET": 36031682874.735,
                "ACTUAL": 34886569347,
                "PERSEN": 96.8
            },
            {
                "nmcab": "TOPPOYO",
                "PARETO": "Y",
                "TARGET": 28532966085.4266,
                "ACTUAL": 27599752583,
                "PERSEN": 96.7
            },
            {
                "nmcab": "LADONGI",
                "PARETO": "T",
                "TARGET": 11756188018.275,
                "ACTUAL": 11366620710,
                "PERSEN": 96.7
            },
            {
                "nmcab": "GARUT",
                "PARETO": "Y",
                "TARGET": 19331040582.6554,
                "ACTUAL": 18702702573,
                "PERSEN": 96.7
            },
            {
                "nmcab": "PROBOLINGGO",
                "PARETO": "T",
                "TARGET": 5722204935.3061,
                "ACTUAL": 5532045889,
                "PERSEN": 96.7
            },
            {
                "nmcab": "MARTAPURA KAL",
                "PARETO": "Y",
                "TARGET": 15660797514.9488,
                "ACTUAL": 15140899305,
                "PERSEN": 96.7
            },
            {
                "nmcab": "TUGUMULYO",
                "PARETO": "T",
                "TARGET": 7281983718.7015,
                "ACTUAL": 7041574039,
                "PERSEN": 96.7
            },
            {
                "nmcab": "MANADO",
                "PARETO": "Y",
                "TARGET": 36560404762.0852,
                "ACTUAL": 35354592594,
                "PERSEN": 96.7
            },
            {
                "nmcab": "PANGKALANBUN",
                "PARETO": "T",
                "TARGET": 3238695294.2451,
                "ACTUAL": 3127719558,
                "PERSEN": 96.6
            },
            {
                "nmcab": "SINJAI",
                "PARETO": "T",
                "TARGET": 14920284811.514002,
                "ACTUAL": 14413830263,
                "PERSEN": 96.6
            },
            {
                "nmcab": "MUARA ENIM",
                "PARETO": "Y",
                "TARGET": 12875642808.821001,
                "ACTUAL": 12438008268,
                "PERSEN": 96.6
            },
            {
                "nmcab": "BELITANG",
                "PARETO": "T",
                "TARGET": 5440536744.2112,
                "ACTUAL": 5253644087,
                "PERSEN": 96.6
            },
            {
                "nmcab": "LAMPUNG",
                "PARETO": "Y",
                "TARGET": 38253992498.7262,
                "ACTUAL": 36966769777,
                "PERSEN": 96.6
            },
            {
                "nmcab": "KALIANDA",
                "PARETO": "Y",
                "TARGET": 16932165597.8034,
                "ACTUAL": 16332153349,
                "PERSEN": 96.5
            },
            {
                "nmcab": "ARGA MAKMUR",
                "PARETO": "T",
                "TARGET": 10916710414.473,
                "ACTUAL": 10523939133,
                "PERSEN": 96.4
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "PARETO": "T",
                "TARGET": 7109425574.834,
                "ACTUAL": 6855469254,
                "PERSEN": 96.4
            },
            {
                "nmcab": "BULUKUMBA",
                "PARETO": "T",
                "TARGET": 36370365413.9776,
                "ACTUAL": 35033018668,
                "PERSEN": 96.3
            },
            {
                "nmcab": "SERANG",
                "PARETO": "Y",
                "TARGET": 17317326543.105,
                "ACTUAL": 16655400008,
                "PERSEN": 96.2
            },
            {
                "nmcab": "ACEH",
                "PARETO": "Y",
                "TARGET": 30778794173.216003,
                "ACTUAL": 29622991699,
                "PERSEN": 96.2
            },
            {
                "nmcab": "INDRALAYA",
                "PARETO": "Y",
                "TARGET": 11843013432.5519,
                "ACTUAL": 11379762408,
                "PERSEN": 96.1
            },
            {
                "nmcab": "BENGKULU",
                "PARETO": "T",
                "TARGET": 5915324429.9241,
                "ACTUAL": 5682323202,
                "PERSEN": 96.1
            },
            {
                "nmcab": "PARIAMAN",
                "PARETO": "Y",
                "TARGET": 9877897725.7632,
                "ACTUAL": 9482797901,
                "PERSEN": 96
            },
            {
                "nmcab": "PURWOKERTO",
                "PARETO": "T",
                "TARGET": 8100280548.0257,
                "ACTUAL": 7778541777,
                "PERSEN": 96
            },
            {
                "nmcab": "BALARAJA",
                "PARETO": "T",
                "TARGET": 14621733271.9112,
                "ACTUAL": 14030468840,
                "PERSEN": 96
            },
            {
                "nmcab": "KAPUAS",
                "PARETO": "T",
                "TARGET": 3123659058.9484,
                "ACTUAL": 2999539373,
                "PERSEN": 96
            },
            {
                "nmcab": "BANJAR",
                "PARETO": "T",
                "TARGET": 11515645407.0925,
                "ACTUAL": 11039192242,
                "PERSEN": 95.9
            },
            {
                "nmcab": "NAMLEA",
                "PARETO": "T",
                "TARGET": 21417173209.1816,
                "ACTUAL": 20537261131,
                "PERSEN": 95.9
            },
            {
                "nmcab": "BABAT TOMAN",
                "PARETO": "T",
                "TARGET": 10418008895.677101,
                "ACTUAL": 9987195542,
                "PERSEN": 95.9
            },
            {
                "nmcab": "RAHA",
                "PARETO": "T",
                "TARGET": 15602469656.3808,
                "ACTUAL": 14954137533,
                "PERSEN": 95.8
            },
            {
                "nmcab": "BANGKO",
                "PARETO": "T",
                "TARGET": 12079866176.2272,
                "ACTUAL": 11566899943,
                "PERSEN": 95.8
            },
            {
                "nmcab": "BUNTA",
                "PARETO": "Y",
                "TARGET": 17309764861.162,
                "ACTUAL": 16566079414,
                "PERSEN": 95.7
            },
            {
                "nmcab": "SIJUNGJUNG",
                "PARETO": "T",
                "TARGET": 15716203965.5522,
                "ACTUAL": 15037790481,
                "PERSEN": 95.7
            },
            {
                "nmcab": "TEMANGGUNG",
                "PARETO": "T",
                "TARGET": 12366333334.4835,
                "ACTUAL": 11840359654,
                "PERSEN": 95.7
            },
            {
                "nmcab": "TOMOHON",
                "PARETO": "T",
                "TARGET": 8645836376.188,
                "ACTUAL": 8267878488,
                "PERSEN": 95.6
            },
            {
                "nmcab": "BATURAJA",
                "PARETO": "T",
                "TARGET": 9036072519.501999,
                "ACTUAL": 8641589203,
                "PERSEN": 95.6
            },
            {
                "nmcab": "BUTON",
                "PARETO": "Y",
                "TARGET": 32790165994.119102,
                "ACTUAL": 31356370344,
                "PERSEN": 95.6
            },
            {
                "nmcab": "MARISA",
                "PARETO": "T",
                "TARGET": 20169938879.1712,
                "ACTUAL": 19260870557,
                "PERSEN": 95.5
            },
            {
                "nmcab": "MASAMBA",
                "PARETO": "Y",
                "TARGET": 22722280431.634003,
                "ACTUAL": 21698611959,
                "PERSEN": 95.5
            },
            {
                "nmcab": "TORAJA",
                "PARETO": "Y",
                "TARGET": 27324345611.044598,
                "ACTUAL": 26061788878,
                "PERSEN": 95.4
            },
            {
                "nmcab": "PRABUMULIH",
                "PARETO": "Y",
                "TARGET": 13537606876.9486,
                "ACTUAL": 12916155223,
                "PERSEN": 95.4
            },
            {
                "nmcab": "SOPPENG",
                "PARETO": "T",
                "TARGET": 15800838928.8328,
                "ACTUAL": 15038520271,
                "PERSEN": 95.2
            },
            {
                "nmcab": "MANGKUTANA",
                "PARETO": "T",
                "TARGET": 22533330715.121998,
                "ACTUAL": 21447802060,
                "PERSEN": 95.2
            },
            {
                "nmcab": "MALILI",
                "PARETO": "T",
                "TARGET": 22242847346.970398,
                "ACTUAL": 21134409061,
                "PERSEN": 95
            },
            {
                "nmcab": "CILEDUG",
                "PARETO": "T",
                "TARGET": 13818551596.0268,
                "ACTUAL": 13126138773,
                "PERSEN": 95
            },
            {
                "nmcab": "BARRU",
                "PARETO": "T",
                "TARGET": 16417144125.98,
                "ACTUAL": 15583806824,
                "PERSEN": 94.9
            },
            {
                "nmcab": "PONTIANAK",
                "PARETO": "T",
                "TARGET": 2671945034.2911997,
                "ACTUAL": 2536737619,
                "PERSEN": 94.9
            },
            {
                "nmcab": "TULANG BAWANG",
                "PARETO": "T",
                "TARGET": 8315139289.949501,
                "ACTUAL": 7882518546,
                "PERSEN": 94.8
            },
            {
                "nmcab": "TASIKMALAYA",
                "PARETO": "Y",
                "TARGET": 16694721426.9538,
                "ACTUAL": 15815429835,
                "PERSEN": 94.7
            },
            {
                "nmcab": "KOTA AGUNG",
                "PARETO": "T",
                "TARGET": 6911002926.1264,
                "ACTUAL": 6546644753,
                "PERSEN": 94.7
            },
            {
                "nmcab": "ULEE GLEE",
                "PARETO": "T",
                "TARGET": 8287939105.9656,
                "ACTUAL": 7850758273,
                "PERSEN": 94.7
            },
            {
                "nmcab": "CURUP",
                "PARETO": "T",
                "TARGET": 7263102205.8395,
                "ACTUAL": 6860792062,
                "PERSEN": 94.5
            },
            {
                "nmcab": "MALINO",
                "PARETO": "T",
                "TARGET": 9681158651.097599,
                "ACTUAL": 9136178425,
                "PERSEN": 94.4
            },
            {
                "nmcab": "ENREKANG",
                "PARETO": "T",
                "TARGET": 11323110325.7837,
                "ACTUAL": 10655444866,
                "PERSEN": 94.1
            },
            {
                "nmcab": "BATU SANGKAR",
                "PARETO": "T",
                "TARGET": 13281921961.0572,
                "ACTUAL": 12494714024,
                "PERSEN": 94.1
            },
            {
                "nmcab": "SABAK",
                "PARETO": "T",
                "TARGET": 8810868383.1509,
                "ACTUAL": 8287822442,
                "PERSEN": 94.1
            },
            {
                "nmcab": "TAHUNA",
                "PARETO": "T",
                "TARGET": 12113657695.564,
                "ACTUAL": 11398837290,
                "PERSEN": 94.1
            },
            {
                "nmcab": "PATI",
                "PARETO": "T",
                "TARGET": 6720523803.5812,
                "ACTUAL": 6314682797,
                "PERSEN": 94
            },
            {
                "nmcab": "BLITAR",
                "PARETO": "Y",
                "TARGET": 9116593975.3683,
                "ACTUAL": 8562050150,
                "PERSEN": 93.9
            },
            {
                "nmcab": "METRO",
                "PARETO": "Y",
                "TARGET": 11739683636.4032,
                "ACTUAL": 11019378858,
                "PERSEN": 93.9
            },
            {
                "nmcab": "BOALEMO",
                "PARETO": "T",
                "TARGET": 17099785011.8235,
                "ACTUAL": 16061414198,
                "PERSEN": 93.9
            },
            {
                "nmcab": "SUKABUMI",
                "PARETO": "Y",
                "TARGET": 14920189817.941902,
                "ACTUAL": 13992861245,
                "PERSEN": 93.8
            },
            {
                "nmcab": "PASAMAN",
                "PARETO": "T",
                "TARGET": 10655531206.7808,
                "ACTUAL": 9991812652,
                "PERSEN": 93.8
            },
            {
                "nmcab": "TENGGARONG",
                "PARETO": "Y",
                "TARGET": 13533475233.073599,
                "ACTUAL": 12683884307,
                "PERSEN": 93.7
            },
            {
                "nmcab": "TUNGKAL",
                "PARETO": "T",
                "TARGET": 3832516001.5275,
                "ACTUAL": 3586898366,
                "PERSEN": 93.6
            },
            {
                "nmcab": "SOLOK",
                "PARETO": "T",
                "TARGET": 13007815270.359798,
                "ACTUAL": 12175656498,
                "PERSEN": 93.6
            },
            {
                "nmcab": "JAMBI",
                "PARETO": "T",
                "TARGET": 17480125753.9776,
                "ACTUAL": 16358007961,
                "PERSEN": 93.6
            },
            {
                "nmcab": "SEKAYU",
                "PARETO": "T",
                "TARGET": 6698858689.0842,
                "ACTUAL": 6265791306,
                "PERSEN": 93.5
            },
            {
                "nmcab": "PAYAKUMBUH",
                "PARETO": "T",
                "TARGET": 10481817983.968498,
                "ACTUAL": 9801132773,
                "PERSEN": 93.5
            },
            {
                "nmcab": "BUKITTINGGI",
                "PARETO": "Y",
                "TARGET": 12590392824.8976,
                "ACTUAL": 11769686439,
                "PERSEN": 93.5
            },
            {
                "nmcab": "SIDRAP",
                "PARETO": "T",
                "TARGET": 27735104008.012497,
                "ACTUAL": 25943363834,
                "PERSEN": 93.5
            },
            {
                "nmcab": "SORONG",
                "PARETO": "T",
                "TARGET": 7277742335.924799,
                "ACTUAL": 6794345683,
                "PERSEN": 93.4
            },
            {
                "nmcab": "KOTABUMI",
                "PARETO": "Y",
                "TARGET": 7784697432.124001,
                "ACTUAL": 7274357560,
                "PERSEN": 93.4
            },
            {
                "nmcab": "SELAYAR",
                "PARETO": "T",
                "TARGET": 16104425437.5615,
                "ACTUAL": 15028950429,
                "PERSEN": 93.3
            },
            {
                "nmcab": "WAY JEPARA",
                "PARETO": "T",
                "TARGET": 7150655395.754,
                "ACTUAL": 6658744921,
                "PERSEN": 93.1
            },
            {
                "nmcab": "CILACAP",
                "PARETO": "T",
                "TARGET": 7652746858.4855995,
                "ACTUAL": 7127322074,
                "PERSEN": 93.1
            },
            {
                "nmcab": "BINJAI",
                "PARETO": "T",
                "TARGET": 10859609073.983,
                "ACTUAL": 10098894672,
                "PERSEN": 93
            },
            {
                "nmcab": "MAJENE",
                "PARETO": "T",
                "TARGET": 12846375133.136,
                "ACTUAL": 11949197863,
                "PERSEN": 93
            },
            {
                "nmcab": "SENGKANG",
                "PARETO": "T",
                "TARGET": 25861397411.850002,
                "ACTUAL": 24053669869,
                "PERSEN": 93
            },
            {
                "nmcab": "LEUWILIANG",
                "PARETO": "Y",
                "TARGET": 22715585703.456,
                "ACTUAL": 21105609887,
                "PERSEN": 92.9
            },
            {
                "nmcab": "KAYU AGUNG",
                "PARETO": "T",
                "TARGET": 10734650167.033598,
                "ACTUAL": 9964851453,
                "PERSEN": 92.8
            },
            {
                "nmcab": "LHOKSUKON",
                "PARETO": "T",
                "TARGET": 10837886566.4775,
                "ACTUAL": 10057883942,
                "PERSEN": 92.8
            },
            {
                "nmcab": "DAYA MURNI",
                "PARETO": "T",
                "TARGET": 5761774965.404,
                "ACTUAL": 5326958122,
                "PERSEN": 92.5
            },
            {
                "nmcab": "TEBO",
                "PARETO": "T",
                "TARGET": 9402835362.2202,
                "ACTUAL": 8695487469,
                "PERSEN": 92.5
            },
            {
                "nmcab": "LANGSA ACEH",
                "PARETO": "T",
                "TARGET": 10482171537.549799,
                "ACTUAL": 9699293293,
                "PERSEN": 92.5
            },
            {
                "nmcab": "GRESIK",
                "PARETO": "T",
                "TARGET": 5615137186.907,
                "ACTUAL": 5181531185,
                "PERSEN": 92.3
            },
            {
                "nmcab": "EREKE",
                "PARETO": "T",
                "TARGET": 9329790515.3048,
                "ACTUAL": 8605048145,
                "PERSEN": 92.2
            },
            {
                "nmcab": "PEKALONGAN",
                "PARETO": "T",
                "TARGET": 4426330016.3906,
                "ACTUAL": 4082014668,
                "PERSEN": 92.2
            },
            {
                "nmcab": "SAUMLAKI",
                "PARETO": "T",
                "TARGET": 6545033063.4703,
                "ACTUAL": 6029841965,
                "PERSEN": 92.1
            },
            {
                "nmcab": "WONOGIRI",
                "PARETO": "T",
                "TARGET": 8453849118.76,
                "ACTUAL": 7767161933,
                "PERSEN": 91.9
            },
            {
                "nmcab": "SOLO",
                "PARETO": "Y",
                "TARGET": 9095826328.174,
                "ACTUAL": 8359296508,
                "PERSEN": 91.9
            },
            {
                "nmcab": "KEDIRI",
                "PARETO": "Y",
                "TARGET": 8395599648.791401,
                "ACTUAL": 7708220699,
                "PERSEN": 91.8
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "PARETO": "T",
                "TARGET": 11074323528.457998,
                "ACTUAL": 10152559805,
                "PERSEN": 91.7
            },
            {
                "nmcab": "MEDAN",
                "PARETO": "T",
                "TARGET": 16829281317.9472,
                "ACTUAL": 15408958659,
                "PERSEN": 91.6
            },
            {
                "nmcab": "MADIUN",
                "PARETO": "T",
                "TARGET": 5276042796.538,
                "ACTUAL": 4828289215,
                "PERSEN": 91.5
            },
            {
                "nmcab": "SIDOARJO",
                "PARETO": "Y",
                "TARGET": 8764917062.7336,
                "ACTUAL": 8011543338,
                "PERSEN": 91.4
            },
            {
                "nmcab": "PARUNG",
                "PARETO": "T",
                "TARGET": 12424868640.6444,
                "ACTUAL": 11343460587,
                "PERSEN": 91.3
            },
            {
                "nmcab": "KARANGANYAR",
                "PARETO": "T",
                "TARGET": 7785395179.91,
                "ACTUAL": 7104415011,
                "PERSEN": 91.3
            },
            {
                "nmcab": "KOTAMOBAGU",
                "PARETO": "T",
                "TARGET": 10052492753.5472,
                "ACTUAL": 9181311205,
                "PERSEN": 91.3
            },
            {
                "nmcab": "SURABAYA",
                "PARETO": "T",
                "TARGET": 6329585440.6245,
                "ACTUAL": 5759863280,
                "PERSEN": 91
            },
            {
                "nmcab": "MAMUJU",
                "PARETO": "Y",
                "TARGET": 19464464141.4046,
                "ACTUAL": 17711314292,
                "PERSEN": 91
            },
            {
                "nmcab": "WONOSOBO",
                "PARETO": "Y",
                "TARGET": 11730872508.4924,
                "ACTUAL": 10657245624,
                "PERSEN": 90.8
            },
            {
                "nmcab": "LIWA",
                "PARETO": "T",
                "TARGET": 8402369967.302,
                "ACTUAL": 7625539910,
                "PERSEN": 90.8
            },
            {
                "nmcab": "RUMBIA",
                "PARETO": "T",
                "TARGET": 7956498422.327001,
                "ACTUAL": 7227155687,
                "PERSEN": 90.8
            },
            {
                "nmcab": "BANDAR JAYA",
                "PARETO": "T",
                "TARGET": 7068255071.503399,
                "ACTUAL": 6359382845,
                "PERSEN": 90
            },
            {
                "nmcab": "LASUSUA",
                "PARETO": "T",
                "TARGET": 5286341181.914499,
                "ACTUAL": 4757824525,
                "PERSEN": 90
            },
            {
                "nmcab": "PEKANBARU",
                "PARETO": "Y",
                "TARGET": 19359309866.201603,
                "ACTUAL": 17409282775,
                "PERSEN": 89.9
            },
            {
                "nmcab": "POLMAS",
                "PARETO": "T",
                "TARGET": 14014124477.4081,
                "ACTUAL": 12453398246,
                "PERSEN": 88.9
            },
            {
                "nmcab": "BUNGO",
                "PARETO": "T",
                "TARGET": 11991252255.703001,
                "ACTUAL": 10659258061,
                "PERSEN": 88.9
            },
            {
                "nmcab": "MARTAPURA",
                "PARETO": "T",
                "TARGET": 3402202195.096,
                "ACTUAL": 3017933833,
                "PERSEN": 88.7
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "PARETO": "T",
                "TARGET": 581045711.6236,
                "ACTUAL": 510020947,
                "PERSEN": 87.8
            },
            {
                "nmcab": "BOJONEGORO",
                "PARETO": "T",
                "TARGET": 3292291983.222,
                "ACTUAL": 2868978064,
                "PERSEN": 87.1
            },
            {
                "nmcab": "BULI",
                "PARETO": "T",
                "TARGET": 216649731,
                "ACTUAL": 185875274,
                "PERSEN": 85.8
            },
            {
                "nmcab": "KEBUMEN",
                "PARETO": "T",
                "TARGET": 4028082711.5016,
                "ACTUAL": 3408742158,
                "PERSEN": 84.6
            },
            {
                "nmcab": "TULUNGAGUNG",
                "PARETO": "T",
                "TARGET": 4143356435.799,
                "ACTUAL": 3497680015,
                "PERSEN": 84.4
            },
            {
                "nmcab": "JAYAPURA",
                "PARETO": "T",
                "TARGET": 7768484297.8728,
                "ACTUAL": 6407892008,
                "PERSEN": 82.5
            },
            {
                "nmcab": "MOJOKERTO",
                "PARETO": "T",
                "TARGET": 4342366587.4742,
                "ACTUAL": 3543100464,
                "PERSEN": 81.6
            },
            {
                "nmcab": "SOROLANGON",
                "PARETO": "T",
                "TARGET": 449457324,
                "ACTUAL": 0,
                "PERSEN": 0
            },
            {
                "nmcab": "MUARA BULIAN",
                "PARETO": "T",
                "TARGET": 0,
                "ACTUAL": 0,
                "PERSEN": null
            }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "PARETO" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

    $('#tableArCabKon').DataTable({
        "data":[
            {
                "nmcab": "BULI",
                "PARETO": "T",
                "TARGET": 26,
                "ACTUAL": 32,
                "PERSEN": 123.1
            },
            {
                "nmcab": "BELINYU",
                "PARETO": "T",
                "TARGET": 1323,
                "ACTUAL": 1390,
                "PERSEN": 105.1
            },
            {
                "nmcab": "PATROL",
                "PARETO": "T",
                "TARGET": 1327,
                "ACTUAL": 1388,
                "PERSEN": 104.6
            },
            {
                "nmcab": "PELABUHAN RATU",
                "PARETO": "T",
                "TARGET": 2893,
                "ACTUAL": 2992,
                "PERSEN": 103.4
            },
            {
                "nmcab": "DOMPU",
                "PARETO": "T",
                "TARGET": 735,
                "ACTUAL": 756,
                "PERSEN": 102.9
            },
            {
                "nmcab": "JATIBARANG",
                "PARETO": "Y",
                "TARGET": 1768,
                "ACTUAL": 1816,
                "PERSEN": 102.7
            },
            {
                "nmcab": "MOROWALI",
                "PARETO": "T",
                "TARGET": 3370,
                "ACTUAL": 3458,
                "PERSEN": 102.6
            },
            {
                "nmcab": "CIMAHI",
                "PARETO": "Y",
                "TARGET": 2941,
                "ACTUAL": 3015,
                "PERSEN": 102.5
            },
            {
                "nmcab": "BELITUNG",
                "PARETO": "T",
                "TARGET": 2190,
                "ACTUAL": 2240,
                "PERSEN": 102.3
            },
            {
                "nmcab": "GORONTALO",
                "PARETO": "Y",
                "TARGET": 5263,
                "ACTUAL": 5371,
                "PERSEN": 102.1
            },
            {
                "nmcab": "BELTIM",
                "PARETO": "T",
                "TARGET": 1257,
                "ACTUAL": 1282,
                "PERSEN": 102
            },
            {
                "nmcab": "UNAAHA",
                "PARETO": "T",
                "TARGET": 2215,
                "ACTUAL": 2257,
                "PERSEN": 101.9
            },
            {
                "nmcab": "BUNGKU",
                "PARETO": "T",
                "TARGET": 4786,
                "ACTUAL": 4874,
                "PERSEN": 101.8
            },
            {
                "nmcab": "BUOL",
                "PARETO": "T",
                "TARGET": 2869,
                "ACTUAL": 2918,
                "PERSEN": 101.7
            },
            {
                "nmcab": "BARABAI",
                "PARETO": "T",
                "TARGET": 937,
                "ACTUAL": 952,
                "PERSEN": 101.6
            },
            {
                "nmcab": "BERAU",
                "PARETO": "Y",
                "TARGET": 2506,
                "ACTUAL": 2542,
                "PERSEN": 101.4
            },
            {
                "nmcab": "LUWUK",
                "PARETO": "T",
                "TARGET": 2285,
                "ACTUAL": 2314,
                "PERSEN": 101.3
            },
            {
                "nmcab": "TANGGEUNG",
                "PARETO": "T",
                "TARGET": 1532,
                "ACTUAL": 1548,
                "PERSEN": 101
            },
            {
                "nmcab": "KENDARI",
                "PARETO": "Y",
                "TARGET": 5239,
                "ACTUAL": 5289,
                "PERSEN": 101
            },
            {
                "nmcab": "PALU",
                "PARETO": "Y",
                "TARGET": 9779,
                "ACTUAL": 9874,
                "PERSEN": 101
            },
            {
                "nmcab": "PALU 2",
                "PARETO": "Y",
                "TARGET": 5465,
                "ACTUAL": 5518,
                "PERSEN": 101
            },
            {
                "nmcab": "CIREBON",
                "PARETO": "Y",
                "TARGET": 1907,
                "ACTUAL": 1923,
                "PERSEN": 100.8
            },
            {
                "nmcab": "TOBOALI",
                "PARETO": "T",
                "TARGET": 1164,
                "ACTUAL": 1172,
                "PERSEN": 100.7
            },
            {
                "nmcab": "KOTA FAJAR",
                "PARETO": "T",
                "TARGET": 2678,
                "ACTUAL": 2694,
                "PERSEN": 100.6
            },
            {
                "nmcab": "TOMPE",
                "PARETO": "T",
                "TARGET": 1429,
                "ACTUAL": 1436,
                "PERSEN": 100.5
            },
            {
                "nmcab": "SUNGAI LIAT",
                "PARETO": "Y",
                "TARGET": 1137,
                "ACTUAL": 1142,
                "PERSEN": 100.4
            },
            {
                "nmcab": "BANGKA",
                "PARETO": "Y",
                "TARGET": 3452,
                "ACTUAL": 3465,
                "PERSEN": 100.4
            },
            {
                "nmcab": "TOLI TOLI",
                "PARETO": "T",
                "TARGET": 1951,
                "ACTUAL": 1958,
                "PERSEN": 100.4
            },
            {
                "nmcab": "PANGANDARAN",
                "PARETO": "T",
                "TARGET": 2156,
                "ACTUAL": 2164,
                "PERSEN": 100.4
            },
            {
                "nmcab": "BOROKO",
                "PARETO": "T",
                "TARGET": 772,
                "ACTUAL": 774,
                "PERSEN": 100.3
            },
            {
                "nmcab": "KOBA",
                "PARETO": "T",
                "TARGET": 982,
                "ACTUAL": 984,
                "PERSEN": 100.2
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "PARETO": "T",
                "TARGET": 1241,
                "ACTUAL": 1243,
                "PERSEN": 100.2
            },
            {
                "nmcab": "MAKASSAR 3",
                "PARETO": "Y",
                "TARGET": 7132,
                "ACTUAL": 7141,
                "PERSEN": 100.1
            },
            {
                "nmcab": "SANGATTA",
                "PARETO": "Y",
                "TARGET": 1833,
                "ACTUAL": 1835,
                "PERSEN": 100.1
            },
            {
                "nmcab": "CIANJUR",
                "PARETO": "Y",
                "TARGET": 3130,
                "ACTUAL": 3133,
                "PERSEN": 100.1
            },
            {
                "nmcab": "MAGELANG",
                "PARETO": "T",
                "TARGET": 1983,
                "ACTUAL": 1985,
                "PERSEN": 100.1
            },
            {
                "nmcab": "BOEPINANG",
                "PARETO": "T",
                "TARGET": 1352,
                "ACTUAL": 1352,
                "PERSEN": 100
            },
            {
                "nmcab": "JEBUS",
                "PARETO": "T",
                "TARGET": 804,
                "ACTUAL": 804,
                "PERSEN": 100
            },
            {
                "nmcab": "SUMEDANG",
                "PARETO": "T",
                "TARGET": 1555,
                "ACTUAL": 1555,
                "PERSEN": 100
            },
            {
                "nmcab": "MUARA TEWEH",
                "PARETO": "Y",
                "TARGET": 2018,
                "ACTUAL": 2018,
                "PERSEN": 100
            },
            {
                "nmcab": "BATU LICIN",
                "PARETO": "Y",
                "TARGET": 2022,
                "ACTUAL": 2019,
                "PERSEN": 99.9
            },
            {
                "nmcab": "SUNGAI LILIN",
                "PARETO": "T",
                "TARGET": 2391,
                "ACTUAL": 2389,
                "PERSEN": 99.9
            },
            {
                "nmcab": "JAILOLO",
                "PARETO": "Y",
                "TARGET": 3123,
                "ACTUAL": 3116,
                "PERSEN": 99.8
            },
            {
                "nmcab": "RAWAJITU",
                "PARETO": "T",
                "TARGET": 991,
                "ACTUAL": 988,
                "PERSEN": 99.7
            },
            {
                "nmcab": "SALAKAN",
                "PARETO": "T",
                "TARGET": 3706,
                "ACTUAL": 3690,
                "PERSEN": 99.6
            },
            {
                "nmcab": "PENAJAM",
                "PARETO": "T",
                "TARGET": 707,
                "ACTUAL": 704,
                "PERSEN": 99.6
            },
            {
                "nmcab": "POSO",
                "PARETO": "Y",
                "TARGET": 3317,
                "ACTUAL": 3305,
                "PERSEN": 99.6
            },
            {
                "nmcab": "PENDOLO",
                "PARETO": "T",
                "TARGET": 1327,
                "ACTUAL": 1321,
                "PERSEN": 99.5
            },
            {
                "nmcab": "SAMARINDA",
                "PARETO": "Y",
                "TARGET": 1891,
                "ACTUAL": 1880,
                "PERSEN": 99.4
            },
            {
                "nmcab": "SAMPIT",
                "PARETO": "T",
                "TARGET": 1564,
                "ACTUAL": 1554,
                "PERSEN": 99.4
            },
            {
                "nmcab": "KELAPA",
                "PARETO": "Y",
                "TARGET": 1065,
                "ACTUAL": 1059,
                "PERSEN": 99.4
            },
            {
                "nmcab": "MOLIBAGU",
                "PARETO": "T",
                "TARGET": 714,
                "ACTUAL": 710,
                "PERSEN": 99.4
            },
            {
                "nmcab": "KOTARAYA",
                "PARETO": "T",
                "TARGET": 2019,
                "ACTUAL": 2004,
                "PERSEN": 99.3
            },
            {
                "nmcab": "PUNGGALUKU",
                "PARETO": "T",
                "TARGET": 1985,
                "ACTUAL": 1972,
                "PERSEN": 99.3
            },
            {
                "nmcab": "BANDUNG",
                "PARETO": "Y",
                "TARGET": 1988,
                "ACTUAL": 1974,
                "PERSEN": 99.3
            },
            {
                "nmcab": "BIREUEN",
                "PARETO": "Y",
                "TARGET": 2372,
                "ACTUAL": 2355,
                "PERSEN": 99.3
            },
            {
                "nmcab": "RATAHAN",
                "PARETO": "Y",
                "TARGET": 2792,
                "ACTUAL": 2770,
                "PERSEN": 99.2
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "PARETO": "T",
                "TARGET": 2687,
                "ACTUAL": 2666,
                "PERSEN": 99.2
            },
            {
                "nmcab": "GOWA",
                "PARETO": "Y",
                "TARGET": 5662,
                "ACTUAL": 5616,
                "PERSEN": 99.2
            },
            {
                "nmcab": "PLEIHARI",
                "PARETO": "T",
                "TARGET": 1118,
                "ACTUAL": 1109,
                "PERSEN": 99.2
            },
            {
                "nmcab": "BOGOR",
                "PARETO": "Y",
                "TARGET": 2719,
                "ACTUAL": 2696,
                "PERSEN": 99.2
            },
            {
                "nmcab": "CILEUNGSI",
                "PARETO": "Y",
                "TARGET": 4458,
                "ACTUAL": 4423,
                "PERSEN": 99.2
            },
            {
                "nmcab": "SUMBAWA",
                "PARETO": "T",
                "TARGET": 644,
                "ACTUAL": 638,
                "PERSEN": 99.1
            },
            {
                "nmcab": "TALAUD",
                "PARETO": "T",
                "TARGET": 1349,
                "ACTUAL": 1337,
                "PERSEN": 99.1
            },
            {
                "nmcab": "GOWA 2",
                "PARETO": "Y",
                "TARGET": 4545,
                "ACTUAL": 4504,
                "PERSEN": 99.1
            },
            {
                "nmcab": "PALANGKARAYA",
                "PARETO": "Y",
                "TARGET": 1934,
                "ACTUAL": 1917,
                "PERSEN": 99.1
            },
            {
                "nmcab": "PADANG",
                "PARETO": "Y",
                "TARGET": 1808,
                "ACTUAL": 1791,
                "PERSEN": 99.1
            },
            {
                "nmcab": "SIAU",
                "PARETO": "T",
                "TARGET": 932,
                "ACTUAL": 924,
                "PERSEN": 99.1
            },
            {
                "nmcab": "PARIGI",
                "PARETO": "T",
                "TARGET": 2501,
                "ACTUAL": 2477,
                "PERSEN": 99
            },
            {
                "nmcab": "JENEPONTO",
                "PARETO": "T",
                "TARGET": 3810,
                "ACTUAL": 3773,
                "PERSEN": 99
            },
            {
                "nmcab": "KOTABARU",
                "PARETO": "T",
                "TARGET": 1295,
                "ACTUAL": 1282,
                "PERSEN": 99
            },
            {
                "nmcab": "PRINGSEWU",
                "PARETO": "T",
                "TARGET": 1182,
                "ACTUAL": 1169,
                "PERSEN": 98.9
            },
            {
                "nmcab": "TUGUMULYO",
                "PARETO": "T",
                "TARGET": 1038,
                "ACTUAL": 1027,
                "PERSEN": 98.9
            },
            {
                "nmcab": "UJUNG GADING",
                "PARETO": "T",
                "TARGET": 2013,
                "ACTUAL": 1991,
                "PERSEN": 98.9
            },
            {
                "nmcab": "SUBANG",
                "PARETO": "T",
                "TARGET": 1414,
                "ACTUAL": 1398,
                "PERSEN": 98.9
            },
            {
                "nmcab": "PARUNGKUDA",
                "PARETO": "Y",
                "TARGET": 2382,
                "ACTUAL": 2353,
                "PERSEN": 98.8
            },
            {
                "nmcab": "GARUT",
                "PARETO": "Y",
                "TARGET": 2908,
                "ACTUAL": 2874,
                "PERSEN": 98.8
            },
            {
                "nmcab": "TANJUNG",
                "PARETO": "T",
                "TARGET": 1318,
                "ACTUAL": 1302,
                "PERSEN": 98.8
            },
            {
                "nmcab": "KOTOBARU",
                "PARETO": "Y",
                "TARGET": 2370,
                "ACTUAL": 2342,
                "PERSEN": 98.8
            },
            {
                "nmcab": "BELITANG",
                "PARETO": "T",
                "TARGET": 759,
                "ACTUAL": 750,
                "PERSEN": 98.8
            },
            {
                "nmcab": "PANGKEP",
                "PARETO": "T",
                "TARGET": 2143,
                "ACTUAL": 2117,
                "PERSEN": 98.8
            },
            {
                "nmcab": "BEKASI",
                "PARETO": "Y",
                "TARGET": 7393,
                "ACTUAL": 7297,
                "PERSEN": 98.7
            },
            {
                "nmcab": "ALUE BILIE",
                "PARETO": "T",
                "TARGET": 1188,
                "ACTUAL": 1173,
                "PERSEN": 98.7
            },
            {
                "nmcab": "BACAN",
                "PARETO": "T",
                "TARGET": 601,
                "ACTUAL": 593,
                "PERSEN": 98.7
            },
            {
                "nmcab": "MAROS",
                "PARETO": "T",
                "TARGET": 3926,
                "ACTUAL": 3873,
                "PERSEN": 98.7
            },
            {
                "nmcab": "KAPUAS",
                "PARETO": "T",
                "TARGET": 381,
                "ACTUAL": 376,
                "PERSEN": 98.7
            },
            {
                "nmcab": "BANJARMASIN",
                "PARETO": "Y",
                "TARGET": 4886,
                "ACTUAL": 4816,
                "PERSEN": 98.6
            },
            {
                "nmcab": "LUBUKBASUNG",
                "PARETO": "T",
                "TARGET": 1186,
                "ACTUAL": 1169,
                "PERSEN": 98.6
            },
            {
                "nmcab": "AMPANA",
                "PARETO": "T",
                "TARGET": 2138,
                "ACTUAL": 2108,
                "PERSEN": 98.6
            },
            {
                "nmcab": "MENTOK",
                "PARETO": "Y",
                "TARGET": 1154,
                "ACTUAL": 1138,
                "PERSEN": 98.6
            },
            {
                "nmcab": "BLANG PIDIE",
                "PARETO": "T",
                "TARGET": 1860,
                "ACTUAL": 1834,
                "PERSEN": 98.6
            },
            {
                "nmcab": "BETUNG",
                "PARETO": "T",
                "TARGET": 1883,
                "ACTUAL": 1857,
                "PERSEN": 98.6
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "PARETO": "T",
                "TARGET": 990,
                "ACTUAL": 976,
                "PERSEN": 98.6
            },
            {
                "nmcab": "MALANG",
                "PARETO": "T",
                "TARGET": 1823,
                "ACTUAL": 1798,
                "PERSEN": 98.6
            },
            {
                "nmcab": "RUTENG",
                "PARETO": "T",
                "TARGET": 1076,
                "ACTUAL": 1061,
                "PERSEN": 98.6
            },
            {
                "nmcab": "PANGKALANBUN",
                "PARETO": "T",
                "TARGET": 516,
                "ACTUAL": 509,
                "PERSEN": 98.6
            },
            {
                "nmcab": "BALIKPAPAN",
                "PARETO": "Y",
                "TARGET": 1763,
                "ACTUAL": 1737,
                "PERSEN": 98.5
            },
            {
                "nmcab": "MAKASSAR",
                "PARETO": "Y",
                "TARGET": 7125,
                "ACTUAL": 7019,
                "PERSEN": 98.5
            },
            {
                "nmcab": "ARGA MAKMUR",
                "PARETO": "T",
                "TARGET": 1056,
                "ACTUAL": 1039,
                "PERSEN": 98.4
            },
            {
                "nmcab": "MAKASSAR 2",
                "PARETO": "Y",
                "TARGET": 6149,
                "ACTUAL": 6049,
                "PERSEN": 98.4
            },
            {
                "nmcab": "AMBON",
                "PARETO": "Y",
                "TARGET": 4875,
                "ACTUAL": 4799,
                "PERSEN": 98.4
            },
            {
                "nmcab": "BAWEN",
                "PARETO": "T",
                "TARGET": 2822,
                "ACTUAL": 2778,
                "PERSEN": 98.4
            },
            {
                "nmcab": "BATURAJA",
                "PARETO": "T",
                "TARGET": 814,
                "ACTUAL": 800,
                "PERSEN": 98.3
            },
            {
                "nmcab": "TERNATE",
                "PARETO": "Y",
                "TARGET": 3061,
                "ACTUAL": 3008,
                "PERSEN": 98.3
            },
            {
                "nmcab": "SINJAI",
                "PARETO": "T",
                "TARGET": 1487,
                "ACTUAL": 1460,
                "PERSEN": 98.2
            },
            {
                "nmcab": "UJUNG BERUNG",
                "PARETO": "T",
                "TARGET": 1262,
                "ACTUAL": 1239,
                "PERSEN": 98.2
            },
            {
                "nmcab": "SRAGEN",
                "PARETO": "T",
                "TARGET": 1207,
                "ACTUAL": 1185,
                "PERSEN": 98.2
            },
            {
                "nmcab": "BONE",
                "PARETO": "Y",
                "TARGET": 3061,
                "ACTUAL": 3005,
                "PERSEN": 98.2
            },
            {
                "nmcab": "KADIPATEN",
                "PARETO": "T",
                "TARGET": 1640,
                "ACTUAL": 1611,
                "PERSEN": 98.2
            },
            {
                "nmcab": "LAHAT",
                "PARETO": "Y",
                "TARGET": 2854,
                "ACTUAL": 2799,
                "PERSEN": 98.1
            },
            {
                "nmcab": "KARAWANG",
                "PARETO": "Y",
                "TARGET": 5045,
                "ACTUAL": 4947,
                "PERSEN": 98.1
            },
            {
                "nmcab": "MUARA ENIM",
                "PARETO": "Y",
                "TARGET": 1284,
                "ACTUAL": 1259,
                "PERSEN": 98.1
            },
            {
                "nmcab": "PASANGKAYU",
                "PARETO": "T",
                "TARGET": 2661,
                "ACTUAL": 2611,
                "PERSEN": 98.1
            },
            {
                "nmcab": "PURWAKARTA",
                "PARETO": "T",
                "TARGET": 2681,
                "ACTUAL": 2631,
                "PERSEN": 98.1
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "PARETO": "T",
                "TARGET": 2146,
                "ACTUAL": 2106,
                "PERSEN": 98.1
            },
            {
                "nmcab": "ENDE",
                "PARETO": "T",
                "TARGET": 611,
                "ACTUAL": 599,
                "PERSEN": 98
            },
            {
                "nmcab": "SEMARANG",
                "PARETO": "Y",
                "TARGET": 4638,
                "ACTUAL": 4542,
                "PERSEN": 97.9
            },
            {
                "nmcab": "MARTAPURA KAL",
                "PARETO": "Y",
                "TARGET": 2047,
                "ACTUAL": 2004,
                "PERSEN": 97.9
            },
            {
                "nmcab": "TENTENA",
                "PARETO": "T",
                "TARGET": 2009,
                "ACTUAL": 1966,
                "PERSEN": 97.9
            },
            {
                "nmcab": "MASBAGIK",
                "PARETO": "T",
                "TARGET": 1966,
                "ACTUAL": 1924,
                "PERSEN": 97.9
            },
            {
                "nmcab": "KASIPUTE",
                "PARETO": "T",
                "TARGET": 1617,
                "ACTUAL": 1583,
                "PERSEN": 97.9
            },
            {
                "nmcab": "ULEE GLEE",
                "PARETO": "T",
                "TARGET": 804,
                "ACTUAL": 787,
                "PERSEN": 97.9
            },
            {
                "nmcab": "WAISARISSA",
                "PARETO": "T",
                "TARGET": 1806,
                "ACTUAL": 1767,
                "PERSEN": 97.8
            },
            {
                "nmcab": "TARAKAN",
                "PARETO": "T",
                "TARGET": 877,
                "ACTUAL": 858,
                "PERSEN": 97.8
            },
            {
                "nmcab": "BENGKULU",
                "PARETO": "T",
                "TARGET": 691,
                "ACTUAL": 676,
                "PERSEN": 97.8
            },
            {
                "nmcab": "BANTAENG",
                "PARETO": "T",
                "TARGET": 1995,
                "ACTUAL": 1951,
                "PERSEN": 97.8
            },
            {
                "nmcab": "BELOPA",
                "PARETO": "T",
                "TARGET": 2466,
                "ACTUAL": 2412,
                "PERSEN": 97.8
            },
            {
                "nmcab": "CIBINONG",
                "PARETO": "T",
                "TARGET": 3336,
                "ACTUAL": 3264,
                "PERSEN": 97.8
            },
            {
                "nmcab": "CIAWI",
                "PARETO": "T",
                "TARGET": 1222,
                "ACTUAL": 1194,
                "PERSEN": 97.7
            },
            {
                "nmcab": "TOILI",
                "PARETO": "T",
                "TARGET": 2435,
                "ACTUAL": 2378,
                "PERSEN": 97.7
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "PARETO": "T",
                "TARGET": 2989,
                "ACTUAL": 2920,
                "PERSEN": 97.7
            },
            {
                "nmcab": "KOLAKA",
                "PARETO": "Y",
                "TARGET": 3851,
                "ACTUAL": 3761,
                "PERSEN": 97.7
            },
            {
                "nmcab": "MEULABOH",
                "PARETO": "Y",
                "TARGET": 3641,
                "ACTUAL": 3553,
                "PERSEN": 97.6
            },
            {
                "nmcab": "DONGGALA",
                "PARETO": "T",
                "TARGET": 2710,
                "ACTUAL": 2646,
                "PERSEN": 97.6
            },
            {
                "nmcab": "LABUAN BAJO",
                "PARETO": "T",
                "TARGET": 831,
                "ACTUAL": 811,
                "PERSEN": 97.6
            },
            {
                "nmcab": "BANJAR",
                "PARETO": "T",
                "TARGET": 1687,
                "ACTUAL": 1646,
                "PERSEN": 97.6
            },
            {
                "nmcab": "TAKALAR",
                "PARETO": "Y",
                "TARGET": 3827,
                "ACTUAL": 3734,
                "PERSEN": 97.6
            },
            {
                "nmcab": "JAMPANG",
                "PARETO": "T",
                "TARGET": 967,
                "ACTUAL": 944,
                "PERSEN": 97.6
            },
            {
                "nmcab": "PALEMBANG",
                "PARETO": "Y",
                "TARGET": 4025,
                "ACTUAL": 3925,
                "PERSEN": 97.5
            },
            {
                "nmcab": "MASOHI",
                "PARETO": "Y",
                "TARGET": 2689,
                "ACTUAL": 2622,
                "PERSEN": 97.5
            },
            {
                "nmcab": "PONTIANAK",
                "PARETO": "T",
                "TARGET": 401,
                "ACTUAL": 391,
                "PERSEN": 97.5
            },
            {
                "nmcab": "MANADO",
                "PARETO": "Y",
                "TARGET": 3443,
                "ACTUAL": 3357,
                "PERSEN": 97.5
            },
            {
                "nmcab": "KUNINGAN",
                "PARETO": "T",
                "TARGET": 1190,
                "ACTUAL": 1160,
                "PERSEN": 97.5
            },
            {
                "nmcab": "TOMOHON",
                "PARETO": "T",
                "TARGET": 769,
                "ACTUAL": 750,
                "PERSEN": 97.5
            },
            {
                "nmcab": "MANOKWARI",
                "PARETO": "T",
                "TARGET": 1290,
                "ACTUAL": 1257,
                "PERSEN": 97.4
            },
            {
                "nmcab": "YOGYAKARTA",
                "PARETO": "T",
                "TARGET": 1736,
                "ACTUAL": 1691,
                "PERSEN": 97.4
            },
            {
                "nmcab": "BANGKALA",
                "PARETO": "T",
                "TARGET": 2378,
                "ACTUAL": 2317,
                "PERSEN": 97.4
            },
            {
                "nmcab": "KUALA SIMPANG",
                "PARETO": "Y",
                "TARGET": 3827,
                "ACTUAL": 3725,
                "PERSEN": 97.3
            },
            {
                "nmcab": "BUTON",
                "PARETO": "Y",
                "TARGET": 4107,
                "ACTUAL": 3997,
                "PERSEN": 97.3
            },
            {
                "nmcab": "PINRANG",
                "PARETO": "T",
                "TARGET": 2509,
                "ACTUAL": 2438,
                "PERSEN": 97.2
            },
            {
                "nmcab": "PALOPO",
                "PARETO": "Y",
                "TARGET": 4142,
                "ACTUAL": 4027,
                "PERSEN": 97.2
            },
            {
                "nmcab": "JEMBER",
                "PARETO": "T",
                "TARGET": 2351,
                "ACTUAL": 2285,
                "PERSEN": 97.2
            },
            {
                "nmcab": "TULANG BAWANG",
                "PARETO": "T",
                "TARGET": 1115,
                "ACTUAL": 1084,
                "PERSEN": 97.2
            },
            {
                "nmcab": "LADONGI",
                "PARETO": "T",
                "TARGET": 1290,
                "ACTUAL": 1252,
                "PERSEN": 97.1
            },
            {
                "nmcab": "BANGKO",
                "PARETO": "T",
                "TARGET": 1152,
                "ACTUAL": 1119,
                "PERSEN": 97.1
            },
            {
                "nmcab": "RAHA",
                "PARETO": "T",
                "TARGET": 2035,
                "ACTUAL": 1977,
                "PERSEN": 97.1
            },
            {
                "nmcab": "ACEH",
                "PARETO": "Y",
                "TARGET": 3037,
                "ACTUAL": 2950,
                "PERSEN": 97.1
            },
            {
                "nmcab": "TEGAL",
                "PARETO": "T",
                "TARGET": 1886,
                "ACTUAL": 1831,
                "PERSEN": 97.1
            },
            {
                "nmcab": "IDIE",
                "PARETO": "Y",
                "TARGET": 3161,
                "ACTUAL": 3070,
                "PERSEN": 97.1
            },
            {
                "nmcab": "MAKALE",
                "PARETO": "T",
                "TARGET": 2194,
                "ACTUAL": 2131,
                "PERSEN": 97.1
            },
            {
                "nmcab": "CIKARANG",
                "PARETO": "T",
                "TARGET": 2616,
                "ACTUAL": 2539,
                "PERSEN": 97.1
            },
            {
                "nmcab": "KOTAMOBAGU",
                "PARETO": "T",
                "TARGET": 1212,
                "ACTUAL": 1177,
                "PERSEN": 97.1
            },
            {
                "nmcab": "NAGAN",
                "PARETO": "T",
                "TARGET": 1330,
                "ACTUAL": 1291,
                "PERSEN": 97.1
            },
            {
                "nmcab": "PARIAMAN",
                "PARETO": "Y",
                "TARGET": 1122,
                "ACTUAL": 1089,
                "PERSEN": 97.1
            },
            {
                "nmcab": "TANAH GROGOT",
                "PARETO": "T",
                "TARGET": 1042,
                "ACTUAL": 1011,
                "PERSEN": 97
            },
            {
                "nmcab": "TOPPOYO",
                "PARETO": "Y",
                "TARGET": 2567,
                "ACTUAL": 2489,
                "PERSEN": 97
            },
            {
                "nmcab": "KALIANDA",
                "PARETO": "Y",
                "TARGET": 1723,
                "ACTUAL": 1670,
                "PERSEN": 96.9
            },
            {
                "nmcab": "SIGLI",
                "PARETO": "T",
                "TARGET": 1286,
                "ACTUAL": 1246,
                "PERSEN": 96.9
            },
            {
                "nmcab": "PRABUMULIH",
                "PARETO": "Y",
                "TARGET": 1295,
                "ACTUAL": 1255,
                "PERSEN": 96.9
            },
            {
                "nmcab": "BABAT TOMAN",
                "PARETO": "T",
                "TARGET": 818,
                "ACTUAL": 793,
                "PERSEN": 96.9
            },
            {
                "nmcab": "TOBELO",
                "PARETO": "T",
                "TARGET": 1335,
                "ACTUAL": 1294,
                "PERSEN": 96.9
            },
            {
                "nmcab": "PANTON LABU",
                "PARETO": "T",
                "TARGET": 1094,
                "ACTUAL": 1060,
                "PERSEN": 96.9
            },
            {
                "nmcab": "BINJAI",
                "PARETO": "T",
                "TARGET": 1000,
                "ACTUAL": 968,
                "PERSEN": 96.8
            },
            {
                "nmcab": "TAKENGON",
                "PARETO": "T",
                "TARGET": 2650,
                "ACTUAL": 2565,
                "PERSEN": 96.8
            },
            {
                "nmcab": "LEUWILIANG",
                "PARETO": "Y",
                "TARGET": 3139,
                "ACTUAL": 3038,
                "PERSEN": 96.8
            },
            {
                "nmcab": "BOALEMO",
                "PARETO": "T",
                "TARGET": 2099,
                "ACTUAL": 2032,
                "PERSEN": 96.8
            },
            {
                "nmcab": "NAMLEA",
                "PARETO": "T",
                "TARGET": 2057,
                "ACTUAL": 1992,
                "PERSEN": 96.8
            },
            {
                "nmcab": "TEMANGGUNG",
                "PARETO": "T",
                "TARGET": 3392,
                "ACTUAL": 3285,
                "PERSEN": 96.8
            },
            {
                "nmcab": "TUNGKAL",
                "PARETO": "T",
                "TARGET": 581,
                "ACTUAL": 562,
                "PERSEN": 96.7
            },
            {
                "nmcab": "INDRALAYA",
                "PARETO": "Y",
                "TARGET": 1199,
                "ACTUAL": 1159,
                "PERSEN": 96.7
            },
            {
                "nmcab": "BULUKUMBA",
                "PARETO": "T",
                "TARGET": 3380,
                "ACTUAL": 3270,
                "PERSEN": 96.7
            },
            {
                "nmcab": "BITUNG",
                "PARETO": "Y",
                "TARGET": 3370,
                "ACTUAL": 3258,
                "PERSEN": 96.7
            },
            {
                "nmcab": "SERANG",
                "PARETO": "Y",
                "TARGET": 1839,
                "ACTUAL": 1778,
                "PERSEN": 96.7
            },
            {
                "nmcab": "TASIKMALAYA",
                "PARETO": "Y",
                "TARGET": 2278,
                "ACTUAL": 2203,
                "PERSEN": 96.7
            },
            {
                "nmcab": "DAYA MURNI",
                "PARETO": "T",
                "TARGET": 701,
                "ACTUAL": 677,
                "PERSEN": 96.6
            },
            {
                "nmcab": "WONOSARI",
                "PARETO": "T",
                "TARGET": 1702,
                "ACTUAL": 1644,
                "PERSEN": 96.6
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "PARETO": "T",
                "TARGET": 929,
                "ACTUAL": 897,
                "PERSEN": 96.6
            },
            {
                "nmcab": "BANJARAN",
                "PARETO": "T",
                "TARGET": 1756,
                "ACTUAL": 1697,
                "PERSEN": 96.6
            },
            {
                "nmcab": "MEDAN",
                "PARETO": "T",
                "TARGET": 1395,
                "ACTUAL": 1348,
                "PERSEN": 96.6
            },
            {
                "nmcab": "PASAMAN",
                "PARETO": "T",
                "TARGET": 996,
                "ACTUAL": 962,
                "PERSEN": 96.6
            },
            {
                "nmcab": "TANGERANG",
                "PARETO": "Y",
                "TARGET": 2516,
                "ACTUAL": 2427,
                "PERSEN": 96.5
            },
            {
                "nmcab": "MALINO",
                "PARETO": "T",
                "TARGET": 949,
                "ACTUAL": 915,
                "PERSEN": 96.4
            },
            {
                "nmcab": "MASAMBA",
                "PARETO": "Y",
                "TARGET": 2752,
                "ACTUAL": 2652,
                "PERSEN": 96.4
            },
            {
                "nmcab": "SIJUNGJUNG",
                "PARETO": "T",
                "TARGET": 1461,
                "ACTUAL": 1407,
                "PERSEN": 96.3
            },
            {
                "nmcab": "METRO",
                "PARETO": "Y",
                "TARGET": 1677,
                "ACTUAL": 1615,
                "PERSEN": 96.3
            },
            {
                "nmcab": "MANGKUTANA",
                "PARETO": "T",
                "TARGET": 2511,
                "ACTUAL": 2419,
                "PERSEN": 96.3
            },
            {
                "nmcab": "BUNTA",
                "PARETO": "Y",
                "TARGET": 2330,
                "ACTUAL": 2244,
                "PERSEN": 96.3
            },
            {
                "nmcab": "PROBOLINGGO",
                "PARETO": "T",
                "TARGET": 1186,
                "ACTUAL": 1141,
                "PERSEN": 96.2
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "PARETO": "T",
                "TARGET": 79,
                "ACTUAL": 76,
                "PERSEN": 96.2
            },
            {
                "nmcab": "BOYOLALI",
                "PARETO": "T",
                "TARGET": 1559,
                "ACTUAL": 1498,
                "PERSEN": 96.1
            },
            {
                "nmcab": "WAY KANAN",
                "PARETO": "T",
                "TARGET": 1191,
                "ACTUAL": 1143,
                "PERSEN": 96
            },
            {
                "nmcab": "PEKALONGAN",
                "PARETO": "T",
                "TARGET": 1130,
                "ACTUAL": 1085,
                "PERSEN": 96
            },
            {
                "nmcab": "TUAL",
                "PARETO": "T",
                "TARGET": 1580,
                "ACTUAL": 1515,
                "PERSEN": 95.9
            },
            {
                "nmcab": "CURUP",
                "PARETO": "T",
                "TARGET": 811,
                "ACTUAL": 777,
                "PERSEN": 95.8
            },
            {
                "nmcab": "MALILI",
                "PARETO": "T",
                "TARGET": 2173,
                "ACTUAL": 2082,
                "PERSEN": 95.8
            },
            {
                "nmcab": "LAMPUNG",
                "PARETO": "Y",
                "TARGET": 3680,
                "ACTUAL": 3527,
                "PERSEN": 95.8
            },
            {
                "nmcab": "TORAJA",
                "PARETO": "Y",
                "TARGET": 3103,
                "ACTUAL": 2973,
                "PERSEN": 95.8
            },
            {
                "nmcab": "BLITAR",
                "PARETO": "Y",
                "TARGET": 1986,
                "ACTUAL": 1903,
                "PERSEN": 95.8
            },
            {
                "nmcab": "ENREKANG",
                "PARETO": "T",
                "TARGET": 1138,
                "ACTUAL": 1089,
                "PERSEN": 95.7
            },
            {
                "nmcab": "MARISA",
                "PARETO": "T",
                "TARGET": 2361,
                "ACTUAL": 2259,
                "PERSEN": 95.7
            },
            {
                "nmcab": "LIWA",
                "PARETO": "T",
                "TARGET": 1043,
                "ACTUAL": 998,
                "PERSEN": 95.7
            },
            {
                "nmcab": "SELAYAR",
                "PARETO": "T",
                "TARGET": 1927,
                "ACTUAL": 1845,
                "PERSEN": 95.7
            },
            {
                "nmcab": "KAYU AGUNG",
                "PARETO": "T",
                "TARGET": 1025,
                "ACTUAL": 981,
                "PERSEN": 95.7
            },
            {
                "nmcab": "PARE-PARE",
                "PARETO": "Y",
                "TARGET": 2480,
                "ACTUAL": 2372,
                "PERSEN": 95.6
            },
            {
                "nmcab": "BUKITTINGGI",
                "PARETO": "Y",
                "TARGET": 1259,
                "ACTUAL": 1204,
                "PERSEN": 95.6
            },
            {
                "nmcab": "LHOKSUKON",
                "PARETO": "T",
                "TARGET": 959,
                "ACTUAL": 916,
                "PERSEN": 95.5
            },
            {
                "nmcab": "MAMUJU",
                "PARETO": "Y",
                "TARGET": 2194,
                "ACTUAL": 2095,
                "PERSEN": 95.5
            },
            {
                "nmcab": "MAJENE",
                "PARETO": "T",
                "TARGET": 1501,
                "ACTUAL": 1433,
                "PERSEN": 95.5
            },
            {
                "nmcab": "TENGGARONG",
                "PARETO": "Y",
                "TARGET": 1287,
                "ACTUAL": 1228,
                "PERSEN": 95.4
            },
            {
                "nmcab": "SABAK",
                "PARETO": "T",
                "TARGET": 867,
                "ACTUAL": 827,
                "PERSEN": 95.4
            },
            {
                "nmcab": "PAYAKUMBUH",
                "PARETO": "T",
                "TARGET": 967,
                "ACTUAL": 922,
                "PERSEN": 95.3
            },
            {
                "nmcab": "SOPPENG",
                "PARETO": "T",
                "TARGET": 1413,
                "ACTUAL": 1345,
                "PERSEN": 95.2
            },
            {
                "nmcab": "KOTA AGUNG",
                "PARETO": "T",
                "TARGET": 689,
                "ACTUAL": 656,
                "PERSEN": 95.2
            },
            {
                "nmcab": "SAUMLAKI",
                "PARETO": "T",
                "TARGET": 1078,
                "ACTUAL": 1025,
                "PERSEN": 95.1
            },
            {
                "nmcab": "KOTABUMI",
                "PARETO": "Y",
                "TARGET": 1011,
                "ACTUAL": 961,
                "PERSEN": 95.1
            },
            {
                "nmcab": "JAMBI",
                "PARETO": "T",
                "TARGET": 1553,
                "ACTUAL": 1477,
                "PERSEN": 95.1
            },
            {
                "nmcab": "PURWOKERTO",
                "PARETO": "T",
                "TARGET": 1942,
                "ACTUAL": 1845,
                "PERSEN": 95
            },
            {
                "nmcab": "TAHUNA",
                "PARETO": "T",
                "TARGET": 1475,
                "ACTUAL": 1401,
                "PERSEN": 95
            },
            {
                "nmcab": "SUKABUMI",
                "PARETO": "Y",
                "TARGET": 1808,
                "ACTUAL": 1716,
                "PERSEN": 94.9
            },
            {
                "nmcab": "SEKAYU",
                "PARETO": "T",
                "TARGET": 648,
                "ACTUAL": 615,
                "PERSEN": 94.9
            },
            {
                "nmcab": "LASUSUA",
                "PARETO": "T",
                "TARGET": 765,
                "ACTUAL": 726,
                "PERSEN": 94.9
            },
            {
                "nmcab": "LANGSA ACEH",
                "PARETO": "T",
                "TARGET": 1114,
                "ACTUAL": 1057,
                "PERSEN": 94.9
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "PARETO": "T",
                "TARGET": 1149,
                "ACTUAL": 1090,
                "PERSEN": 94.9
            },
            {
                "nmcab": "BATU SANGKAR",
                "PARETO": "T",
                "TARGET": 1219,
                "ACTUAL": 1155,
                "PERSEN": 94.7
            },
            {
                "nmcab": "MOROTAI",
                "PARETO": "T",
                "TARGET": 201,
                "ACTUAL": 190,
                "PERSEN": 94.5
            },
            {
                "nmcab": "SOLO",
                "PARETO": "Y",
                "TARGET": 2094,
                "ACTUAL": 1976,
                "PERSEN": 94.4
            },
            {
                "nmcab": "SENGKANG",
                "PARETO": "T",
                "TARGET": 2218,
                "ACTUAL": 2094,
                "PERSEN": 94.4
            },
            {
                "nmcab": "WAY JEPARA",
                "PARETO": "T",
                "TARGET": 940,
                "ACTUAL": 887,
                "PERSEN": 94.4
            },
            {
                "nmcab": "SIDRAP",
                "PARETO": "T",
                "TARGET": 2566,
                "ACTUAL": 2421,
                "PERSEN": 94.3
            },
            {
                "nmcab": "SOLOK",
                "PARETO": "T",
                "TARGET": 1328,
                "ACTUAL": 1252,
                "PERSEN": 94.3
            },
            {
                "nmcab": "CILEDUG",
                "PARETO": "T",
                "TARGET": 1790,
                "ACTUAL": 1688,
                "PERSEN": 94.3
            },
            {
                "nmcab": "BARRU",
                "PARETO": "T",
                "TARGET": 1554,
                "ACTUAL": 1464,
                "PERSEN": 94.2
            },
            {
                "nmcab": "MARTAPURA",
                "PARETO": "T",
                "TARGET": 445,
                "ACTUAL": 419,
                "PERSEN": 94.2
            },
            {
                "nmcab": "BUNGO",
                "PARETO": "T",
                "TARGET": 920,
                "ACTUAL": 866,
                "PERSEN": 94.1
            },
            {
                "nmcab": "BALARAJA",
                "PARETO": "T",
                "TARGET": 1554,
                "ACTUAL": 1463,
                "PERSEN": 94.1
            },
            {
                "nmcab": "TEBO",
                "PARETO": "T",
                "TARGET": 734,
                "ACTUAL": 690,
                "PERSEN": 94
            },
            {
                "nmcab": "EREKE",
                "PARETO": "T",
                "TARGET": 1101,
                "ACTUAL": 1030,
                "PERSEN": 93.6
            },
            {
                "nmcab": "SIDOARJO",
                "PARETO": "Y",
                "TARGET": 1992,
                "ACTUAL": 1865,
                "PERSEN": 93.6
            },
            {
                "nmcab": "RUMBIA",
                "PARETO": "T",
                "TARGET": 1043,
                "ACTUAL": 976,
                "PERSEN": 93.6
            },
            {
                "nmcab": "SURABAYA",
                "PARETO": "T",
                "TARGET": 1336,
                "ACTUAL": 1249,
                "PERSEN": 93.5
            },
            {
                "nmcab": "PARUNG",
                "PARETO": "T",
                "TARGET": 1704,
                "ACTUAL": 1594,
                "PERSEN": 93.5
            },
            {
                "nmcab": "WONOSOBO",
                "PARETO": "Y",
                "TARGET": 2874,
                "ACTUAL": 2688,
                "PERSEN": 93.5
            },
            {
                "nmcab": "WONOGIRI",
                "PARETO": "T",
                "TARGET": 1912,
                "ACTUAL": 1787,
                "PERSEN": 93.5
            },
            {
                "nmcab": "POLMAS",
                "PARETO": "T",
                "TARGET": 1643,
                "ACTUAL": 1535,
                "PERSEN": 93.4
            },
            {
                "nmcab": "SORONG",
                "PARETO": "T",
                "TARGET": 587,
                "ACTUAL": 548,
                "PERSEN": 93.4
            },
            {
                "nmcab": "KEDIRI",
                "PARETO": "Y",
                "TARGET": 1898,
                "ACTUAL": 1764,
                "PERSEN": 92.9
            },
            {
                "nmcab": "BANDAR JAYA",
                "PARETO": "T",
                "TARGET": 903,
                "ACTUAL": 839,
                "PERSEN": 92.9
            },
            {
                "nmcab": "PATI",
                "PARETO": "T",
                "TARGET": 1298,
                "ACTUAL": 1202,
                "PERSEN": 92.6
            },
            {
                "nmcab": "GRESIK",
                "PARETO": "T",
                "TARGET": 1127,
                "ACTUAL": 1039,
                "PERSEN": 92.2
            },
            {
                "nmcab": "PEKANBARU",
                "PARETO": "Y",
                "TARGET": 1522,
                "ACTUAL": 1402,
                "PERSEN": 92.1
            },
            {
                "nmcab": "KARANGANYAR",
                "PARETO": "T",
                "TARGET": 1801,
                "ACTUAL": 1656,
                "PERSEN": 91.9
            },
            {
                "nmcab": "CILACAP",
                "PARETO": "T",
                "TARGET": 1664,
                "ACTUAL": 1528,
                "PERSEN": 91.8
            },
            {
                "nmcab": "TULUNGAGUNG",
                "PARETO": "T",
                "TARGET": 1075,
                "ACTUAL": 981,
                "PERSEN": 91.3
            },
            {
                "nmcab": "MADIUN",
                "PARETO": "T",
                "TARGET": 1092,
                "ACTUAL": 997,
                "PERSEN": 91.3
            },
            {
                "nmcab": "KEBUMEN",
                "PARETO": "T",
                "TARGET": 1009,
                "ACTUAL": 912,
                "PERSEN": 90.4
            },
            {
                "nmcab": "MOJOKERTO",
                "PARETO": "T",
                "TARGET": 1081,
                "ACTUAL": 967,
                "PERSEN": 89.5
            },
            {
                "nmcab": "BOJONEGORO",
                "PARETO": "T",
                "TARGET": 705,
                "ACTUAL": 624,
                "PERSEN": 88.5
            },
            {
                "nmcab": "JAYAPURA",
                "PARETO": "T",
                "TARGET": 608,
                "ACTUAL": 535,
                "PERSEN": 88
            },
            {
                "nmcab": "SOROLANGON",
                "PARETO": "T",
                "TARGET": 20,
                "ACTUAL": 0,
                "PERSEN": 0
            },
            {
                "nmcab": "MUARA BULIAN",
                "PARETO": "T",
                "TARGET": 0,
                "ACTUAL": 0,
                "PERSEN": null
            }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "PARETO" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

    $('#tableBucketRp').DataTable({
        "data":[
            {
                "bucket": "LANCAR",
                "RUPIAH": 4315594820445,
                "PERSEN": 88.9
            },
            {
                "bucket": "OD1",
                "RUPIAH": 322984835699,
                "PERSEN": 6.7
            },
            {
                "bucket": "OD2",
                "RUPIAH": 95855393516,
                "PERSEN": 2
            },
            {
                "bucket": "OD3",
                "RUPIAH": 50444117456,
                "PERSEN": 1
            },
            {
                "bucket": "OD4",
                "RUPIAH": 30296486165,
                "PERSEN": 0.6
            },
            {
                "bucket": "OD5",
                "RUPIAH": 23310196555,
                "PERSEN": 0.5
            },
            {
                "bucket": "OD6",
                "RUPIAH": 17991850058,
                "PERSEN": 0.4
            },
            {
                "bucket": "ODLB6",
                "RUPIAH": 189489832,
                "PERSEN": 0.1
            }
        ],
        "columns": [
            { "data": "bucket" },
            { "data": "RUPIAH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableBucketKon').DataTable({
        "data":[
            {
                "bucket": "LANCAR",
                "KONSUMEN": 453963,
                "PERSEN": 86.5
            },
            {
                "bucket": "OD1",
                "KONSUMEN": 41893,
                "PERSEN": 8
            },
            {
                "bucket": "OD2",
                "KONSUMEN": 12877,
                "PERSEN": 2.5
            },
            {
                "bucket": "OD3",
                "KONSUMEN": 6663,
                "PERSEN": 1.3
            },
            {
                "bucket": "OD4",
                "KONSUMEN": 4064,
                "PERSEN": 0.8
            },
            {
                "bucket": "OD5",
                "KONSUMEN": 3004,
                "PERSEN": 0.6
            },
            {
                "bucket": "OD6",
                "KONSUMEN": 2343,
                "PERSEN": 0.5
            },
            {
                "bucket": "ODLB6",
                "KONSUMEN": 17,
                "PERSEN": 0.1
            }
        ],
        "columns": [
            { "data": "bucket" },
            { "data": "KONSUMEN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableBucketRegRp').DataTable({
        "data":[
          {
            "regional": "ACEH 1",
            "LANCAR": 91.1,
            "OD1": 5.9,
            "OD2": 1.5,
            "OD3": 0.7,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "regional": "ACEH 2",
            "LANCAR": 90.2,
            "OD1": 6.9,
            "OD2": 1.6,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "JAWA BARAT 1",
            "LANCAR": 88.1,
            "OD1": 6.7,
            "OD2": 2.2,
            "OD3": 1.4,
            "OD4": 0.8,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "JAWA BARAT 2",
            "LANCAR": 86.7,
            "OD1": 7.4,
            "OD2": 2.9,
            "OD3": 1.6,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "regional": "JAWA BARAT 3",
            "LANCAR": 84.8,
            "OD1": 8.1,
            "OD2": 2.7,
            "OD3": 2.2,
            "OD4": 1.4,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "JAWA TENGAH",
            "LANCAR": 77.3,
            "OD1": 12.2,
            "OD2": 4.3,
            "OD3": 2.4,
            "OD4": 1.6,
            "OD5": 1.3,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "regional": "JAWA TIMUR",
            "LANCAR": 81.5,
            "OD1": 9.8,
            "OD2": 3.6,
            "OD3": 1.8,
            "OD4": 1.4,
            "OD5": 1.1,
            "OD6": 0.8,
            "ODLB6": 0.1
          },
          {
            "regional": "KALIMANTAN 1",
            "LANCAR": 85.8,
            "OD1": 8.6,
            "OD2": 2.5,
            "OD3": 1.2,
            "OD4": 0.8,
            "OD5": 0.6,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "KALIMANTAN 2",
            "LANCAR": 90.4,
            "OD1": 5.5,
            "OD2": 1.7,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.5,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "MAPA",
            "LANCAR": 90.2,
            "OD1": 6.9,
            "OD2": 1.4,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0.1
          },
          {
            "regional": "NUSA TENGGARA",
            "LANCAR": 89.2,
            "OD1": 6.1,
            "OD2": 1.7,
            "OD3": 1.3,
            "OD4": 1,
            "OD5": 0.6,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 1",
            "LANCAR": 89.5,
            "OD1": 7.1,
            "OD2": 1.6,
            "OD3": 0.7,
            "OD4": 0.4,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 2",
            "LANCAR": 94.1,
            "OD1": 3.9,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 3",
            "LANCAR": 90.6,
            "OD1": 6.1,
            "OD2": 1.6,
            "OD3": 0.8,
            "OD4": 0.4,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 4",
            "LANCAR": 93.1,
            "OD1": 4.5,
            "OD2": 1.1,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 5",
            "LANCAR": 85.3,
            "OD1": 8,
            "OD2": 2.6,
            "OD3": 1.5,
            "OD4": 1,
            "OD5": 0.9,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "regional": "SUMATERA 2",
            "LANCAR": 83.8,
            "OD1": 8.2,
            "OD2": 3.7,
            "OD3": 1.8,
            "OD4": 1.3,
            "OD5": 1,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "SUMATERA 3",
            "LANCAR": 88.6,
            "OD1": 6.7,
            "OD2": 2.1,
            "OD3": 1.1,
            "OD4": 0.6,
            "OD5": 0.5,
            "OD6": 0.4,
            "ODLB6": 0.2
          },
          {
            "regional": "SUMATERA 4",
            "LANCAR": 86.5,
            "OD1": 7.1,
            "OD2": 2.6,
            "OD3": 1.4,
            "OD4": 0.9,
            "OD5": 0.8,
            "OD6": 0.6,
            "ODLB6": 0.1
          },
          {
            "regional": "SUMATERA 5",
            "LANCAR": 96.6,
            "OD1": 2.4,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "regional": "SUMATERA 6",
            "LANCAR": 86.8,
            "OD1": 7.1,
            "OD2": 2.7,
            "OD3": 1.3,
            "OD4": 0.8,
            "OD5": 0.8,
            "OD6": 0.6,
            "ODLB6": 0.1
          }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "LANCAR" },
            { "data": "OD1" },
            { "data": "OD2" },
            { "data": "OD3" },
            { "data": "OD4" },
            { "data": "OD5" },
            { "data": "OD6" },
            { "data": "ODLB6" },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableBucketRegKon').DataTable({
        "data":[
          {
            "regional": "ACEH 1",
            "LANCAR": 91.1,
            "OD1": 5.9,
            "OD2": 1.5,
            "OD3": 0.7,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "regional": "ACEH 2",
            "LANCAR": 90.2,
            "OD1": 6.9,
            "OD2": 1.6,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "JAWA BARAT 1",
            "LANCAR": 88.1,
            "OD1": 6.7,
            "OD2": 2.2,
            "OD3": 1.4,
            "OD4": 0.8,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "JAWA BARAT 2",
            "LANCAR": 86.7,
            "OD1": 7.4,
            "OD2": 2.9,
            "OD3": 1.6,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "regional": "JAWA BARAT 3",
            "LANCAR": 84.8,
            "OD1": 8.1,
            "OD2": 2.7,
            "OD3": 2.2,
            "OD4": 1.4,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "JAWA TENGAH",
            "LANCAR": 77.3,
            "OD1": 12.2,
            "OD2": 4.3,
            "OD3": 2.4,
            "OD4": 1.6,
            "OD5": 1.3,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "regional": "JAWA TIMUR",
            "LANCAR": 81.5,
            "OD1": 9.8,
            "OD2": 3.6,
            "OD3": 1.8,
            "OD4": 1.4,
            "OD5": 1.1,
            "OD6": 0.8,
            "ODLB6": 0.1
          },
          {
            "regional": "KALIMANTAN 1",
            "LANCAR": 85.8,
            "OD1": 8.6,
            "OD2": 2.5,
            "OD3": 1.2,
            "OD4": 0.8,
            "OD5": 0.6,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "KALIMANTAN 2",
            "LANCAR": 90.4,
            "OD1": 5.5,
            "OD2": 1.7,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.5,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "MAPA",
            "LANCAR": 90.2,
            "OD1": 6.9,
            "OD2": 1.4,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0.1
          },
          {
            "regional": "NUSA TENGGARA",
            "LANCAR": 89.2,
            "OD1": 6.1,
            "OD2": 1.7,
            "OD3": 1.3,
            "OD4": 1,
            "OD5": 0.6,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 1",
            "LANCAR": 89.5,
            "OD1": 7.1,
            "OD2": 1.6,
            "OD3": 0.7,
            "OD4": 0.4,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 2",
            "LANCAR": 94.1,
            "OD1": 3.9,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 3",
            "LANCAR": 90.6,
            "OD1": 6.1,
            "OD2": 1.6,
            "OD3": 0.8,
            "OD4": 0.4,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 4",
            "LANCAR": 93.1,
            "OD1": 4.5,
            "OD2": 1.1,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "regional": "SULAWESI 5",
            "LANCAR": 85.3,
            "OD1": 8,
            "OD2": 2.6,
            "OD3": 1.5,
            "OD4": 1,
            "OD5": 0.9,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "regional": "SUMATERA 2",
            "LANCAR": 83.8,
            "OD1": 8.2,
            "OD2": 3.7,
            "OD3": 1.8,
            "OD4": 1.3,
            "OD5": 1,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "regional": "SUMATERA 3",
            "LANCAR": 88.6,
            "OD1": 6.7,
            "OD2": 2.1,
            "OD3": 1.1,
            "OD4": 0.6,
            "OD5": 0.5,
            "OD6": 0.4,
            "ODLB6": 0.2
          },
          {
            "regional": "SUMATERA 4",
            "LANCAR": 86.5,
            "OD1": 7.1,
            "OD2": 2.6,
            "OD3": 1.4,
            "OD4": 0.9,
            "OD5": 0.8,
            "OD6": 0.6,
            "ODLB6": 0.1
          },
          {
            "regional": "SUMATERA 5",
            "LANCAR": 96.6,
            "OD1": 2.4,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "regional": "SUMATERA 6",
            "LANCAR": 86.8,
            "OD1": 7.1,
            "OD2": 2.7,
            "OD3": 1.3,
            "OD4": 0.8,
            "OD5": 0.8,
            "OD6": 0.6,
            "ODLB6": 0.1
          }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "LANCAR" },
            { "data": "OD1" },
            { "data": "OD2" },
            { "data": "OD3" },
            { "data": "OD4" },
            { "data": "OD5" },
            { "data": "OD6" },
            { "data": "ODLB6" },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableBucketCabRp').DataTable({
        "data":[
          {
            "cabang": "ACEH",
            "LANCAR": 90.2,
            "OD1": 8.1,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "ALUEBILIE",
            "LANCAR": 94.6,
            "OD1": 3.8,
            "OD2": 1,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "AMBON",
            "LANCAR": 93.8,
            "OD1": 5,
            "OD2": 0.5,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "AMPANA",
            "LANCAR": 91.6,
            "OD1": 5.7,
            "OD2": 1,
            "OD3": 0.7,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "ARGAMAKMUR",
            "LANCAR": 86.8,
            "OD1": 5.5,
            "OD2": 2.8,
            "OD3": 1.8,
            "OD4": 0.7,
            "OD5": 1.3,
            "OD6": 1.1,
            "ODLB6": 0
          },
          {
            "cabang": "BABATTOMAN",
            "LANCAR": 95.3,
            "OD1": 2.6,
            "OD2": 0.8,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "BACAN",
            "LANCAR": 82.5,
            "OD1": 10.4,
            "OD2": 2.9,
            "OD3": 1.2,
            "OD4": 1.1,
            "OD5": 1.5,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BALARAJA",
            "LANCAR": 79.6,
            "OD1": 7.4,
            "OD2": 4.3,
            "OD3": 2.5,
            "OD4": 3.1,
            "OD5": 1.5,
            "OD6": 1.7,
            "ODLB6": 0
          },
          {
            "cabang": "BALIKPAPAN",
            "LANCAR": 78.6,
            "OD1": 10.6,
            "OD2": 4.8,
            "OD3": 2.5,
            "OD4": 1.8,
            "OD5": 0.6,
            "OD6": 1.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANDARJAYA",
            "LANCAR": 88.5,
            "OD1": 6.9,
            "OD2": 1.8,
            "OD3": 1.3,
            "OD4": 0.7,
            "OD5": 0.8,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BANDUNG",
            "LANCAR": 88.5,
            "OD1": 7.6,
            "OD2": 2.3,
            "OD3": 1,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKA",
            "LANCAR": 95.2,
            "OD1": 3.3,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKALA",
            "LANCAR": 96.5,
            "OD1": 2.3,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKO",
            "LANCAR": 92.2,
            "OD1": 5.1,
            "OD2": 1.4,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0.2
          },
          {
            "cabang": "BANJAR",
            "LANCAR": 91.2,
            "OD1": 4.5,
            "OD2": 1.9,
            "OD3": 1.5,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANJARAN",
            "LANCAR": 87.3,
            "OD1": 6.5,
            "OD2": 3.3,
            "OD3": 1.8,
            "OD4": 0.3,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "BANJARMASIN",
            "LANCAR": 83.8,
            "OD1": 11.7,
            "OD2": 2.2,
            "OD3": 0.7,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BANTAENG",
            "LANCAR": 88.5,
            "OD1": 6.1,
            "OD2": 2,
            "OD3": 1.2,
            "OD4": 0.9,
            "OD5": 1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BARABAI",
            "LANCAR": 74.2,
            "OD1": 9.6,
            "OD2": 6,
            "OD3": 4.7,
            "OD4": 2.6,
            "OD5": 1.6,
            "OD6": 1.4,
            "ODLB6": 0
          },
          {
            "cabang": "BARRU",
            "LANCAR": 95,
            "OD1": 4.1,
            "OD2": 0.5,
            "OD3": 0.1,
            "OD4": 0.1,
            "OD5": 0,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BATULICIN",
            "LANCAR": 88.3,
            "OD1": 7.6,
            "OD2": 2,
            "OD3": 0.8,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BATUSANGKAR",
            "LANCAR": 95.4,
            "OD1": 2.4,
            "OD2": 1.2,
            "OD3": 0.2,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BATURAJA",
            "LANCAR": 71.9,
            "OD1": 13.7,
            "OD2": 6.1,
            "OD3": 3.4,
            "OD4": 2.6,
            "OD5": 1.7,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "BAWEN",
            "LANCAR": 66.7,
            "OD1": 17.3,
            "OD2": 7.6,
            "OD3": 3.8,
            "OD4": 1.7,
            "OD5": 1.8,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "cabang": "BAYUNGLENCIR",
            "LANCAR": 93.9,
            "OD1": 4.1,
            "OD2": 1.2,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BEKASI",
            "LANCAR": 86.8,
            "OD1": 8.4,
            "OD2": 1.7,
            "OD3": 1.7,
            "OD4": 1.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELINYU",
            "LANCAR": 97.8,
            "OD1": 1.7,
            "OD2": 0.4,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BELITANG",
            "LANCAR": 93.7,
            "OD1": 4.5,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELITUNG",
            "LANCAR": 97.2,
            "OD1": 2,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BELOPA",
            "LANCAR": 95.5,
            "OD1": 3,
            "OD2": 0.7,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELTIM",
            "LANCAR": 96.3,
            "OD1": 2.6,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BENGKULU",
            "LANCAR": 79.9,
            "OD1": 8.5,
            "OD2": 3.8,
            "OD3": 1.8,
            "OD4": 3,
            "OD5": 1.8,
            "OD6": 1.1,
            "ODLB6": 0
          },
          {
            "cabang": "BERAU",
            "LANCAR": 97.4,
            "OD1": 1.5,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BETUNG",
            "LANCAR": 77.7,
            "OD1": 12.3,
            "OD2": 4.7,
            "OD3": 2,
            "OD4": 1.7,
            "OD5": 1,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "BINJAI",
            "LANCAR": 89.6,
            "OD1": 6.3,
            "OD2": 2.3,
            "OD3": 0.8,
            "OD4": 0.5,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BIREUEN",
            "LANCAR": 94.7,
            "OD1": 4.2,
            "OD2": 0.6,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BITUNG",
            "LANCAR": 72.8,
            "OD1": 11.4,
            "OD2": 4.9,
            "OD3": 3.7,
            "OD4": 2.2,
            "OD5": 2.5,
            "OD6": 2.4,
            "ODLB6": 0
          },
          {
            "cabang": "BLANGPIDIE",
            "LANCAR": 89.4,
            "OD1": 7.5,
            "OD2": 1.5,
            "OD3": 1.1,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BLITAR",
            "LANCAR": 88.6,
            "OD1": 4,
            "OD2": 2.5,
            "OD3": 1.7,
            "OD4": 1.5,
            "OD5": 1,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BOALEMO",
            "LANCAR": 87.8,
            "OD1": 7.7,
            "OD2": 2.5,
            "OD3": 0.5,
            "OD4": 0.7,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BOEPINANG",
            "LANCAR": 96.2,
            "OD1": 2,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BOGOR",
            "LANCAR": 95.3,
            "OD1": 2.8,
            "OD2": 0.8,
            "OD3": 0.5,
            "OD4": 0.5,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BOJONEGORO",
            "LANCAR": 74.3,
            "OD1": 12.1,
            "OD2": 5.1,
            "OD3": 4.2,
            "OD4": 1.8,
            "OD5": 1.9,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BONE",
            "LANCAR": 89.5,
            "OD1": 5.5,
            "OD2": 2.7,
            "OD3": 1.1,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BOROKO",
            "LANCAR": 85.8,
            "OD1": 7.2,
            "OD2": 2.5,
            "OD3": 1.9,
            "OD4": 1.1,
            "OD5": 0.7,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "BOYOLALI",
            "LANCAR": 92.8,
            "OD1": 5.9,
            "OD2": 1.2,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BUKITTINGGI",
            "LANCAR": 94.4,
            "OD1": 3.9,
            "OD2": 0.8,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BULI",
            "LANCAR": 19.2,
            "OD1": 34.4,
            "OD2": 4.3,
            "OD3": 9.2,
            "OD4": 12.6,
            "OD5": 16.2,
            "OD6": 4.1,
            "ODLB6": 0
          },
          {
            "cabang": "BULUKUMBA",
            "LANCAR": 94.1,
            "OD1": 3.9,
            "OD2": 1.1,
            "OD3": 0.5,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUNGKU",
            "LANCAR": 92.1,
            "OD1": 5.6,
            "OD2": 1.2,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUNGO",
            "LANCAR": 76,
            "OD1": 13.5,
            "OD2": 2.9,
            "OD3": 2.2,
            "OD4": 1.7,
            "OD5": 1.6,
            "OD6": 2.1,
            "ODLB6": 0
          },
          {
            "cabang": "BUNTA",
            "LANCAR": 96.2,
            "OD1": 2.2,
            "OD2": 0.6,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUOL",
            "LANCAR": 90.6,
            "OD1": 5.9,
            "OD2": 1.5,
            "OD3": 1,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BUTON",
            "LANCAR": 96.5,
            "OD1": 2.7,
            "OD2": 0.3,
            "OD3": 0.1,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "CIANJUR",
            "LANCAR": 81.4,
            "OD1": 10,
            "OD2": 4.3,
            "OD3": 2.4,
            "OD4": 1,
            "OD5": 0.5,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "CIAWI",
            "LANCAR": 95.9,
            "OD1": 2.5,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "CIBINONG",
            "LANCAR": 90.2,
            "OD1": 6.2,
            "OD2": 0.8,
            "OD3": 1,
            "OD4": 1.2,
            "OD5": 0.1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "CIKARANG",
            "LANCAR": 86.1,
            "OD1": 6.5,
            "OD2": 3.4,
            "OD3": 2.4,
            "OD4": 1.1,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "CILACAP",
            "LANCAR": 75.2,
            "OD1": 14.2,
            "OD2": 4.6,
            "OD3": 2,
            "OD4": 1.4,
            "OD5": 1.3,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "CILEDUG",
            "LANCAR": 80.3,
            "OD1": 11.8,
            "OD2": 4,
            "OD3": 1.6,
            "OD4": 1.1,
            "OD5": 0.1,
            "OD6": 1,
            "ODLB6": 0.1
          },
          {
            "cabang": "CILEUNGSI",
            "LANCAR": 90.1,
            "OD1": 6.4,
            "OD2": 1.6,
            "OD3": 1.4,
            "OD4": 0.4,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0.1
          },
          {
            "cabang": "CIMAHI",
            "LANCAR": 89.1,
            "OD1": 6.8,
            "OD2": 1.8,
            "OD3": 0.8,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "CIREBON",
            "LANCAR": 93.9,
            "OD1": 2.9,
            "OD2": 1.5,
            "OD3": 1.4,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "CURUP",
            "LANCAR": 82.1,
            "OD1": 8.9,
            "OD2": 2.8,
            "OD3": 1.2,
            "OD4": 2,
            "OD5": 1.3,
            "OD6": 1.7,
            "ODLB6": 0
          },
          {
            "cabang": "DAYAMURNI",
            "LANCAR": 97.1,
            "OD1": 1,
            "OD2": 0,
            "OD3": 1.2,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "DOMPU",
            "LANCAR": 99.1,
            "OD1": 0.9,
            "OD2": 0,
            "OD3": 0,
            "OD4": 0.1,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "DONGGALA",
            "LANCAR": 95.9,
            "OD1": 3.3,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "ENDE",
            "LANCAR": 92,
            "OD1": 5.1,
            "OD2": 1.3,
            "OD3": 0.7,
            "OD4": 0.1,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "ENREKANG",
            "LANCAR": 92.7,
            "OD1": 4.5,
            "OD2": 1.6,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "EREKE",
            "LANCAR": 97,
            "OD1": 2.5,
            "OD2": 0.2,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "GARUT",
            "LANCAR": 82.9,
            "OD1": 10.6,
            "OD2": 3.7,
            "OD3": 1.9,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "GORONTALO",
            "LANCAR": 86.1,
            "OD1": 9.4,
            "OD2": 2,
            "OD3": 1.1,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "GOWA",
            "LANCAR": 88,
            "OD1": 8.3,
            "OD2": 1.5,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.7,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "GOWA2",
            "LANCAR": 92,
            "OD1": 6.3,
            "OD2": 1.1,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "GRESIK",
            "LANCAR": 90.7,
            "OD1": 4.6,
            "OD2": 1.9,
            "OD3": 0.7,
            "OD4": 1.1,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "IDIE",
            "LANCAR": 97.4,
            "OD1": 1.4,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "INDRALAYA",
            "LANCAR": 83.3,
            "OD1": 8.5,
            "OD2": 3.7,
            "OD3": 2.4,
            "OD4": 1.1,
            "OD5": 0.7,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "JAILOLO",
            "LANCAR": 96.1,
            "OD1": 2.9,
            "OD2": 0.5,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "JAMBI",
            "LANCAR": 82.4,
            "OD1": 9.9,
            "OD2": 2.6,
            "OD3": 1.8,
            "OD4": 1,
            "OD5": 1.5,
            "OD6": 0.9,
            "ODLB6": 0
          },
          {
            "cabang": "JAMPANG",
            "LANCAR": 84.7,
            "OD1": 6.2,
            "OD2": 2.7,
            "OD3": 1.9,
            "OD4": 1.4,
            "OD5": 1.3,
            "OD6": 1.7,
            "ODLB6": 0.1
          },
          {
            "cabang": "JATIBARANG",
            "LANCAR": 89.2,
            "OD1": 5,
            "OD2": 2.1,
            "OD3": 1.8,
            "OD4": 0.9,
            "OD5": 0.5,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "cabang": "JAYAPURA",
            "LANCAR": 88.1,
            "OD1": 9.4,
            "OD2": 1,
            "OD3": 0.4,
            "OD4": 0.7,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "JEBUS",
            "LANCAR": 94.9,
            "OD1": 3.4,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "JEMBER",
            "LANCAR": 78.3,
            "OD1": 14.9,
            "OD2": 3.9,
            "OD3": 0.9,
            "OD4": 0.7,
            "OD5": 1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "JENEPONTO",
            "LANCAR": 92.9,
            "OD1": 4.3,
            "OD2": 1.4,
            "OD3": 0.6,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KADIPATEN",
            "LANCAR": 85.5,
            "OD1": 8,
            "OD2": 3.9,
            "OD3": 1.3,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KALIANDA",
            "LANCAR": 85.3,
            "OD1": 7.1,
            "OD2": 3.3,
            "OD3": 2.3,
            "OD4": 0.6,
            "OD5": 0.6,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "KAPUAS",
            "LANCAR": 93.1,
            "OD1": 6,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KARANGANYAR",
            "LANCAR": 94.2,
            "OD1": 3.6,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KARAWANG",
            "LANCAR": 82,
            "OD1": 9.1,
            "OD2": 3.2,
            "OD3": 3,
            "OD4": 1.9,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KASIPUTE",
            "LANCAR": 91.6,
            "OD1": 4.8,
            "OD2": 1.3,
            "OD3": 1.1,
            "OD4": 0.4,
            "OD5": 0.7,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KAYUAGUNG",
            "LANCAR": 93.9,
            "OD1": 2.6,
            "OD2": 1.1,
            "OD3": 0.9,
            "OD4": 0.6,
            "OD5": 0.2,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "KEBUMEN",
            "LANCAR": 70.6,
            "OD1": 21.7,
            "OD2": 2.7,
            "OD3": 2.3,
            "OD4": 0.8,
            "OD5": 1.3,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "KEDIRI",
            "LANCAR": 70.3,
            "OD1": 13.6,
            "OD2": 6.3,
            "OD3": 2.8,
            "OD4": 2.7,
            "OD5": 2.1,
            "OD6": 2.1,
            "ODLB6": 0
          },
          {
            "cabang": "KELAPA",
            "LANCAR": 98.3,
            "OD1": 1.5,
            "OD2": 0,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KENDARI",
            "LANCAR": 88.7,
            "OD1": 7.3,
            "OD2": 1.9,
            "OD3": 0.8,
            "OD4": 0.5,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOBA",
            "LANCAR": 97.8,
            "OD1": 1.7,
            "OD2": 0.4,
            "OD3": 0,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KOLAKA",
            "LANCAR": 95.3,
            "OD1": 3,
            "OD2": 1,
            "OD3": 0.3,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAAGUNG",
            "LANCAR": 83.7,
            "OD1": 6.8,
            "OD2": 4.6,
            "OD3": 1.9,
            "OD4": 1.6,
            "OD5": 1.1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAFAJAR",
            "LANCAR": 91.5,
            "OD1": 6,
            "OD2": 1.7,
            "OD3": 0.6,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KOTABARU",
            "LANCAR": 87.3,
            "OD1": 7.4,
            "OD2": 2.5,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.9,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOTABUMI",
            "LANCAR": 94.4,
            "OD1": 3.3,
            "OD2": 1.1,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAMOBAGU",
            "LANCAR": 74.6,
            "OD1": 10,
            "OD2": 4.7,
            "OD3": 3.7,
            "OD4": 2.6,
            "OD5": 2.5,
            "OD6": 2,
            "ODLB6": 0
          },
          {
            "cabang": "KOTARAYA",
            "LANCAR": 93.5,
            "OD1": 4,
            "OD2": 0.9,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KOTOBARU",
            "LANCAR": 91.8,
            "OD1": 5,
            "OD2": 1.5,
            "OD3": 0.6,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KUALASIMPANG",
            "LANCAR": 90.8,
            "OD1": 6.9,
            "OD2": 1.2,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KUNINGAN",
            "LANCAR": 81.2,
            "OD1": 8.3,
            "OD2": 4.3,
            "OD3": 3.1,
            "OD4": 1.4,
            "OD5": 0.4,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "LABUANBAJO",
            "LANCAR": 94.3,
            "OD1": 4,
            "OD2": 0.6,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LADONGI",
            "LANCAR": 93,
            "OD1": 4.6,
            "OD2": 0.7,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "LAHAT",
            "LANCAR": 90.6,
            "OD1": 6.1,
            "OD2": 1.6,
            "OD3": 0.8,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LAMPUNG",
            "LANCAR": 75.8,
            "OD1": 13.5,
            "OD2": 5.6,
            "OD3": 1.8,
            "OD4": 1.2,
            "OD5": 1.2,
            "OD6": 0.8,
            "ODLB6": 0.1
          },
          {
            "cabang": "LANGSAACEH",
            "LANCAR": 96.9,
            "OD1": 2.2,
            "OD2": 0.2,
            "OD3": 0.3,
            "OD4": 0,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LASUSUA",
            "LANCAR": 98.2,
            "OD1": 0.6,
            "OD2": 0.4,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "LEUWILIANG",
            "LANCAR": 95.1,
            "OD1": 3.5,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LHOKSEUMAWE",
            "LANCAR": 79.4,
            "OD1": 11.7,
            "OD2": 4.2,
            "OD3": 2.2,
            "OD4": 1.3,
            "OD5": 0.5,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "LHOKSUKON",
            "LANCAR": 95.4,
            "OD1": 2.8,
            "OD2": 0.7,
            "OD3": 0.1,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LIWA",
            "LANCAR": 88.4,
            "OD1": 7.1,
            "OD2": 2.2,
            "OD3": 0.7,
            "OD4": 0.2,
            "OD5": 1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "LUBUKBASUNG",
            "LANCAR": 89.6,
            "OD1": 6.8,
            "OD2": 1.8,
            "OD3": 1.1,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LUBUKLINGGAU",
            "LANCAR": 84.9,
            "OD1": 7.9,
            "OD2": 1.8,
            "OD3": 1.7,
            "OD4": 1.2,
            "OD5": 1.4,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "cabang": "LUWUK",
            "LANCAR": 79.9,
            "OD1": 10.2,
            "OD2": 3.4,
            "OD3": 2.7,
            "OD4": 1.5,
            "OD5": 1,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "MADIUN",
            "LANCAR": 70.5,
            "OD1": 16.3,
            "OD2": 5.6,
            "OD3": 2.9,
            "OD4": 2.3,
            "OD5": 1.6,
            "OD6": 0.9,
            "ODLB6": 0
          },
          {
            "cabang": "MAGELANG",
            "LANCAR": 89.2,
            "OD1": 7.4,
            "OD2": 1.5,
            "OD3": 0.7,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "MAJENE",
            "LANCAR": 87.7,
            "OD1": 6.3,
            "OD2": 2,
            "OD3": 1.7,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 1.6,
            "ODLB6": 0
          },
          {
            "cabang": "MAKALE",
            "LANCAR": 95.9,
            "OD1": 3.7,
            "OD2": 0.3,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR",
            "LANCAR": 89.3,
            "OD1": 6.8,
            "OD2": 1.2,
            "OD3": 0.7,
            "OD4": 0.5,
            "OD5": 0.7,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR2",
            "LANCAR": 86.4,
            "OD1": 9.4,
            "OD2": 1.9,
            "OD3": 0.9,
            "OD4": 0.4,
            "OD5": 0.7,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR3",
            "LANCAR": 88.5,
            "OD1": 8.2,
            "OD2": 1.7,
            "OD3": 0.6,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MALANG",
            "LANCAR": 82.6,
            "OD1": 8.9,
            "OD2": 4.2,
            "OD3": 1.8,
            "OD4": 1.3,
            "OD5": 0.7,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "MALILI",
            "LANCAR": 93.6,
            "OD1": 4.2,
            "OD2": 1,
            "OD3": 0.8,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MALINO",
            "LANCAR": 94.3,
            "OD1": 4.1,
            "OD2": 0.8,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MAMUJU",
            "LANCAR": 91.8,
            "OD1": 5.8,
            "OD2": 0.9,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.3,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MANADO",
            "LANCAR": 78.4,
            "OD1": 9.8,
            "OD2": 5.1,
            "OD3": 2.2,
            "OD4": 1.7,
            "OD5": 1.3,
            "OD6": 1.5,
            "ODLB6": 0
          },
          {
            "cabang": "MANGKUTANA",
            "LANCAR": 95.6,
            "OD1": 3.3,
            "OD2": 0.6,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MANOKWARI",
            "LANCAR": 85,
            "OD1": 9,
            "OD2": 2.8,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 1.3,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "cabang": "MARISA",
            "LANCAR": 91,
            "OD1": 6,
            "OD2": 1.5,
            "OD3": 0.8,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MAROS",
            "LANCAR": 89.2,
            "OD1": 7.2,
            "OD2": 1.7,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.6,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MARTAPURA-KAL",
            "LANCAR": 92.2,
            "OD1": 5.8,
            "OD2": 0.9,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MARTAPURA-SUMSEL",
            "LANCAR": 87,
            "OD1": 6.3,
            "OD2": 3.2,
            "OD3": 1.2,
            "OD4": 0.1,
            "OD5": 0.8,
            "OD6": 0.9,
            "ODLB6": 0.4
          },
          {
            "cabang": "MASAMBA",
            "LANCAR": 94.8,
            "OD1": 4.4,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MASBAGIK",
            "LANCAR": 83,
            "OD1": 8.6,
            "OD2": 2.9,
            "OD3": 1.9,
            "OD4": 1.8,
            "OD5": 0.9,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MASOHI",
            "LANCAR": 89.6,
            "OD1": 7.8,
            "OD2": 1.7,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MEDAN",
            "LANCAR": 80.1,
            "OD1": 9.1,
            "OD2": 5.2,
            "OD3": 2.4,
            "OD4": 1.5,
            "OD5": 1.3,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MENTOK",
            "LANCAR": 94.5,
            "OD1": 3.8,
            "OD2": 0.8,
            "OD3": 0.7,
            "OD4": 0,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "METRO",
            "LANCAR": 90,
            "OD1": 6.6,
            "OD2": 1.2,
            "OD3": 0.6,
            "OD4": 0.6,
            "OD5": 0.5,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "MEULABOH",
            "LANCAR": 91.7,
            "OD1": 0,
            "OD2": 0,
            "OD3": 0,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          }
        ],
        "columns": [
            { "data": "cabang" },
            { "data": "LANCAR" },
            { "data": "OD1" },
            { "data": "OD2" },
            { "data": "OD3" },
            { "data": "OD4" },
            { "data": "OD5" },
            { "data": "OD6" },
            { "data": "ODLB6" },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableBucketCabKon').DataTable({
        "data":[
          {
            "cabang": "ACEH",
            "LANCAR": 90.2,
            "OD1": 8.1,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "ALUEBILIE",
            "LANCAR": 94.6,
            "OD1": 3.8,
            "OD2": 1,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "AMBON",
            "LANCAR": 93.8,
            "OD1": 5,
            "OD2": 0.5,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "AMPANA",
            "LANCAR": 91.6,
            "OD1": 5.7,
            "OD2": 1,
            "OD3": 0.7,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "ARGAMAKMUR",
            "LANCAR": 86.8,
            "OD1": 5.5,
            "OD2": 2.8,
            "OD3": 1.8,
            "OD4": 0.7,
            "OD5": 1.3,
            "OD6": 1.1,
            "ODLB6": 0
          },
          {
            "cabang": "BABATTOMAN",
            "LANCAR": 95.3,
            "OD1": 2.6,
            "OD2": 0.8,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "BACAN",
            "LANCAR": 82.5,
            "OD1": 10.4,
            "OD2": 2.9,
            "OD3": 1.2,
            "OD4": 1.1,
            "OD5": 1.5,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BALARAJA",
            "LANCAR": 79.6,
            "OD1": 7.4,
            "OD2": 4.3,
            "OD3": 2.5,
            "OD4": 3.1,
            "OD5": 1.5,
            "OD6": 1.7,
            "ODLB6": 0
          },
          {
            "cabang": "BALIKPAPAN",
            "LANCAR": 78.6,
            "OD1": 10.6,
            "OD2": 4.8,
            "OD3": 2.5,
            "OD4": 1.8,
            "OD5": 0.6,
            "OD6": 1.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANDARJAYA",
            "LANCAR": 88.5,
            "OD1": 6.9,
            "OD2": 1.8,
            "OD3": 1.3,
            "OD4": 0.7,
            "OD5": 0.8,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BANDUNG",
            "LANCAR": 88.5,
            "OD1": 7.6,
            "OD2": 2.3,
            "OD3": 1,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKA",
            "LANCAR": 95.2,
            "OD1": 3.3,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKALA",
            "LANCAR": 96.5,
            "OD1": 2.3,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BANGKO",
            "LANCAR": 92.2,
            "OD1": 5.1,
            "OD2": 1.4,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0.2
          },
          {
            "cabang": "BANJAR",
            "LANCAR": 91.2,
            "OD1": 4.5,
            "OD2": 1.9,
            "OD3": 1.5,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BANJARAN",
            "LANCAR": 87.3,
            "OD1": 6.5,
            "OD2": 3.3,
            "OD3": 1.8,
            "OD4": 0.3,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "BANJARMASIN",
            "LANCAR": 83.8,
            "OD1": 11.7,
            "OD2": 2.2,
            "OD3": 0.7,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BANTAENG",
            "LANCAR": 88.5,
            "OD1": 6.1,
            "OD2": 2,
            "OD3": 1.2,
            "OD4": 0.9,
            "OD5": 1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BARABAI",
            "LANCAR": 74.2,
            "OD1": 9.6,
            "OD2": 6,
            "OD3": 4.7,
            "OD4": 2.6,
            "OD5": 1.6,
            "OD6": 1.4,
            "ODLB6": 0
          },
          {
            "cabang": "BARRU",
            "LANCAR": 95,
            "OD1": 4.1,
            "OD2": 0.5,
            "OD3": 0.1,
            "OD4": 0.1,
            "OD5": 0,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BATULICIN",
            "LANCAR": 88.3,
            "OD1": 7.6,
            "OD2": 2,
            "OD3": 0.8,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BATUSANGKAR",
            "LANCAR": 95.4,
            "OD1": 2.4,
            "OD2": 1.2,
            "OD3": 0.2,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BATURAJA",
            "LANCAR": 71.9,
            "OD1": 13.7,
            "OD2": 6.1,
            "OD3": 3.4,
            "OD4": 2.6,
            "OD5": 1.7,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "BAWEN",
            "LANCAR": 66.7,
            "OD1": 17.3,
            "OD2": 7.6,
            "OD3": 3.8,
            "OD4": 1.7,
            "OD5": 1.8,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "cabang": "BAYUNGLENCIR",
            "LANCAR": 93.9,
            "OD1": 4.1,
            "OD2": 1.2,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BEKASI",
            "LANCAR": 86.8,
            "OD1": 8.4,
            "OD2": 1.7,
            "OD3": 1.7,
            "OD4": 1.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELINYU",
            "LANCAR": 97.8,
            "OD1": 1.7,
            "OD2": 0.4,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BELITANG",
            "LANCAR": 93.7,
            "OD1": 4.5,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELITUNG",
            "LANCAR": 97.2,
            "OD1": 2,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BELOPA",
            "LANCAR": 95.5,
            "OD1": 3,
            "OD2": 0.7,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BELTIM",
            "LANCAR": 96.3,
            "OD1": 2.6,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BENGKULU",
            "LANCAR": 79.9,
            "OD1": 8.5,
            "OD2": 3.8,
            "OD3": 1.8,
            "OD4": 3,
            "OD5": 1.8,
            "OD6": 1.1,
            "ODLB6": 0
          },
          {
            "cabang": "BERAU",
            "LANCAR": 97.4,
            "OD1": 1.5,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BETUNG",
            "LANCAR": 77.7,
            "OD1": 12.3,
            "OD2": 4.7,
            "OD3": 2,
            "OD4": 1.7,
            "OD5": 1,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "BINJAI",
            "LANCAR": 89.6,
            "OD1": 6.3,
            "OD2": 2.3,
            "OD3": 0.8,
            "OD4": 0.5,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BIREUEN",
            "LANCAR": 94.7,
            "OD1": 4.2,
            "OD2": 0.6,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BITUNG",
            "LANCAR": 72.8,
            "OD1": 11.4,
            "OD2": 4.9,
            "OD3": 3.7,
            "OD4": 2.2,
            "OD5": 2.5,
            "OD6": 2.4,
            "ODLB6": 0
          },
          {
            "cabang": "BLANGPIDIE",
            "LANCAR": 89.4,
            "OD1": 7.5,
            "OD2": 1.5,
            "OD3": 1.1,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BLITAR",
            "LANCAR": 88.6,
            "OD1": 4,
            "OD2": 2.5,
            "OD3": 1.7,
            "OD4": 1.5,
            "OD5": 1,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BOALEMO",
            "LANCAR": 87.8,
            "OD1": 7.7,
            "OD2": 2.5,
            "OD3": 0.5,
            "OD4": 0.7,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BOEPINANG",
            "LANCAR": 96.2,
            "OD1": 2,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BOGOR",
            "LANCAR": 95.3,
            "OD1": 2.8,
            "OD2": 0.8,
            "OD3": 0.5,
            "OD4": 0.5,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BOJONEGORO",
            "LANCAR": 74.3,
            "OD1": 12.1,
            "OD2": 5.1,
            "OD3": 4.2,
            "OD4": 1.8,
            "OD5": 1.9,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "BONE",
            "LANCAR": 89.5,
            "OD1": 5.5,
            "OD2": 2.7,
            "OD3": 1.1,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "BOROKO",
            "LANCAR": 85.8,
            "OD1": 7.2,
            "OD2": 2.5,
            "OD3": 1.9,
            "OD4": 1.1,
            "OD5": 0.7,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "BOYOLALI",
            "LANCAR": 92.8,
            "OD1": 5.9,
            "OD2": 1.2,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "BUKITTINGGI",
            "LANCAR": 94.4,
            "OD1": 3.9,
            "OD2": 0.8,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BULI",
            "LANCAR": 19.2,
            "OD1": 34.4,
            "OD2": 4.3,
            "OD3": 9.2,
            "OD4": 12.6,
            "OD5": 16.2,
            "OD6": 4.1,
            "ODLB6": 0
          },
          {
            "cabang": "BULUKUMBA",
            "LANCAR": 94.1,
            "OD1": 3.9,
            "OD2": 1.1,
            "OD3": 0.5,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUNGKU",
            "LANCAR": 92.1,
            "OD1": 5.6,
            "OD2": 1.2,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUNGO",
            "LANCAR": 76,
            "OD1": 13.5,
            "OD2": 2.9,
            "OD3": 2.2,
            "OD4": 1.7,
            "OD5": 1.6,
            "OD6": 2.1,
            "ODLB6": 0
          },
          {
            "cabang": "BUNTA",
            "LANCAR": 96.2,
            "OD1": 2.2,
            "OD2": 0.6,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "BUOL",
            "LANCAR": 90.6,
            "OD1": 5.9,
            "OD2": 1.5,
            "OD3": 1,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "BUTON",
            "LANCAR": 96.5,
            "OD1": 2.7,
            "OD2": 0.3,
            "OD3": 0.1,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "CIANJUR",
            "LANCAR": 81.4,
            "OD1": 10,
            "OD2": 4.3,
            "OD3": 2.4,
            "OD4": 1,
            "OD5": 0.5,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "CIAWI",
            "LANCAR": 95.9,
            "OD1": 2.5,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "CIBINONG",
            "LANCAR": 90.2,
            "OD1": 6.2,
            "OD2": 0.8,
            "OD3": 1,
            "OD4": 1.2,
            "OD5": 0.1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "CIKARANG",
            "LANCAR": 86.1,
            "OD1": 6.5,
            "OD2": 3.4,
            "OD3": 2.4,
            "OD4": 1.1,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "CILACAP",
            "LANCAR": 75.2,
            "OD1": 14.2,
            "OD2": 4.6,
            "OD3": 2,
            "OD4": 1.4,
            "OD5": 1.3,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "CILEDUG",
            "LANCAR": 80.3,
            "OD1": 11.8,
            "OD2": 4,
            "OD3": 1.6,
            "OD4": 1.1,
            "OD5": 0.1,
            "OD6": 1,
            "ODLB6": 0.1
          },
          {
            "cabang": "CILEUNGSI",
            "LANCAR": 90.1,
            "OD1": 6.4,
            "OD2": 1.6,
            "OD3": 1.4,
            "OD4": 0.4,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0.1
          },
          {
            "cabang": "CIMAHI",
            "LANCAR": 89.1,
            "OD1": 6.8,
            "OD2": 1.8,
            "OD3": 0.8,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "CIREBON",
            "LANCAR": 93.9,
            "OD1": 2.9,
            "OD2": 1.5,
            "OD3": 1.4,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "CURUP",
            "LANCAR": 82.1,
            "OD1": 8.9,
            "OD2": 2.8,
            "OD3": 1.2,
            "OD4": 2,
            "OD5": 1.3,
            "OD6": 1.7,
            "ODLB6": 0
          },
          {
            "cabang": "DAYAMURNI",
            "LANCAR": 97.1,
            "OD1": 1,
            "OD2": 0,
            "OD3": 1.2,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "DOMPU",
            "LANCAR": 99.1,
            "OD1": 0.9,
            "OD2": 0,
            "OD3": 0,
            "OD4": 0.1,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "DONGGALA",
            "LANCAR": 95.9,
            "OD1": 3.3,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "ENDE",
            "LANCAR": 92,
            "OD1": 5.1,
            "OD2": 1.3,
            "OD3": 0.7,
            "OD4": 0.1,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "ENREKANG",
            "LANCAR": 92.7,
            "OD1": 4.5,
            "OD2": 1.6,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "EREKE",
            "LANCAR": 97,
            "OD1": 2.5,
            "OD2": 0.2,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "GARUT",
            "LANCAR": 82.9,
            "OD1": 10.6,
            "OD2": 3.7,
            "OD3": 1.9,
            "OD4": 0.5,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "GORONTALO",
            "LANCAR": 86.1,
            "OD1": 9.4,
            "OD2": 2,
            "OD3": 1.1,
            "OD4": 0.6,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "GOWA",
            "LANCAR": 88,
            "OD1": 8.3,
            "OD2": 1.5,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.7,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "GOWA2",
            "LANCAR": 92,
            "OD1": 6.3,
            "OD2": 1.1,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "GRESIK",
            "LANCAR": 90.7,
            "OD1": 4.6,
            "OD2": 1.9,
            "OD3": 0.7,
            "OD4": 1.1,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "IDIE",
            "LANCAR": 97.4,
            "OD1": 1.4,
            "OD2": 0.5,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "INDRALAYA",
            "LANCAR": 83.3,
            "OD1": 8.5,
            "OD2": 3.7,
            "OD3": 2.4,
            "OD4": 1.1,
            "OD5": 0.7,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "JAILOLO",
            "LANCAR": 96.1,
            "OD1": 2.9,
            "OD2": 0.5,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "JAMBI",
            "LANCAR": 82.4,
            "OD1": 9.9,
            "OD2": 2.6,
            "OD3": 1.8,
            "OD4": 1,
            "OD5": 1.5,
            "OD6": 0.9,
            "ODLB6": 0
          },
          {
            "cabang": "JAMPANG",
            "LANCAR": 84.7,
            "OD1": 6.2,
            "OD2": 2.7,
            "OD3": 1.9,
            "OD4": 1.4,
            "OD5": 1.3,
            "OD6": 1.7,
            "ODLB6": 0.1
          },
          {
            "cabang": "JATIBARANG",
            "LANCAR": 89.2,
            "OD1": 5,
            "OD2": 2.1,
            "OD3": 1.8,
            "OD4": 0.9,
            "OD5": 0.5,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "cabang": "JAYAPURA",
            "LANCAR": 88.1,
            "OD1": 9.4,
            "OD2": 1,
            "OD3": 0.4,
            "OD4": 0.7,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0.1
          },
          {
            "cabang": "JEBUS",
            "LANCAR": 94.9,
            "OD1": 3.4,
            "OD2": 0.9,
            "OD3": 0.4,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "JEMBER",
            "LANCAR": 78.3,
            "OD1": 14.9,
            "OD2": 3.9,
            "OD3": 0.9,
            "OD4": 0.7,
            "OD5": 1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "JENEPONTO",
            "LANCAR": 92.9,
            "OD1": 4.3,
            "OD2": 1.4,
            "OD3": 0.6,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KADIPATEN",
            "LANCAR": 85.5,
            "OD1": 8,
            "OD2": 3.9,
            "OD3": 1.3,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KALIANDA",
            "LANCAR": 85.3,
            "OD1": 7.1,
            "OD2": 3.3,
            "OD3": 2.3,
            "OD4": 0.6,
            "OD5": 0.6,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "KAPUAS",
            "LANCAR": 93.1,
            "OD1": 6,
            "OD2": 0.4,
            "OD3": 0.3,
            "OD4": 0,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KARANGANYAR",
            "LANCAR": 94.2,
            "OD1": 3.6,
            "OD2": 0.9,
            "OD3": 0.5,
            "OD4": 0.3,
            "OD5": 0.3,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KARAWANG",
            "LANCAR": 82,
            "OD1": 9.1,
            "OD2": 3.2,
            "OD3": 3,
            "OD4": 1.9,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KASIPUTE",
            "LANCAR": 91.6,
            "OD1": 4.8,
            "OD2": 1.3,
            "OD3": 1.1,
            "OD4": 0.4,
            "OD5": 0.7,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KAYUAGUNG",
            "LANCAR": 93.9,
            "OD1": 2.6,
            "OD2": 1.1,
            "OD3": 0.9,
            "OD4": 0.6,
            "OD5": 0.2,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "KEBUMEN",
            "LANCAR": 70.6,
            "OD1": 21.7,
            "OD2": 2.7,
            "OD3": 2.3,
            "OD4": 0.8,
            "OD5": 1.3,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "KEDIRI",
            "LANCAR": 70.3,
            "OD1": 13.6,
            "OD2": 6.3,
            "OD3": 2.8,
            "OD4": 2.7,
            "OD5": 2.1,
            "OD6": 2.1,
            "ODLB6": 0
          },
          {
            "cabang": "KELAPA",
            "LANCAR": 98.3,
            "OD1": 1.5,
            "OD2": 0,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KENDARI",
            "LANCAR": 88.7,
            "OD1": 7.3,
            "OD2": 1.9,
            "OD3": 0.8,
            "OD4": 0.5,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOBA",
            "LANCAR": 97.8,
            "OD1": 1.7,
            "OD2": 0.4,
            "OD3": 0,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KOLAKA",
            "LANCAR": 95.3,
            "OD1": 3,
            "OD2": 1,
            "OD3": 0.3,
            "OD4": 0.1,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAAGUNG",
            "LANCAR": 83.7,
            "OD1": 6.8,
            "OD2": 4.6,
            "OD3": 1.9,
            "OD4": 1.6,
            "OD5": 1.1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAFAJAR",
            "LANCAR": 91.5,
            "OD1": 6,
            "OD2": 1.7,
            "OD3": 0.6,
            "OD4": 0.1,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "KOTABARU",
            "LANCAR": 87.3,
            "OD1": 7.4,
            "OD2": 2.5,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 0.9,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "KOTABUMI",
            "LANCAR": 94.4,
            "OD1": 3.3,
            "OD2": 1.1,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "KOTAMOBAGU",
            "LANCAR": 74.6,
            "OD1": 10,
            "OD2": 4.7,
            "OD3": 3.7,
            "OD4": 2.6,
            "OD5": 2.5,
            "OD6": 2,
            "ODLB6": 0
          },
          {
            "cabang": "KOTARAYA",
            "LANCAR": 93.5,
            "OD1": 4,
            "OD2": 0.9,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KOTOBARU",
            "LANCAR": 91.8,
            "OD1": 5,
            "OD2": 1.5,
            "OD3": 0.6,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "KUALASIMPANG",
            "LANCAR": 90.8,
            "OD1": 6.9,
            "OD2": 1.2,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "KUNINGAN",
            "LANCAR": 81.2,
            "OD1": 8.3,
            "OD2": 4.3,
            "OD3": 3.1,
            "OD4": 1.4,
            "OD5": 0.4,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "LABUANBAJO",
            "LANCAR": 94.3,
            "OD1": 4,
            "OD2": 0.6,
            "OD3": 0.5,
            "OD4": 0.4,
            "OD5": 0,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LADONGI",
            "LANCAR": 93,
            "OD1": 4.6,
            "OD2": 0.7,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "LAHAT",
            "LANCAR": 90.6,
            "OD1": 6.1,
            "OD2": 1.6,
            "OD3": 0.8,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LAMPUNG",
            "LANCAR": 75.8,
            "OD1": 13.5,
            "OD2": 5.6,
            "OD3": 1.8,
            "OD4": 1.2,
            "OD5": 1.2,
            "OD6": 0.8,
            "ODLB6": 0.1
          },
          {
            "cabang": "LANGSAACEH",
            "LANCAR": 96.9,
            "OD1": 2.2,
            "OD2": 0.2,
            "OD3": 0.3,
            "OD4": 0,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LASUSUA",
            "LANCAR": 98.2,
            "OD1": 0.6,
            "OD2": 0.4,
            "OD3": 0.2,
            "OD4": 0.1,
            "OD5": 0.3,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "LEUWILIANG",
            "LANCAR": 95.1,
            "OD1": 3.5,
            "OD2": 0.7,
            "OD3": 0.3,
            "OD4": 0.3,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LHOKSEUMAWE",
            "LANCAR": 79.4,
            "OD1": 11.7,
            "OD2": 4.2,
            "OD3": 2.2,
            "OD4": 1.3,
            "OD5": 0.5,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "LHOKSUKON",
            "LANCAR": 95.4,
            "OD1": 2.8,
            "OD2": 0.7,
            "OD3": 0.1,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "LIWA",
            "LANCAR": 88.4,
            "OD1": 7.1,
            "OD2": 2.2,
            "OD3": 0.7,
            "OD4": 0.2,
            "OD5": 1,
            "OD6": 0.4,
            "ODLB6": 0
          },
          {
            "cabang": "LUBUKBASUNG",
            "LANCAR": 89.6,
            "OD1": 6.8,
            "OD2": 1.8,
            "OD3": 1.1,
            "OD4": 0.4,
            "OD5": 0.2,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "LUBUKLINGGAU",
            "LANCAR": 84.9,
            "OD1": 7.9,
            "OD2": 1.8,
            "OD3": 1.7,
            "OD4": 1.2,
            "OD5": 1.4,
            "OD6": 1,
            "ODLB6": 0
          },
          {
            "cabang": "LUWUK",
            "LANCAR": 79.9,
            "OD1": 10.2,
            "OD2": 3.4,
            "OD3": 2.7,
            "OD4": 1.5,
            "OD5": 1,
            "OD6": 1.3,
            "ODLB6": 0
          },
          {
            "cabang": "MADIUN",
            "LANCAR": 70.5,
            "OD1": 16.3,
            "OD2": 5.6,
            "OD3": 2.9,
            "OD4": 2.3,
            "OD5": 1.6,
            "OD6": 0.9,
            "ODLB6": 0
          },
          {
            "cabang": "MAGELANG",
            "LANCAR": 89.2,
            "OD1": 7.4,
            "OD2": 1.5,
            "OD3": 0.7,
            "OD4": 0.5,
            "OD5": 0.5,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "MAJENE",
            "LANCAR": 87.7,
            "OD1": 6.3,
            "OD2": 2,
            "OD3": 1.7,
            "OD4": 0.3,
            "OD5": 0.4,
            "OD6": 1.6,
            "ODLB6": 0
          },
          {
            "cabang": "MAKALE",
            "LANCAR": 95.9,
            "OD1": 3.7,
            "OD2": 0.3,
            "OD3": 0.1,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR",
            "LANCAR": 89.3,
            "OD1": 6.8,
            "OD2": 1.2,
            "OD3": 0.7,
            "OD4": 0.5,
            "OD5": 0.7,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR2",
            "LANCAR": 86.4,
            "OD1": 9.4,
            "OD2": 1.9,
            "OD3": 0.9,
            "OD4": 0.4,
            "OD5": 0.7,
            "OD6": 0.2,
            "ODLB6": 0
          },
          {
            "cabang": "MAKASSAR3",
            "LANCAR": 88.5,
            "OD1": 8.2,
            "OD2": 1.7,
            "OD3": 0.6,
            "OD4": 0.4,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MALANG",
            "LANCAR": 82.6,
            "OD1": 8.9,
            "OD2": 4.2,
            "OD3": 1.8,
            "OD4": 1.3,
            "OD5": 0.7,
            "OD6": 0.6,
            "ODLB6": 0
          },
          {
            "cabang": "MALILI",
            "LANCAR": 93.6,
            "OD1": 4.2,
            "OD2": 1,
            "OD3": 0.8,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MALINO",
            "LANCAR": 94.3,
            "OD1": 4.1,
            "OD2": 0.8,
            "OD3": 0.6,
            "OD4": 0.2,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MAMUJU",
            "LANCAR": 91.8,
            "OD1": 5.8,
            "OD2": 0.9,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.3,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MANADO",
            "LANCAR": 78.4,
            "OD1": 9.8,
            "OD2": 5.1,
            "OD3": 2.2,
            "OD4": 1.7,
            "OD5": 1.3,
            "OD6": 1.5,
            "ODLB6": 0
          },
          {
            "cabang": "MANGKUTANA",
            "LANCAR": 95.6,
            "OD1": 3.3,
            "OD2": 0.6,
            "OD3": 0.3,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MANOKWARI",
            "LANCAR": 85,
            "OD1": 9,
            "OD2": 2.8,
            "OD3": 0.8,
            "OD4": 0.7,
            "OD5": 1.3,
            "OD6": 0.5,
            "ODLB6": 0
          },
          {
            "cabang": "MARISA",
            "LANCAR": 91,
            "OD1": 6,
            "OD2": 1.5,
            "OD3": 0.8,
            "OD4": 0.3,
            "OD5": 0.1,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MAROS",
            "LANCAR": 89.2,
            "OD1": 7.2,
            "OD2": 1.7,
            "OD3": 0.7,
            "OD4": 0.3,
            "OD5": 0.6,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MARTAPURA-KAL",
            "LANCAR": 92.2,
            "OD1": 5.8,
            "OD2": 0.9,
            "OD3": 0.2,
            "OD4": 0.2,
            "OD5": 0.4,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MARTAPURA-SUMSEL",
            "LANCAR": 87,
            "OD1": 6.3,
            "OD2": 3.2,
            "OD3": 1.2,
            "OD4": 0.1,
            "OD5": 0.8,
            "OD6": 0.9,
            "ODLB6": 0.4
          },
          {
            "cabang": "MASAMBA",
            "LANCAR": 94.8,
            "OD1": 4.4,
            "OD2": 0.6,
            "OD3": 0.2,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "MASBAGIK",
            "LANCAR": 83,
            "OD1": 8.6,
            "OD2": 2.9,
            "OD3": 1.9,
            "OD4": 1.8,
            "OD5": 0.9,
            "OD6": 0.8,
            "ODLB6": 0
          },
          {
            "cabang": "MASOHI",
            "LANCAR": 89.6,
            "OD1": 7.8,
            "OD2": 1.7,
            "OD3": 0.4,
            "OD4": 0.2,
            "OD5": 0.1,
            "OD6": 0.1,
            "ODLB6": 0
          },
          {
            "cabang": "MEDAN",
            "LANCAR": 80.1,
            "OD1": 9.1,
            "OD2": 5.2,
            "OD3": 2.4,
            "OD4": 1.5,
            "OD5": 1.3,
            "OD6": 0.3,
            "ODLB6": 0
          },
          {
            "cabang": "MENTOK",
            "LANCAR": 94.5,
            "OD1": 3.8,
            "OD2": 0.8,
            "OD3": 0.7,
            "OD4": 0,
            "OD5": 0.2,
            "OD6": 0,
            "ODLB6": 0
          },
          {
            "cabang": "METRO",
            "LANCAR": 90,
            "OD1": 6.6,
            "OD2": 1.2,
            "OD3": 0.6,
            "OD4": 0.6,
            "OD5": 0.5,
            "OD6": 0.7,
            "ODLB6": 0
          },
          {
            "cabang": "MEULABOH",
            "LANCAR": 91.7,
            "OD1": 0,
            "OD2": 0,
            "OD3": 0,
            "OD4": 0,
            "OD5": 0,
            "OD6": 0,
            "ODLB6": 0
          }
        ],
        "columns": [
            { "data": "cabang" },
            { "data": "LANCAR" },
            { "data": "OD1" },
            { "data": "OD2" },
            { "data": "OD3" },
            { "data": "OD4" },
            { "data": "OD5" },
            { "data": "OD6" },
            { "data": "ODLB6" },
        ],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableRundownAr').DataTable({
        "data":[
            {
                "KET": "SALDO AWAL",
                "KONSUMEN": 516046,
                "RP": 4753444779594
            },
            {
                "KET": "BOOKING",
                "KONSUMEN": 37219,
                "RP": 462296540174
            },
            {
                "KET": "BAYAR ANGSURAN",
                "KONSUMEN": 0,
                "RP": 266523018166
            },
            {
                "KET": "LUNAS NORMAL",
                "KONSUMEN": 21079,
                "RP": 38786947011
            },
            {
                "KET": "LUNAS PERCEPATAN",
                "KONSUMEN": 4467,
                "RP": 25769425877
            },
            {
                "KET": "KLAIM",
                "KONSUMEN": 161,
                "RP": 1950328561
            },
            {
                "KET": "WO",
                "KONSUMEN": 1923,
                "RP": 15420366875
            },
            {
                "KET": "TB",
                "KONSUMEN": 796,
                "RP": 10442844302
            },
            {
                "KET": "SALDO AKHIR",
                "KONSUMEN": 524840,
                "RP": 4856849559126
            }
        ],
        "columns": [
            { "data": "KET" },
            { "data": "KONSUMEN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RP", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });
});
</script>
<script type="text/javascript">
    "use strict";

$(document).ready(function () {

  var echartElemBar1 = document.getElementById('echartBar1');

  if (echartElemBar1) {
    var echartBar1 = echarts.init(echartElemBar1);
    echartBar1.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target','Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [4.86,4.85,0,0,0,0,0,0,0,0,0,0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [4.94,5.11,5.31,5.58,5.76,5.92,6.09,6.25,6.41,6.55,6.7,6.86],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [98.3,94.9,0,0,0,0,0,0,0,0,0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar1.resize();
      }, 500);
    });
  }

  var echartElemBar2 = document.getElementById('echartBar2');

  if (echartElemBar2) {
    var echartBar2 = echarts.init(echartElemBar2);
    echartBar2.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target','Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Total',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [525,524,0,0,0,0,0,0,0,0,0,0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [536,552,570,591,610,625,639,653,664,674,689,705],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [97.9,94.9,0,0,0,0,0,0,0,0,0,0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar2.resize();
      }, 500);
    });
  }

  var echartElemBarHorizontal1 = document.getElementById('echartBarHorizontal1');

  if (echartElemBarHorizontal1) {
    var echartBarHorizontal1 = echarts.init(echartElemBarHorizontal1);
    echartBarHorizontal1.setOption({
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          // Use axis to trigger tooltip
          type: 'shadow' // 'shadow' as default; can also be 'line' or 'shadow'
        }
      },
      legend: {},
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'value'
      },
      yAxis: {
        type: 'category',
        data: ["JAWABARAT3","JAWABARAT1","JAWABARAT2","JAWATENGAH","JAWATIMUR","SUMATERA6","SUMATERA4","SUMATERA5","SUMATERA3","SUMATERA2","ACEH1","ACEH2","SULAWESI1","SULAWESI2","SULAWESI3","SULAWESI4","SULAWESI5","MAPA","KALIMANTAN2","KALIMANTAN1","NUSATENGGARA"]
      },
      series: [
        {
          name: 'Booking',
          type: 'bar',
          stack: 'total',
          label: {
            show: true
          },
          emphasis: {
            focus: 'series'
          },
          data: [2218,2018,2907,2189,1212,1344,1693,1237,980,373,958,759,3346,2733,4260,1970,2464,1324,1154,1614,466]
        },
        {
          name: 'Rundown',
          type: 'bar',
          stack: 'total',
          label: {
            show: true
          },
          emphasis: {
            focus: 'series'
          },
          data: [1353,1212,1660,2229,1080,1127,1314,621,840,249,1018,644,2942,2537,2576,1618,1902,1031,917,1210,346]
        }
      ]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar2.resize();
      }, 500);
    });
  }

});

</script>