<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsSdm')">SDM</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>    

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Per Regional</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Produktivitas SDM</div>
                    <div class="table-responsive">
                        <table id="tableSdmReg" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col">Divisi</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Budget</th>
                                    <th scope="col" style="text-align: right;">Varian</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Per Cabang Pareto</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Produktivitas SDM</div>
                    <div class="table-responsive">
                        <table id="tableSdmPareto" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Jenis</th>
                                    <th scope="col">Divisi</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Budget</th>
                                    <th scope="col" style="text-align: right;">Varian</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1."); 
        }
    }
}

$(document).ready(function () {
    $('#tableSdmReg').DataTable({
        "data":[
            {
                "regional": "ACEH 1",
                "divisi": "COLLECTION",
                "BUDGET": 370.9193548387097,
                "ACTUAL": 279.80555555555554,
                "VARIANCE": -91.11379928315415
            },
            {
                "regional": "ACEH 1",
                "divisi": "CREDIT",
                "BUDGET": 88.15789473684211,
                "ACTUAL": 43.766666666666666,
                "VARIANCE": -44.391228070175444
            },
            {
                "regional": "ACEH 1",
                "divisi": "OPERATION",
                "BUDGET": 489.29787234042556,
                "ACTUAL": 428.63829787234044,
                "VARIANCE": -60.65957446808511
            },
            {
                "regional": "ACEH 1",
                "divisi": "SALES",
                "BUDGET": 55.166666666666664,
                "ACTUAL": 54.73684210526316,
                "VARIANCE": -0.4298245614035068
            },
            {
                "regional": "ACEH 2",
                "divisi": "COLLECTION",
                "BUDGET": 369.7567567567568,
                "ACTUAL": 309.4047619047619,
                "VARIANCE": -60.351994851994846
            },
            {
                "regional": "ACEH 2",
                "divisi": "CREDIT",
                "BUDGET": 83.16666666666667,
                "ACTUAL": 52.888888888888886,
                "VARIANCE": -30.277777777777786
            },
            {
                "regional": "ACEH 2",
                "divisi": "OPERATION",
                "BUDGET": 441.3225806451613,
                "ACTUAL": 541.4583333333334,
                "VARIANCE": 100.13575268817209
            },
            {
                "regional": "ACEH 2",
                "divisi": "SALES",
                "BUDGET": 59.1,
                "ACTUAL": 67.6923076923077,
                "VARIANCE": 8.592307692307692
            },
            {
                "regional": "JAWA BARAT 1",
                "divisi": "COLLECTION",
                "BUDGET": 232.95689655172413,
                "ACTUAL": 295.6842105263158,
                "VARIANCE": 62.72731397459165
            },
            {
                "regional": "JAWA BARAT 1",
                "divisi": "CREDIT",
                "BUDGET": 101.4,
                "ACTUAL": 78.6470588235294,
                "VARIANCE": -22.7529411764706
            },
            {
                "regional": "JAWA BARAT 1",
                "divisi": "OPERATION",
                "BUDGET": 551.4897959183673,
                "ACTUAL": 522.6046511627907,
                "VARIANCE": -28.885144755576675
            },
            {
                "regional": "JAWA BARAT 1",
                "divisi": "SALES",
                "BUDGET": 77.09677419354838,
                "ACTUAL": 76.25,
                "VARIANCE": -0.8467741935483843
            },
            {
                "regional": "JAWA BARAT 2",
                "divisi": "COLLECTION",
                "BUDGET": 197.5,
                "ACTUAL": 287.59375,
                "VARIANCE": 90.09375
            },
            {
                "regional": "JAWA BARAT 2",
                "divisi": "CREDIT",
                "BUDGET": 89.5925925925926,
                "ACTUAL": 116.7872340425532,
                "VARIANCE": 27.1946414499606
            },
            {
                "regional": "JAWA BARAT 2",
                "divisi": "OPERATION",
                "BUDGET": 459.05405405405406,
                "ACTUAL": 400.1304347826087,
                "VARIANCE": -58.923619271445375
            },
            {
                "regional": "JAWA BARAT 2",
                "divisi": "SALES",
                "BUDGET": 73.17948717948718,
                "ACTUAL": 75.725,
                "VARIANCE": 2.545512820512812
            },
            {
                "regional": "JAWA BARAT 3",
                "divisi": "COLLECTION",
                "BUDGET": 226.4125874125874,
                "ACTUAL": 314.75555555555553,
                "VARIANCE": 88.34296814296812
            },
            {
                "regional": "JAWA BARAT 3",
                "divisi": "CREDIT",
                "BUDGET": 118.21428571428571,
                "ACTUAL": 97.89473684210526,
                "VARIANCE": -20.319548872180448
            },
            {
                "regional": "JAWA BARAT 3",
                "divisi": "OPERATION",
                "BUDGET": 610.8867924528302,
                "ACTUAL": 629.5111111111111,
                "VARIANCE": 18.624318658280913
            },
            {
                "regional": "JAWA BARAT 3",
                "divisi": "SALES",
                "BUDGET": 104.39285714285714,
                "ACTUAL": 84.06896551724138,
                "VARIANCE": -20.323891625615758
            },
            {
                "regional": "JAWA TENGAH",
                "divisi": "COLLECTION",
                "BUDGET": 398.5979381443299,
                "ACTUAL": 313.9017857142857,
                "VARIANCE": -84.69615243004415
            },
            {
                "regional": "JAWA TENGAH",
                "divisi": "CREDIT",
                "BUDGET": 116.20930232558139,
                "ACTUAL": 78.84313725490196,
                "VARIANCE": -37.36616507067943
            },
            {
                "regional": "JAWA TENGAH",
                "divisi": "OPERATION",
                "BUDGET": 449.5813953488372,
                "ACTUAL": 423.578313253012,
                "VARIANCE": -26.003082095825164
            },
            {
                "regional": "JAWA TENGAH",
                "divisi": "SALES",
                "BUDGET": 58.88,
                "ACTUAL": 60.74418604651163,
                "VARIANCE": 1.8641860465116267
            },
            {
                "regional": "JAWA TIMUR",
                "divisi": "COLLECTION",
                "BUDGET": 442.1860465116279,
                "ACTUAL": 358.2826086956522,
                "VARIANCE": -83.90343781597574
            },
            {
                "regional": "JAWA TIMUR",
                "divisi": "CREDIT",
                "BUDGET": 121.52,
                "ACTUAL": 76.85185185185185,
                "VARIANCE": -44.66814814814815
            },
            {
                "regional": "JAWA TIMUR",
                "divisi": "OPERATION",
                "BUDGET": 475.35,
                "ACTUAL": 412.025,
                "VARIANCE": -63.325000000000045
            },
            {
                "regional": "JAWA TIMUR",
                "divisi": "SALES",
                "BUDGET": 68.84615384615384,
                "ACTUAL": 96.3529411764706,
                "VARIANCE": 27.506787330316754
            },
            {
                "regional": "KALIMANTAN 1",
                "divisi": "COLLECTION",
                "BUDGET": 337.7432432432432,
                "ACTUAL": 303.96875,
                "VARIANCE": -33.77449324324323
            },
            {
                "regional": "KALIMANTAN 1",
                "divisi": "CREDIT",
                "BUDGET": 97.6923076923077,
                "ACTUAL": 82.21875,
                "VARIANCE": -15.473557692307693
            },
            {
                "regional": "KALIMANTAN 1",
                "divisi": "OPERATION",
                "BUDGET": 454.41818181818184,
                "ACTUAL": 474.4878048780488,
                "VARIANCE": 20.069623059866956
            },
            {
                "regional": "KALIMANTAN 1",
                "divisi": "SALES",
                "BUDGET": 102.22727272727273,
                "ACTUAL": 99.5625,
                "VARIANCE": -2.6647727272727337
            },
            {
                "regional": "KALIMANTAN 2",
                "divisi": "COLLECTION",
                "BUDGET": 315.609375,
                "ACTUAL": 280.6808510638298,
                "VARIANCE": -34.92852393617022
            },
            {
                "regional": "KALIMANTAN 2",
                "divisi": "CREDIT",
                "BUDGET": 92.02631578947368,
                "ACTUAL": 62.44444444444444,
                "VARIANCE": -29.581871345029242
            },
            {
                "regional": "KALIMANTAN 2",
                "divisi": "OPERATION",
                "BUDGET": 388.4423076923077,
                "ACTUAL": 314.0952380952381,
                "VARIANCE": -74.3470695970696
            },
            {
                "regional": "KALIMANTAN 2",
                "divisi": "SALES",
                "BUDGET": 98.19047619047619,
                "ACTUAL": 73.73333333333333,
                "VARIANCE": -24.457142857142856
            },
            {
                "regional": "MAPA",
                "divisi": "COLLECTION",
                "BUDGET": 424.6938775510204,
                "ACTUAL": 303.21153846153845,
                "VARIANCE": -121.48233908948197
            },
            {
                "regional": "MAPA",
                "divisi": "CREDIT",
                "BUDGET": 135.7391304347826,
                "ACTUAL": 76.20833333333333,
                "VARIANCE": -59.53079710144927
            },
            {
                "regional": "MAPA",
                "divisi": "OPERATION",
                "BUDGET": 472.95454545454544,
                "ACTUAL": 426.13513513513516,
                "VARIANCE": -46.81941031941028
            },
            {
                "regional": "MAPA",
                "divisi": "SALES",
                "BUDGET": 131.57142857142858,
                "ACTUAL": 111,
                "VARIANCE": -20.571428571428584
            },
            {
                "regional": "NUSA TENGGARA",
                "divisi": "COLLECTION",
                "BUDGET": 258.30434782608694,
                "ACTUAL": 283.45,
                "VARIANCE": 25.14565217391305
            },
            {
                "regional": "NUSA TENGGARA",
                "divisi": "CREDIT",
                "BUDGET": 72.53846153846153,
                "ACTUAL": 61.84615384615385,
                "VARIANCE": -10.692307692307686
            },
            {
                "regional": "NUSA TENGGARA",
                "divisi": "OPERATION",
                "BUDGET": 495.0833333333333,
                "ACTUAL": 436.0769230769231,
                "VARIANCE": -59.00641025641022
            },
            {
                "regional": "NUSA TENGGARA",
                "divisi": "SALES",
                "BUDGET": 46.333333333333336,
                "ACTUAL": 42.07692307692308,
                "VARIANCE": -4.2564102564102555
            },
            {
                "regional": "SULAWESI 1",
                "divisi": "COLLECTION",
                "BUDGET": 338.8688524590164,
                "ACTUAL": 330.59659090909093,
                "VARIANCE": -8.272261549925474
            },
            {
                "regional": "SULAWESI 1",
                "divisi": "CREDIT",
                "BUDGET": 84.34285714285714,
                "ACTUAL": 62.72222222222222,
                "VARIANCE": -21.62063492063492
            },
            {
                "regional": "SULAWESI 1",
                "divisi": "OPERATION",
                "BUDGET": 548.787610619469,
                "ACTUAL": 524.1891891891892,
                "VARIANCE": -24.598421430279814
            },
            {
                "regional": "SULAWESI 1",
                "divisi": "SALES",
                "BUDGET": 94.1891891891892,
                "ACTUAL": 119.34375,
                "VARIANCE": 25.154560810810807
            },
            {
                "regional": "SULAWESI 2",
                "divisi": "COLLECTION",
                "BUDGET": 293.4,
                "ACTUAL": 242.11560693641619,
                "VARIANCE": -51.28439306358379
            },
            {
                "regional": "SULAWESI 2",
                "divisi": "CREDIT",
                "BUDGET": 90.98484848484848,
                "ACTUAL": 65.93548387096774,
                "VARIANCE": -25.04936461388074
            },
            {
                "regional": "SULAWESI 2",
                "divisi": "OPERATION",
                "BUDGET": 471.5357142857143,
                "ACTUAL": 384.27522935779814,
                "VARIANCE": -87.26048492791614
            },
            {
                "regional": "SULAWESI 2",
                "divisi": "SALES",
                "BUDGET": 90.82051282051282,
                "ACTUAL": 67.67391304347827,
                "VARIANCE": -23.146599777034552
            },
            {
                "regional": "SULAWESI 3",
                "divisi": "COLLECTION",
                "BUDGET": 325.17105263157896,
                "ACTUAL": 360.5592105263158,
                "VARIANCE": 35.38815789473682
            },
            {
                "regional": "SULAWESI 3",
                "divisi": "CREDIT",
                "BUDGET": 92.68852459016394,
                "ACTUAL": 99.38709677419355,
                "VARIANCE": 6.698572184029615
            },
            {
                "regional": "SULAWESI 3",
                "divisi": "OPERATION",
                "BUDGET": 453.44954128440367,
                "ACTUAL": 489.33035714285717,
                "VARIANCE": 35.8808158584535
            },
            {
                "regional": "SULAWESI 3",
                "divisi": "SALES",
                "BUDGET": 95.17142857142858,
                "ACTUAL": 120.85,
                "VARIANCE": 25.678571428571416
            },
            {
                "regional": "SULAWESI 4",
                "divisi": "COLLECTION",
                "BUDGET": 358.59090909090907,
                "ACTUAL": 279.14606741573033,
                "VARIANCE": -79.44484167517874
            },
            {
                "regional": "SULAWESI 4",
                "divisi": "CREDIT",
                "BUDGET": 119.1025641025641,
                "ACTUAL": 80.05555555555556,
                "VARIANCE": -39.047008547008545
            },
            {
                "regional": "SULAWESI 4",
                "divisi": "OPERATION",
                "BUDGET": 444.4507042253521,
                "ACTUAL": 388.1875,
                "VARIANCE": -56.263204225352126
            },
            {
                "regional": "SULAWESI 4",
                "divisi": "SALES",
                "BUDGET": 119.21739130434783,
                "ACTUAL": 89.1304347826087,
                "VARIANCE": -30.086956521739125
            },
            {
                "regional": "SULAWESI 5",
                "divisi": "COLLECTION",
                "BUDGET": 306.6475409836066,
                "ACTUAL": 307.1818181818182,
                "VARIANCE": 0.5342771982116119
            },
            {
                "regional": "SULAWESI 5",
                "divisi": "CREDIT",
                "BUDGET": 113.91304347826087,
                "ACTUAL": 77,
                "VARIANCE": -36.913043478260875
            },
            {
                "regional": "SULAWESI 5",
                "divisi": "OPERATION",
                "BUDGET": 445.3690476190476,
                "ACTUAL": 422.375,
                "VARIANCE": -22.994047619047592
            },
            {
                "regional": "SULAWESI 5",
                "divisi": "SALES",
                "BUDGET": 134.56521739130434,
                "ACTUAL": 128.36363636363637,
                "VARIANCE": -6.20158102766797
            },
            {
                "regional": "SUMATERA 2",
                "divisi": "COLLECTION",
                "BUDGET": 341.60869565217394,
                "ACTUAL": 288.8,
                "VARIANCE": -52.808695652173924
            },
            {
                "regional": "SUMATERA 2",
                "divisi": "CREDIT",
                "BUDGET": 104.125,
                "ACTUAL": 57.333333333333336,
                "VARIANCE": -46.791666666666664
            },
            {
                "regional": "SUMATERA 2",
                "divisi": "OPERATION",
                "BUDGET": 462.1764705882353,
                "ACTUAL": 444.3076923076923,
                "VARIANCE": -17.868778280542983
            },
            {
                "regional": "SUMATERA 2",
                "divisi": "SALES",
                "BUDGET": 82.16666666666667,
                "ACTUAL": 58.714285714285715,
                "VARIANCE": -23.452380952380956
            },
            {
                "regional": "SUMATERA 3",
                "divisi": "COLLECTION",
                "BUDGET": 318.06060606060606,
                "ACTUAL": 323.203125,
                "VARIANCE": 5.142518939393938
            },
            {
                "regional": "SUMATERA 3",
                "divisi": "CREDIT",
                "BUDGET": 71,
                "ACTUAL": 53.205128205128204,
                "VARIANCE": -17.794871794871796
            },
            {
                "regional": "SUMATERA 3",
                "divisi": "OPERATION",
                "BUDGET": 428.40816326530614,
                "ACTUAL": 459.6666666666667,
                "VARIANCE": 31.258503401360542
            },
            {
                "regional": "SUMATERA 3",
                "divisi": "SALES",
                "BUDGET": 86.86666666666666,
                "ACTUAL": 53.63636363636363,
                "VARIANCE": -33.23030303030303
            },
            {
                "regional": "SUMATERA 4",
                "divisi": "COLLECTION",
                "BUDGET": 337.97333333333336,
                "ACTUAL": 345.29333333333335,
                "VARIANCE": 7.319999999999993
            },
            {
                "regional": "SUMATERA 4",
                "divisi": "CREDIT",
                "BUDGET": 62.83783783783784,
                "ACTUAL": 55.4375,
                "VARIANCE": -7.400337837837839
            },
            {
                "regional": "SUMATERA 4",
                "divisi": "OPERATION",
                "BUDGET": 402.3492063492063,
                "ACTUAL": 431.6166666666667,
                "VARIANCE": 29.267460317460348
            },
            {
                "regional": "SUMATERA 4",
                "divisi": "SALES",
                "BUDGET": 55.28,
                "ACTUAL": 55.724137931034484,
                "VARIANCE": 0.44413793103448285
            },
            {
                "regional": "SUMATERA 5",
                "divisi": "COLLECTION",
                "BUDGET": 363.52941176470586,
                "ACTUAL": 334.76190476190476,
                "VARIANCE": -28.767507002801096
            },
            {
                "regional": "SUMATERA 5",
                "divisi": "CREDIT",
                "BUDGET": 90.8125,
                "ACTUAL": 89.95652173913044,
                "VARIANCE": -0.8559782608695627
            },
            {
                "regional": "SUMATERA 5",
                "divisi": "OPERATION",
                "BUDGET": 412,
                "ACTUAL": 426.06060606060606,
                "VARIANCE": 14.060606060606062
            },
            {
                "regional": "SUMATERA 5",
                "divisi": "SALES",
                "BUDGET": 171.6,
                "ACTUAL": 126.72727272727273,
                "VARIANCE": -44.87272727272726
            },
            {
                "regional": "SUMATERA 6",
                "divisi": "COLLECTION",
                "BUDGET": 358.34375,
                "ACTUAL": 330.63157894736844,
                "VARIANCE": -27.71217105263156
            },
            {
                "regional": "SUMATERA 6",
                "divisi": "CREDIT",
                "BUDGET": 106.84210526315789,
                "ACTUAL": 97.35,
                "VARIANCE": -9.492105263157896
            },
            {
                "regional": "SUMATERA 6",
                "divisi": "OPERATION",
                "BUDGET": 416.9818181818182,
                "ACTUAL": 362.4230769230769,
                "VARIANCE": -54.55874125874129
            },
            {
                "regional": "SUMATERA 6",
                "divisi": "SALES",
                "BUDGET": 52.52173913043478,
                "ACTUAL": 55.958333333333336,
                "VARIANCE": 3.4365942028985543
            }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "divisi" },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "BUDGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "VARIANCE", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableSdmPareto').DataTable({
        "data":[
            {
                "jenis": "NON PARETO",
                "divisi": "COLLECTION",
                "BUDGET": 323.9003181336161,
                "ACTUAL": 306.5457627118644,
                "VARIANCE": -17.354555421751684
            },
            {
                "jenis": "NON PARETO",
                "divisi": "CREDIT",
                "BUDGET": 97.93654822335026,
                "ACTUAL": 73.05687203791469,
                "VARIANCE": -24.87967618543557
            },
            {
                "jenis": "NON PARETO",
                "divisi": "OPERATION",
                "BUDGET": 436.34,
                "ACTUAL": 418.0169491525424,
                "VARIANCE": -18.32305084745758
            },
            {
                "jenis": "NON PARETO",
                "divisi": "SALES",
                "BUDGET": 85.71428571428571,
                "ACTUAL": 78.66308243727599,
                "VARIANCE": -7.051203277009719
            },
            {
                "jenis": "PARETO",
                "divisi": "COLLECTION",
                "BUDGET": 299.71861471861473,
                "ACTUAL": 309.8113924050633,
                "VARIANCE": 10.092777686448585
            },
            {
                "jenis": "PARETO",
                "divisi": "CREDIT",
                "BUDGET": 96.95100864553314,
                "ACTUAL": 79.61290322580645,
                "VARIANCE": -17.338105419726688
            },
            {
                "jenis": "PARETO",
                "divisi": "OPERATION",
                "BUDGET": 507.2161172161172,
                "ACTUAL": 476.1692607003891,
                "VARIANCE": -31.04685651572811
            },
            {
                "jenis": "PARETO",
                "divisi": "SALES",
                "BUDGET": 84.03813559322033,
                "ACTUAL": 85.52702702702703,
                "VARIANCE": 1.4888914338066996
            }
        ],
        "columns": [
            { "data": "jenis" },
            { "data": "divisi" },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "BUDGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "VARIANCE", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });
});

</script>