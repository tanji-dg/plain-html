<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsNcl')">NCL</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>    

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Per Produk</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Produk - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableNclProdukRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Per Regional</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Regional - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableNclRegRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Regional Per Produk - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableNclRegProdukRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Cabang - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableNclCabRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Cabang Per Produk - Rp.</div>
                    <div class="table-responsive">
                        <table id="tableNclCabProdukRp" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Per Cabang Pareto</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">NCL Per Cabang Pareto</div>
                    <div class="table-responsive">
                        <table id="tableNclParetoCab" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Jenis</th>
                                    <th scope="col" style="text-align: right;">WO</th>
                                    <th scope="col" style="text-align: right;">Rugi TB</th>
                                    <th scope="col" style="text-align: right;">NCL</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1."); 
        }
    }
}

$(document).ready(function () {
    $('#tableNclProdukRp').DataTable({
        "data":[
            {
                "nama_produk": "AISI",
                "WO": 148275018005,
                "RUGI_TB": 30543719046,
                "NCL": 2.96
            },
            {
                "nama_produk": "KPM",
                "WO": 23099805847,
                "RUGI_TB": 290439022,
                "NCL": 1.52
            },
            {
                "nama_produk": "RETENTION",
                "WO": 28295967823,
                "RUGI_TB": 2811822196,
                "NCL": 1.42
            }
        ],
        "columns": [
            { "data": "nama_produk" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableNclRegRp').DataTable({
        "data":[
            {
                "regional": null,
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "regional": "NUSA TENGGARA",
                "WO": 990144949,
                "RUGI_TB": 41340702,
                "NCL": 1.52
            },
            {
                "regional": "SUMATERA 5",
                "WO": 1704131205,
                "RUGI_TB": 972221035,
                "NCL": 0.89
            },
            {
                "regional": "MAPA",
                "WO": 1983313040,
                "RUGI_TB": 1012244019,
                "NCL": 0.94
            },
            {
                "regional": "ACEH 2",
                "WO": 3288998106,
                "RUGI_TB": 1671144968,
                "NCL": 1.9
            },
            {
                "regional": "JAWA TIMUR",
                "WO": 3438861952,
                "RUGI_TB": 21098285,
                "NCL": 2.37
            },
            {
                "regional": "KALIMANTAN 2",
                "WO": 4614913115,
                "RUGI_TB": 417847066,
                "NCL": 1.64
            },
            {
                "regional": "JAWA TENGAH",
                "WO": 5001570454,
                "RUGI_TB": 56839684,
                "NCL": 1.47
            },
            {
                "regional": "SULAWESI 4",
                "WO": 5501178077,
                "RUGI_TB": 1251159127,
                "NCL": 1.29
            },
            {
                "regional": "ACEH 1",
                "WO": 5726088827,
                "RUGI_TB": 2155322489,
                "NCL": 1.63
            },
            {
                "regional": "JAWA BARAT 1",
                "WO": 7779699674,
                "RUGI_TB": 565376243,
                "NCL": 2.54
            },
            {
                "regional": "KALIMANTAN 1",
                "WO": 10437589071,
                "RUGI_TB": 1083433121,
                "NCL": 3.29
            },
            {
                "regional": "SUMATERA 6",
                "WO": 10655180372,
                "RUGI_TB": 1728555576,
                "NCL": 3.35
            },
            {
                "regional": "SULAWESI 3",
                "WO": 11085558615,
                "RUGI_TB": 3993826061,
                "NCL": 1.55
            },
            {
                "regional": "SUMATERA 3",
                "WO": 11094488901,
                "RUGI_TB": 1292942262,
                "NCL": 3.13
            },
            {
                "regional": "JAWA BARAT 3",
                "WO": 11894421899,
                "RUGI_TB": 707100201,
                "NCL": 2.51
            },
            {
                "regional": "SUMATERA 2",
                "WO": 12876792432,
                "RUGI_TB": 696631177,
                "NCL": 10.34
            },
            {
                "regional": "SULAWESI 2",
                "WO": 13178587662,
                "RUGI_TB": 3982857441,
                "NCL": 1.72
            },
            {
                "regional": "JAWA BARAT 2",
                "WO": 16815994780,
                "RUGI_TB": 424547009,
                "NCL": 4.11
            },
            {
                "regional": "SULAWESI 1",
                "WO": 16989722490,
                "RUGI_TB": 5473842637,
                "NCL": 1.69
            },
            {
                "regional": "SUMATERA 4",
                "WO": 19322844209,
                "RUGI_TB": 3603933776,
                "NCL": 4.42
            },
            {
                "regional": "SULAWESI 5",
                "WO": 25290711845,
                "RUGI_TB": 2493717385,
                "NCL": 3.93
            }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableNclRegProdukRp').DataTable({
        "data":[
            {
                "regional": null,
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "regional": "ACEH 1",
                "nama_produk": "AISI",
                "WO": 5115902409,
                "RUGI_TB": 2089038953,
                "NCL": 1.86
            },
            {
                "regional": "ACEH 1",
                "nama_produk": "KPM",
                "WO": 236699785,
                "RUGI_TB": 6552019,
                "NCL": 0.68
            },
            {
                "regional": "ACEH 1",
                "nama_produk": "RETENTION",
                "WO": 373486633,
                "RUGI_TB": 59731517,
                "NCL": 0.71
            },
            {
                "regional": "ACEH 2",
                "nama_produk": "AISI",
                "WO": 2551284498,
                "RUGI_TB": 1479682241,
                "NCL": 2.35
            },
            {
                "regional": "ACEH 2",
                "nama_produk": "KPM",
                "WO": 324187556,
                "RUGI_TB": 80478555,
                "NCL": 1.14
            },
            {
                "regional": "ACEH 2",
                "nama_produk": "RETENTION",
                "WO": 413526052,
                "RUGI_TB": 110984172,
                "NCL": 0.98
            },
            {
                "regional": "JAWA BARAT 1",
                "nama_produk": "AISI",
                "WO": 4884175988,
                "RUGI_TB": 195370712,
                "NCL": 5.36
            },
            {
                "regional": "JAWA BARAT 1",
                "nama_produk": "KPM",
                "WO": 1603117707,
                "RUGI_TB": 67448395,
                "NCL": 1.33
            },
            {
                "regional": "JAWA BARAT 1",
                "nama_produk": "RETENTION",
                "WO": 1292405979,
                "RUGI_TB": 302557136,
                "NCL": 1.47
            },
            {
                "regional": "JAWA BARAT 2",
                "nama_produk": "AISI",
                "WO": 9716486606,
                "RUGI_TB": 266455931,
                "NCL": 6.97
            },
            {
                "regional": "JAWA BARAT 2",
                "nama_produk": "KPM",
                "WO": 3518706895,
                "RUGI_TB": -1753216,
                "NCL": 2.98
            },
            {
                "regional": "JAWA BARAT 2",
                "nama_produk": "RETENTION",
                "WO": 3580801279,
                "RUGI_TB": 159844294,
                "NCL": 2.36
            },
            {
                "regional": "JAWA BARAT 3",
                "nama_produk": "AISI",
                "WO": 9671469767,
                "RUGI_TB": 706019404,
                "NCL": 3.95
            },
            {
                "regional": "JAWA BARAT 3",
                "nama_produk": "KPM",
                "WO": 1204305983,
                "RUGI_TB": -60689251,
                "NCL": 1.09
            },
            {
                "regional": "JAWA BARAT 3",
                "nama_produk": "RETENTION",
                "WO": 1018646149,
                "RUGI_TB": 61770048,
                "NCL": 0.81
            },
            {
                "regional": "JAWA TENGAH",
                "nama_produk": "KPM",
                "WO": 3157468570,
                "RUGI_TB": -9591916,
                "NCL": 1.59
            },
            {
                "regional": "JAWA TENGAH",
                "nama_produk": "RETENTION",
                "WO": 1844101884,
                "RUGI_TB": 66431600,
                "NCL": 1.31
            },
            {
                "regional": "JAWA TIMUR",
                "nama_produk": "KPM",
                "WO": 1729888241,
                "RUGI_TB": -11601634,
                "NCL": 1.93
            },
            {
                "regional": "JAWA TIMUR",
                "nama_produk": "RETENTION",
                "WO": 1708973711,
                "RUGI_TB": 32699919,
                "NCL": 3.03
            },
            {
                "regional": "KALIMANTAN 1",
                "nama_produk": "AISI",
                "WO": 8448662835,
                "RUGI_TB": 1029283258,
                "NCL": 4.35
            },
            {
                "regional": "KALIMANTAN 1",
                "nama_produk": "KPM",
                "WO": 800216760,
                "RUGI_TB": 777194,
                "NCL": 1.64
            },
            {
                "regional": "KALIMANTAN 1",
                "nama_produk": "RETENTION",
                "WO": 1188709476,
                "RUGI_TB": 53372669,
                "NCL": 1.5
            },
            {
                "regional": "KALIMANTAN 2",
                "nama_produk": "AISI",
                "WO": 3977556261,
                "RUGI_TB": 347106978,
                "NCL": 2.24
            },
            {
                "regional": "KALIMANTAN 2",
                "nama_produk": "KPM",
                "WO": 228517276,
                "RUGI_TB": 12496632,
                "NCL": 0.62
            },
            {
                "regional": "KALIMANTAN 2",
                "nama_produk": "RETENTION",
                "WO": 408839578,
                "RUGI_TB": 58243456,
                "NCL": 0.62
            },
            {
                "regional": "MAPA",
                "nama_produk": "AISI",
                "WO": 714740892,
                "RUGI_TB": 730986070,
                "NCL": 1
            },
            {
                "regional": "MAPA",
                "nama_produk": "KPM",
                "WO": 467019406,
                "RUGI_TB": -3979636,
                "NCL": 0.74
            },
            {
                "regional": "MAPA",
                "nama_produk": "RETENTION",
                "WO": 801552742,
                "RUGI_TB": 285237585,
                "NCL": 0.98
            },
            {
                "regional": "NUSA TENGGARA",
                "nama_produk": "AISI",
                "WO": 412556990,
                "RUGI_TB": 2791161,
                "NCL": 5.3
            },
            {
                "regional": "NUSA TENGGARA",
                "nama_produk": "KPM",
                "WO": 344350497,
                "RUGI_TB": 11480032,
                "NCL": 1.07
            },
            {
                "regional": "NUSA TENGGARA",
                "nama_produk": "RETENTION",
                "WO": 233237462,
                "RUGI_TB": 27069509,
                "NCL": 0.97
            },
            {
                "regional": "SULAWESI 1",
                "nama_produk": "AISI",
                "WO": 13645910788,
                "RUGI_TB": 5065346972,
                "NCL": 1.93
            },
            {
                "regional": "SULAWESI 1",
                "nama_produk": "KPM",
                "WO": 1084786679,
                "RUGI_TB": 14773491,
                "NCL": 1
            },
            {
                "regional": "SULAWESI 1",
                "nama_produk": "RETENTION",
                "WO": 2259025023,
                "RUGI_TB": 393722174,
                "NCL": 1.06
            },
            {
                "regional": "SULAWESI 2",
                "nama_produk": "AISI",
                "WO": 10163678907,
                "RUGI_TB": 3730345923,
                "NCL": 1.91
            },
            {
                "regional": "SULAWESI 2",
                "nama_produk": "KPM",
                "WO": 774527138,
                "RUGI_TB": -2075210,
                "NCL": 1.14
            },
            {
                "regional": "SULAWESI 2",
                "nama_produk": "RETENTION",
                "WO": 2240381617,
                "RUGI_TB": 254586728,
                "NCL": 1.23
            },
            {
                "regional": "SULAWESI 3",
                "nama_produk": "AISI",
                "WO": 9463849441,
                "RUGI_TB": 3799455182,
                "NCL": 1.97
            },
            {
                "regional": "SULAWESI 3",
                "nama_produk": "KPM",
                "WO": 506653623,
                "RUGI_TB": 42117175,
                "NCL": 0.48
            },
            {
                "regional": "SULAWESI 3",
                "nama_produk": "RETENTION",
                "WO": 1115055551,
                "RUGI_TB": 152253704,
                "NCL": 0.68
            },
            {
                "regional": "SULAWESI 4",
                "nama_produk": "AISI",
                "WO": 4077410388,
                "RUGI_TB": 1234555077,
                "NCL": 1.5
            },
            {
                "regional": "SULAWESI 4",
                "nama_produk": "KPM",
                "WO": 503838134,
                "RUGI_TB": -17697149,
                "NCL": 0.84
            },
            {
                "regional": "SULAWESI 4",
                "nama_produk": "RETENTION",
                "WO": 919929555,
                "RUGI_TB": 34301199,
                "NCL": 0.86
            },
            {
                "regional": "SULAWESI 5",
                "nama_produk": "AISI",
                "WO": 19089011904,
                "RUGI_TB": 1952005243,
                "NCL": 5.1
            },
            {
                "regional": "SULAWESI 5",
                "nama_produk": "KPM",
                "WO": 2006245318,
                "RUGI_TB": 52411757,
                "NCL": 2
            },
            {
                "regional": "SULAWESI 5",
                "nama_produk": "RETENTION",
                "WO": 4195454623,
                "RUGI_TB": 489300385,
                "NCL": 2.44
            },
            {
                "regional": "SUMATERA 2",
                "nama_produk": "AISI",
                "WO": 10992484067,
                "RUGI_TB": 700095617,
                "NCL": 11.91
            },
            {
                "regional": "SUMATERA 2",
                "nama_produk": "KPM",
                "WO": 1269797780,
                "RUGI_TB": -5205588,
                "NCL": 6.27
            },
            {
                "regional": "SUMATERA 2",
                "nama_produk": "RETENTION",
                "WO": 614510585,
                "RUGI_TB": 1741148,
                "NCL": 4.78
            },
            {
                "regional": "SUMATERA 3",
                "nama_produk": "AISI",
                "WO": 8415437798,
                "RUGI_TB": 1197131530,
                "NCL": 3.13
            },
            {
                "regional": "SUMATERA 3",
                "nama_produk": "KPM",
                "WO": 1242761919,
                "RUGI_TB": 9966510,
                "NCL": 3.29
            },
            {
                "regional": "SUMATERA 3",
                "nama_produk": "RETENTION",
                "WO": 1436289184,
                "RUGI_TB": 85844222,
                "NCL": 2.98
            },
            {
                "regional": "SUMATERA 4",
                "nama_produk": "AISI",
                "WO": 16776501444,
                "RUGI_TB": 3381346668,
                "NCL": 5.23
            },
            {
                "regional": "SUMATERA 4",
                "nama_produk": "KPM",
                "WO": 1211231814,
                "RUGI_TB": 126111669,
                "NCL": 2.34
            },
            {
                "regional": "SUMATERA 4",
                "nama_produk": "RETENTION",
                "WO": 1335110951,
                "RUGI_TB": 96475439,
                "NCL": 1.9
            },
            {
                "regional": "SUMATERA 5",
                "nama_produk": "AISI",
                "WO": 1123511895,
                "RUGI_TB": 967784275,
                "NCL": 0.84
            },
            {
                "regional": "SUMATERA 5",
                "nama_produk": "KPM",
                "WO": 263707260,
                "RUGI_TB": 5345706,
                "NCL": 1.08
            },
            {
                "regional": "SUMATERA 5",
                "nama_produk": "RETENTION",
                "WO": 316912050,
                "RUGI_TB": -908946,
                "NCL": 1.13
            },
            {
                "regional": "SUMATERA 6",
                "nama_produk": "AISI",
                "WO": 9034385127,
                "RUGI_TB": 1668917851,
                "NCL": 4.44
            },
            {
                "regional": "SUMATERA 6",
                "nama_produk": "KPM",
                "WO": 621777506,
                "RUGI_TB": -26926513,
                "NCL": 1.1
            },
            {
                "regional": "SUMATERA 6",
                "nama_produk": "RETENTION",
                "WO": 999017739,
                "RUGI_TB": 86564238,
                "NCL": 1.45
            }
        ],
        "columns": [
            { "data": "regional" },
            { "data": "nama_produk" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableNclCabRp').DataTable({
        "data":[
            {
                "nmcab": null,
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "DOMPU",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "KAPUAS",
                "WO": 17664618,
                "RUGI_TB": 9636146,
                "NCL": 0.47
            },
            {
                "nmcab": "RUTENG",
                "WO": 18899924,
                "RUGI_TB": 22471467,
                "NCL": 0.36
            },
            {
                "nmcab": "SORONG",
                "WO": 20615230,
                "RUGI_TB": 106693931,
                "NCL": 0.95
            },
            {
                "nmcab": "BELITUNG",
                "WO": 23088521,
                "RUGI_TB": 219307319,
                "NCL": 0.45
            },
            {
                "nmcab": "SIAU",
                "WO": 24129447,
                "RUGI_TB": 900319,
                "NCL": 0.16
            },
            {
                "nmcab": "ULEE GLEE",
                "WO": 29195011,
                "RUGI_TB": 4302612,
                "NCL": 0.23
            },
            {
                "nmcab": "SOROLANGON",
                "WO": 34554851,
                "RUGI_TB": 0,
                "NCL": 32.97
            },
            {
                "nmcab": "MUARA BULIAN",
                "WO": 35411200,
                "RUGI_TB": 0,
                "NCL": 43.27
            },
            {
                "nmcab": "TUNGKAL",
                "WO": 35601658,
                "RUGI_TB": 5258032,
                "NCL": 0.65
            },
            {
                "nmcab": "ALUE BILIE",
                "WO": 41822900,
                "RUGI_TB": 8297119,
                "NCL": 0.25
            },
            {
                "nmcab": "LABUAN BAJO",
                "WO": 46666116,
                "RUGI_TB": 9165010,
                "NCL": 0.46
            },
            {
                "nmcab": "SELAYAR",
                "WO": 46792578,
                "RUGI_TB": 83435420,
                "NCL": 0.37
            },
            {
                "nmcab": "MALINO",
                "WO": 50428099,
                "RUGI_TB": 58864171,
                "NCL": 0.54
            },
            {
                "nmcab": "EREKE",
                "WO": 51267469,
                "RUGI_TB": 6756443,
                "NCL": 0.29
            },
            {
                "nmcab": "SALAKAN",
                "WO": 55297477,
                "RUGI_TB": 150013735,
                "NCL": 0.33
            },
            {
                "nmcab": "PONTIANAK",
                "WO": 55441042,
                "RUGI_TB": -2398717,
                "NCL": 1.3
            },
            {
                "nmcab": "WAISARISSA",
                "WO": 55766877,
                "RUGI_TB": -5316232,
                "NCL": 0.17
            },
            {
                "nmcab": "TULANG BAWANG",
                "WO": 56696778,
                "RUGI_TB": 9025683,
                "NCL": 0.44
            },
            {
                "nmcab": "BOYOLALI",
                "WO": 59335185,
                "RUGI_TB": -8341717,
                "NCL": 0.33
            },
            {
                "nmcab": "MOLIBAGU",
                "WO": 63764364,
                "RUGI_TB": 571472,
                "NCL": 0.62
            },
            {
                "nmcab": "BELINYU",
                "WO": 70938639,
                "RUGI_TB": 49170471,
                "NCL": 0.52
            },
            {
                "nmcab": "ENDE",
                "WO": 71965257,
                "RUGI_TB": 2697015,
                "NCL": 1.16
            },
            {
                "nmcab": "RAWAJITU",
                "WO": 73209139,
                "RUGI_TB": 11556381,
                "NCL": 0.5
            },
            {
                "nmcab": "TOBELO",
                "WO": 75323729,
                "RUGI_TB": 33056867,
                "NCL": 0.37
            },
            {
                "nmcab": "KELAPA",
                "WO": 76221762,
                "RUGI_TB": 32788386,
                "NCL": 0.51
            },
            {
                "nmcab": "WONOSARI",
                "WO": 77635514,
                "RUGI_TB": -7374254,
                "NCL": 0.52
            },
            {
                "nmcab": "BELTIM",
                "WO": 78886309,
                "RUGI_TB": 153226331,
                "NCL": 0.82
            },
            {
                "nmcab": "MADIUN",
                "WO": 79400360,
                "RUGI_TB": 62672,
                "NCL": 0.92
            },
            {
                "nmcab": "KARANGANYAR",
                "WO": 81323151,
                "RUGI_TB": -3049463,
                "NCL": 0.44
            },
            {
                "nmcab": "MOROTAI",
                "WO": 84066053,
                "RUGI_TB": 1110358,
                "NCL": 2.81
            },
            {
                "nmcab": "TAHUNA",
                "WO": 84259800,
                "RUGI_TB": 37031192,
                "NCL": 0.46
            },
            {
                "nmcab": "SUNGAI LIAT",
                "WO": 84454919,
                "RUGI_TB": 51506593,
                "NCL": 0.63
            },
            {
                "nmcab": "TOBOALI",
                "WO": 86505643,
                "RUGI_TB": 24662410,
                "NCL": 0.53
            },
            {
                "nmcab": "BACAN",
                "WO": 89302371,
                "RUGI_TB": 20504211,
                "NCL": 0.96
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "WO": 89483774,
                "RUGI_TB": 5256456,
                "NCL": 0.76
            },
            {
                "nmcab": "KOBA",
                "WO": 90851312,
                "RUGI_TB": 36502164,
                "NCL": 0.63
            },
            {
                "nmcab": "WONOGIRI",
                "WO": 91418064,
                "RUGI_TB": -10265766,
                "NCL": 0.43
            },
            {
                "nmcab": "BELITANG",
                "WO": 91480763,
                "RUGI_TB": 0,
                "NCL": 0.92
            },
            {
                "nmcab": "SRAGEN",
                "WO": 98610715,
                "RUGI_TB": 42133467,
                "NCL": 1.02
            },
            {
                "nmcab": "TALAUD",
                "WO": 99493895,
                "RUGI_TB": 21451573,
                "NCL": 0.51
            },
            {
                "nmcab": "PENDOLO",
                "WO": 101872368,
                "RUGI_TB": 22828450,
                "NCL": 0.57
            },
            {
                "nmcab": "BUOL",
                "WO": 104915457,
                "RUGI_TB": 100703659,
                "NCL": 0.5
            },
            {
                "nmcab": "UJUNG GADING",
                "WO": 107167841,
                "RUGI_TB": 49596546,
                "NCL": 0.4
            },
            {
                "nmcab": "LASUSUA",
                "WO": 107222027,
                "RUGI_TB": -6083912,
                "NCL": 0.82
            },
            {
                "nmcab": "BULI",
                "WO": 107849426,
                "RUGI_TB": 0,
                "NCL": 7.14
            },
            {
                "nmcab": "PANGKALANBUN",
                "WO": 111085409,
                "RUGI_TB": 2317038,
                "NCL": 1.71
            },
            {
                "nmcab": "TANGGEUNG",
                "WO": 111126360,
                "RUGI_TB": 61240953,
                "NCL": 0.84
            },
            {
                "nmcab": "MASOHI",
                "WO": 112583768,
                "RUGI_TB": 21818475,
                "NCL": 0.31
            },
            {
                "nmcab": "DONGGALA",
                "WO": 117351841,
                "RUGI_TB": 242087821,
                "NCL": 0.81
            },
            {
                "nmcab": "DAYA MURNI",
                "WO": 118102729,
                "RUGI_TB": 8814954,
                "NCL": 1.18
            },
            {
                "nmcab": "BOEPINANG",
                "WO": 121242500,
                "RUGI_TB": 24175183,
                "NCL": 0.54
            },
            {
                "nmcab": "NAMLEA",
                "WO": 121790867,
                "RUGI_TB": 87918754,
                "NCL": 0.53
            },
            {
                "nmcab": "PAYAKUMBUH",
                "WO": 123597938,
                "RUGI_TB": 9319328,
                "NCL": 0.89
            },
            {
                "nmcab": "PROBOLINGGO",
                "WO": 125512850,
                "RUGI_TB": -2853984,
                "NCL": 1.33
            },
            {
                "nmcab": "MAGELANG",
                "WO": 128926774,
                "RUGI_TB": 10271296,
                "NCL": 0.77
            },
            {
                "nmcab": "ENREKANG",
                "WO": 132492045,
                "RUGI_TB": 69718736,
                "NCL": 0.75
            },
            {
                "nmcab": "MARTAPURA",
                "WO": 137289629,
                "RUGI_TB": 260928,
                "NCL": 2.35
            },
            {
                "nmcab": "BUTON",
                "WO": 140764813,
                "RUGI_TB": 85501609,
                "NCL": 0.3
            },
            {
                "nmcab": "TULUNGAGUNG",
                "WO": 145906160,
                "RUGI_TB": 0,
                "NCL": 1.86
            },
            {
                "nmcab": "SURABAYA",
                "WO": 146845923,
                "RUGI_TB": 890396,
                "NCL": 1.31
            },
            {
                "nmcab": "MANGKUTANA",
                "WO": 150024539,
                "RUGI_TB": 84173856,
                "NCL": 0.49
            },
            {
                "nmcab": "TOPPOYO",
                "WO": 150047196,
                "RUGI_TB": 73767578,
                "NCL": 0.4
            },
            {
                "nmcab": "TENGGARONG",
                "WO": 151383253,
                "RUGI_TB": 73522742,
                "NCL": 0.66
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "WO": 154421570,
                "RUGI_TB": 36520634,
                "NCL": 0.4
            },
            {
                "nmcab": "TARAKAN",
                "WO": 161718602,
                "RUGI_TB": 3636234,
                "NCL": 1.24
            },
            {
                "nmcab": "JEBUS",
                "WO": 161885004,
                "RUGI_TB": 19376447,
                "NCL": 1.39
            },
            {
                "nmcab": "YOGYAKARTA",
                "WO": 162342739,
                "RUGI_TB": 19299604,
                "NCL": 0.92
            },
            {
                "nmcab": "LANGSA ACEH",
                "WO": 164276212,
                "RUGI_TB": 22866890,
                "NCL": 0.79
            },
            {
                "nmcab": "BARRU",
                "WO": 165734824,
                "RUGI_TB": 165533987,
                "NCL": 0.97
            },
            {
                "nmcab": "WONOSOBO",
                "WO": 168609258,
                "RUGI_TB": 18237466,
                "NCL": 0.69
            },
            {
                "nmcab": "GRESIK",
                "WO": 169262041,
                "RUGI_TB": -1452512,
                "NCL": 1.63
            },
            {
                "nmcab": "PEKALONGAN",
                "WO": 171468799,
                "RUGI_TB": -2091491,
                "NCL": 1.9
            },
            {
                "nmcab": "TUGUMULYO",
                "WO": 172165890,
                "RUGI_TB": 22763954,
                "NCL": 1.21
            },
            {
                "nmcab": "SUMBAWA",
                "WO": 179226882,
                "RUGI_TB": 0,
                "NCL": 2.45
            },
            {
                "nmcab": "JAYAPURA",
                "WO": 185672554,
                "RUGI_TB": 89584442,
                "NCL": 1.58
            },
            {
                "nmcab": "BLANG PIDIE",
                "WO": 186803669,
                "RUGI_TB": 164161689,
                "NCL": 0.96
            },
            {
                "nmcab": "BABAT TOMAN",
                "WO": 193118650,
                "RUGI_TB": 23036130,
                "NCL": 1.31
            },
            {
                "nmcab": "PUNGGALUKU",
                "WO": 197741343,
                "RUGI_TB": 104770887,
                "NCL": 0.76
            },
            {
                "nmcab": "PURWOKERTO",
                "WO": 198837594,
                "RUGI_TB": 11736596,
                "NCL": 1.34
            },
            {
                "nmcab": "TENTENA",
                "WO": 200707548,
                "RUGI_TB": 23974583,
                "NCL": 0.61
            },
            {
                "nmcab": "PASANGKAYU",
                "WO": 200965733,
                "RUGI_TB": 126357573,
                "NCL": 0.66
            },
            {
                "nmcab": "TOLI TOLI",
                "WO": 202881884,
                "RUGI_TB": 61832010,
                "NCL": 0.84
            },
            {
                "nmcab": "BOROKO",
                "WO": 204296350,
                "RUGI_TB": 24767225,
                "NCL": 1.77
            },
            {
                "nmcab": "AMPANA",
                "WO": 209313113,
                "RUGI_TB": 53967622,
                "NCL": 0.87
            },
            {
                "nmcab": "LEUWILIANG",
                "WO": 212008952,
                "RUGI_TB": 52765269,
                "NCL": 0.64
            },
            {
                "nmcab": "JEMBER",
                "WO": 213816968,
                "RUGI_TB": -2011259,
                "NCL": 1.25
            },
            {
                "nmcab": "BOJONEGORO",
                "WO": 213996385,
                "RUGI_TB": -338429,
                "NCL": 3.46
            },
            {
                "nmcab": "TOMPE",
                "WO": 215913019,
                "RUGI_TB": 72822025,
                "NCL": 1.25
            },
            {
                "nmcab": "BULUKUMBA",
                "WO": 220338787,
                "RUGI_TB": 84322642,
                "NCL": 0.38
            },
            {
                "nmcab": "KEBUMEN",
                "WO": 223383405,
                "RUGI_TB": 5367339,
                "NCL": 2.51
            },
            {
                "nmcab": "WAY KANAN",
                "WO": 226307753,
                "RUGI_TB": 80314842,
                "NCL": 1.28
            },
            {
                "nmcab": "MOROWALI",
                "WO": 236460235,
                "RUGI_TB": 116454356,
                "NCL": 0.62
            },
            {
                "nmcab": "SIJUNGJUNG",
                "WO": 242887186,
                "RUGI_TB": 128842216,
                "NCL": 1.33
            },
            {
                "nmcab": "MENTOK",
                "WO": 247951140,
                "RUGI_TB": 94765847,
                "NCL": 1.52
            },
            {
                "nmcab": "PARUNG",
                "WO": 253197708,
                "RUGI_TB": 16935078,
                "NCL": 1.11
            },
            {
                "nmcab": "SOPPENG",
                "WO": 253705521,
                "RUGI_TB": 34262087,
                "NCL": 0.79
            },
            {
                "nmcab": "BELOPA",
                "WO": 256437138,
                "RUGI_TB": 242235138,
                "NCL": 0.88
            },
            {
                "nmcab": "PALANGKARAYA",
                "WO": 258027865,
                "RUGI_TB": 13366902,
                "NCL": 0.89
            },
            {
                "nmcab": "CIAWI",
                "WO": 258449511,
                "RUGI_TB": 11957058,
                "NCL": 1.71
            },
            {
                "nmcab": "LUBUKBASUNG",
                "WO": 264972428,
                "RUGI_TB": 75486762,
                "NCL": 1.7
            },
            {
                "nmcab": "JAILOLO",
                "WO": 265699179,
                "RUGI_TB": 240725244,
                "NCL": 0.77
            },
            {
                "nmcab": "TEMANGGUNG",
                "WO": 267480979,
                "RUGI_TB": -492098,
                "NCL": 0.9
            },
            {
                "nmcab": "BERAU",
                "WO": 268019221,
                "RUGI_TB": 54153962,
                "NCL": 0.59
            },
            {
                "nmcab": "POSO",
                "WO": 271275251,
                "RUGI_TB": 37291990,
                "NCL": 0.54
            },
            {
                "nmcab": "WAY JEPARA",
                "WO": 273910027,
                "RUGI_TB": 28943339,
                "NCL": 1.74
            },
            {
                "nmcab": "BATU SANGKAR",
                "WO": 274407346,
                "RUGI_TB": 171396668,
                "NCL": 1.82
            },
            {
                "nmcab": "PENAJAM",
                "WO": 288519772,
                "RUGI_TB": 31586581,
                "NCL": 2.28
            },
            {
                "nmcab": "SIGLI",
                "WO": 290209863,
                "RUGI_TB": 227746856,
                "NCL": 2.01
            },
            {
                "nmcab": "BANTAENG",
                "WO": 293432742,
                "RUGI_TB": 79831344,
                "NCL": 0.97
            },
            {
                "nmcab": "SAUMLAKI",
                "WO": 294425945,
                "RUGI_TB": 247559349,
                "NCL": 2.87
            },
            {
                "nmcab": "BUNTA",
                "WO": 303332048,
                "RUGI_TB": 35505921,
                "NCL": 1.02
            },
            {
                "nmcab": "SAMPIT",
                "WO": 305115168,
                "RUGI_TB": 41320966,
                "NCL": 1.46
            },
            {
                "nmcab": "TOILI",
                "WO": 308166971,
                "RUGI_TB": 99285071,
                "NCL": 0.94
            },
            {
                "nmcab": "BUNGKU",
                "WO": 314760125,
                "RUGI_TB": 31279723,
                "NCL": 0.38
            },
            {
                "nmcab": "LHOKSUKON",
                "WO": 323173829,
                "RUGI_TB": 99539129,
                "NCL": 2.03
            },
            {
                "nmcab": "MOJOKERTO",
                "WO": 324089279,
                "RUGI_TB": -96259,
                "NCL": 3.94
            },
            {
                "nmcab": "AMBON",
                "WO": 332936373,
                "RUGI_TB": 418945015,
                "NCL": 0.77
            },
            {
                "nmcab": "TUAL",
                "WO": 335210415,
                "RUGI_TB": -16413017,
                "NCL": 1.21
            },
            {
                "nmcab": "CILACAP",
                "WO": 335976509,
                "RUGI_TB": -5633900,
                "NCL": 2.01
            },
            {
                "nmcab": "BLITAR",
                "WO": 338862399,
                "RUGI_TB": 889384,
                "NCL": 1.81
            },
            {
                "nmcab": "MARISA",
                "WO": 342740340,
                "RUGI_TB": 68433883,
                "NCL": 0.95
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "WO": 345839722,
                "RUGI_TB": 48740789,
                "NCL": 1.62
            },
            {
                "nmcab": "BANDAR JAYA",
                "WO": 356185151,
                "RUGI_TB": 62696155,
                "NCL": 2.52
            },
            {
                "nmcab": "KASIPUTE",
                "WO": 360987629,
                "RUGI_TB": 65499852,
                "NCL": 1.23
            },
            {
                "nmcab": "BETUNG",
                "WO": 366925731,
                "RUGI_TB": 131118167,
                "NCL": 1.47
            },
            {
                "nmcab": "SUNGAI LILIN",
                "WO": 377208324,
                "RUGI_TB": 66057640,
                "NCL": 1.1
            },
            {
                "nmcab": "METRO",
                "WO": 391982976,
                "RUGI_TB": 73507475,
                "NCL": 1.71
            },
            {
                "nmcab": "BANGKALA",
                "WO": 397764344,
                "RUGI_TB": 122140363,
                "NCL": 1.19
            },
            {
                "nmcab": "TANAH GROGOT",
                "WO": 398605943,
                "RUGI_TB": 29608187,
                "NCL": 1.63
            },
            {
                "nmcab": "KAYU AGUNG",
                "WO": 398855732,
                "RUGI_TB": 29430560,
                "NCL": 2.61
            },
            {
                "nmcab": "UNAAHA",
                "WO": 408076383,
                "RUGI_TB": 146727223,
                "NCL": 1.15
            },
            {
                "nmcab": "BUKITTINGGI",
                "WO": 415950897,
                "RUGI_TB": 68259051,
                "NCL": 2.02
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "WO": 417046543,
                "RUGI_TB": 3703116,
                "NCL": 15.5
            },
            {
                "nmcab": "MASAMBA",
                "WO": 417438428,
                "RUGI_TB": 297202251,
                "NCL": 1.12
            },
            {
                "nmcab": "KOTARAYA",
                "WO": 432369937,
                "RUGI_TB": 244859865,
                "NCL": 1.9
            },
            {
                "nmcab": "PANGKEP",
                "WO": 436408276,
                "RUGI_TB": 123357374,
                "NCL": 1.11
            },
            {
                "nmcab": "SEKAYU",
                "WO": 438376894,
                "RUGI_TB": 6622472,
                "NCL": 3.73
            },
            {
                "nmcab": "SOLO",
                "WO": 439081190,
                "RUGI_TB": -166077,
                "NCL": 2.04
            },
            {
                "nmcab": "KOTABUMI",
                "WO": 441650024,
                "RUGI_TB": 39332934,
                "NCL": 2.84
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "WO": 442270119,
                "RUGI_TB": 65571880,
                "NCL": 2.98
            },
            {
                "nmcab": "PANTON LABU",
                "WO": 444054834,
                "RUGI_TB": 77893352,
                "NCL": 1.93
            },
            {
                "nmcab": "PRINGSEWU",
                "WO": 444975397,
                "RUGI_TB": 119297138,
                "NCL": 2.26
            },
            {
                "nmcab": "ACEH",
                "WO": 448942688,
                "RUGI_TB": 273728524,
                "NCL": 0.97
            },
            {
                "nmcab": "SERANG",
                "WO": 451188837,
                "RUGI_TB": 9007281,
                "NCL": 1.59
            },
            {
                "nmcab": "RUMBIA",
                "WO": 452467004,
                "RUGI_TB": 51862277,
                "NCL": 2.77
            },
            {
                "nmcab": "SANGATTA",
                "WO": 463776344,
                "RUGI_TB": 15576104,
                "NCL": 1.07
            },
            {
                "nmcab": "JENEPONTO",
                "WO": 469177233,
                "RUGI_TB": 94699048,
                "NCL": 0.8
            },
            {
                "nmcab": "BANGKO",
                "WO": 469398870,
                "RUGI_TB": 15156458,
                "NCL": 2.67
            },
            {
                "nmcab": "BOGOR",
                "WO": 480961528,
                "RUGI_TB": -6069743,
                "NCL": 1.34
            },
            {
                "nmcab": "SINJAI",
                "WO": 481692291,
                "RUGI_TB": 182778319,
                "NCL": 2.19
            },
            {
                "nmcab": "MALANG",
                "WO": 487425968,
                "RUGI_TB": 265397,
                "NCL": 3.16
            },
            {
                "nmcab": "IDIE",
                "WO": 489298423,
                "RUGI_TB": 139827904,
                "NCL": 0.78
            },
            {
                "nmcab": "RAHA",
                "WO": 493421695,
                "RUGI_TB": 112736389,
                "NCL": 1.46
            },
            {
                "nmcab": "SIDOARJO",
                "WO": 495471363,
                "RUGI_TB": -5118229,
                "NCL": 2.76
            },
            {
                "nmcab": "MAKALE",
                "WO": 499522281,
                "RUGI_TB": 342396784,
                "NCL": 1.7
            },
            {
                "nmcab": "SOLOK",
                "WO": 502647222,
                "RUGI_TB": 160788942,
                "NCL": 2.79
            },
            {
                "nmcab": "BAWEN",
                "WO": 510307502,
                "RUGI_TB": -2809493,
                "NCL": 2.05
            },
            {
                "nmcab": "MANOKWARI",
                "WO": 524311011,
                "RUGI_TB": 61453302,
                "NCL": 1.84
            },
            {
                "nmcab": "TEGAL",
                "WO": 530908697,
                "RUGI_TB": 12343421,
                "NCL": 3.18
            },
            {
                "nmcab": "TERNATE",
                "WO": 531421320,
                "RUGI_TB": 18835554,
                "NCL": 0.76
            },
            {
                "nmcab": "TAKENGON",
                "WO": 543592090,
                "RUGI_TB": 517502425,
                "NCL": 2.12
            },
            {
                "nmcab": "CIANJUR",
                "WO": 554775779,
                "RUGI_TB": 106917953,
                "NCL": 1.74
            },
            {
                "nmcab": "KOLAKA",
                "WO": 559414678,
                "RUGI_TB": 140273010,
                "NCL": 0.94
            },
            {
                "nmcab": "LADONGI",
                "WO": 563744482,
                "RUGI_TB": 72806122,
                "NCL": 2.39
            },
            {
                "nmcab": "SABAK",
                "WO": 567192858,
                "RUGI_TB": 22496760,
                "NCL": 3.99
            },
            {
                "nmcab": "TANGERANG",
                "WO": 568651502,
                "RUGI_TB": 68506898,
                "NCL": 1.43
            },
            {
                "nmcab": "BOALEMO",
                "WO": 574703586,
                "RUGI_TB": 110259547,
                "NCL": 1.84
            },
            {
                "nmcab": "KOTABARU",
                "WO": 585557144,
                "RUGI_TB": 138160637,
                "NCL": 2.98
            },
            {
                "nmcab": "BANJAR",
                "WO": 600710627,
                "RUGI_TB": 12512039,
                "NCL": 2.82
            },
            {
                "nmcab": "PARIGI",
                "WO": 600800580,
                "RUGI_TB": 141311876,
                "NCL": 1.66
            },
            {
                "nmcab": "MAMUJU",
                "WO": 614635788,
                "RUGI_TB": 326771243,
                "NCL": 2.35
            },
            {
                "nmcab": "KUNINGAN",
                "WO": 616279208,
                "RUGI_TB": 46933446,
                "NCL": 3.59
            },
            {
                "nmcab": "MUARA ENIM",
                "WO": 621179436,
                "RUGI_TB": 77288463,
                "NCL": 2.85
            },
            {
                "nmcab": "PASAMAN",
                "WO": 627261500,
                "RUGI_TB": 50108922,
                "NCL": 3.54
            },
            {
                "nmcab": "LIWA",
                "WO": 639722078,
                "RUGI_TB": 144990494,
                "NCL": 3.96
            },
            {
                "nmcab": "MARTAPURA KAL",
                "WO": 640027107,
                "RUGI_TB": 92706032,
                "NCL": 2.04
            },
            {
                "nmcab": "MALILI",
                "WO": 642108550,
                "RUGI_TB": 189116540,
                "NCL": 1.65
            },
            {
                "nmcab": "GOWA 2",
                "WO": 643629368,
                "RUGI_TB": 324780136,
                "NCL": 0.99
            },
            {
                "nmcab": "MASBAGIK",
                "WO": 673386770,
                "RUGI_TB": 7007210,
                "NCL": 2.93
            },
            {
                "nmcab": "CURUP",
                "WO": 678690281,
                "RUGI_TB": 63492437,
                "NCL": 4.93
            },
            {
                "nmcab": "NAGAN",
                "WO": 683082781,
                "RUGI_TB": 200332273,
                "NCL": 3.4
            },
            {
                "nmcab": "BIREUEN",
                "WO": 687320143,
                "RUGI_TB": 281484358,
                "NCL": 1.68
            },
            {
                "nmcab": "TAKALAR",
                "WO": 689488471,
                "RUGI_TB": 284062593,
                "NCL": 1.16
            },
            {
                "nmcab": "SAMARINDA",
                "WO": 694219818,
                "RUGI_TB": 102337566,
                "NCL": 1.8
            },
            {
                "nmcab": "KEDIRI",
                "WO": 698272256,
                "RUGI_TB": 30861108,
                "NCL": 4.66
            },
            {
                "nmcab": "PATI",
                "WO": 705751469,
                "RUGI_TB": -16854507,
                "NCL": 4.91
            },
            {
                "nmcab": "JAMBI",
                "WO": 719200550,
                "RUGI_TB": 150790025,
                "NCL": 3.37
            },
            {
                "nmcab": "BATURAJA",
                "WO": 720353324,
                "RUGI_TB": 93486074,
                "NCL": 5.67
            },
            {
                "nmcab": "TEBO",
                "WO": 721038450,
                "RUGI_TB": 13895454,
                "NCL": 5.56
            },
            {
                "nmcab": "PATROL",
                "WO": 728355121,
                "RUGI_TB": 11617349,
                "NCL": 3.85
            },
            {
                "nmcab": "TORAJA",
                "WO": 734211559,
                "RUGI_TB": 303515251,
                "NCL": 1.48
            },
            {
                "nmcab": "SENGKANG",
                "WO": 748651780,
                "RUGI_TB": 199293024,
                "NCL": 1.57
            },
            {
                "nmcab": "SEMARANG",
                "WO": 750172910,
                "RUGI_TB": -5470739,
                "NCL": 1.79
            },
            {
                "nmcab": "JATIBARANG",
                "WO": 760366600,
                "RUGI_TB": 46901821,
                "NCL": 2.9
            },
            {
                "nmcab": "PELABUHAN RATU",
                "WO": 766513594,
                "RUGI_TB": -2155104,
                "NCL": 2.34
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "WO": 771220073,
                "RUGI_TB": 9009265,
                "NCL": 3.49
            },
            {
                "nmcab": "BANGKA",
                "WO": 783347956,
                "RUGI_TB": 290915067,
                "NCL": 1.41
            },
            {
                "nmcab": "BENGKULU",
                "WO": 803273496,
                "RUGI_TB": 87771768,
                "NCL": 7.56
            },
            {
                "nmcab": "CIKARANG",
                "WO": 812527886,
                "RUGI_TB": 83882133,
                "NCL": 2.06
            },
            {
                "nmcab": "ARGA MAKMUR",
                "WO": 826911415,
                "RUGI_TB": 110059516,
                "NCL": 4.96
            },
            {
                "nmcab": "BUNGO",
                "WO": 828963867,
                "RUGI_TB": 51280763,
                "NCL": 5.52
            },
            {
                "nmcab": "BATU LICIN",
                "WO": 847756809,
                "RUGI_TB": 160555852,
                "NCL": 2.76
            },
            {
                "nmcab": "KOTA AGUNG",
                "WO": 862360130,
                "RUGI_TB": 102482461,
                "NCL": 6.41
            },
            {
                "nmcab": "CIREBON",
                "WO": 875502442,
                "RUGI_TB": 6772491,
                "NCL": 3.57
            },
            {
                "nmcab": "PARIAMAN",
                "WO": 878349775,
                "RUGI_TB": 61353055,
                "NCL": 3.65
            },
            {
                "nmcab": "SUMEDANG",
                "WO": 891229453,
                "RUGI_TB": 26047464,
                "NCL": 4.29
            },
            {
                "nmcab": "PRABUMULIH",
                "WO": 900276725,
                "RUGI_TB": 222309278,
                "NCL": 3.98
            },
            {
                "nmcab": "KOTA FAJAR",
                "WO": 915475376,
                "RUGI_TB": 451918272,
                "NCL": 2.38
            },
            {
                "nmcab": "MEULABOH",
                "WO": 918221290,
                "RUGI_TB": 328933190,
                "NCL": 1.78
            },
            {
                "nmcab": "KADIPATEN",
                "WO": 938805019,
                "RUGI_TB": -376965,
                "NCL": 3.65
            },
            {
                "nmcab": "PALOPO",
                "WO": 955149952,
                "RUGI_TB": 416867817,
                "NCL": 1.38
            },
            {
                "nmcab": "SUKABUMI",
                "WO": 972073368,
                "RUGI_TB": 164200074,
                "NCL": 3.97
            },
            {
                "nmcab": "MAJENE",
                "WO": 1000579883,
                "RUGI_TB": 185338558,
                "NCL": 4.02
            },
            {
                "nmcab": "PLEIHARI",
                "WO": 1017843055,
                "RUGI_TB": 43603355,
                "NCL": 4.36
            },
            {
                "nmcab": "CIBINONG",
                "WO": 1028613580,
                "RUGI_TB": 38838327,
                "NCL": 2.08
            },
            {
                "nmcab": "BALARAJA",
                "WO": 1030903097,
                "RUGI_TB": 8289303,
                "NCL": 3.94
            },
            {
                "nmcab": "BONE",
                "WO": 1037061155,
                "RUGI_TB": 164816560,
                "NCL": 1.71
            },
            {
                "nmcab": "BANJARAN",
                "WO": 1054191348,
                "RUGI_TB": 26274458,
                "NCL": 4.08
            },
            {
                "nmcab": "POLMAS",
                "WO": 1072952473,
                "RUGI_TB": 313369706,
                "NCL": 3.9
            },
            {
                "nmcab": "INDRALAYA",
                "WO": 1081235219,
                "RUGI_TB": 446599700,
                "NCL": 6.21
            },
            {
                "nmcab": "KALIANDA",
                "WO": 1082073802,
                "RUGI_TB": 127702796,
                "NCL": 3.12
            },
            {
                "nmcab": "CILEUNGSI",
                "WO": 1089215534,
                "RUGI_TB": 83439010,
                "NCL": 1.55
            },
            {
                "nmcab": "BANDUNG",
                "WO": 1100488346,
                "RUGI_TB": 19908346,
                "NCL": 3.59
            },
            {
                "nmcab": "SUBANG",
                "WO": 1104700858,
                "RUGI_TB": -35698382,
                "NCL": 5.64
            },
            {
                "nmcab": "KUALA SIMPANG",
                "WO": 1114478023,
                "RUGI_TB": 489348863,
                "NCL": 1.78
            },
            {
                "nmcab": "MUARA TEWEH",
                "WO": 1121261467,
                "RUGI_TB": 304260632,
                "NCL": 3.7
            },
            {
                "nmcab": "GOWA",
                "WO": 1153262151,
                "RUGI_TB": 509109053,
                "NCL": 1.33
            },
            {
                "nmcab": "TANJUNG",
                "WO": 1160731331,
                "RUGI_TB": 75414304,
                "NCL": 4.52
            },
            {
                "nmcab": "LAHAT",
                "WO": 1164255334,
                "RUGI_TB": 630727294,
                "NCL": 3.22
            },
            {
                "nmcab": "TASIKMALAYA",
                "WO": 1180173747,
                "RUGI_TB": 60112406,
                "NCL": 3.74
            },
            {
                "nmcab": "CILEDUG",
                "WO": 1195765872,
                "RUGI_TB": 38348745,
                "NCL": 4.07
            },
            {
                "nmcab": "CIMAHI",
                "WO": 1229571679,
                "RUGI_TB": 59127911,
                "NCL": 3.13
            },
            {
                "nmcab": "PURWAKARTA",
                "WO": 1245789996,
                "RUGI_TB": 46707868,
                "NCL": 3.27
            },
            {
                "nmcab": "PINRANG",
                "WO": 1321085142,
                "RUGI_TB": 345308631,
                "NCL": 2.65
            },
            {
                "nmcab": "PANGANDARAN",
                "WO": 1410463632,
                "RUGI_TB": 59040605,
                "NCL": 4.5
            },
            {
                "nmcab": "BINJAI",
                "WO": 1459420738,
                "RUGI_TB": 48973566,
                "NCL": 8.59
            },
            {
                "nmcab": "SIDRAP",
                "WO": 1459918189,
                "RUGI_TB": 88358188,
                "NCL": 2.31
            },
            {
                "nmcab": "JAMPANG",
                "WO": 1560445573,
                "RUGI_TB": -1477418,
                "NCL": 8.81
            },
            {
                "nmcab": "MAROS",
                "WO": 1604526336,
                "RUGI_TB": 402261603,
                "NCL": 2.27
            },
            {
                "nmcab": "KOTAMOBAGU",
                "WO": 1611644030,
                "RUGI_TB": 180301005,
                "NCL": 7.91
            },
            {
                "nmcab": "KARAWANG",
                "WO": 1663639752,
                "RUGI_TB": 100792647,
                "NCL": 2.38
            },
            {
                "nmcab": "PALU 2",
                "WO": 1702324905,
                "RUGI_TB": 966381344,
                "NCL": 2.61
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "WO": 1735139801,
                "RUGI_TB": 538584001,
                "NCL": 3.28
            },
            {
                "nmcab": "BALIKPAPAN",
                "WO": 1787389398,
                "RUGI_TB": 61083618,
                "NCL": 3.88
            },
            {
                "nmcab": "GARUT",
                "WO": 1827778876,
                "RUGI_TB": 38741915,
                "NCL": 4.92
            },
            {
                "nmcab": "PARUNGKUDA",
                "WO": 1839983232,
                "RUGI_TB": 134180854,
                "NCL": 5.11
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "WO": 1861051295,
                "RUGI_TB": 80651654,
                "NCL": 4.65
            },
            {
                "nmcab": "KOTOBARU",
                "WO": 1948192811,
                "RUGI_TB": 78003348,
                "NCL": 4.14
            },
            {
                "nmcab": "BARABAI",
                "WO": 2121590433,
                "RUGI_TB": 34557644,
                "NCL": 11.71
            },
            {
                "nmcab": "LUWUK",
                "WO": 2132963130,
                "RUGI_TB": 135224175,
                "NCL": 6.08
            },
            {
                "nmcab": "UJUNG BERUNG",
                "WO": 2238928313,
                "RUGI_TB": 34675047,
                "NCL": 9.8
            },
            {
                "nmcab": "BANJARMASIN",
                "WO": 2250928665,
                "RUGI_TB": 167533613,
                "NCL": 3.1
            },
            {
                "nmcab": "TOMOHON",
                "WO": 2266651377,
                "RUGI_TB": 41682045,
                "NCL": 11.65
            },
            {
                "nmcab": "PADANG",
                "WO": 2297691653,
                "RUGI_TB": 180909932,
                "NCL": 7.42
            },
            {
                "nmcab": "PARE-PARE",
                "WO": 2402926641,
                "RUGI_TB": 179270493,
                "NCL": 4.33
            },
            {
                "nmcab": "KENDARI",
                "WO": 2497295058,
                "RUGI_TB": 497996321,
                "NCL": 2.43
            },
            {
                "nmcab": "MAKASSAR 3",
                "WO": 2745098342,
                "RUGI_TB": 738136287,
                "NCL": 2.06
            },
            {
                "nmcab": "GORONTALO",
                "WO": 2822977325,
                "RUGI_TB": 361883756,
                "NCL": 3.94
            },
            {
                "nmcab": "RATAHAN",
                "WO": 3018239493,
                "RUGI_TB": 123193665,
                "NCL": 5.4
            },
            {
                "nmcab": "MAKASSAR",
                "WO": 3314321602,
                "RUGI_TB": 1465719110,
                "NCL": 2.78
            },
            {
                "nmcab": "MAKASSAR 2",
                "WO": 3406300715,
                "RUGI_TB": 755528614,
                "NCL": 2.76
            },
            {
                "nmcab": "PALU",
                "WO": 3574852726,
                "RUGI_TB": 1458001835,
                "NCL": 2.73
            },
            {
                "nmcab": "BEKASI",
                "WO": 3836739423,
                "RUGI_TB": 268126316,
                "NCL": 2.97
            },
            {
                "nmcab": "MEDAN",
                "WO": 4240206077,
                "RUGI_TB": 78989035,
                "NCL": 14.59
            },
            {
                "nmcab": "LAMPUNG",
                "WO": 4703783491,
                "RUGI_TB": 797200311,
                "NCL": 6.98
            },
            {
                "nmcab": "PEKANBARU",
                "WO": 4899067779,
                "RUGI_TB": 484313806,
                "NCL": 13.59
            },
            {
                "nmcab": "BITUNG",
                "WO": 5072013981,
                "RUGI_TB": 685130659,
                "NCL": 6.84
            },
            {
                "nmcab": "MANADO",
                "WO": 7952135779,
                "RUGI_TB": 523878810,
                "NCL": 9.54
            },
            {
                "nmcab": "PALEMBANG",
                "WO": 9425605723,
                "RUGI_TB": 1547379496,
                "NCL": 10.57
            }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableNclCabProdukRp').DataTable({
        "data":[
            {
                "nmcab": null,
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "ACEH",
                "nama_produk": "AISI",
                "WO": 406652129,
                "RUGI_TB": 268759314,
                "NCL": 1.21
            },
            {
                "nmcab": "ACEH",
                "nama_produk": "KPM",
                "WO": 2555888,
                "RUGI_TB": -7483146,
                "NCL": -0.1
            },
            {
                "nmcab": "ACEH",
                "nama_produk": "RETENTION",
                "WO": 39734671,
                "RUGI_TB": 12452356,
                "NCL": 0.39
            },
            {
                "nmcab": "ALUE BILIE",
                "nama_produk": "AISI",
                "WO": 18169690,
                "RUGI_TB": 6123496,
                "NCL": 0.18
            },
            {
                "nmcab": "ALUE BILIE",
                "nama_produk": "KPM",
                "WO": 2264617,
                "RUGI_TB": 148197,
                "NCL": 0.11
            },
            {
                "nmcab": "ALUE BILIE",
                "nama_produk": "RETENTION",
                "WO": 21388593,
                "RUGI_TB": 2025426,
                "NCL": 0.48
            },
            {
                "nmcab": "AMBON",
                "nama_produk": "AISI",
                "WO": 142139279,
                "RUGI_TB": 279994286,
                "NCL": 0.95
            },
            {
                "nmcab": "AMBON",
                "nama_produk": "KPM",
                "WO": 44127069,
                "RUGI_TB": 21087500,
                "NCL": 0.37
            },
            {
                "nmcab": "AMBON",
                "nama_produk": "RETENTION",
                "WO": 146670025,
                "RUGI_TB": 117863229,
                "NCL": 0.75
            },
            {
                "nmcab": "AMPANA",
                "nama_produk": "AISI",
                "WO": 160999249,
                "RUGI_TB": 55380407,
                "NCL": 1.33
            },
            {
                "nmcab": "AMPANA",
                "nama_produk": "KPM",
                "WO": 6757376,
                "RUGI_TB": -2310492,
                "NCL": 0.09
            },
            {
                "nmcab": "AMPANA",
                "nama_produk": "RETENTION",
                "WO": 41556488,
                "RUGI_TB": 897707,
                "NCL": 0.47
            },
            {
                "nmcab": "ARGA MAKMUR",
                "nama_produk": "AISI",
                "WO": 572168409,
                "RUGI_TB": 100782422,
                "NCL": 4.74
            },
            {
                "nmcab": "ARGA MAKMUR",
                "nama_produk": "KPM",
                "WO": 121023006,
                "RUGI_TB": 1507395,
                "NCL": 4.86
            },
            {
                "nmcab": "ARGA MAKMUR",
                "nama_produk": "RETENTION",
                "WO": 133720000,
                "RUGI_TB": 7769699,
                "NCL": 6.57
            },
            {
                "nmcab": "BABAT TOMAN",
                "nama_produk": "AISI",
                "WO": 158399714,
                "RUGI_TB": 18853844,
                "NCL": 1.42
            },
            {
                "nmcab": "BABAT TOMAN",
                "nama_produk": "KPM",
                "WO": 4459645,
                "RUGI_TB": 476134,
                "NCL": 0.34
            },
            {
                "nmcab": "BABAT TOMAN",
                "nama_produk": "RETENTION",
                "WO": 30259291,
                "RUGI_TB": 3706152,
                "NCL": 1.29
            },
            {
                "nmcab": "BACAN",
                "nama_produk": "AISI",
                "WO": 35061001,
                "RUGI_TB": 22580474,
                "NCL": 1.06
            },
            {
                "nmcab": "BACAN",
                "nama_produk": "KPM",
                "WO": 18861640,
                "RUGI_TB": -2076263,
                "NCL": 0.53
            },
            {
                "nmcab": "BACAN",
                "nama_produk": "RETENTION",
                "WO": 35379730,
                "RUGI_TB": 0,
                "NCL": 1.25
            },
            {
                "nmcab": "BALARAJA",
                "nama_produk": "AISI",
                "WO": 877710734,
                "RUGI_TB": 10469519,
                "NCL": 6.31
            },
            {
                "nmcab": "BALARAJA",
                "nama_produk": "KPM",
                "WO": 106914148,
                "RUGI_TB": 2179549,
                "NCL": 1.81
            },
            {
                "nmcab": "BALARAJA",
                "nama_produk": "RETENTION",
                "WO": 46278215,
                "RUGI_TB": -4359765,
                "NCL": 0.67
            },
            {
                "nmcab": "BALIKPAPAN",
                "nama_produk": "AISI",
                "WO": 1526828829,
                "RUGI_TB": 57884832,
                "NCL": 4.68
            },
            {
                "nmcab": "BALIKPAPAN",
                "nama_produk": "KPM",
                "WO": 58510457,
                "RUGI_TB": 1896537,
                "NCL": 1.34
            },
            {
                "nmcab": "BALIKPAPAN",
                "nama_produk": "RETENTION",
                "WO": 202050112,
                "RUGI_TB": 1302249,
                "NCL": 2.19
            },
            {
                "nmcab": "BANDAR JAYA",
                "nama_produk": "AISI",
                "WO": 280573696,
                "RUGI_TB": 66137651,
                "NCL": 3.49
            },
            {
                "nmcab": "BANDAR JAYA",
                "nama_produk": "KPM",
                "WO": 30698479,
                "RUGI_TB": -7100687,
                "NCL": 0.98
            },
            {
                "nmcab": "BANDAR JAYA",
                "nama_produk": "RETENTION",
                "WO": 44912976,
                "RUGI_TB": 3659191,
                "NCL": 1.14
            },
            {
                "nmcab": "BANDUNG",
                "nama_produk": "AISI",
                "WO": 588077038,
                "RUGI_TB": -3981576,
                "NCL": 4.92
            },
            {
                "nmcab": "BANDUNG",
                "nama_produk": "KPM",
                "WO": 189058323,
                "RUGI_TB": -7935690,
                "NCL": 2.53
            },
            {
                "nmcab": "BANDUNG",
                "nama_produk": "RETENTION",
                "WO": 323352985,
                "RUGI_TB": 31825612,
                "NCL": 2.91
            },
            {
                "nmcab": "BANGKA",
                "nama_produk": "AISI",
                "WO": 554229869,
                "RUGI_TB": 286263887,
                "NCL": 1.32
            },
            {
                "nmcab": "BANGKA",
                "nama_produk": "KPM",
                "WO": 83704344,
                "RUGI_TB": 1570124,
                "NCL": 1.55
            },
            {
                "nmcab": "BANGKA",
                "nama_produk": "RETENTION",
                "WO": 145413743,
                "RUGI_TB": 3081056,
                "NCL": 2.18
            },
            {
                "nmcab": "BANGKALA",
                "nama_produk": "AISI",
                "WO": 163613747,
                "RUGI_TB": 121793858,
                "NCL": 1.01
            },
            {
                "nmcab": "BANGKALA",
                "nama_produk": "KPM",
                "WO": 66096879,
                "RUGI_TB": -500124,
                "NCL": 1.22
            },
            {
                "nmcab": "BANGKALA",
                "nama_produk": "RETENTION",
                "WO": 168053718,
                "RUGI_TB": 846629,
                "NCL": 1.67
            },
            {
                "nmcab": "BANGKO",
                "nama_produk": "AISI",
                "WO": 231220615,
                "RUGI_TB": 23236109,
                "NCL": 2.28
            },
            {
                "nmcab": "BANGKO",
                "nama_produk": "KPM",
                "WO": 95773248,
                "RUGI_TB": -12382290,
                "NCL": 2.22
            },
            {
                "nmcab": "BANGKO",
                "nama_produk": "RETENTION",
                "WO": 142405007,
                "RUGI_TB": 4302639,
                "NCL": 4.51
            },
            {
                "nmcab": "BANJAR",
                "nama_produk": "AISI",
                "WO": 275924339,
                "RUGI_TB": 8393356,
                "NCL": 5.37
            },
            {
                "nmcab": "BANJAR",
                "nama_produk": "KPM",
                "WO": 144457832,
                "RUGI_TB": 3644769,
                "NCL": 2.11
            },
            {
                "nmcab": "BANJAR",
                "nama_produk": "RETENTION",
                "WO": 180328456,
                "RUGI_TB": 473914,
                "NCL": 1.91
            },
            {
                "nmcab": "BANJARAN",
                "nama_produk": "AISI",
                "WO": 645530683,
                "RUGI_TB": 18036279,
                "NCL": 7.95
            },
            {
                "nmcab": "BANJARAN",
                "nama_produk": "KPM",
                "WO": 222187145,
                "RUGI_TB": 3356365,
                "NCL": 3.11
            },
            {
                "nmcab": "BANJARAN",
                "nama_produk": "RETENTION",
                "WO": 186473520,
                "RUGI_TB": 4881814,
                "NCL": 1.76
            },
            {
                "nmcab": "BANJARMASIN",
                "nama_produk": "AISI",
                "WO": 1608397261,
                "RUGI_TB": 159883119,
                "NCL": 4.07
            },
            {
                "nmcab": "BANJARMASIN",
                "nama_produk": "KPM",
                "WO": 340737091,
                "RUGI_TB": -10264428,
                "NCL": 2.07
            },
            {
                "nmcab": "BANJARMASIN",
                "nama_produk": "RETENTION",
                "WO": 301794313,
                "RUGI_TB": 17914922,
                "NCL": 1.71
            },
            {
                "nmcab": "BANTAENG",
                "nama_produk": "AISI",
                "WO": 161981781,
                "RUGI_TB": 70159645,
                "NCL": 0.89
            },
            {
                "nmcab": "BANTAENG",
                "nama_produk": "KPM",
                "WO": 58271092,
                "RUGI_TB": -2062034,
                "NCL": 1.15
            },
            {
                "nmcab": "BANTAENG",
                "nama_produk": "RETENTION",
                "WO": 73179869,
                "RUGI_TB": 11733733,
                "NCL": 1.1
            },
            {
                "nmcab": "BARABAI",
                "nama_produk": "AISI",
                "WO": 1764498241,
                "RUGI_TB": 35672470,
                "NCL": 14.54
            },
            {
                "nmcab": "BARABAI",
                "nama_produk": "KPM",
                "WO": 175031114,
                "RUGI_TB": 0,
                "NCL": 6.19
            },
            {
                "nmcab": "BARABAI",
                "nama_produk": "RETENTION",
                "WO": 182061078,
                "RUGI_TB": -1114826,
                "NCL": 5.64
            },
            {
                "nmcab": "BARRU",
                "nama_produk": "AISI",
                "WO": 128841312,
                "RUGI_TB": 138395106,
                "NCL": 1.08
            },
            {
                "nmcab": "BARRU",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": -3486279,
                "NCL": -0.18
            },
            {
                "nmcab": "BARRU",
                "nama_produk": "RETENTION",
                "WO": 36893512,
                "RUGI_TB": 30625160,
                "NCL": 0.9
            },
            {
                "nmcab": "BATU LICIN",
                "nama_produk": "AISI",
                "WO": 633844953,
                "RUGI_TB": 145610153,
                "NCL": 3.42
            },
            {
                "nmcab": "BATU LICIN",
                "nama_produk": "KPM",
                "WO": 67577901,
                "RUGI_TB": -1049318,
                "NCL": 1.5
            },
            {
                "nmcab": "BATU LICIN",
                "nama_produk": "RETENTION",
                "WO": 146333955,
                "RUGI_TB": 15995017,
                "NCL": 1.75
            },
            {
                "nmcab": "BATU SANGKAR",
                "nama_produk": "AISI",
                "WO": 211482549,
                "RUGI_TB": 140814313,
                "NCL": 1.75
            },
            {
                "nmcab": "BATU SANGKAR",
                "nama_produk": "KPM",
                "WO": 44599233,
                "RUGI_TB": 6490924,
                "NCL": 4.6
            },
            {
                "nmcab": "BATU SANGKAR",
                "nama_produk": "RETENTION",
                "WO": 18325564,
                "RUGI_TB": 24091431,
                "NCL": 1.34
            },
            {
                "nmcab": "BATURAJA",
                "nama_produk": "AISI",
                "WO": 612986941,
                "RUGI_TB": 87759670,
                "NCL": 6.45
            },
            {
                "nmcab": "BATURAJA",
                "nama_produk": "KPM",
                "WO": 68943692,
                "RUGI_TB": 0,
                "NCL": 4.25
            },
            {
                "nmcab": "BATURAJA",
                "nama_produk": "RETENTION",
                "WO": 38422691,
                "RUGI_TB": 5726404,
                "NCL": 2.36
            },
            {
                "nmcab": "BAWEN",
                "nama_produk": "KPM",
                "WO": 323983350,
                "RUGI_TB": -7009280,
                "NCL": 1.95
            },
            {
                "nmcab": "BAWEN",
                "nama_produk": "RETENTION",
                "WO": 186324152,
                "RUGI_TB": 4199787,
                "NCL": 2.23
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "nama_produk": "AISI",
                "WO": 105546877,
                "RUGI_TB": 36517033,
                "NCL": 0.47
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "nama_produk": "KPM",
                "WO": 6185108,
                "RUGI_TB": 905369,
                "NCL": 0.12
            },
            {
                "nmcab": "BAYUNG LENCIR",
                "nama_produk": "RETENTION",
                "WO": 42689585,
                "RUGI_TB": -901768,
                "NCL": 0.36
            },
            {
                "nmcab": "BEKASI",
                "nama_produk": "AISI",
                "WO": 3322832202,
                "RUGI_TB": 267226066,
                "NCL": 4.98
            },
            {
                "nmcab": "BEKASI",
                "nama_produk": "KPM",
                "WO": 178564854,
                "RUGI_TB": -1743407,
                "NCL": 0.89
            },
            {
                "nmcab": "BEKASI",
                "nama_produk": "RETENTION",
                "WO": 335342367,
                "RUGI_TB": 2643657,
                "NCL": 0.73
            },
            {
                "nmcab": "BELINYU",
                "nama_produk": "AISI",
                "WO": 58549003,
                "RUGI_TB": 50820294,
                "NCL": 0.56
            },
            {
                "nmcab": "BELINYU",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": -1654626,
                "NCL": -0.08
            },
            {
                "nmcab": "BELINYU",
                "nama_produk": "RETENTION",
                "WO": 12389636,
                "RUGI_TB": 4803,
                "NCL": 0.8
            },
            {
                "nmcab": "BELITANG",
                "nama_produk": "AISI",
                "WO": 15987294,
                "RUGI_TB": 0,
                "NCL": 0.32
            },
            {
                "nmcab": "BELITANG",
                "nama_produk": "KPM",
                "WO": 4531549,
                "RUGI_TB": 0,
                "NCL": 0.27
            },
            {
                "nmcab": "BELITANG",
                "nama_produk": "RETENTION",
                "WO": 70961920,
                "RUGI_TB": 0,
                "NCL": 2.16
            },
            {
                "nmcab": "BELITUNG",
                "nama_produk": "AISI",
                "WO": 17127278,
                "RUGI_TB": 222086923,
                "NCL": 0.52
            },
            {
                "nmcab": "BELITUNG",
                "nama_produk": "KPM",
                "WO": 3896394,
                "RUGI_TB": 1086482,
                "NCL": 0.16
            },
            {
                "nmcab": "BELITUNG",
                "nama_produk": "RETENTION",
                "WO": 2064849,
                "RUGI_TB": -3866086,
                "NCL": -0.04
            },
            {
                "nmcab": "BELOPA",
                "nama_produk": "AISI",
                "WO": 222911776,
                "RUGI_TB": 248283859,
                "NCL": 1.04
            },
            {
                "nmcab": "BELOPA",
                "nama_produk": "KPM",
                "WO": 15842810,
                "RUGI_TB": -5622846,
                "NCL": 0.27
            },
            {
                "nmcab": "BELOPA",
                "nama_produk": "RETENTION",
                "WO": 17682552,
                "RUGI_TB": -425875,
                "NCL": 0.23
            },
            {
                "nmcab": "BELTIM",
                "nama_produk": "AISI",
                "WO": 57323115,
                "RUGI_TB": 157682089,
                "NCL": 0.84
            },
            {
                "nmcab": "BELTIM",
                "nama_produk": "KPM",
                "WO": 8321069,
                "RUGI_TB": 0,
                "NCL": 0.69
            },
            {
                "nmcab": "BELTIM",
                "nama_produk": "RETENTION",
                "WO": 13242125,
                "RUGI_TB": -4455758,
                "NCL": 0.63
            },
            {
                "nmcab": "BENGKULU",
                "nama_produk": "AISI",
                "WO": 672488378,
                "RUGI_TB": 84840694,
                "NCL": 9.34
            },
            {
                "nmcab": "BENGKULU",
                "nama_produk": "KPM",
                "WO": 47428295,
                "RUGI_TB": 0,
                "NCL": 3.27
            },
            {
                "nmcab": "BENGKULU",
                "nama_produk": "RETENTION",
                "WO": 83356823,
                "RUGI_TB": 2931074,
                "NCL": 3.87
            },
            {
                "nmcab": "BERAU",
                "nama_produk": "AISI",
                "WO": 160882273,
                "RUGI_TB": 31426643,
                "NCL": 0.8
            },
            {
                "nmcab": "BERAU",
                "nama_produk": "KPM",
                "WO": 13721625,
                "RUGI_TB": 54048,
                "NCL": 0.19
            },
            {
                "nmcab": "BERAU",
                "nama_produk": "RETENTION",
                "WO": 93415323,
                "RUGI_TB": 22673271,
                "NCL": 0.49
            },
            {
                "nmcab": "BETUNG",
                "nama_produk": "AISI",
                "WO": 322988985,
                "RUGI_TB": 134233844,
                "NCL": 1.52
            },
            {
                "nmcab": "BETUNG",
                "nama_produk": "KPM",
                "WO": 4726662,
                "RUGI_TB": -4663677,
                "NCL": 0
            },
            {
                "nmcab": "BETUNG",
                "nama_produk": "RETENTION",
                "WO": 39210084,
                "RUGI_TB": 1548000,
                "NCL": 2.34
            },
            {
                "nmcab": "BINJAI",
                "nama_produk": "AISI",
                "WO": 1004701085,
                "RUGI_TB": 44474027,
                "NCL": 8.91
            },
            {
                "nmcab": "BINJAI",
                "nama_produk": "KPM",
                "WO": 382545931,
                "RUGI_TB": 3803952,
                "NCL": 8.83
            },
            {
                "nmcab": "BINJAI",
                "nama_produk": "RETENTION",
                "WO": 72173722,
                "RUGI_TB": 695587,
                "NCL": 5.14
            },
            {
                "nmcab": "BIREUEN",
                "nama_produk": "AISI",
                "WO": 618998343,
                "RUGI_TB": 271873892,
                "NCL": 1.86
            },
            {
                "nmcab": "BIREUEN",
                "nama_produk": "KPM",
                "WO": 35211139,
                "RUGI_TB": -280970,
                "NCL": 0.83
            },
            {
                "nmcab": "BIREUEN",
                "nama_produk": "RETENTION",
                "WO": 33110661,
                "RUGI_TB": 9891436,
                "NCL": 0.78
            },
            {
                "nmcab": "BITUNG",
                "nama_produk": "AISI",
                "WO": 3872228833,
                "RUGI_TB": 532041688,
                "NCL": 7.8
            },
            {
                "nmcab": "BITUNG",
                "nama_produk": "KPM",
                "WO": 249644388,
                "RUGI_TB": 19255535,
                "NCL": 3.09
            },
            {
                "nmcab": "BITUNG",
                "nama_produk": "RETENTION",
                "WO": 950140760,
                "RUGI_TB": 133833436,
                "NCL": 5.71
            },
            {
                "nmcab": "BLANG PIDIE",
                "nama_produk": "AISI",
                "WO": 115749258,
                "RUGI_TB": 119667257,
                "NCL": 0.96
            },
            {
                "nmcab": "BLANG PIDIE",
                "nama_produk": "KPM",
                "WO": 11430266,
                "RUGI_TB": 472415,
                "NCL": 0.3
            },
            {
                "nmcab": "BLANG PIDIE",
                "nama_produk": "RETENTION",
                "WO": 59624145,
                "RUGI_TB": 44022017,
                "NCL": 1.24
            },
            {
                "nmcab": "BLITAR",
                "nama_produk": "KPM",
                "WO": 152556795,
                "RUGI_TB": -1933978,
                "NCL": 1.29
            },
            {
                "nmcab": "BLITAR",
                "nama_produk": "RETENTION",
                "WO": 186305604,
                "RUGI_TB": 2823362,
                "NCL": 2.67
            },
            {
                "nmcab": "BOALEMO",
                "nama_produk": "AISI",
                "WO": 445970641,
                "RUGI_TB": 108853336,
                "NCL": 2.69
            },
            {
                "nmcab": "BOALEMO",
                "nama_produk": "KPM",
                "WO": 33150145,
                "RUGI_TB": -6351394,
                "NCL": 0.43
            },
            {
                "nmcab": "BOALEMO",
                "nama_produk": "RETENTION",
                "WO": 95582800,
                "RUGI_TB": 7757605,
                "NCL": 1.01
            },
            {
                "nmcab": "BOEPINANG",
                "nama_produk": "AISI",
                "WO": 77982086,
                "RUGI_TB": 28541065,
                "NCL": 0.59
            },
            {
                "nmcab": "BOEPINANG",
                "nama_produk": "KPM",
                "WO": 40411687,
                "RUGI_TB": -3655505,
                "NCL": 1.06
            },
            {
                "nmcab": "BOEPINANG",
                "nama_produk": "RETENTION",
                "WO": 2848727,
                "RUGI_TB": -710377,
                "NCL": 0.04
            },
            {
                "nmcab": "BOGOR",
                "nama_produk": "AISI",
                "WO": 332582737,
                "RUGI_TB": 14809835,
                "NCL": 3.72
            },
            {
                "nmcab": "BOGOR",
                "nama_produk": "KPM",
                "WO": 60475748,
                "RUGI_TB": -8156916,
                "NCL": 0.43
            },
            {
                "nmcab": "BOGOR",
                "nama_produk": "RETENTION",
                "WO": 87903043,
                "RUGI_TB": -12722662,
                "NCL": 0.53
            },
            {
                "nmcab": "BOJONEGORO",
                "nama_produk": "KPM",
                "WO": 146347410,
                "RUGI_TB": 0,
                "NCL": 4.49
            },
            {
                "nmcab": "BOJONEGORO",
                "nama_produk": "RETENTION",
                "WO": 67648975,
                "RUGI_TB": -338429,
                "NCL": 2.31
            },
            {
                "nmcab": "BONE",
                "nama_produk": "AISI",
                "WO": 738946692,
                "RUGI_TB": 141788188,
                "NCL": 1.71
            },
            {
                "nmcab": "BONE",
                "nama_produk": "KPM",
                "WO": 162820150,
                "RUGI_TB": 5867612,
                "NCL": 2.67
            },
            {
                "nmcab": "BONE",
                "nama_produk": "RETENTION",
                "WO": 135294313,
                "RUGI_TB": 17160760,
                "NCL": 1.22
            },
            {
                "nmcab": "BOROKO",
                "nama_produk": "AISI",
                "WO": 88916931,
                "RUGI_TB": 26609091,
                "NCL": 1.47
            },
            {
                "nmcab": "BOROKO",
                "nama_produk": "KPM",
                "WO": 41870533,
                "RUGI_TB": -1841866,
                "NCL": 1.62
            },
            {
                "nmcab": "BOROKO",
                "nama_produk": "RETENTION",
                "WO": 73508886,
                "RUGI_TB": 0,
                "NCL": 2.83
            },
            {
                "nmcab": "BOYOLALI",
                "nama_produk": "KPM",
                "WO": 15932376,
                "RUGI_TB": -1370099,
                "NCL": 0.2
            },
            {
                "nmcab": "BOYOLALI",
                "nama_produk": "RETENTION",
                "WO": 43402809,
                "RUGI_TB": -6971618,
                "NCL": 0.43
            },
            {
                "nmcab": "BUKITTINGGI",
                "nama_produk": "AISI",
                "WO": 285988008,
                "RUGI_TB": 65825311,
                "NCL": 1.94
            },
            {
                "nmcab": "BUKITTINGGI",
                "nama_produk": "KPM",
                "WO": 29865787,
                "RUGI_TB": 1753220,
                "NCL": 1.9
            },
            {
                "nmcab": "BUKITTINGGI",
                "nama_produk": "RETENTION",
                "WO": 100097102,
                "RUGI_TB": 680520,
                "NCL": 2.43
            },
            {
                "nmcab": "BULI",
                "nama_produk": "AISI",
                "WO": 24563539,
                "RUGI_TB": 0,
                "NCL": 2.88
            },
            {
                "nmcab": "BULI",
                "nama_produk": "KPM",
                "WO": 46475194,
                "RUGI_TB": 0,
                "NCL": 12.16
            },
            {
                "nmcab": "BULI",
                "nama_produk": "RETENTION",
                "WO": 36810693,
                "RUGI_TB": 0,
                "NCL": 13.34
            },
            {
                "nmcab": "BULUKUMBA",
                "nama_produk": "AISI",
                "WO": 167288768,
                "RUGI_TB": 81849253,
                "NCL": 0.4
            },
            {
                "nmcab": "BULUKUMBA",
                "nama_produk": "KPM",
                "WO": 9784253,
                "RUGI_TB": -195605,
                "NCL": 0.31
            },
            {
                "nmcab": "BULUKUMBA",
                "nama_produk": "RETENTION",
                "WO": 43265766,
                "RUGI_TB": 2668994,
                "NCL": 0.31
            },
            {
                "nmcab": "BUNGKU",
                "nama_produk": "AISI",
                "WO": 240983502,
                "RUGI_TB": 28570243,
                "NCL": 0.46
            },
            {
                "nmcab": "BUNGKU",
                "nama_produk": "KPM",
                "WO": 33895710,
                "RUGI_TB": 1589440,
                "NCL": 0.23
            },
            {
                "nmcab": "BUNGKU",
                "nama_produk": "RETENTION",
                "WO": 39880913,
                "RUGI_TB": 1120040,
                "NCL": 0.24
            },
            {
                "nmcab": "BUNGO",
                "nama_produk": "AISI",
                "WO": 480037393,
                "RUGI_TB": 50026348,
                "NCL": 4.45
            },
            {
                "nmcab": "BUNGO",
                "nama_produk": "KPM",
                "WO": 192762841,
                "RUGI_TB": 1254415,
                "NCL": 7.45
            },
            {
                "nmcab": "BUNGO",
                "nama_produk": "RETENTION",
                "WO": 156163633,
                "RUGI_TB": 0,
                "NCL": 11.06
            },
            {
                "nmcab": "BUNTA",
                "nama_produk": "AISI",
                "WO": 187061818,
                "RUGI_TB": 28577643,
                "NCL": 1.2
            },
            {
                "nmcab": "BUNTA",
                "nama_produk": "KPM",
                "WO": 35218191,
                "RUGI_TB": 6355674,
                "NCL": 0.69
            },
            {
                "nmcab": "BUNTA",
                "nama_produk": "RETENTION",
                "WO": 81052039,
                "RUGI_TB": 572604,
                "NCL": 0.88
            },
            {
                "nmcab": "BUOL",
                "nama_produk": "AISI",
                "WO": 63246400,
                "RUGI_TB": 97158622,
                "NCL": 0.7
            },
            {
                "nmcab": "BUOL",
                "nama_produk": "KPM",
                "WO": 12666345,
                "RUGI_TB": 2743132,
                "NCL": 0.21
            },
            {
                "nmcab": "BUOL",
                "nama_produk": "RETENTION",
                "WO": 29002712,
                "RUGI_TB": 801905,
                "NCL": 0.28
            },
            {
                "nmcab": "BUTON",
                "nama_produk": "AISI",
                "WO": 79546417,
                "RUGI_TB": 69787846,
                "NCL": 0.32
            },
            {
                "nmcab": "BUTON",
                "nama_produk": "KPM",
                "WO": 18514915,
                "RUGI_TB": 3632504,
                "NCL": 0.23
            },
            {
                "nmcab": "BUTON",
                "nama_produk": "RETENTION",
                "WO": 42703481,
                "RUGI_TB": 12081259,
                "NCL": 0.28
            },
            {
                "nmcab": "CIANJUR",
                "nama_produk": "AISI",
                "WO": 242942721,
                "RUGI_TB": 11629382,
                "NCL": 4.32
            },
            {
                "nmcab": "CIANJUR",
                "nama_produk": "KPM",
                "WO": 129028272,
                "RUGI_TB": 6623150,
                "NCL": 0.95
            },
            {
                "nmcab": "CIANJUR",
                "nama_produk": "RETENTION",
                "WO": 182804786,
                "RUGI_TB": 88665421,
                "NCL": 1.52
            },
            {
                "nmcab": "CIAWI",
                "nama_produk": "AISI",
                "WO": 85493412,
                "RUGI_TB": 7810272,
                "NCL": 6.4
            },
            {
                "nmcab": "CIAWI",
                "nama_produk": "KPM",
                "WO": 81963589,
                "RUGI_TB": 1956647,
                "NCL": 1.68
            },
            {
                "nmcab": "CIAWI",
                "nama_produk": "RETENTION",
                "WO": 90992510,
                "RUGI_TB": 2190139,
                "NCL": 0.99
            },
            {
                "nmcab": "CIBINONG",
                "nama_produk": "AISI",
                "WO": 884591422,
                "RUGI_TB": 24547486,
                "NCL": 4.59
            },
            {
                "nmcab": "CIBINONG",
                "nama_produk": "KPM",
                "WO": 70633800,
                "RUGI_TB": 6254516,
                "NCL": 0.47
            },
            {
                "nmcab": "CIBINONG",
                "nama_produk": "RETENTION",
                "WO": 73388358,
                "RUGI_TB": 8036325,
                "NCL": 0.54
            },
            {
                "nmcab": "CIKARANG",
                "nama_produk": "AISI",
                "WO": 726773063,
                "RUGI_TB": 86536062,
                "NCL": 3.1
            },
            {
                "nmcab": "CIKARANG",
                "nama_produk": "KPM",
                "WO": 76739760,
                "RUGI_TB": -2806187,
                "NCL": 0.9
            },
            {
                "nmcab": "CIKARANG",
                "nama_produk": "RETENTION",
                "WO": 9015063,
                "RUGI_TB": 152258,
                "NCL": 0.1
            },
            {
                "nmcab": "CILACAP",
                "nama_produk": "KPM",
                "WO": 172747897,
                "RUGI_TB": -7341866,
                "NCL": 1.89
            },
            {
                "nmcab": "CILACAP",
                "nama_produk": "RETENTION",
                "WO": 163228612,
                "RUGI_TB": 1707966,
                "NCL": 2.15
            },
            {
                "nmcab": "CILEDUG",
                "nama_produk": "AISI",
                "WO": 992233480,
                "RUGI_TB": 39833549,
                "NCL": 7.5
            },
            {
                "nmcab": "CILEDUG",
                "nama_produk": "KPM",
                "WO": 57298573,
                "RUGI_TB": -8926036,
                "NCL": 0.94
            },
            {
                "nmcab": "CILEDUG",
                "nama_produk": "RETENTION",
                "WO": 146233819,
                "RUGI_TB": 7441232,
                "NCL": 1.35
            },
            {
                "nmcab": "CILEUNGSI",
                "nama_produk": "AISI",
                "WO": 1060720715,
                "RUGI_TB": 116732792,
                "NCL": 2.28
            },
            {
                "nmcab": "CILEUNGSI",
                "nama_produk": "KPM",
                "WO": 22855471,
                "RUGI_TB": -19907765,
                "NCL": 0.03
            },
            {
                "nmcab": "CILEUNGSI",
                "nama_produk": "RETENTION",
                "WO": 5639348,
                "RUGI_TB": -13386017,
                "NCL": -0.06
            },
            {
                "nmcab": "CIMAHI",
                "nama_produk": "AISI",
                "WO": 567774792,
                "RUGI_TB": 20955574,
                "NCL": 4.25
            },
            {
                "nmcab": "CIMAHI",
                "nama_produk": "KPM",
                "WO": 315401965,
                "RUGI_TB": 22164398,
                "NCL": 2.26
            },
            {
                "nmcab": "CIMAHI",
                "nama_produk": "RETENTION",
                "WO": 346394922,
                "RUGI_TB": 16007939,
                "NCL": 2.93
            },
            {
                "nmcab": "CIREBON",
                "nama_produk": "AISI",
                "WO": 565317191,
                "RUGI_TB": 29668359,
                "NCL": 6.06
            },
            {
                "nmcab": "CIREBON",
                "nama_produk": "KPM",
                "WO": 138110534,
                "RUGI_TB": -15695939,
                "NCL": 1.69
            },
            {
                "nmcab": "CIREBON",
                "nama_produk": "RETENTION",
                "WO": 172074717,
                "RUGI_TB": -7199929,
                "NCL": 2.15
            },
            {
                "nmcab": "CURUP",
                "nama_produk": "AISI",
                "WO": 591040341,
                "RUGI_TB": 57998718,
                "NCL": 6.26
            },
            {
                "nmcab": "CURUP",
                "nama_produk": "KPM",
                "WO": 19461879,
                "RUGI_TB": 0,
                "NCL": 1.51
            },
            {
                "nmcab": "CURUP",
                "nama_produk": "RETENTION",
                "WO": 68188061,
                "RUGI_TB": 5493719,
                "NCL": 2.16
            },
            {
                "nmcab": "DAYA MURNI",
                "nama_produk": "AISI",
                "WO": 67510071,
                "RUGI_TB": 12352601,
                "NCL": 1.33
            },
            {
                "nmcab": "DAYA MURNI",
                "nama_produk": "KPM",
                "WO": 31506380,
                "RUGI_TB": -3537647,
                "NCL": 1.3
            },
            {
                "nmcab": "DAYA MURNI",
                "nama_produk": "RETENTION",
                "WO": 19086278,
                "RUGI_TB": 0,
                "NCL": 0.74
            },
            {
                "nmcab": "DOMPU",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "DOMPU",
                "nama_produk": "RETENTION",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "DONGGALA",
                "nama_produk": "AISI",
                "WO": 117351841,
                "RUGI_TB": 235231118,
                "NCL": 1.07
            },
            {
                "nmcab": "DONGGALA",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 5926201,
                "NCL": 0.11
            },
            {
                "nmcab": "DONGGALA",
                "nama_produk": "RETENTION",
                "WO": 0,
                "RUGI_TB": 930502,
                "NCL": 0.02
            },
            {
                "nmcab": "ENDE",
                "nama_produk": "AISI",
                "WO": 3670308,
                "RUGI_TB": 0,
                "NCL": 0.81
            },
            {
                "nmcab": "ENDE",
                "nama_produk": "KPM",
                "WO": 41059943,
                "RUGI_TB": -775040,
                "NCL": 1.12
            },
            {
                "nmcab": "ENDE",
                "nama_produk": "RETENTION",
                "WO": 27235006,
                "RUGI_TB": 3472055,
                "NCL": 1.3
            },
            {
                "nmcab": "ENREKANG",
                "nama_produk": "AISI",
                "WO": 84028397,
                "RUGI_TB": 59700442,
                "NCL": 0.72
            },
            {
                "nmcab": "ENREKANG",
                "nama_produk": "KPM",
                "WO": 4857717,
                "RUGI_TB": 0,
                "NCL": 0.32
            },
            {
                "nmcab": "ENREKANG",
                "nama_produk": "RETENTION",
                "WO": 43605931,
                "RUGI_TB": 10018294,
                "NCL": 0.97
            },
            {
                "nmcab": "EREKE",
                "nama_produk": "AISI",
                "WO": 40217860,
                "RUGI_TB": 1866851,
                "NCL": 0.35
            },
            {
                "nmcab": "EREKE",
                "nama_produk": "KPM",
                "WO": 11049609,
                "RUGI_TB": -2661440,
                "NCL": 0.33
            },
            {
                "nmcab": "EREKE",
                "nama_produk": "RETENTION",
                "WO": 0,
                "RUGI_TB": 7551032,
                "NCL": 0.14
            },
            {
                "nmcab": "GARUT",
                "nama_produk": "AISI",
                "WO": 869085350,
                "RUGI_TB": 4579896,
                "NCL": 7.6
            },
            {
                "nmcab": "GARUT",
                "nama_produk": "KPM",
                "WO": 549948616,
                "RUGI_TB": 1110615,
                "NCL": 4.05
            },
            {
                "nmcab": "GARUT",
                "nama_produk": "RETENTION",
                "WO": 408744910,
                "RUGI_TB": 33051404,
                "NCL": 3.44
            },
            {
                "nmcab": "GORONTALO",
                "nama_produk": "AISI",
                "WO": 2096762382,
                "RUGI_TB": 252662912,
                "NCL": 5.76
            },
            {
                "nmcab": "GORONTALO",
                "nama_produk": "KPM",
                "WO": 249363559,
                "RUGI_TB": 44269264,
                "NCL": 1.52
            },
            {
                "nmcab": "GORONTALO",
                "nama_produk": "RETENTION",
                "WO": 476851384,
                "RUGI_TB": 64951580,
                "NCL": 2.61
            },
            {
                "nmcab": "GOWA",
                "nama_produk": "AISI",
                "WO": 848148925,
                "RUGI_TB": 432740281,
                "NCL": 1.5
            },
            {
                "nmcab": "GOWA",
                "nama_produk": "KPM",
                "WO": 65561111,
                "RUGI_TB": -3402644,
                "NCL": 0.47
            },
            {
                "nmcab": "GOWA",
                "nama_produk": "RETENTION",
                "WO": 239552115,
                "RUGI_TB": 79771416,
                "NCL": 1.21
            },
            {
                "nmcab": "GOWA 2",
                "nama_produk": "AISI",
                "WO": 528598962,
                "RUGI_TB": 292459239,
                "NCL": 1.19
            },
            {
                "nmcab": "GOWA 2",
                "nama_produk": "KPM",
                "WO": 42951419,
                "RUGI_TB": 9773045,
                "NCL": 0.71
            },
            {
                "nmcab": "GOWA 2",
                "nama_produk": "RETENTION",
                "WO": 72078987,
                "RUGI_TB": 22547852,
                "NCL": 0.45
            },
            {
                "nmcab": "GRESIK",
                "nama_produk": "KPM",
                "WO": 53740639,
                "RUGI_TB": 0,
                "NCL": 1.02
            },
            {
                "nmcab": "GRESIK",
                "nama_produk": "RETENTION",
                "WO": 115521402,
                "RUGI_TB": -1452512,
                "NCL": 2.28
            },
            {
                "nmcab": "IDIE",
                "nama_produk": "AISI",
                "WO": 446969917,
                "RUGI_TB": 156467861,
                "NCL": 0.87
            },
            {
                "nmcab": "IDIE",
                "nama_produk": "KPM",
                "WO": 8361595,
                "RUGI_TB": -10308640,
                "NCL": -0.06
            },
            {
                "nmcab": "IDIE",
                "nama_produk": "RETENTION",
                "WO": 33966911,
                "RUGI_TB": -6331317,
                "NCL": 0.39
            },
            {
                "nmcab": "INDRALAYA",
                "nama_produk": "AISI",
                "WO": 789193435,
                "RUGI_TB": 421483586,
                "NCL": 7.04
            },
            {
                "nmcab": "INDRALAYA",
                "nama_produk": "KPM",
                "WO": 163089824,
                "RUGI_TB": 8807794,
                "NCL": 4.66
            },
            {
                "nmcab": "INDRALAYA",
                "nama_produk": "RETENTION",
                "WO": 128951960,
                "RUGI_TB": 16308320,
                "NCL": 3.94
            },
            {
                "nmcab": "JAILOLO",
                "nama_produk": "AISI",
                "WO": 222539190,
                "RUGI_TB": 207494919,
                "NCL": 0.95
            },
            {
                "nmcab": "JAILOLO",
                "nama_produk": "KPM",
                "WO": 17383391,
                "RUGI_TB": 1362391,
                "NCL": 0.21
            },
            {
                "nmcab": "JAILOLO",
                "nama_produk": "RETENTION",
                "WO": 25776598,
                "RUGI_TB": 31867934,
                "NCL": 0.49
            },
            {
                "nmcab": "JAMBI",
                "nama_produk": "AISI",
                "WO": 614272161,
                "RUGI_TB": 146181678,
                "NCL": 4.06
            },
            {
                "nmcab": "JAMBI",
                "nama_produk": "KPM",
                "WO": 35115783,
                "RUGI_TB": 5496429,
                "NCL": 1.05
            },
            {
                "nmcab": "JAMBI",
                "nama_produk": "RETENTION",
                "WO": 69812606,
                "RUGI_TB": -888082,
                "NCL": 2.15
            },
            {
                "nmcab": "JAMPANG",
                "nama_produk": "AISI",
                "WO": 1454724141,
                "RUGI_TB": -9239774,
                "NCL": 12.35
            },
            {
                "nmcab": "JAMPANG",
                "nama_produk": "KPM",
                "WO": 53174827,
                "RUGI_TB": 3760350,
                "NCL": 1.56
            },
            {
                "nmcab": "JAMPANG",
                "nama_produk": "RETENTION",
                "WO": 52546605,
                "RUGI_TB": 4002006,
                "NCL": 2.43
            },
            {
                "nmcab": "JATIBARANG",
                "nama_produk": "AISI",
                "WO": 565106192,
                "RUGI_TB": 38978382,
                "NCL": 4.83
            },
            {
                "nmcab": "JATIBARANG",
                "nama_produk": "KPM",
                "WO": 108182860,
                "RUGI_TB": 5784489,
                "NCL": 1.93
            },
            {
                "nmcab": "JATIBARANG",
                "nama_produk": "RETENTION",
                "WO": 87077548,
                "RUGI_TB": 2138950,
                "NCL": 0.94
            },
            {
                "nmcab": "JAYAPURA",
                "nama_produk": "AISI",
                "WO": 155429618,
                "RUGI_TB": 93028682,
                "NCL": 1.6
            },
            {
                "nmcab": "JAYAPURA",
                "nama_produk": "KPM",
                "WO": 17516590,
                "RUGI_TB": -3444240,
                "NCL": 1.54
            },
            {
                "nmcab": "JAYAPURA",
                "nama_produk": "RETENTION",
                "WO": 12726346,
                "RUGI_TB": 0,
                "NCL": 1.25
            },
            {
                "nmcab": "JEBUS",
                "nama_produk": "AISI",
                "WO": 102107150,
                "RUGI_TB": 16872089,
                "NCL": 1.3
            },
            {
                "nmcab": "JEBUS",
                "nama_produk": "KPM",
                "WO": 38366673,
                "RUGI_TB": 2361217,
                "NCL": 1.79
            },
            {
                "nmcab": "JEBUS",
                "nama_produk": "RETENTION",
                "WO": 21411181,
                "RUGI_TB": 143141,
                "NCL": 1.34
            },
            {
                "nmcab": "JEMBER",
                "nama_produk": "KPM",
                "WO": 133264066,
                "RUGI_TB": -2011259,
                "NCL": 1.1
            },
            {
                "nmcab": "JEMBER",
                "nama_produk": "RETENTION",
                "WO": 80552902,
                "RUGI_TB": 0,
                "NCL": 1.64
            },
            {
                "nmcab": "JENEPONTO",
                "nama_produk": "AISI",
                "WO": 284442299,
                "RUGI_TB": 79260528,
                "NCL": 0.89
            },
            {
                "nmcab": "JENEPONTO",
                "nama_produk": "KPM",
                "WO": 50324091,
                "RUGI_TB": -1015831,
                "NCL": 0.5
            },
            {
                "nmcab": "JENEPONTO",
                "nama_produk": "RETENTION",
                "WO": 134410843,
                "RUGI_TB": 16454351,
                "NCL": 0.76
            },
            {
                "nmcab": "KADIPATEN",
                "nama_produk": "AISI",
                "WO": 576913284,
                "RUGI_TB": 2953556,
                "NCL": 4.79
            },
            {
                "nmcab": "KADIPATEN",
                "nama_produk": "KPM",
                "WO": 221784814,
                "RUGI_TB": 290111,
                "NCL": 3.34
            },
            {
                "nmcab": "KADIPATEN",
                "nama_produk": "RETENTION",
                "WO": 140106921,
                "RUGI_TB": -3620632,
                "NCL": 1.97
            },
            {
                "nmcab": "KALIANDA",
                "nama_produk": "AISI",
                "WO": 885317790,
                "RUGI_TB": 119921059,
                "NCL": 3.66
            },
            {
                "nmcab": "KALIANDA",
                "nama_produk": "KPM",
                "WO": 106990875,
                "RUGI_TB": 2569303,
                "NCL": 2.27
            },
            {
                "nmcab": "KALIANDA",
                "nama_produk": "RETENTION",
                "WO": 89765137,
                "RUGI_TB": 5212434,
                "NCL": 1.48
            },
            {
                "nmcab": "KAPUAS",
                "nama_produk": "AISI",
                "WO": 12484919,
                "RUGI_TB": 9419717,
                "NCL": 0.73
            },
            {
                "nmcab": "KAPUAS",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "KAPUAS",
                "nama_produk": "RETENTION",
                "WO": 5179699,
                "RUGI_TB": 216429,
                "NCL": 0.28
            },
            {
                "nmcab": "KARANGANYAR",
                "nama_produk": "KPM",
                "WO": 37257679,
                "RUGI_TB": -3442803,
                "NCL": 0.45
            },
            {
                "nmcab": "KARANGANYAR",
                "nama_produk": "RETENTION",
                "WO": 44065472,
                "RUGI_TB": 393340,
                "NCL": 0.42
            },
            {
                "nmcab": "KARAWANG",
                "nama_produk": "AISI",
                "WO": 1143428773,
                "RUGI_TB": 86575204,
                "NCL": 4.55
            },
            {
                "nmcab": "KARAWANG",
                "nama_produk": "KPM",
                "WO": 349061374,
                "RUGI_TB": -16308206,
                "NCL": 1.22
            },
            {
                "nmcab": "KARAWANG",
                "nama_produk": "RETENTION",
                "WO": 171149605,
                "RUGI_TB": 30525649,
                "NCL": 1.02
            },
            {
                "nmcab": "KASIPUTE",
                "nama_produk": "AISI",
                "WO": 272780148,
                "RUGI_TB": 75110255,
                "NCL": 1.37
            },
            {
                "nmcab": "KASIPUTE",
                "nama_produk": "KPM",
                "WO": 31675975,
                "RUGI_TB": -2002090,
                "NCL": 0.77
            },
            {
                "nmcab": "KASIPUTE",
                "nama_produk": "RETENTION",
                "WO": 56531506,
                "RUGI_TB": -7608313,
                "NCL": 0.92
            },
            {
                "nmcab": "KAYU AGUNG",
                "nama_produk": "AISI",
                "WO": 157823519,
                "RUGI_TB": 29057631,
                "NCL": 1.75
            },
            {
                "nmcab": "KAYU AGUNG",
                "nama_produk": "KPM",
                "WO": 139752591,
                "RUGI_TB": -991982,
                "NCL": 5.6
            },
            {
                "nmcab": "KAYU AGUNG",
                "nama_produk": "RETENTION",
                "WO": 101279622,
                "RUGI_TB": 1364911,
                "NCL": 3.14
            },
            {
                "nmcab": "KEBUMEN",
                "nama_produk": "KPM",
                "WO": 137760994,
                "RUGI_TB": 660729,
                "NCL": 2.84
            },
            {
                "nmcab": "KEBUMEN",
                "nama_produk": "RETENTION",
                "WO": 85622411,
                "RUGI_TB": 4706610,
                "NCL": 2.13
            },
            {
                "nmcab": "KEDIRI",
                "nama_produk": "KPM",
                "WO": 252492460,
                "RUGI_TB": 857316,
                "NCL": 3.53
            },
            {
                "nmcab": "KEDIRI",
                "nama_produk": "RETENTION",
                "WO": 445779796,
                "RUGI_TB": 30003792,
                "NCL": 5.61
            },
            {
                "nmcab": "KELAPA",
                "nama_produk": "AISI",
                "WO": 55246331,
                "RUGI_TB": 30502700,
                "NCL": 0.53
            },
            {
                "nmcab": "KELAPA",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "KELAPA",
                "nama_produk": "RETENTION",
                "WO": 20975431,
                "RUGI_TB": 2285686,
                "NCL": 1.01
            },
            {
                "nmcab": "KENDARI",
                "nama_produk": "AISI",
                "WO": 2058274559,
                "RUGI_TB": 498264911,
                "NCL": 2.69
            },
            {
                "nmcab": "KENDARI",
                "nama_produk": "KPM",
                "WO": 126821139,
                "RUGI_TB": 2601806,
                "NCL": 1.52
            },
            {
                "nmcab": "KENDARI",
                "nama_produk": "RETENTION",
                "WO": 312199360,
                "RUGI_TB": -2870396,
                "NCL": 1.56
            },
            {
                "nmcab": "KOBA",
                "nama_produk": "AISI",
                "WO": 82554972,
                "RUGI_TB": 38664988,
                "NCL": 0.73
            },
            {
                "nmcab": "KOBA",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "KOBA",
                "nama_produk": "RETENTION",
                "WO": 8296340,
                "RUGI_TB": -2162824,
                "NCL": 0.29
            },
            {
                "nmcab": "KOLAKA",
                "nama_produk": "AISI",
                "WO": 348621552,
                "RUGI_TB": 153231888,
                "NCL": 1.16
            },
            {
                "nmcab": "KOLAKA",
                "nama_produk": "KPM",
                "WO": 74557419,
                "RUGI_TB": -17070611,
                "NCL": 0.54
            },
            {
                "nmcab": "KOLAKA",
                "nama_produk": "RETENTION",
                "WO": 136235707,
                "RUGI_TB": 4111733,
                "NCL": 0.69
            },
            {
                "nmcab": "KOTA AGUNG",
                "nama_produk": "AISI",
                "WO": 700814886,
                "RUGI_TB": 91786187,
                "NCL": 6.92
            },
            {
                "nmcab": "KOTA AGUNG",
                "nama_produk": "KPM",
                "WO": 73076661,
                "RUGI_TB": 737612,
                "NCL": 5.08
            },
            {
                "nmcab": "KOTA AGUNG",
                "nama_produk": "RETENTION",
                "WO": 88468583,
                "RUGI_TB": 9958662,
                "NCL": 4.57
            },
            {
                "nmcab": "KOTA FAJAR",
                "nama_produk": "AISI",
                "WO": 794868526,
                "RUGI_TB": 444120285,
                "NCL": 2.55
            },
            {
                "nmcab": "KOTA FAJAR",
                "nama_produk": "KPM",
                "WO": 101012712,
                "RUGI_TB": 5993034,
                "NCL": 2.26
            },
            {
                "nmcab": "KOTA FAJAR",
                "nama_produk": "RETENTION",
                "WO": 19594138,
                "RUGI_TB": 1804953,
                "NCL": 0.5
            },
            {
                "nmcab": "KOTABARU",
                "nama_produk": "AISI",
                "WO": 495100807,
                "RUGI_TB": 126578703,
                "NCL": 3.49
            },
            {
                "nmcab": "KOTABARU",
                "nama_produk": "KPM",
                "WO": 9053605,
                "RUGI_TB": 6172449,
                "NCL": 0.81
            },
            {
                "nmcab": "KOTABARU",
                "nama_produk": "RETENTION",
                "WO": 81402732,
                "RUGI_TB": 5409485,
                "NCL": 1.89
            },
            {
                "nmcab": "KOTABUMI",
                "nama_produk": "AISI",
                "WO": 302671898,
                "RUGI_TB": 37200171,
                "NCL": 3.07
            },
            {
                "nmcab": "KOTABUMI",
                "nama_produk": "KPM",
                "WO": 26652525,
                "RUGI_TB": 0,
                "NCL": 1.35
            },
            {
                "nmcab": "KOTABUMI",
                "nama_produk": "RETENTION",
                "WO": 112325601,
                "RUGI_TB": 2132763,
                "NCL": 2.96
            },
            {
                "nmcab": "KOTAMOBAGU",
                "nama_produk": "AISI",
                "WO": 1290231645,
                "RUGI_TB": 160213618,
                "NCL": 10.99
            },
            {
                "nmcab": "KOTAMOBAGU",
                "nama_produk": "KPM",
                "WO": 168303382,
                "RUGI_TB": -2758768,
                "NCL": 4.43
            },
            {
                "nmcab": "KOTAMOBAGU",
                "nama_produk": "RETENTION",
                "WO": 153109003,
                "RUGI_TB": 22846155,
                "NCL": 3.08
            },
            {
                "nmcab": "KOTARAYA",
                "nama_produk": "AISI",
                "WO": 361952537,
                "RUGI_TB": 228753478,
                "NCL": 2.13
            },
            {
                "nmcab": "KOTARAYA",
                "nama_produk": "KPM",
                "WO": 20651109,
                "RUGI_TB": 1079613,
                "NCL": 0.92
            },
            {
                "nmcab": "KOTARAYA",
                "nama_produk": "RETENTION",
                "WO": 49766291,
                "RUGI_TB": 15026774,
                "NCL": 1.17
            },
            {
                "nmcab": "KOTOBARU",
                "nama_produk": "AISI",
                "WO": 1783668327,
                "RUGI_TB": 77285985,
                "NCL": 4.51
            },
            {
                "nmcab": "KOTOBARU",
                "nama_produk": "KPM",
                "WO": 75460394,
                "RUGI_TB": 1353378,
                "NCL": 3.76
            },
            {
                "nmcab": "KOTOBARU",
                "nama_produk": "RETENTION",
                "WO": 89064090,
                "RUGI_TB": -636015,
                "NCL": 1.56
            },
            {
                "nmcab": "KUALA SIMPANG",
                "nama_produk": "AISI",
                "WO": 942022990,
                "RUGI_TB": 463244892,
                "NCL": 1.95
            },
            {
                "nmcab": "KUALA SIMPANG",
                "nama_produk": "KPM",
                "WO": 83047967,
                "RUGI_TB": 5873165,
                "NCL": 1.32
            },
            {
                "nmcab": "KUALA SIMPANG",
                "nama_produk": "RETENTION",
                "WO": 89407066,
                "RUGI_TB": 20230806,
                "NCL": 0.97
            },
            {
                "nmcab": "KUNINGAN",
                "nama_produk": "AISI",
                "WO": 342112165,
                "RUGI_TB": 46658879,
                "NCL": 6.14
            },
            {
                "nmcab": "KUNINGAN",
                "nama_produk": "KPM",
                "WO": 115767063,
                "RUGI_TB": -730596,
                "NCL": 2.67
            },
            {
                "nmcab": "KUNINGAN",
                "nama_produk": "RETENTION",
                "WO": 158399980,
                "RUGI_TB": 1005163,
                "NCL": 2.03
            },
            {
                "nmcab": "LABUAN BAJO",
                "nama_produk": "AISI",
                "WO": 35077069,
                "RUGI_TB": 0,
                "NCL": 1.15
            },
            {
                "nmcab": "LABUAN BAJO",
                "nama_produk": "KPM",
                "WO": 2937912,
                "RUGI_TB": 1321333,
                "NCL": 0.1
            },
            {
                "nmcab": "LABUAN BAJO",
                "nama_produk": "RETENTION",
                "WO": 8651135,
                "RUGI_TB": 7843677,
                "NCL": 0.35
            },
            {
                "nmcab": "LADONGI",
                "nama_produk": "AISI",
                "WO": 429801798,
                "RUGI_TB": 74148693,
                "NCL": 2.59
            },
            {
                "nmcab": "LADONGI",
                "nama_produk": "KPM",
                "WO": 31331901,
                "RUGI_TB": 1733092,
                "NCL": 1.32
            },
            {
                "nmcab": "LADONGI",
                "nama_produk": "RETENTION",
                "WO": 102610783,
                "RUGI_TB": -3075663,
                "NCL": 2.13
            },
            {
                "nmcab": "LAHAT",
                "nama_produk": "AISI",
                "WO": 981743778,
                "RUGI_TB": 501302161,
                "NCL": 3.78
            },
            {
                "nmcab": "LAHAT",
                "nama_produk": "KPM",
                "WO": 130390921,
                "RUGI_TB": 102857422,
                "NCL": 2.57
            },
            {
                "nmcab": "LAHAT",
                "nama_produk": "RETENTION",
                "WO": 52120635,
                "RUGI_TB": 26567711,
                "NCL": 1.06
            },
            {
                "nmcab": "LAMPUNG",
                "nama_produk": "AISI",
                "WO": 4317836983,
                "RUGI_TB": 747132462,
                "NCL": 8.8
            },
            {
                "nmcab": "LAMPUNG",
                "nama_produk": "KPM",
                "WO": 144503515,
                "RUGI_TB": -72263,
                "NCL": 1.87
            },
            {
                "nmcab": "LAMPUNG",
                "nama_produk": "RETENTION",
                "WO": 241442993,
                "RUGI_TB": 50140112,
                "NCL": 2.15
            },
            {
                "nmcab": "LANGSA ACEH",
                "nama_produk": "AISI",
                "WO": 151982173,
                "RUGI_TB": 31199383,
                "NCL": 0.99
            },
            {
                "nmcab": "LANGSA ACEH",
                "nama_produk": "KPM",
                "WO": 8925082,
                "RUGI_TB": -967136,
                "NCL": 0.37
            },
            {
                "nmcab": "LANGSA ACEH",
                "nama_produk": "RETENTION",
                "WO": 3368957,
                "RUGI_TB": -7365357,
                "NCL": -0.14
            },
            {
                "nmcab": "LASUSUA",
                "nama_produk": "AISI",
                "WO": 41250549,
                "RUGI_TB": 1852012,
                "NCL": 0.69
            },
            {
                "nmcab": "LASUSUA",
                "nama_produk": "KPM",
                "WO": 11463517,
                "RUGI_TB": 0,
                "NCL": 0.59
            },
            {
                "nmcab": "LASUSUA",
                "nama_produk": "RETENTION",
                "WO": 54507961,
                "RUGI_TB": -7935924,
                "NCL": 1.12
            },
            {
                "nmcab": "LEUWILIANG",
                "nama_produk": "AISI",
                "WO": 77250088,
                "RUGI_TB": 4616073,
                "NCL": 1.19
            },
            {
                "nmcab": "LEUWILIANG",
                "nama_produk": "KPM",
                "WO": 35623545,
                "RUGI_TB": -6600217,
                "NCL": 0.18
            },
            {
                "nmcab": "LEUWILIANG",
                "nama_produk": "RETENTION",
                "WO": 99135319,
                "RUGI_TB": 54749413,
                "NCL": 0.87
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "nama_produk": "AISI",
                "WO": 1555020880,
                "RUGI_TB": 525426109,
                "NCL": 3.74
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "nama_produk": "KPM",
                "WO": 51471822,
                "RUGI_TB": 9220254,
                "NCL": 1.02
            },
            {
                "nmcab": "LHOKSEUMAWE",
                "nama_produk": "RETENTION",
                "WO": 128647099,
                "RUGI_TB": 3937638,
                "NCL": 1.72
            },
            {
                "nmcab": "LHOKSUKON",
                "nama_produk": "AISI",
                "WO": 294724602,
                "RUGI_TB": 99412852,
                "NCL": 2.26
            },
            {
                "nmcab": "LHOKSUKON",
                "nama_produk": "KPM",
                "WO": 21710993,
                "RUGI_TB": 1265288,
                "NCL": 1.35
            },
            {
                "nmcab": "LHOKSUKON",
                "nama_produk": "RETENTION",
                "WO": 6738234,
                "RUGI_TB": -1139011,
                "NCL": 0.33
            },
            {
                "nmcab": "LIWA",
                "nama_produk": "AISI",
                "WO": 570175921,
                "RUGI_TB": 140854186,
                "NCL": 4.5
            },
            {
                "nmcab": "LIWA",
                "nama_produk": "KPM",
                "WO": 27434481,
                "RUGI_TB": 0,
                "NCL": 1.52
            },
            {
                "nmcab": "LIWA",
                "nama_produk": "RETENTION",
                "WO": 42111676,
                "RUGI_TB": 4136308,
                "NCL": 2.1
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "nama_produk": "AISI",
                "WO": 671461934,
                "RUGI_TB": 9009265,
                "NCL": 4.17
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "nama_produk": "KPM",
                "WO": 31862581,
                "RUGI_TB": 0,
                "NCL": 1.22
            },
            {
                "nmcab": "LUBUK LINGGAU",
                "nama_produk": "RETENTION",
                "WO": 67895558,
                "RUGI_TB": 0,
                "NCL": 2
            },
            {
                "nmcab": "LUBUKBASUNG",
                "nama_produk": "AISI",
                "WO": 228950569,
                "RUGI_TB": 75580574,
                "NCL": 1.83
            },
            {
                "nmcab": "LUBUKBASUNG",
                "nama_produk": "KPM",
                "WO": 27599686,
                "RUGI_TB": 0,
                "NCL": 1.56
            },
            {
                "nmcab": "LUBUKBASUNG",
                "nama_produk": "RETENTION",
                "WO": 8422173,
                "RUGI_TB": -93812,
                "NCL": 0.53
            },
            {
                "nmcab": "LUWUK",
                "nama_produk": "AISI",
                "WO": 1763282997,
                "RUGI_TB": 135423576,
                "NCL": 8.42
            },
            {
                "nmcab": "LUWUK",
                "nama_produk": "KPM",
                "WO": 132558162,
                "RUGI_TB": 2635033,
                "NCL": 1.87
            },
            {
                "nmcab": "LUWUK",
                "nama_produk": "RETENTION",
                "WO": 237121971,
                "RUGI_TB": -2834434,
                "NCL": 3.12
            },
            {
                "nmcab": "MADIUN",
                "nama_produk": "KPM",
                "WO": 40205590,
                "RUGI_TB": -10970,
                "NCL": 0.71
            },
            {
                "nmcab": "MADIUN",
                "nama_produk": "RETENTION",
                "WO": 39194770,
                "RUGI_TB": 73642,
                "NCL": 1.3
            },
            {
                "nmcab": "MAGELANG",
                "nama_produk": "KPM",
                "WO": 86344732,
                "RUGI_TB": 6335986,
                "NCL": 0.86
            },
            {
                "nmcab": "MAGELANG",
                "nama_produk": "RETENTION",
                "WO": 42582042,
                "RUGI_TB": 3935310,
                "NCL": 0.64
            },
            {
                "nmcab": "MAJENE",
                "nama_produk": "AISI",
                "WO": 598549457,
                "RUGI_TB": 170573825,
                "NCL": 4.13
            },
            {
                "nmcab": "MAJENE",
                "nama_produk": "KPM",
                "WO": 142340456,
                "RUGI_TB": -4521743,
                "NCL": 4.19
            },
            {
                "nmcab": "MAJENE",
                "nama_produk": "RETENTION",
                "WO": 259689970,
                "RUGI_TB": 19286476,
                "NCL": 3.7
            },
            {
                "nmcab": "MAKALE",
                "nama_produk": "AISI",
                "WO": 417683268,
                "RUGI_TB": 241579153,
                "NCL": 2.08
            },
            {
                "nmcab": "MAKALE",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": -4856428,
                "NCL": -0.12
            },
            {
                "nmcab": "MAKALE",
                "nama_produk": "RETENTION",
                "WO": 81839013,
                "RUGI_TB": 105674059,
                "NCL": 1.37
            },
            {
                "nmcab": "MAKASSAR",
                "nama_produk": "AISI",
                "WO": 2796856115,
                "RUGI_TB": 1357736755,
                "NCL": 3.2
            },
            {
                "nmcab": "MAKASSAR",
                "nama_produk": "KPM",
                "WO": 168582887,
                "RUGI_TB": -15878,
                "NCL": 1.16
            },
            {
                "nmcab": "MAKASSAR",
                "nama_produk": "RETENTION",
                "WO": 348882600,
                "RUGI_TB": 107998233,
                "NCL": 1.66
            },
            {
                "nmcab": "MAKASSAR 2",
                "nama_produk": "AISI",
                "WO": 2993437681,
                "RUGI_TB": 742341587,
                "NCL": 3.18
            },
            {
                "nmcab": "MAKASSAR 2",
                "nama_produk": "KPM",
                "WO": 144657442,
                "RUGI_TB": 2202463,
                "NCL": 1.31
            },
            {
                "nmcab": "MAKASSAR 2",
                "nama_produk": "RETENTION",
                "WO": 268205592,
                "RUGI_TB": 10984564,
                "NCL": 1.26
            },
            {
                "nmcab": "MAKASSAR 3",
                "nama_produk": "AISI",
                "WO": 2294144978,
                "RUGI_TB": 730096462,
                "NCL": 2.24
            },
            {
                "nmcab": "MAKASSAR 3",
                "nama_produk": "KPM",
                "WO": 97422332,
                "RUGI_TB": -155427,
                "NCL": 1.17
            },
            {
                "nmcab": "MAKASSAR 3",
                "nama_produk": "RETENTION",
                "WO": 353531032,
                "RUGI_TB": 8195252,
                "NCL": 1.39
            },
            {
                "nmcab": "MALANG",
                "nama_produk": "KPM",
                "WO": 323723363,
                "RUGI_TB": 265397,
                "NCL": 3
            },
            {
                "nmcab": "MALANG",
                "nama_produk": "RETENTION",
                "WO": 163702605,
                "RUGI_TB": 0,
                "NCL": 3.52
            },
            {
                "nmcab": "MALILI",
                "nama_produk": "AISI",
                "WO": 420804155,
                "RUGI_TB": 185002488,
                "NCL": 1.74
            },
            {
                "nmcab": "MALILI",
                "nama_produk": "KPM",
                "WO": 25955899,
                "RUGI_TB": 1409278,
                "NCL": 0.62
            },
            {
                "nmcab": "MALILI",
                "nama_produk": "RETENTION",
                "WO": 195348496,
                "RUGI_TB": 2704774,
                "NCL": 1.78
            },
            {
                "nmcab": "MALINO",
                "nama_produk": "AISI",
                "WO": 40382824,
                "RUGI_TB": 59352882,
                "NCL": 0.68
            },
            {
                "nmcab": "MALINO",
                "nama_produk": "KPM",
                "WO": 8313017,
                "RUGI_TB": 0,
                "NCL": 0.41
            },
            {
                "nmcab": "MALINO",
                "nama_produk": "RETENTION",
                "WO": 1732258,
                "RUGI_TB": -488711,
                "NCL": 0.03
            },
            {
                "nmcab": "MAMUJU",
                "nama_produk": "AISI",
                "WO": 484876844,
                "RUGI_TB": 296288832,
                "NCL": 3.1
            },
            {
                "nmcab": "MAMUJU",
                "nama_produk": "KPM",
                "WO": 38779551,
                "RUGI_TB": 2868347,
                "NCL": 1.16
            },
            {
                "nmcab": "MAMUJU",
                "nama_produk": "RETENTION",
                "WO": 90979393,
                "RUGI_TB": 27614064,
                "NCL": 1.05
            },
            {
                "nmcab": "MANADO",
                "nama_produk": "AISI",
                "WO": 6435822164,
                "RUGI_TB": 366388940,
                "NCL": 10.86
            },
            {
                "nmcab": "MANADO",
                "nama_produk": "KPM",
                "WO": 402317250,
                "RUGI_TB": 6795742,
                "NCL": 6.44
            },
            {
                "nmcab": "MANADO",
                "nama_produk": "RETENTION",
                "WO": 1113996365,
                "RUGI_TB": 150694128,
                "NCL": 6.39
            },
            {
                "nmcab": "MANGKUTANA",
                "nama_produk": "AISI",
                "WO": 95864946,
                "RUGI_TB": 85320442,
                "NCL": 0.6
            },
            {
                "nmcab": "MANGKUTANA",
                "nama_produk": "KPM",
                "WO": 4245970,
                "RUGI_TB": 1604544,
                "NCL": 0.13
            },
            {
                "nmcab": "MANGKUTANA",
                "nama_produk": "RETENTION",
                "WO": 49913623,
                "RUGI_TB": -2751130,
                "NCL": 0.37
            },
            {
                "nmcab": "MANOKWARI",
                "nama_produk": "AISI",
                "WO": 318380679,
                "RUGI_TB": 114267233,
                "NCL": 1.77
            },
            {
                "nmcab": "MANOKWARI",
                "nama_produk": "KPM",
                "WO": 116025691,
                "RUGI_TB": -42324479,
                "NCL": 1.85
            },
            {
                "nmcab": "MANOKWARI",
                "nama_produk": "RETENTION",
                "WO": 89904641,
                "RUGI_TB": -10489452,
                "NCL": 2.32
            },
            {
                "nmcab": "MARISA",
                "nama_produk": "AISI",
                "WO": 197594067,
                "RUGI_TB": 74013136,
                "NCL": 1.18
            },
            {
                "nmcab": "MARISA",
                "nama_produk": "KPM",
                "WO": 54586431,
                "RUGI_TB": -1660417,
                "NCL": 0.95
            },
            {
                "nmcab": "MARISA",
                "nama_produk": "RETENTION",
                "WO": 90559842,
                "RUGI_TB": -3918836,
                "NCL": 0.59
            },
            {
                "nmcab": "MAROS",
                "nama_produk": "AISI",
                "WO": 1418073151,
                "RUGI_TB": 368851539,
                "NCL": 2.57
            },
            {
                "nmcab": "MAROS",
                "nama_produk": "KPM",
                "WO": 49599212,
                "RUGI_TB": 4754257,
                "NCL": 0.93
            },
            {
                "nmcab": "MAROS",
                "nama_produk": "RETENTION",
                "WO": 136853973,
                "RUGI_TB": 28655807,
                "NCL": 1.26
            },
            {
                "nmcab": "MARTAPURA",
                "nama_produk": "AISI",
                "WO": 111091182,
                "RUGI_TB": 0,
                "NCL": 3.93
            },
            {
                "nmcab": "MARTAPURA",
                "nama_produk": "KPM",
                "WO": 13243740,
                "RUGI_TB": 0,
                "NCL": 1.15
            },
            {
                "nmcab": "MARTAPURA",
                "nama_produk": "RETENTION",
                "WO": 12954707,
                "RUGI_TB": 260928,
                "NCL": 0.71
            },
            {
                "nmcab": "MARTAPURA KAL",
                "nama_produk": "AISI",
                "WO": 546633417,
                "RUGI_TB": 87378385,
                "NCL": 3.24
            },
            {
                "nmcab": "MARTAPURA KAL",
                "nama_produk": "KPM",
                "WO": 32655293,
                "RUGI_TB": -1181890,
                "NCL": 0.66
            },
            {
                "nmcab": "MARTAPURA KAL",
                "nama_produk": "RETENTION",
                "WO": 60738397,
                "RUGI_TB": 6509537,
                "NCL": 0.58
            },
            {
                "nmcab": "MASAMBA",
                "nama_produk": "AISI",
                "WO": 286076844,
                "RUGI_TB": 304603588,
                "NCL": 1.28
            },
            {
                "nmcab": "MASAMBA",
                "nama_produk": "KPM",
                "WO": 39988149,
                "RUGI_TB": 1387660,
                "NCL": 0.75
            },
            {
                "nmcab": "MASAMBA",
                "nama_produk": "RETENTION",
                "WO": 91373435,
                "RUGI_TB": -8788997,
                "NCL": 0.66
            },
            {
                "nmcab": "MASBAGIK",
                "nama_produk": "AISI",
                "WO": 331042821,
                "RUGI_TB": 0,
                "NCL": 11.38
            },
            {
                "nmcab": "MASBAGIK",
                "nama_produk": "KPM",
                "WO": 188288441,
                "RUGI_TB": 3620253,
                "NCL": 1.57
            },
            {
                "nmcab": "MASBAGIK",
                "nama_produk": "RETENTION",
                "WO": 154055508,
                "RUGI_TB": 3386957,
                "NCL": 1.95
            },
            {
                "nmcab": "MASOHI",
                "nama_produk": "AISI",
                "WO": 17695443,
                "RUGI_TB": 19207956,
                "NCL": 0.36
            },
            {
                "nmcab": "MASOHI",
                "nama_produk": "KPM",
                "WO": 21499075,
                "RUGI_TB": -2269940,
                "NCL": 0.16
            },
            {
                "nmcab": "MASOHI",
                "nama_produk": "RETENTION",
                "WO": 73389250,
                "RUGI_TB": 4880459,
                "NCL": 0.37
            },
            {
                "nmcab": "MEDAN",
                "nama_produk": "AISI",
                "WO": 4071949485,
                "RUGI_TB": 80656616,
                "NCL": 17.41
            },
            {
                "nmcab": "MEDAN",
                "nama_produk": "KPM",
                "WO": 59956401,
                "RUGI_TB": -1667581,
                "NCL": 1.4
            },
            {
                "nmcab": "MEDAN",
                "nama_produk": "RETENTION",
                "WO": 108300191,
                "RUGI_TB": 0,
                "NCL": 6.89
            },
            {
                "nmcab": "MENTOK",
                "nama_produk": "AISI",
                "WO": 104448793,
                "RUGI_TB": 86665575,
                "NCL": 1.2
            },
            {
                "nmcab": "MENTOK",
                "nama_produk": "KPM",
                "WO": 92331960,
                "RUGI_TB": 1982509,
                "NCL": 2.84
            },
            {
                "nmcab": "MENTOK",
                "nama_produk": "RETENTION",
                "WO": 51170387,
                "RUGI_TB": 6117763,
                "NCL": 1.69
            },
            {
                "nmcab": "METRO",
                "nama_produk": "AISI",
                "WO": 258119456,
                "RUGI_TB": 66968654,
                "NCL": 2.43
            },
            {
                "nmcab": "METRO",
                "nama_produk": "KPM",
                "WO": 33553806,
                "RUGI_TB": 3354219,
                "NCL": 0.73
            },
            {
                "nmcab": "METRO",
                "nama_produk": "RETENTION",
                "WO": 100309714,
                "RUGI_TB": 3184602,
                "NCL": 1.16
            },
            {
                "nmcab": "MEULABOH",
                "nama_produk": "AISI",
                "WO": 713038979,
                "RUGI_TB": 253877822,
                "NCL": 2.48
            },
            {
                "nmcab": "MEULABOH",
                "nama_produk": "KPM",
                "WO": 66792631,
                "RUGI_TB": 45067566,
                "NCL": 0.94
            },
            {
                "nmcab": "MEULABOH",
                "nama_produk": "RETENTION",
                "WO": 138389680,
                "RUGI_TB": 29987802,
                "NCL": 0.88
            },
            {
                "nmcab": "MOJOKERTO",
                "nama_produk": "KPM",
                "WO": 217152320,
                "RUGI_TB": 96267,
                "NCL": 3.69
            },
            {
                "nmcab": "MOJOKERTO",
                "nama_produk": "RETENTION",
                "WO": 106936959,
                "RUGI_TB": -192526,
                "NCL": 4.59
            },
            {
                "nmcab": "MOLIBAGU",
                "nama_produk": "AISI",
                "WO": 42395381,
                "RUGI_TB": 0,
                "NCL": 0.96
            },
            {
                "nmcab": "MOLIBAGU",
                "nama_produk": "KPM",
                "WO": 21368983,
                "RUGI_TB": 571472,
                "NCL": 0.76
            },
            {
                "nmcab": "MOLIBAGU",
                "nama_produk": "RETENTION",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "MOROTAI",
                "nama_produk": "AISI",
                "WO": 15618032,
                "RUGI_TB": 0,
                "NCL": 2.1
            },
            {
                "nmcab": "MOROTAI",
                "nama_produk": "KPM",
                "WO": 67371550,
                "RUGI_TB": 0,
                "NCL": 4.72
            },
            {
                "nmcab": "MOROTAI",
                "nama_produk": "RETENTION",
                "WO": 1076471,
                "RUGI_TB": 1110358,
                "NCL": 0.25
            },
            {
                "nmcab": "MOROWALI",
                "nama_produk": "AISI",
                "WO": 185590056,
                "RUGI_TB": 84131821,
                "NCL": 0.75
            },
            {
                "nmcab": "MOROWALI",
                "nama_produk": "KPM",
                "WO": 16087370,
                "RUGI_TB": 12264930,
                "NCL": 0.31
            },
            {
                "nmcab": "MOROWALI",
                "nama_produk": "RETENTION",
                "WO": 34782809,
                "RUGI_TB": 20057605,
                "NCL": 0.47
            },
            {
                "nmcab": "MUARA BULIAN",
                "nama_produk": "KPM",
                "WO": 9578959,
                "RUGI_TB": 0,
                "NCL": 63.15
            },
            {
                "nmcab": "MUARA BULIAN",
                "nama_produk": "RETENTION",
                "WO": 25832241,
                "RUGI_TB": 0,
                "NCL": 38.75
            },
            {
                "nmcab": "MUARA ENIM",
                "nama_produk": "AISI",
                "WO": 563035771,
                "RUGI_TB": 77288463,
                "NCL": 3.37
            },
            {
                "nmcab": "MUARA ENIM",
                "nama_produk": "KPM",
                "WO": 23522939,
                "RUGI_TB": 0,
                "NCL": 0.89
            },
            {
                "nmcab": "MUARA ENIM",
                "nama_produk": "RETENTION",
                "WO": 34620726,
                "RUGI_TB": 0,
                "NCL": 1.2
            },
            {
                "nmcab": "MUARA TEWEH",
                "nama_produk": "AISI",
                "WO": 968146164,
                "RUGI_TB": 291068626,
                "NCL": 4.45
            },
            {
                "nmcab": "MUARA TEWEH",
                "nama_produk": "KPM",
                "WO": 69616718,
                "RUGI_TB": 3518241,
                "NCL": 1.54
            },
            {
                "nmcab": "MUARA TEWEH",
                "nama_produk": "RETENTION",
                "WO": 83498585,
                "RUGI_TB": 9673765,
                "NCL": 1.7
            },
            {
                "nmcab": "NAGAN",
                "nama_produk": "AISI",
                "WO": 515151192,
                "RUGI_TB": 172721808,
                "NCL": 4.16
            },
            {
                "nmcab": "NAGAN",
                "nama_produk": "KPM",
                "WO": 49177564,
                "RUGI_TB": 20917389,
                "NCL": 1.75
            },
            {
                "nmcab": "NAGAN",
                "nama_produk": "RETENTION",
                "WO": 118754025,
                "RUGI_TB": 6693076,
                "NCL": 2.3
            },
            {
                "nmcab": "NAMLEA",
                "nama_produk": "AISI",
                "WO": 51897531,
                "RUGI_TB": 50700582,
                "NCL": 0.44
            },
            {
                "nmcab": "NAMLEA",
                "nama_produk": "KPM",
                "WO": 15560780,
                "RUGI_TB": 8710673,
                "NCL": 0.44
            },
            {
                "nmcab": "NAMLEA",
                "nama_produk": "RETENTION",
                "WO": 54332556,
                "RUGI_TB": 28507499,
                "NCL": 0.76
            },
            {
                "nmcab": "PADANG",
                "nama_produk": "AISI",
                "WO": 1844867300,
                "RUGI_TB": 154169140,
                "NCL": 8.72
            },
            {
                "nmcab": "PADANG",
                "nama_produk": "KPM",
                "WO": 190846305,
                "RUGI_TB": 14137980,
                "NCL": 5.12
            },
            {
                "nmcab": "PADANG",
                "nama_produk": "RETENTION",
                "WO": 261978048,
                "RUGI_TB": 12602812,
                "NCL": 4.24
            },
            {
                "nmcab": "PALANGKARAYA",
                "nama_produk": "AISI",
                "WO": 195556719,
                "RUGI_TB": 10167111,
                "NCL": 1.33
            },
            {
                "nmcab": "PALANGKARAYA",
                "nama_produk": "KPM",
                "WO": 5801492,
                "RUGI_TB": 1779347,
                "NCL": 0.21
            },
            {
                "nmcab": "PALANGKARAYA",
                "nama_produk": "RETENTION",
                "WO": 56669654,
                "RUGI_TB": 1420444,
                "NCL": 0.51
            },
            {
                "nmcab": "PALEMBANG",
                "nama_produk": "AISI",
                "WO": 8906550401,
                "RUGI_TB": 1536711484,
                "NCL": 11.11
            },
            {
                "nmcab": "PALEMBANG",
                "nama_produk": "KPM",
                "WO": 281548815,
                "RUGI_TB": 3725290,
                "NCL": 7.89
            },
            {
                "nmcab": "PALEMBANG",
                "nama_produk": "RETENTION",
                "WO": 237506507,
                "RUGI_TB": 6942722,
                "NCL": 3.95
            },
            {
                "nmcab": "PALOPO",
                "nama_produk": "AISI",
                "WO": 780362686,
                "RUGI_TB": 374736728,
                "NCL": 1.6
            },
            {
                "nmcab": "PALOPO",
                "nama_produk": "KPM",
                "WO": 31229125,
                "RUGI_TB": -644758,
                "NCL": 0.64
            },
            {
                "nmcab": "PALOPO",
                "nama_produk": "RETENTION",
                "WO": 143558141,
                "RUGI_TB": 42775847,
                "NCL": 0.83
            },
            {
                "nmcab": "PALU",
                "nama_produk": "AISI",
                "WO": 3312813902,
                "RUGI_TB": 1408915407,
                "NCL": 3.14
            },
            {
                "nmcab": "PALU",
                "nama_produk": "KPM",
                "WO": 95685362,
                "RUGI_TB": 9423117,
                "NCL": 0.89
            },
            {
                "nmcab": "PALU",
                "nama_produk": "RETENTION",
                "WO": 166353462,
                "RUGI_TB": 39663311,
                "NCL": 0.92
            },
            {
                "nmcab": "PALU 2",
                "nama_produk": "AISI",
                "WO": 1560990444,
                "RUGI_TB": 922811235,
                "NCL": 3
            },
            {
                "nmcab": "PALU 2",
                "nama_produk": "KPM",
                "WO": 57237129,
                "RUGI_TB": 2863308,
                "NCL": 0.92
            },
            {
                "nmcab": "PALU 2",
                "nama_produk": "RETENTION",
                "WO": 84097332,
                "RUGI_TB": 40706801,
                "NCL": 0.96
            },
            {
                "nmcab": "PANGANDARAN",
                "nama_produk": "AISI",
                "WO": 804583453,
                "RUGI_TB": 35621287,
                "NCL": 7.16
            },
            {
                "nmcab": "PANGANDARAN",
                "nama_produk": "KPM",
                "WO": 282135221,
                "RUGI_TB": 6745346,
                "NCL": 3.51
            },
            {
                "nmcab": "PANGANDARAN",
                "nama_produk": "RETENTION",
                "WO": 323744958,
                "RUGI_TB": 16673972,
                "NCL": 2.68
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "nama_produk": "AISI",
                "WO": 398286068,
                "RUGI_TB": 3703116,
                "NCL": 15.88
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "PANGKALAN BRANDAN",
                "nama_produk": "RETENTION",
                "WO": 18760475,
                "RUGI_TB": 0,
                "NCL": 10.81
            },
            {
                "nmcab": "PANGKALANBUN",
                "nama_produk": "AISI",
                "WO": 73173715,
                "RUGI_TB": 2317038,
                "NCL": 3.41
            },
            {
                "nmcab": "PANGKALANBUN",
                "nama_produk": "KPM",
                "WO": 3697444,
                "RUGI_TB": 0,
                "NCL": 0.26
            },
            {
                "nmcab": "PANGKALANBUN",
                "nama_produk": "RETENTION",
                "WO": 34214250,
                "RUGI_TB": 0,
                "NCL": 1.15
            },
            {
                "nmcab": "PANGKEP",
                "nama_produk": "AISI",
                "WO": 361613021,
                "RUGI_TB": 123200503,
                "NCL": 1.22
            },
            {
                "nmcab": "PANGKEP",
                "nama_produk": "KPM",
                "WO": 26610844,
                "RUGI_TB": -5860719,
                "NCL": 0.69
            },
            {
                "nmcab": "PANGKEP",
                "nama_produk": "RETENTION",
                "WO": 48184411,
                "RUGI_TB": 6017590,
                "NCL": 0.71
            },
            {
                "nmcab": "PANTON LABU",
                "nama_produk": "AISI",
                "WO": 430543457,
                "RUGI_TB": 79652116,
                "NCL": 2.21
            },
            {
                "nmcab": "PANTON LABU",
                "nama_produk": "KPM",
                "WO": 9830610,
                "RUGI_TB": 0,
                "NCL": 0.63
            },
            {
                "nmcab": "PANTON LABU",
                "nama_produk": "RETENTION",
                "WO": 3680767,
                "RUGI_TB": -1758764,
                "NCL": 0.08
            },
            {
                "nmcab": "PARE-PARE",
                "nama_produk": "AISI",
                "WO": 1840650755,
                "RUGI_TB": 215856510,
                "NCL": 4.69
            },
            {
                "nmcab": "PARE-PARE",
                "nama_produk": "KPM",
                "WO": 107329048,
                "RUGI_TB": -8986330,
                "NCL": 2.59
            },
            {
                "nmcab": "PARE-PARE",
                "nama_produk": "RETENTION",
                "WO": 454946838,
                "RUGI_TB": -27599687,
                "NCL": 3.54
            },
            {
                "nmcab": "PARIAMAN",
                "nama_produk": "AISI",
                "WO": 737110845,
                "RUGI_TB": 55901585,
                "NCL": 3.74
            },
            {
                "nmcab": "PARIAMAN",
                "nama_produk": "KPM",
                "WO": 64738046,
                "RUGI_TB": 0,
                "NCL": 3.28
            },
            {
                "nmcab": "PARIAMAN",
                "nama_produk": "RETENTION",
                "WO": 76500884,
                "RUGI_TB": 5451470,
                "NCL": 3.22
            },
            {
                "nmcab": "PARIGI",
                "nama_produk": "AISI",
                "WO": 552584418,
                "RUGI_TB": 151109090,
                "NCL": 1.97
            },
            {
                "nmcab": "PARIGI",
                "nama_produk": "KPM",
                "WO": 15792283,
                "RUGI_TB": 0,
                "NCL": 0.47
            },
            {
                "nmcab": "PARIGI",
                "nama_produk": "RETENTION",
                "WO": 32423879,
                "RUGI_TB": -9797214,
                "NCL": 0.41
            },
            {
                "nmcab": "PARUNG",
                "nama_produk": "AISI",
                "WO": 174277500,
                "RUGI_TB": 18163642,
                "NCL": 1.99
            },
            {
                "nmcab": "PARUNG",
                "nama_produk": "KPM",
                "WO": 30677536,
                "RUGI_TB": 0,
                "NCL": 0.52
            },
            {
                "nmcab": "PARUNG",
                "nama_produk": "RETENTION",
                "WO": 48242672,
                "RUGI_TB": -1228564,
                "NCL": 0.53
            },
            {
                "nmcab": "PARUNGKUDA",
                "nama_produk": "AISI",
                "WO": 784764441,
                "RUGI_TB": 51766020,
                "NCL": 8.99
            },
            {
                "nmcab": "PARUNGKUDA",
                "nama_produk": "KPM",
                "WO": 811735205,
                "RUGI_TB": 36211204,
                "NCL": 4.61
            },
            {
                "nmcab": "PARUNGKUDA",
                "nama_produk": "RETENTION",
                "WO": 243483586,
                "RUGI_TB": 46203630,
                "NCL": 2.65
            },
            {
                "nmcab": "PASAMAN",
                "nama_produk": "AISI",
                "WO": 469913499,
                "RUGI_TB": 48484197,
                "NCL": 3.34
            },
            {
                "nmcab": "PASAMAN",
                "nama_produk": "KPM",
                "WO": 102318819,
                "RUGI_TB": 2314936,
                "NCL": 6.16
            },
            {
                "nmcab": "PASAMAN",
                "nama_produk": "RETENTION",
                "WO": 55029182,
                "RUGI_TB": -690211,
                "NCL": 2.82
            },
            {
                "nmcab": "PASANGKAYU",
                "nama_produk": "AISI",
                "WO": 135610678,
                "RUGI_TB": 114373896,
                "NCL": 0.68
            },
            {
                "nmcab": "PASANGKAYU",
                "nama_produk": "KPM",
                "WO": 20175798,
                "RUGI_TB": -388205,
                "NCL": 0.44
            },
            {
                "nmcab": "PASANGKAYU",
                "nama_produk": "RETENTION",
                "WO": 45179257,
                "RUGI_TB": 12371882,
                "NCL": 0.71
            },
            {
                "nmcab": "PATI",
                "nama_produk": "KPM",
                "WO": 494807664,
                "RUGI_TB": -16518805,
                "NCL": 4.92
            },
            {
                "nmcab": "PATI",
                "nama_produk": "RETENTION",
                "WO": 210943805,
                "RUGI_TB": -335702,
                "NCL": 4.87
            },
            {
                "nmcab": "PATROL",
                "nama_produk": "AISI",
                "WO": 525674137,
                "RUGI_TB": 5749608,
                "NCL": 8.87
            },
            {
                "nmcab": "PATROL",
                "nama_produk": "KPM",
                "WO": 116119125,
                "RUGI_TB": 0,
                "NCL": 2.62
            },
            {
                "nmcab": "PATROL",
                "nama_produk": "RETENTION",
                "WO": 86561859,
                "RUGI_TB": 5867741,
                "NCL": 1.05
            },
            {
                "nmcab": "PAYAKUMBUH",
                "nama_produk": "AISI",
                "WO": 112960972,
                "RUGI_TB": 5582750,
                "NCL": 1.01
            },
            {
                "nmcab": "PAYAKUMBUH",
                "nama_produk": "KPM",
                "WO": 7899534,
                "RUGI_TB": 2075928,
                "NCL": 0.64
            },
            {
                "nmcab": "PAYAKUMBUH",
                "nama_produk": "RETENTION",
                "WO": 2737432,
                "RUGI_TB": 1660650,
                "NCL": 0.25
            },
            {
                "nmcab": "PEKALONGAN",
                "nama_produk": "KPM",
                "WO": 110172982,
                "RUGI_TB": -1035837,
                "NCL": 1.9
            },
            {
                "nmcab": "PEKALONGAN",
                "nama_produk": "RETENTION",
                "WO": 61295817,
                "RUGI_TB": -1055654,
                "NCL": 1.89
            },
            {
                "nmcab": "PEKANBARU",
                "nama_produk": "AISI",
                "WO": 4133752898,
                "RUGI_TB": 486969437,
                "NCL": 14.23
            },
            {
                "nmcab": "PEKANBARU",
                "nama_produk": "KPM",
                "WO": 471611941,
                "RUGI_TB": -625009,
                "NCL": 13.5
            },
            {
                "nmcab": "PEKANBARU",
                "nama_produk": "RETENTION",
                "WO": 293702940,
                "RUGI_TB": -2030622,
                "NCL": 8.02
            },
            {
                "nmcab": "PELABUHAN RATU",
                "nama_produk": "AISI",
                "WO": 328663958,
                "RUGI_TB": -5926121,
                "NCL": 4.56
            },
            {
                "nmcab": "PELABUHAN RATU",
                "nama_produk": "KPM",
                "WO": 188577376,
                "RUGI_TB": -4868979,
                "NCL": 0.94
            },
            {
                "nmcab": "PELABUHAN RATU",
                "nama_produk": "RETENTION",
                "WO": 249272260,
                "RUGI_TB": 8639996,
                "NCL": 4.2
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "nama_produk": "AISI",
                "WO": 1383794531,
                "RUGI_TB": 84292421,
                "NCL": 5.34
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "nama_produk": "KPM",
                "WO": 355683507,
                "RUGI_TB": -6716950,
                "NCL": 4.3
            },
            {
                "nmcab": "PEMATANG SIANTAR",
                "nama_produk": "RETENTION",
                "WO": 121573257,
                "RUGI_TB": 3076183,
                "NCL": 2.04
            },
            {
                "nmcab": "PENAJAM",
                "nama_produk": "AISI",
                "WO": 252714945,
                "RUGI_TB": 30247418,
                "NCL": 3.25
            },
            {
                "nmcab": "PENAJAM",
                "nama_produk": "KPM",
                "WO": 16120187,
                "RUGI_TB": 0,
                "NCL": 0.82
            },
            {
                "nmcab": "PENAJAM",
                "nama_produk": "RETENTION",
                "WO": 19684640,
                "RUGI_TB": 1339163,
                "NCL": 0.62
            },
            {
                "nmcab": "PENDOLO",
                "nama_produk": "AISI",
                "WO": 55386328,
                "RUGI_TB": 22828450,
                "NCL": 0.56
            },
            {
                "nmcab": "PENDOLO",
                "nama_produk": "KPM",
                "WO": 8853665,
                "RUGI_TB": 0,
                "NCL": 0.29
            },
            {
                "nmcab": "PENDOLO",
                "nama_produk": "RETENTION",
                "WO": 37632375,
                "RUGI_TB": 0,
                "NCL": 0.75
            },
            {
                "nmcab": "PINRANG",
                "nama_produk": "AISI",
                "WO": 1122984901,
                "RUGI_TB": 334549504,
                "NCL": 2.88
            },
            {
                "nmcab": "PINRANG",
                "nama_produk": "KPM",
                "WO": 53904895,
                "RUGI_TB": 5476568,
                "NCL": 2.18
            },
            {
                "nmcab": "PINRANG",
                "nama_produk": "RETENTION",
                "WO": 144195346,
                "RUGI_TB": 5282559,
                "NCL": 1.54
            },
            {
                "nmcab": "PLEIHARI",
                "nama_produk": "AISI",
                "WO": 928572220,
                "RUGI_TB": 45939050,
                "NCL": 5.16
            },
            {
                "nmcab": "PLEIHARI",
                "nama_produk": "KPM",
                "WO": 27223312,
                "RUGI_TB": 0,
                "NCL": 2.28
            },
            {
                "nmcab": "PLEIHARI",
                "nama_produk": "RETENTION",
                "WO": 62047523,
                "RUGI_TB": -2335695,
                "NCL": 1.4
            },
            {
                "nmcab": "POLMAS",
                "nama_produk": "AISI",
                "WO": 847272747,
                "RUGI_TB": 293905690,
                "NCL": 4.68
            },
            {
                "nmcab": "POLMAS",
                "nama_produk": "KPM",
                "WO": 108733850,
                "RUGI_TB": 9724048,
                "NCL": 3.25
            },
            {
                "nmcab": "POLMAS",
                "nama_produk": "RETENTION",
                "WO": 116945876,
                "RUGI_TB": 9739968,
                "NCL": 1.69
            },
            {
                "nmcab": "PONTIANAK",
                "nama_produk": "KPM",
                "WO": 46921932,
                "RUGI_TB": 0,
                "NCL": 1.68
            },
            {
                "nmcab": "PONTIANAK",
                "nama_produk": "RETENTION",
                "WO": 8519110,
                "RUGI_TB": -2398717,
                "NCL": 0.48
            },
            {
                "nmcab": "POSO",
                "nama_produk": "AISI",
                "WO": 206862440,
                "RUGI_TB": 35560537,
                "NCL": 0.74
            },
            {
                "nmcab": "POSO",
                "nama_produk": "KPM",
                "WO": 35531820,
                "RUGI_TB": -8641253,
                "NCL": 0.34
            },
            {
                "nmcab": "POSO",
                "nama_produk": "RETENTION",
                "WO": 28880991,
                "RUGI_TB": 10372706,
                "NCL": 0.25
            },
            {
                "nmcab": "PRABUMULIH",
                "nama_produk": "AISI",
                "WO": 841179869,
                "RUGI_TB": 205132003,
                "NCL": 4.68
            },
            {
                "nmcab": "PRABUMULIH",
                "nama_produk": "KPM",
                "WO": 19439410,
                "RUGI_TB": 8782987,
                "NCL": 1.04
            },
            {
                "nmcab": "PRABUMULIH",
                "nama_produk": "RETENTION",
                "WO": 39657446,
                "RUGI_TB": 8394288,
                "NCL": 1.54
            },
            {
                "nmcab": "PRINGSEWU",
                "nama_produk": "AISI",
                "WO": 399744416,
                "RUGI_TB": 121828875,
                "NCL": 2.93
            },
            {
                "nmcab": "PRINGSEWU",
                "nama_produk": "KPM",
                "WO": 6981177,
                "RUGI_TB": 0,
                "NCL": 0.31
            },
            {
                "nmcab": "PRINGSEWU",
                "nama_produk": "RETENTION",
                "WO": 38249804,
                "RUGI_TB": -2531737,
                "NCL": 0.73
            },
            {
                "nmcab": "PROBOLINGGO",
                "nama_produk": "KPM",
                "WO": 37422896,
                "RUGI_TB": -2853984,
                "NCL": 0.56
            },
            {
                "nmcab": "PROBOLINGGO",
                "nama_produk": "RETENTION",
                "WO": 88089954,
                "RUGI_TB": 0,
                "NCL": 2.87
            },
            {
                "nmcab": "PUNGGALUKU",
                "nama_produk": "AISI",
                "WO": 165256509,
                "RUGI_TB": 117341395,
                "NCL": 1.04
            },
            {
                "nmcab": "PUNGGALUKU",
                "nama_produk": "KPM",
                "WO": 13239754,
                "RUGI_TB": -4785795,
                "NCL": 0.17
            },
            {
                "nmcab": "PUNGGALUKU",
                "nama_produk": "RETENTION",
                "WO": 19245080,
                "RUGI_TB": -7784713,
                "NCL": 0.15
            },
            {
                "nmcab": "PURWAKARTA",
                "nama_produk": "AISI",
                "WO": 734874685,
                "RUGI_TB": 51950249,
                "NCL": 4.91
            },
            {
                "nmcab": "PURWAKARTA",
                "nama_produk": "KPM",
                "WO": 325252343,
                "RUGI_TB": -25349595,
                "NCL": 2.3
            },
            {
                "nmcab": "PURWAKARTA",
                "nama_produk": "RETENTION",
                "WO": 185662968,
                "RUGI_TB": 20107214,
                "NCL": 1.98
            },
            {
                "nmcab": "PURWOKERTO",
                "nama_produk": "KPM",
                "WO": 146585627,
                "RUGI_TB": 7434891,
                "NCL": 1.26
            },
            {
                "nmcab": "PURWOKERTO",
                "nama_produk": "RETENTION",
                "WO": 52251967,
                "RUGI_TB": 4301705,
                "NCL": 1.65
            },
            {
                "nmcab": "RAHA",
                "nama_produk": "AISI",
                "WO": 200010174,
                "RUGI_TB": 65865734,
                "NCL": 1.16
            },
            {
                "nmcab": "RAHA",
                "nama_produk": "KPM",
                "WO": 122496212,
                "RUGI_TB": 12835581,
                "NCL": 2.12
            },
            {
                "nmcab": "RAHA",
                "nama_produk": "RETENTION",
                "WO": 170915309,
                "RUGI_TB": 34035074,
                "NCL": 1.7
            },
            {
                "nmcab": "RATAHAN",
                "nama_produk": "AISI",
                "WO": 2068287046,
                "RUGI_TB": 114474012,
                "NCL": 6.2
            },
            {
                "nmcab": "RATAHAN",
                "nama_produk": "KPM",
                "WO": 355813200,
                "RUGI_TB": -6288446,
                "NCL": 4.28
            },
            {
                "nmcab": "RATAHAN",
                "nama_produk": "RETENTION",
                "WO": 594139247,
                "RUGI_TB": 15008099,
                "NCL": 4.11
            },
            {
                "nmcab": "RAWAJITU",
                "nama_produk": "AISI",
                "WO": 60278518,
                "RUGI_TB": 13594637,
                "NCL": 0.83
            },
            {
                "nmcab": "RAWAJITU",
                "nama_produk": "KPM",
                "WO": 1886432,
                "RUGI_TB": -2038256,
                "NCL": 0
            },
            {
                "nmcab": "RAWAJITU",
                "nama_produk": "RETENTION",
                "WO": 11044189,
                "RUGI_TB": 0,
                "NCL": 0.26
            },
            {
                "nmcab": "RUMBIA",
                "nama_produk": "AISI",
                "WO": 320959777,
                "RUGI_TB": 56365475,
                "NCL": 3.88
            },
            {
                "nmcab": "RUMBIA",
                "nama_produk": "KPM",
                "WO": 59001182,
                "RUGI_TB": -5383411,
                "NCL": 1.55
            },
            {
                "nmcab": "RUMBIA",
                "nama_produk": "RETENTION",
                "WO": 72506045,
                "RUGI_TB": 880213,
                "NCL": 1.45
            },
            {
                "nmcab": "RUTENG",
                "nama_produk": "AISI",
                "WO": 5957646,
                "RUGI_TB": 2791161,
                "NCL": 0.74
            },
            {
                "nmcab": "RUTENG",
                "nama_produk": "KPM",
                "WO": 3318000,
                "RUGI_TB": 7313486,
                "NCL": 0.2
            },
            {
                "nmcab": "RUTENG",
                "nama_produk": "RETENTION",
                "WO": 9624278,
                "RUGI_TB": 12366820,
                "NCL": 0.45
            },
            {
                "nmcab": "SABAK",
                "nama_produk": "AISI",
                "WO": 362481927,
                "RUGI_TB": 26116335,
                "NCL": 3.86
            },
            {
                "nmcab": "SABAK",
                "nama_produk": "KPM",
                "WO": 117540217,
                "RUGI_TB": 26564,
                "NCL": 6.7
            },
            {
                "nmcab": "SABAK",
                "nama_produk": "RETENTION",
                "WO": 87170714,
                "RUGI_TB": -3646139,
                "NCL": 2.83
            },
            {
                "nmcab": "SALAKAN",
                "nama_produk": "AISI",
                "WO": 37063158,
                "RUGI_TB": 151047725,
                "NCL": 0.51
            },
            {
                "nmcab": "SALAKAN",
                "nama_produk": "KPM",
                "WO": 2091911,
                "RUGI_TB": -3436469,
                "NCL": -0.02
            },
            {
                "nmcab": "SALAKAN",
                "nama_produk": "RETENTION",
                "WO": 16142408,
                "RUGI_TB": 2402479,
                "NCL": 0.12
            },
            {
                "nmcab": "SAMARINDA",
                "nama_produk": "AISI",
                "WO": 668622337,
                "RUGI_TB": 95973165,
                "NCL": 2.34
            },
            {
                "nmcab": "SAMARINDA",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "SAMARINDA",
                "nama_produk": "RETENTION",
                "WO": 25597481,
                "RUGI_TB": 6364401,
                "NCL": 0.38
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "nama_produk": "AISI",
                "WO": 312950433,
                "RUGI_TB": 33374499,
                "NCL": 2.54
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "nama_produk": "KPM",
                "WO": 22818449,
                "RUGI_TB": 6508923,
                "NCL": 0.66
            },
            {
                "nmcab": "SAMARINDA SEBERANG",
                "nama_produk": "RETENTION",
                "WO": 10070840,
                "RUGI_TB": 8857367,
                "NCL": 0.3
            },
            {
                "nmcab": "SAMPIT",
                "nama_produk": "AISI",
                "WO": 271403690,
                "RUGI_TB": 38501137,
                "NCL": 1.9
            },
            {
                "nmcab": "SAMPIT",
                "nama_produk": "KPM",
                "WO": 7275714,
                "RUGI_TB": 1789,
                "NCL": 0.19
            },
            {
                "nmcab": "SAMPIT",
                "nama_produk": "RETENTION",
                "WO": 26435764,
                "RUGI_TB": 2818040,
                "NCL": 0.82
            },
            {
                "nmcab": "SANGATTA",
                "nama_produk": "AISI",
                "WO": 432166544,
                "RUGI_TB": 15132334,
                "NCL": 1.32
            },
            {
                "nmcab": "SANGATTA",
                "nama_produk": "KPM",
                "WO": 27019963,
                "RUGI_TB": 0,
                "NCL": 0.65
            },
            {
                "nmcab": "SANGATTA",
                "nama_produk": "RETENTION",
                "WO": 4589837,
                "RUGI_TB": 443770,
                "NCL": 0.08
            },
            {
                "nmcab": "SAUMLAKI",
                "nama_produk": "AISI",
                "WO": 21116643,
                "RUGI_TB": 55220315,
                "NCL": 2.6
            },
            {
                "nmcab": "SAUMLAKI",
                "nama_produk": "KPM",
                "WO": 107275178,
                "RUGI_TB": 31009973,
                "NCL": 2.31
            },
            {
                "nmcab": "SAUMLAKI",
                "nama_produk": "RETENTION",
                "WO": 166034124,
                "RUGI_TB": 161329061,
                "NCL": 3.27
            },
            {
                "nmcab": "SEKAYU",
                "nama_produk": "AISI",
                "WO": 354067602,
                "RUGI_TB": 4555790,
                "NCL": 4.14
            },
            {
                "nmcab": "SEKAYU",
                "nama_produk": "KPM",
                "WO": 45255098,
                "RUGI_TB": 0,
                "NCL": 4.61
            },
            {
                "nmcab": "SEKAYU",
                "nama_produk": "RETENTION",
                "WO": 39054194,
                "RUGI_TB": 2066682,
                "NCL": 1.8
            },
            {
                "nmcab": "SELAYAR",
                "nama_produk": "AISI",
                "WO": 24846048,
                "RUGI_TB": 87386408,
                "NCL": 0.56
            },
            {
                "nmcab": "SELAYAR",
                "nama_produk": "KPM",
                "WO": 10385159,
                "RUGI_TB": -6217263,
                "NCL": 0.09
            },
            {
                "nmcab": "SELAYAR",
                "nama_produk": "RETENTION",
                "WO": 11561371,
                "RUGI_TB": 2266275,
                "NCL": 0.13
            },
            {
                "nmcab": "SEMARANG",
                "nama_produk": "KPM",
                "WO": 617678468,
                "RUGI_TB": -4367395,
                "NCL": 2.09
            },
            {
                "nmcab": "SEMARANG",
                "nama_produk": "RETENTION",
                "WO": 132494442,
                "RUGI_TB": -1103344,
                "NCL": 1.07
            },
            {
                "nmcab": "SENGKANG",
                "nama_produk": "AISI",
                "WO": 663095167,
                "RUGI_TB": 208320175,
                "NCL": 1.74
            },
            {
                "nmcab": "SENGKANG",
                "nama_produk": "KPM",
                "WO": 45878310,
                "RUGI_TB": -585884,
                "NCL": 1.65
            },
            {
                "nmcab": "SENGKANG",
                "nama_produk": "RETENTION",
                "WO": 39678303,
                "RUGI_TB": -8441267,
                "NCL": 0.41
            },
            {
                "nmcab": "SERANG",
                "nama_produk": "AISI",
                "WO": 330902624,
                "RUGI_TB": -1178680,
                "NCL": 2.1
            },
            {
                "nmcab": "SERANG",
                "nama_produk": "KPM",
                "WO": 51683334,
                "RUGI_TB": 3984359,
                "NCL": 0.93
            },
            {
                "nmcab": "SERANG",
                "nama_produk": "RETENTION",
                "WO": 68602879,
                "RUGI_TB": 6201602,
                "NCL": 1.02
            },
            {
                "nmcab": "SIAU",
                "nama_produk": "AISI",
                "WO": 10925858,
                "RUGI_TB": 0,
                "NCL": 0.17
            },
            {
                "nmcab": "SIAU",
                "nama_produk": "KPM",
                "WO": 5154947,
                "RUGI_TB": -117315,
                "NCL": 0.18
            },
            {
                "nmcab": "SIAU",
                "nama_produk": "RETENTION",
                "WO": 8048642,
                "RUGI_TB": 1017634,
                "NCL": 0.14
            },
            {
                "nmcab": "SIDOARJO",
                "nama_produk": "KPM",
                "WO": 209257036,
                "RUGI_TB": -6010423,
                "NCL": 2.12
            },
            {
                "nmcab": "SIDOARJO",
                "nama_produk": "RETENTION",
                "WO": 286214327,
                "RUGI_TB": 892194,
                "NCL": 3.49
            },
            {
                "nmcab": "SIDRAP",
                "nama_produk": "AISI",
                "WO": 1194453145,
                "RUGI_TB": 81386884,
                "NCL": 2.39
            },
            {
                "nmcab": "SIDRAP",
                "nama_produk": "KPM",
                "WO": 69429326,
                "RUGI_TB": 7937412,
                "NCL": 2.48
            },
            {
                "nmcab": "SIDRAP",
                "nama_produk": "RETENTION",
                "WO": 196035718,
                "RUGI_TB": -966108,
                "NCL": 1.86
            },
            {
                "nmcab": "SIGLI",
                "nama_produk": "AISI",
                "WO": 252391348,
                "RUGI_TB": 189388922,
                "NCL": 2.65
            },
            {
                "nmcab": "SIGLI",
                "nama_produk": "KPM",
                "WO": 4054156,
                "RUGI_TB": 9233204,
                "NCL": 0.49
            },
            {
                "nmcab": "SIGLI",
                "nama_produk": "RETENTION",
                "WO": 33764359,
                "RUGI_TB": 29124730,
                "NCL": 0.98
            },
            {
                "nmcab": "SIJUNGJUNG",
                "nama_produk": "AISI",
                "WO": 207659241,
                "RUGI_TB": 128842216,
                "NCL": 1.33
            },
            {
                "nmcab": "SIJUNGJUNG",
                "nama_produk": "KPM",
                "WO": 13967990,
                "RUGI_TB": 0,
                "NCL": 1.16
            },
            {
                "nmcab": "SIJUNGJUNG",
                "nama_produk": "RETENTION",
                "WO": 21259955,
                "RUGI_TB": 0,
                "NCL": 1.43
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "nama_produk": "AISI",
                "WO": 84311948,
                "RUGI_TB": 977376,
                "NCL": 1.45
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "nama_produk": "KPM",
                "WO": 2312826,
                "RUGI_TB": -3542675,
                "NCL": -0.03
            },
            {
                "nmcab": "SIMPANG PEMATANG",
                "nama_produk": "RETENTION",
                "WO": 2859000,
                "RUGI_TB": 7821755,
                "NCL": 0.45
            },
            {
                "nmcab": "SINJAI",
                "nama_produk": "AISI",
                "WO": 273602080,
                "RUGI_TB": 156003492,
                "NCL": 2.12
            },
            {
                "nmcab": "SINJAI",
                "nama_produk": "KPM",
                "WO": 80128111,
                "RUGI_TB": 487,
                "NCL": 2.44
            },
            {
                "nmcab": "SINJAI",
                "nama_produk": "RETENTION",
                "WO": 127962100,
                "RUGI_TB": 26774340,
                "NCL": 2.26
            },
            {
                "nmcab": "SOLO",
                "nama_produk": "KPM",
                "WO": 197523685,
                "RUGI_TB": -1547996,
                "NCL": 1.82
            },
            {
                "nmcab": "SOLO",
                "nama_produk": "RETENTION",
                "WO": 241557505,
                "RUGI_TB": 1381919,
                "NCL": 2.27
            },
            {
                "nmcab": "SOLOK",
                "nama_produk": "AISI",
                "WO": 333913727,
                "RUGI_TB": 116697655,
                "NCL": 2.53
            },
            {
                "nmcab": "SOLOK",
                "nama_produk": "KPM",
                "WO": 84806683,
                "RUGI_TB": 20096901,
                "NCL": 3.9
            },
            {
                "nmcab": "SOLOK",
                "nama_produk": "RETENTION",
                "WO": 83926812,
                "RUGI_TB": 23994386,
                "NCL": 3.29
            },
            {
                "nmcab": "SOPPENG",
                "nama_produk": "AISI",
                "WO": 247398828,
                "RUGI_TB": 38959472,
                "NCL": 0.94
            },
            {
                "nmcab": "SOPPENG",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "SOPPENG",
                "nama_produk": "RETENTION",
                "WO": 6306693,
                "RUGI_TB": -4697385,
                "NCL": 0.04
            },
            {
                "nmcab": "SOROLANGON",
                "nama_produk": "KPM",
                "WO": 2389154,
                "RUGI_TB": 0,
                "NCL": 7.35
            },
            {
                "nmcab": "SOROLANGON",
                "nama_produk": "RETENTION",
                "WO": 32165697,
                "RUGI_TB": 0,
                "NCL": 44.48
            },
            {
                "nmcab": "SORONG",
                "nama_produk": "AISI",
                "WO": 1222207,
                "RUGI_TB": 113483487,
                "NCL": 1.15
            },
            {
                "nmcab": "SORONG",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": -11363359,
                "NCL": -1.7
            },
            {
                "nmcab": "SORONG",
                "nama_produk": "RETENTION",
                "WO": 19393023,
                "RUGI_TB": 4573803,
                "NCL": 0.88
            },
            {
                "nmcab": "SRAGEN",
                "nama_produk": "KPM",
                "WO": 36242338,
                "RUGI_TB": 7116665,
                "NCL": 0.72
            },
            {
                "nmcab": "SRAGEN",
                "nama_produk": "RETENTION",
                "WO": 62368377,
                "RUGI_TB": 35016802,
                "NCL": 1.26
            },
            {
                "nmcab": "SUBANG",
                "nama_produk": "AISI",
                "WO": 418395678,
                "RUGI_TB": 0,
                "NCL": 8.79
            },
            {
                "nmcab": "SUBANG",
                "nama_produk": "KPM",
                "WO": 430806413,
                "RUGI_TB": -30077190,
                "NCL": 5.69
            },
            {
                "nmcab": "SUBANG",
                "nama_produk": "RETENTION",
                "WO": 255498767,
                "RUGI_TB": -5621192,
                "NCL": 3.5
            },
            {
                "nmcab": "SUKABUMI",
                "nama_produk": "AISI",
                "WO": 565873145,
                "RUGI_TB": 51017078,
                "NCL": 6.24
            },
            {
                "nmcab": "SUKABUMI",
                "nama_produk": "KPM",
                "WO": 167050961,
                "RUGI_TB": 16746127,
                "NCL": 2.07
            },
            {
                "nmcab": "SUKABUMI",
                "nama_produk": "RETENTION",
                "WO": 239149262,
                "RUGI_TB": 96436869,
                "NCL": 3.4
            },
            {
                "nmcab": "SUMBAWA",
                "nama_produk": "AISI",
                "WO": 36809146,
                "RUGI_TB": 0,
                "NCL": 15.31
            },
            {
                "nmcab": "SUMBAWA",
                "nama_produk": "KPM",
                "WO": 108746201,
                "RUGI_TB": 0,
                "NCL": 3.02
            },
            {
                "nmcab": "SUMBAWA",
                "nama_produk": "RETENTION",
                "WO": 33671535,
                "RUGI_TB": 0,
                "NCL": 0.97
            },
            {
                "nmcab": "SUMEDANG",
                "nama_produk": "AISI",
                "WO": 366912698,
                "RUGI_TB": 5360909,
                "NCL": 7.54
            },
            {
                "nmcab": "SUMEDANG",
                "nama_produk": "KPM",
                "WO": 137593398,
                "RUGI_TB": 4327607,
                "NCL": 2.39
            },
            {
                "nmcab": "SUMEDANG",
                "nama_produk": "RETENTION",
                "WO": 386723357,
                "RUGI_TB": 16358948,
                "NCL": 3.83
            },
            {
                "nmcab": "SUNGAI LIAT",
                "nama_produk": "AISI",
                "WO": 37983449,
                "RUGI_TB": 53563320,
                "NCL": 0.54
            },
            {
                "nmcab": "SUNGAI LIAT",
                "nama_produk": "KPM",
                "WO": 15128662,
                "RUGI_TB": 0,
                "NCL": 0.73
            },
            {
                "nmcab": "SUNGAI LIAT",
                "nama_produk": "RETENTION",
                "WO": 31342808,
                "RUGI_TB": -2056727,
                "NCL": 1.14
            },
            {
                "nmcab": "SUNGAI LILIN",
                "nama_produk": "AISI",
                "WO": 310775422,
                "RUGI_TB": 56205842,
                "NCL": 1.43
            },
            {
                "nmcab": "SUNGAI LILIN",
                "nama_produk": "KPM",
                "WO": 31858640,
                "RUGI_TB": 0,
                "NCL": 0.52
            },
            {
                "nmcab": "SUNGAI LILIN",
                "nama_produk": "RETENTION",
                "WO": 34574262,
                "RUGI_TB": 9851798,
                "NCL": 0.52
            },
            {
                "nmcab": "SURABAYA",
                "nama_produk": "KPM",
                "WO": 92893837,
                "RUGI_TB": 0,
                "NCL": 1.5
            },
            {
                "nmcab": "SURABAYA",
                "nama_produk": "RETENTION",
                "WO": 53952086,
                "RUGI_TB": 890396,
                "NCL": 1.08
            },
            {
                "nmcab": "TAHUNA",
                "nama_produk": "AISI",
                "WO": 33586083,
                "RUGI_TB": 8089560,
                "NCL": 0.33
            },
            {
                "nmcab": "TAHUNA",
                "nama_produk": "KPM",
                "WO": 14331288,
                "RUGI_TB": 12365444,
                "NCL": 0.62
            },
            {
                "nmcab": "TAHUNA",
                "nama_produk": "RETENTION",
                "WO": 36342429,
                "RUGI_TB": 16576188,
                "NCL": 0.56
            },
            {
                "nmcab": "TAKALAR",
                "nama_produk": "AISI",
                "WO": 549933716,
                "RUGI_TB": 220326352,
                "NCL": 1.34
            },
            {
                "nmcab": "TAKALAR",
                "nama_produk": "KPM",
                "WO": 43278680,
                "RUGI_TB": 11601152,
                "NCL": 0.88
            },
            {
                "nmcab": "TAKALAR",
                "nama_produk": "RETENTION",
                "WO": 96276075,
                "RUGI_TB": 52135089,
                "NCL": 0.73
            },
            {
                "nmcab": "TAKENGON",
                "nama_produk": "AISI",
                "WO": 394306853,
                "RUGI_TB": 483171573,
                "NCL": 2.9
            },
            {
                "nmcab": "TAKENGON",
                "nama_produk": "KPM",
                "WO": 93509766,
                "RUGI_TB": 7879954,
                "NCL": 1.19
            },
            {
                "nmcab": "TAKENGON",
                "nama_produk": "RETENTION",
                "WO": 55775471,
                "RUGI_TB": 26450898,
                "NCL": 0.72
            },
            {
                "nmcab": "TALAUD",
                "nama_produk": "AISI",
                "WO": 32645138,
                "RUGI_TB": 9036661,
                "NCL": 0.38
            },
            {
                "nmcab": "TALAUD",
                "nama_produk": "KPM",
                "WO": 11550698,
                "RUGI_TB": 1663449,
                "NCL": 0.33
            },
            {
                "nmcab": "TALAUD",
                "nama_produk": "RETENTION",
                "WO": 55298059,
                "RUGI_TB": 10751463,
                "NCL": 0.73
            },
            {
                "nmcab": "TANAH GROGOT",
                "nama_produk": "AISI",
                "WO": 373452504,
                "RUGI_TB": 20869296,
                "NCL": 2.18
            },
            {
                "nmcab": "TANAH GROGOT",
                "nama_produk": "KPM",
                "WO": 2144082,
                "RUGI_TB": 0,
                "NCL": 0.08
            },
            {
                "nmcab": "TANAH GROGOT",
                "nama_produk": "RETENTION",
                "WO": 23009357,
                "RUGI_TB": 8738891,
                "NCL": 0.58
            },
            {
                "nmcab": "TANGERANG",
                "nama_produk": "AISI",
                "WO": 481993491,
                "RUGI_TB": 47874643,
                "NCL": 2.02
            },
            {
                "nmcab": "TANGERANG",
                "nama_produk": "KPM",
                "WO": 35936126,
                "RUGI_TB": 8188037,
                "NCL": 0.53
            },
            {
                "nmcab": "TANGERANG",
                "nama_produk": "RETENTION",
                "WO": 50721885,
                "RUGI_TB": 12444218,
                "NCL": 0.64
            },
            {
                "nmcab": "TANGGEUNG",
                "nama_produk": "AISI",
                "WO": 38505835,
                "RUGI_TB": 33987091,
                "NCL": 1.38
            },
            {
                "nmcab": "TANGGEUNG",
                "nama_produk": "KPM",
                "WO": 56140437,
                "RUGI_TB": 17479160,
                "NCL": 0.75
            },
            {
                "nmcab": "TANGGEUNG",
                "nama_produk": "RETENTION",
                "WO": 16480088,
                "RUGI_TB": 9774702,
                "NCL": 0.47
            },
            {
                "nmcab": "TANJUNG",
                "nama_produk": "AISI",
                "WO": 950850729,
                "RUGI_TB": 76747749,
                "NCL": 5.73
            },
            {
                "nmcab": "TANJUNG",
                "nama_produk": "KPM",
                "WO": 61547076,
                "RUGI_TB": 1801004,
                "NCL": 1.82
            },
            {
                "nmcab": "TANJUNG",
                "nama_produk": "RETENTION",
                "WO": 148333526,
                "RUGI_TB": -3134449,
                "NCL": 2.45
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "nama_produk": "AISI",
                "WO": 354018413,
                "RUGI_TB": 73164567,
                "NCL": 4.11
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "nama_produk": "KPM",
                "WO": 45066902,
                "RUGI_TB": -8713371,
                "NCL": 0.98
            },
            {
                "nmcab": "TANJUNG BINTANG",
                "nama_produk": "RETENTION",
                "WO": 43184804,
                "RUGI_TB": 1120684,
                "NCL": 1.51
            },
            {
                "nmcab": "TARAKAN",
                "nama_produk": "AISI",
                "WO": 119602270,
                "RUGI_TB": 4111899,
                "NCL": 2.22
            },
            {
                "nmcab": "TARAKAN",
                "nama_produk": "KPM",
                "WO": 20213454,
                "RUGI_TB": -650283,
                "NCL": 0.43
            },
            {
                "nmcab": "TARAKAN",
                "nama_produk": "RETENTION",
                "WO": 21902878,
                "RUGI_TB": 174618,
                "NCL": 0.69
            },
            {
                "nmcab": "TASIKMALAYA",
                "nama_produk": "AISI",
                "WO": 818505588,
                "RUGI_TB": 32851218,
                "NCL": 6.95
            },
            {
                "nmcab": "TASIKMALAYA",
                "nama_produk": "KPM",
                "WO": 137669237,
                "RUGI_TB": 1625738,
                "NCL": 1.68
            },
            {
                "nmcab": "TASIKMALAYA",
                "nama_produk": "RETENTION",
                "WO": 223998922,
                "RUGI_TB": 25635450,
                "NCL": 1.97
            },
            {
                "nmcab": "TEBO",
                "nama_produk": "AISI",
                "WO": 440063120,
                "RUGI_TB": 17486934,
                "NCL": 4.99
            },
            {
                "nmcab": "TEBO",
                "nama_produk": "KPM",
                "WO": 125820208,
                "RUGI_TB": -750488,
                "NCL": 6.65
            },
            {
                "nmcab": "TEBO",
                "nama_produk": "RETENTION",
                "WO": 155155122,
                "RUGI_TB": -2840992,
                "NCL": 7.03
            },
            {
                "nmcab": "TEGAL",
                "nama_produk": "KPM",
                "WO": 312391009,
                "RUGI_TB": 4248108,
                "NCL": 2.73
            },
            {
                "nmcab": "TEGAL",
                "nama_produk": "RETENTION",
                "WO": 218517688,
                "RUGI_TB": 8095313,
                "NCL": 4.13
            },
            {
                "nmcab": "TEMANGGUNG",
                "nama_produk": "KPM",
                "WO": 193291389,
                "RUGI_TB": 1382636,
                "NCL": 1.27
            },
            {
                "nmcab": "TEMANGGUNG",
                "nama_produk": "RETENTION",
                "WO": 74189590,
                "RUGI_TB": -1874734,
                "NCL": 0.51
            },
            {
                "nmcab": "TENGGARONG",
                "nama_produk": "AISI",
                "WO": 130336126,
                "RUGI_TB": 58086892,
                "NCL": 0.83
            },
            {
                "nmcab": "TENGGARONG",
                "nama_produk": "KPM",
                "WO": 21047127,
                "RUGI_TB": 4687407,
                "NCL": 0.74
            },
            {
                "nmcab": "TENGGARONG",
                "nama_produk": "RETENTION",
                "WO": 0,
                "RUGI_TB": 10748443,
                "NCL": 0.14
            },
            {
                "nmcab": "TENTENA",
                "nama_produk": "AISI",
                "WO": 91196907,
                "RUGI_TB": 14460600,
                "NCL": 0.52
            },
            {
                "nmcab": "TENTENA",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "TENTENA",
                "nama_produk": "RETENTION",
                "WO": 109510641,
                "RUGI_TB": 9513983,
                "NCL": 1.01
            },
            {
                "nmcab": "TERNATE",
                "nama_produk": "AISI",
                "WO": 309387689,
                "RUGI_TB": 10649022,
                "NCL": 0.87
            },
            {
                "nmcab": "TERNATE",
                "nama_produk": "KPM",
                "WO": 57598442,
                "RUGI_TB": -12693337,
                "NCL": 0.53
            },
            {
                "nmcab": "TERNATE",
                "nama_produk": "RETENTION",
                "WO": 164435189,
                "RUGI_TB": 20879869,
                "NCL": 0.7
            },
            {
                "nmcab": "TOBELO",
                "nama_produk": "AISI",
                "WO": 43040993,
                "RUGI_TB": 22214699,
                "NCL": 0.43
            },
            {
                "nmcab": "TOBELO",
                "nama_produk": "KPM",
                "WO": 6809887,
                "RUGI_TB": 0,
                "NCL": 0.15
            },
            {
                "nmcab": "TOBELO",
                "nama_produk": "RETENTION",
                "WO": 25472849,
                "RUGI_TB": 10842168,
                "NCL": 0.37
            },
            {
                "nmcab": "TOBOALI",
                "nama_produk": "AISI",
                "WO": 53941935,
                "RUGI_TB": 24662410,
                "NCL": 0.43
            },
            {
                "nmcab": "TOBOALI",
                "nama_produk": "KPM",
                "WO": 21958158,
                "RUGI_TB": 0,
                "NCL": 2.11
            },
            {
                "nmcab": "TOBOALI",
                "nama_produk": "RETENTION",
                "WO": 10605550,
                "RUGI_TB": 0,
                "NCL": 0.69
            },
            {
                "nmcab": "TOILI",
                "nama_produk": "AISI",
                "WO": 194673998,
                "RUGI_TB": 71062640,
                "NCL": 1.02
            },
            {
                "nmcab": "TOILI",
                "nama_produk": "KPM",
                "WO": 23452758,
                "RUGI_TB": 6218520,
                "NCL": 0.47
            },
            {
                "nmcab": "TOILI",
                "nama_produk": "RETENTION",
                "WO": 90040215,
                "RUGI_TB": 22003911,
                "NCL": 1.01
            },
            {
                "nmcab": "TOLI TOLI",
                "nama_produk": "AISI",
                "WO": 162537824,
                "RUGI_TB": 55792041,
                "NCL": 1.03
            },
            {
                "nmcab": "TOLI TOLI",
                "nama_produk": "KPM",
                "WO": 10174432,
                "RUGI_TB": 5406421,
                "NCL": 0.46
            },
            {
                "nmcab": "TOLI TOLI",
                "nama_produk": "RETENTION",
                "WO": 30169628,
                "RUGI_TB": 633548,
                "NCL": 0.45
            },
            {
                "nmcab": "TOMOHON",
                "nama_produk": "AISI",
                "WO": 1823435291,
                "RUGI_TB": 36683175,
                "NCL": 13.12
            },
            {
                "nmcab": "TOMOHON",
                "nama_produk": "KPM",
                "WO": 184290410,
                "RUGI_TB": -83734,
                "NCL": 12.1
            },
            {
                "nmcab": "TOMOHON",
                "nama_produk": "RETENTION",
                "WO": 258925676,
                "RUGI_TB": 5082604,
                "NCL": 6.42
            },
            {
                "nmcab": "TOMPE",
                "nama_produk": "AISI",
                "WO": 209271622,
                "RUGI_TB": 72640549,
                "NCL": 1.49
            },
            {
                "nmcab": "TOMPE",
                "nama_produk": "KPM",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "TOMPE",
                "nama_produk": "RETENTION",
                "WO": 6641397,
                "RUGI_TB": 181476,
                "NCL": 0.28
            },
            {
                "nmcab": "TOPPOYO",
                "nama_produk": "AISI",
                "WO": 74236182,
                "RUGI_TB": 54640005,
                "NCL": 0.3
            },
            {
                "nmcab": "TOPPOYO",
                "nama_produk": "KPM",
                "WO": 18585261,
                "RUGI_TB": 0,
                "NCL": 0.51
            },
            {
                "nmcab": "TOPPOYO",
                "nama_produk": "RETENTION",
                "WO": 57225753,
                "RUGI_TB": 19127573,
                "NCL": 0.71
            },
            {
                "nmcab": "TORAJA",
                "nama_produk": "AISI",
                "WO": 517976819,
                "RUGI_TB": 283869324,
                "NCL": 1.79
            },
            {
                "nmcab": "TORAJA",
                "nama_produk": "KPM",
                "WO": 47250973,
                "RUGI_TB": -3390594,
                "NCL": 0.92
            },
            {
                "nmcab": "TORAJA",
                "nama_produk": "RETENTION",
                "WO": 168983767,
                "RUGI_TB": 23036521,
                "NCL": 0.94
            },
            {
                "nmcab": "TUAL",
                "nama_produk": "AISI",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            },
            {
                "nmcab": "TUAL",
                "nama_produk": "KPM",
                "WO": 138609859,
                "RUGI_TB": -2590645,
                "NCL": 1.36
            },
            {
                "nmcab": "TUAL",
                "nama_produk": "RETENTION",
                "WO": 196600556,
                "RUGI_TB": -13822372,
                "NCL": 1.42
            },
            {
                "nmcab": "TUGUMULYO",
                "nama_produk": "AISI",
                "WO": 37971592,
                "RUGI_TB": 19614218,
                "NCL": 0.67
            },
            {
                "nmcab": "TUGUMULYO",
                "nama_produk": "KPM",
                "WO": 54507419,
                "RUGI_TB": 4704937,
                "NCL": 1.51
            },
            {
                "nmcab": "TUGUMULYO",
                "nama_produk": "RETENTION",
                "WO": 79686879,
                "RUGI_TB": -1555201,
                "NCL": 2.1
            },
            {
                "nmcab": "TULANG BAWANG",
                "nama_produk": "AISI",
                "WO": 45514509,
                "RUGI_TB": 17745091,
                "NCL": 0.91
            },
            {
                "nmcab": "TULANG BAWANG",
                "nama_produk": "KPM",
                "WO": 3292800,
                "RUGI_TB": -4782308,
                "NCL": -0.03
            },
            {
                "nmcab": "TULANG BAWANG",
                "nama_produk": "RETENTION",
                "WO": 7889469,
                "RUGI_TB": -3937100,
                "NCL": 0.16
            },
            {
                "nmcab": "TULUNGAGUNG",
                "nama_produk": "KPM",
                "WO": 70831829,
                "RUGI_TB": 0,
                "NCL": 1.36
            },
            {
                "nmcab": "TULUNGAGUNG",
                "nama_produk": "RETENTION",
                "WO": 75074331,
                "RUGI_TB": 0,
                "NCL": 2.84
            },
            {
                "nmcab": "TUNGKAL",
                "nama_produk": "AISI",
                "WO": 0,
                "RUGI_TB": -496557,
                "NCL": -0.04
            },
            {
                "nmcab": "TUNGKAL",
                "nama_produk": "KPM",
                "WO": 9610645,
                "RUGI_TB": -8674969,
                "NCL": 0.04
            },
            {
                "nmcab": "TUNGKAL",
                "nama_produk": "RETENTION",
                "WO": 25991013,
                "RUGI_TB": 14429558,
                "NCL": 1.59
            },
            {
                "nmcab": "UJUNG BERUNG",
                "nama_produk": "AISI",
                "WO": 1701080606,
                "RUGI_TB": 12819932,
                "NCL": 16.31
            },
            {
                "nmcab": "UJUNG BERUNG",
                "nama_produk": "KPM",
                "WO": 327520760,
                "RUGI_TB": 1680114,
                "NCL": 6.44
            },
            {
                "nmcab": "UJUNG BERUNG",
                "nama_produk": "RETENTION",
                "WO": 210326947,
                "RUGI_TB": 20175001,
                "NCL": 3.04
            },
            {
                "nmcab": "UJUNG GADING",
                "nama_produk": "AISI",
                "WO": 70847545,
                "RUGI_TB": 65396957,
                "NCL": 0.4
            },
            {
                "nmcab": "UJUNG GADING",
                "nama_produk": "KPM",
                "WO": 12068387,
                "RUGI_TB": -23226418,
                "NCL": -0.53
            },
            {
                "nmcab": "UJUNG GADING",
                "nama_produk": "RETENTION",
                "WO": 24251909,
                "RUGI_TB": 7426007,
                "NCL": 0.93
            },
            {
                "nmcab": "ULEE GLEE",
                "nama_produk": "AISI",
                "WO": 16596570,
                "RUGI_TB": 3613612,
                "NCL": 0.2
            },
            {
                "nmcab": "ULEE GLEE",
                "nama_produk": "KPM",
                "WO": 11530533,
                "RUGI_TB": 0,
                "NCL": 0.55
            },
            {
                "nmcab": "ULEE GLEE",
                "nama_produk": "RETENTION",
                "WO": 1067908,
                "RUGI_TB": 689000,
                "NCL": 0.08
            },
            {
                "nmcab": "UNAAHA",
                "nama_produk": "AISI",
                "WO": 363668736,
                "RUGI_TB": 148544427,
                "NCL": 1.32
            },
            {
                "nmcab": "UNAAHA",
                "nama_produk": "KPM",
                "WO": 22276006,
                "RUGI_TB": -8324691,
                "NCL": 0.42
            },
            {
                "nmcab": "UNAAHA",
                "nama_produk": "RETENTION",
                "WO": 22131641,
                "RUGI_TB": 6507487,
                "NCL": 0.44
            },
            {
                "nmcab": "WAISARISSA",
                "nama_produk": "AISI",
                "WO": 6859492,
                "RUGI_TB": 5083529,
                "NCL": 0.12
            },
            {
                "nmcab": "WAISARISSA",
                "nama_produk": "KPM",
                "WO": 6405164,
                "RUGI_TB": -2795119,
                "NCL": 0.06
            },
            {
                "nmcab": "WAISARISSA",
                "nama_produk": "RETENTION",
                "WO": 42502221,
                "RUGI_TB": -7604642,
                "NCL": 0.27
            },
            {
                "nmcab": "WAY JEPARA",
                "nama_produk": "AISI",
                "WO": 213265424,
                "RUGI_TB": 26097988,
                "NCL": 2.44
            },
            {
                "nmcab": "WAY JEPARA",
                "nama_produk": "KPM",
                "WO": 27834876,
                "RUGI_TB": 0,
                "NCL": 1.17
            },
            {
                "nmcab": "WAY JEPARA",
                "nama_produk": "RETENTION",
                "WO": 32809727,
                "RUGI_TB": 2845351,
                "NCL": 0.68
            },
            {
                "nmcab": "WAY KANAN",
                "nama_produk": "AISI",
                "WO": 173271421,
                "RUGI_TB": 76790871,
                "NCL": 1.32
            },
            {
                "nmcab": "WAY KANAN",
                "nama_produk": "KPM",
                "WO": 984589,
                "RUGI_TB": 1582971,
                "NCL": 0.19
            },
            {
                "nmcab": "WAY KANAN",
                "nama_produk": "RETENTION",
                "WO": 52051743,
                "RUGI_TB": 1941000,
                "NCL": 1.51
            },
            {
                "nmcab": "WONOGIRI",
                "nama_produk": "KPM",
                "WO": 52307537,
                "RUGI_TB": -3725737,
                "NCL": 0.45
            },
            {
                "nmcab": "WONOGIRI",
                "nama_produk": "RETENTION",
                "WO": 39110527,
                "RUGI_TB": -6540029,
                "NCL": 0.4
            },
            {
                "nmcab": "WONOSARI",
                "nama_produk": "KPM",
                "WO": 34935890,
                "RUGI_TB": 1156553,
                "NCL": 0.5
            },
            {
                "nmcab": "WONOSARI",
                "nama_produk": "RETENTION",
                "WO": 42699624,
                "RUGI_TB": -8530807,
                "NCL": 0.54
            },
            {
                "nmcab": "WONOSOBO",
                "nama_produk": "KPM",
                "WO": 94359073,
                "RUGI_TB": 8420906,
                "NCL": 0.66
            },
            {
                "nmcab": "WONOSOBO",
                "nama_produk": "RETENTION",
                "WO": 74250185,
                "RUGI_TB": 9816560,
                "NCL": 0.74
            },
            {
                "nmcab": "YOGYAKARTA",
                "nama_produk": "KPM",
                "WO": 93145880,
                "RUGI_TB": 11428,
                "NCL": 1.16
            },
            {
                "nmcab": "YOGYAKARTA",
                "nama_produk": "RETENTION",
                "WO": 69196859,
                "RUGI_TB": 19288176,
                "NCL": 0.76
            }
        ],
        "columns": [
            { "data": "nmcab" },
            { "data": "nama_produk" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3,4],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableNclParetoCab').DataTable({
        "data":[
            {
                "jenis": "PARETO",
                "WO": 112538748974,
                "RUGI_TB": 20570857250,
                "NCL": 2.71
            },
            {
                "jenis": "NON PARETO",
                "WO": 87132042701,
                "RUGI_TB": 13075123014,
                "NCL": 2.06
            },
            {
                "jenis": "XX",
                "WO": 0,
                "RUGI_TB": 0,
                "NCL": 0
            }
        ],
        "columns": [
            { "data": "jenis" },
            { "data": "WO", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUGI_TB", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "NCL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });
});

</script>