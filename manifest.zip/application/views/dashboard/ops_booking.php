<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>Ops</li>
            <li><a onclick="openView('dashboard/opsBooking')">Booking</a></li>
        </ul>
    </div>

    <div class="row">
    	<div class="col-md-2 form-group mb-3">
            <label for="picker1">Tahun</label>
            <select class="form-control">
                <option value="2021">2021</option>
                <option value="2022" selected>2022</option>
            </select>
        </div>
        <div class="col-md-2 form-group mb-3">
            <label for="picker1">Bulan</label>
            <select class="form-control">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-md-2 pt-4 mb-2">
            <button class="btn btn-primary">Filter</button>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Booking - Rp.</div>
                    <div id="echartBar1" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Booking - Konsumen</div>
                    <div id="echartBar2" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Booking Per Produk - Rp.</div>
                    <div id="echartBar3" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Trend Booking Per Konsumen - Konsumen</div>
                    <div id="echartBar4" style="height: 100%;min-height:140px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Booking - MTD</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Rp. (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRpMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Konsumen (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukKonMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Rp. (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRegRpMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Konsumen (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRegKonMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Rp. (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCluRpMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Konsumen (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCluKonMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Rp. (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCabRpMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Konsumen (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCabKonMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Rp. (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableParetoCabRpMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Konsumen (MTD)</div>
                    <div class="table-responsive">
                        <table id="tableParetoCabKonMtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Bookinng - YTD</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Rp. (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRpYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Produk - Konsumen (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukKonYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Rp. (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRegRpYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Regional - Konsumen (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukRegKonYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Regional</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Rp. (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCluRpYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Per Cluster - Konsumen (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCluKonYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cluster</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Rp. (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCabRpYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:280px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang - Konsumen (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableProdukCabKonYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Cabang</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Rp. (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableParetoCabRpYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:200px;">
                <div class="card-body">
                    <div class="card-title">Per Cabang Pareto - Konsumen (YTD)</div>
                    <div class="table-responsive">
                        <table id="tableParetoCabKonYtd" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Pareto</th>
                                    <th scope="col" style="text-align: right;">Target</th>
                                    <th scope="col" style="text-align: right;">Actual</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Customer Retention Rate (CRR)</h1>

    <div class="row">
    	<div class="col-lg-6 col-sm-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Komposisi % CRR Per Periode Lunas</div>
                    <div id="echartPie1" style="height: 100%;min-height:250px;"></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:340px;">
                <div class="card-body">
                    <div class="card-title">Customer Retention Rate</div>
                    <div class="table-responsive">
                        <table id="tableCrr" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Periode Lunas</th>
                                    <th scope="col" style="text-align: right;">Konsumen Lunas</th>
                                    <th scope="col" style="text-align: right;">RO</th>
                                    <th scope="col" style="text-align: right;">CRR %</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Contact Rate</h1>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card mb-4"  style="height:340px;">
                <div class="card-body">
                    <div class="card-title">Retention - Contact Rate</div>
                    <div class="table-responsive">
                        <table id="tableContactRate" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Keterangan</th>
                                    <th scope="col" style="text-align: right;">Jumlah Kons</th>
                                    <th scope="col" style="text-align: right;">Persen</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Program Marketing</h1>

    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Booking Per Program Marketing</div>
                    <div class="table-responsive">
                        <table id="tableProgramMkt" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Program Marketing</th>
                                    <th scope="col" style="text-align: right;">Total Konsumen</th>
                                    <th scope="col" style="text-align: right;">Total Rp.</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4" style="height:400px;">
                <div class="card-body">
                    <div class="card-title">Program Marketing Per Produk</div>
                    <div class="table-responsive">
                        <table id="tableProdukProgramMkt" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Nama Produk</th>
                                    <th scope="col">Program Marketing</th>
                                    <th scope="col" style="text-align: right;">Total Konsumen</th>
                                    <th scope="col" style="text-align: right;">Total Rupiah</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>
    
    <h1>Dealer</h1>

    <div class="row">
    	<div class="col-lg-6 col-sm-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Booking Rata-rata 3 Bulan</div>
                    <div id="echartPie2" style="height: 100%;min-height:250px;"></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6">
            <div class="card mb-4"  style="height:340px;">
                <div class="card-body">
                    <div class="card-title">Booking Top 100 Dealer</div>
                    <div class="table-responsive">
                        <table id="tableDealerTop" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Nama Vendor</th>
                                    <th scope="col" style="text-align: right;">Rata-rata 3 Bulan</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="separator-breadcrumb border-top"></div>

	<div class="row">
	    <div class="col-lg-12 col-md-12">
            <div class="card mb-4"  style="height:360px;">
                <div class="card-body">
                    <div class="card-title">Produktivitas Team Sales - KPM & Retention</div>
                    <div class="table-responsive">
                        <table id="tableProduktivitas" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Wilayah</th>
                                    <th scope="col">Produk</th>
                                    <th scope="col">Kode Jabatan</th>
                                    <th scope="col" style="text-align: right;">Jumlah Penjual</th>
                                    <th scope="col" style="text-align: right;">Konsumen</th>
                                    <th scope="col" style="text-align: right;">Konsumen/Penjual</th>
                                    <th scope="col" style="text-align: right;">Rupiah</th>
                                    <th scope="col" style="text-align: right;">Rupiah/Penjual</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



</div>

<style>
    .table td {
        padding:0 !important;
    }
    .table th {
        padding:0 !important;
    }
</style>

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/datatables.min.css" />
<script src="<?php echo base_url();?>assets/js/plugins/echarts.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/echart.options.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/datatables.min.js"></script>

<script type="text/javascript">
    "use strict";

function formatPrice(data){
    var num;
    var num1;
    if(data == null) { 
        return '-'; 
    } else { 
        num = Math.round(data);
        if(num.toString().length > 9) {
            num1 = num / 1000000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"B";
        } else if(num.toString().length > 6) {
            num1 = num / 1000000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"M";
        } else if(num.toString().length > 3) {
            num1 = num / 1000;
            return Math.round(num1).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.")+"K";
        } else {
            return Math.round(data).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1."); 
        }
    }
}

$(document).ready(function () {
	$('#tableProdukRpMtd').DataTable({
        "data":[
		    {
		        "nama_produk": "RETENTION",
		        "TARGET": 114774130425,
		        "ACTUAL": 123060134751,
		        "PERSEN": 107.2
		    },
		    {
		        "nama_produk": "AISI",
		        "TARGET": 234483028650,
		        "ACTUAL": 226135833166,
		        "PERSEN": 96.4
		    },
		    {
		        "nama_produk": "KPM",
		        "TARGET": 165934238258,
		        "ACTUAL": 112681961339,
		        "PERSEN": 67.9
		    }
		],
        "columns": [
            { "data": "nama_produk" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukKonMtd').DataTable({
        "data":[
		    {
		        "nama_produk": "AISI",
		        "TARGET": 9328,
		        "ACTUAL": 10141,
		        "PERSEN": 108.7
		    },
		    {
		        "nama_produk": "RETENTION",
		        "TARGET": 12722,
		        "ACTUAL": 13041,
		        "PERSEN": 102.5
		    },
		    {
		        "nama_produk": "KPM",
		        "TARGET": 19306,
		        "ACTUAL": 14013,
		        "PERSEN": 72.6
		    }
		],
        "columns": [
            { "data": "nama_produk" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukRegRpMtd').DataTable({
        "data":[
		  {
		    "regional": "SUMATERA5",
		    "TARGET": 15129650477,
		    "ACTUAL": 23134479299,
		    "PERSEN": 152.9
		  },
		  {
		    "regional": "SULAWESI3",
		    "TARGET": 44687410371,
		    "ACTUAL": 58623498362,
		    "PERSEN": 131.2
		  },
		  {
		    "regional": "ACEH2",
		    "TARGET": 10951852662,
		    "ACTUAL": 10955157981,
		    "PERSEN": 100
		  },
		  {
		    "regional": "JAWABARAT2",
		    "TARGET": 27602191114,
		    "ACTUAL": 27402269004,
		    "PERSEN": 99.3
		  },
		  {
		    "regional": "KALIMANTAN2",
		    "TARGET": 15969146374,
		    "ACTUAL": 15778535767,
		    "PERSEN": 98.8
		  },
		  {
		    "regional": "SULAWESI4",
		    "TARGET": 26051485558,
		    "ACTUAL": 25693738612,
		    "PERSEN": 98.6
		  },
		  {
		    "regional": "JAWABARAT3",
		    "TARGET": 28110954280,
		    "ACTUAL": 27717134032,
		    "PERSEN": 98.6
		  },
		  {
		    "regional": "NUSATENGGARA",
		    "TARGET": 3757309275,
		    "ACTUAL": 3508086380,
		    "PERSEN": 93.4
		  },
		  {
		    "regional": "JAWABARAT1",
		    "TARGET": 22722737670,
		    "ACTUAL": 20948046954,
		    "PERSEN": 92.2
		  },
		  {
		    "regional": "KALIMANTAN1",
		    "TARGET": 18280824706,
		    "ACTUAL": 16816969897,
		    "PERSEN": 92
		  },
		  {
		    "regional": "SULAWESI5",
		    "TARGET": 36991168929,
		    "ACTUAL": 33639783777,
		    "PERSEN": 90.9
		  },
		  {
		    "regional": "SULAWESI1",
		    "TARGET": 54545012288,
		    "ACTUAL": 48744323918,
		    "PERSEN": 89.4
		  },
		  {
		    "regional": "MAPA",
		    "TARGET": 20491828901,
		    "ACTUAL": 17610204133,
		    "PERSEN": 85.9
		  },
		  {
		    "regional": "SUMATERA4",
		    "TARGET": 29880166918,
		    "ACTUAL": 23197765985,
		    "PERSEN": 77.6
		  },
		  {
		    "regional": "ACEH1",
		    "TARGET": 18922048549,
		    "ACTUAL": 14231084857,
		    "PERSEN": 75.2
		  },
		  {
		    "regional": "SULAWESI2",
		    "TARGET": 54649594359,
		    "ACTUAL": 38909240411,
		    "PERSEN": 71.2
		  },
		  {
		    "regional": "SUMATERA6",
		    "TARGET": 20124968813,
		    "ACTUAL": 13937173706,
		    "PERSEN": 69.3
		  },
		  {
		    "regional": "JAWATENGAH",
		    "TARGET": 21860695031,
		    "ACTUAL": 14913644473,
		    "PERSEN": 68.2
		  },
		  {
		    "regional": "SUMATERA2",
		    "TARGET": 9165227789,
		    "ACTUAL": 5477571121,
		    "PERSEN": 59.8
		  },
		  {
		    "regional": "JAWATIMUR",
		    "TARGET": 13033745624,
		    "ACTUAL": 7773546902,
		    "PERSEN": 59.6
		  },
		  {
		    "regional": "SUMATERA3",
		    "TARGET": 22263377645,
		    "ACTUAL": 12865673685,
		    "PERSEN": 57.8
		  }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukRegKonMtd').DataTable({
        "data":[
		    {
		        "regional": "SULAWESI 3",
		        "TARGET": 3248,
		        "ACTUAL": 4258,
		        "PERSEN": 131.0961
		    },
		    {
		        "regional": "SUMATERA 5",
		        "TARGET": 1060,
		        "ACTUAL": 1237,
		        "PERSEN": 116.6981
		    },
		    {
		        "regional": "JAWA BARAT 2",
		        "TARGET": 2604,
		        "ACTUAL": 2907,
		        "PERSEN": 111.6359
		    },
		    {
		        "regional": "KALIMANTAN 1",
		        "TARGET": 1511,
		        "ACTUAL": 1613,
		        "PERSEN": 106.7505
		    },
		    {
		        "regional": "NUSA TENGGARA",
		        "TARGET": 443,
		        "ACTUAL": 466,
		        "PERSEN": 105.1919
		    },
		    {
		        "regional": "KALIMANTAN 2",
		        "TARGET": 1112,
		        "ACTUAL": 1154,
		        "PERSEN": 103.777
		    },
		    {
		        "regional": "SULAWESI 4",
		        "TARGET": 1920,
		        "ACTUAL": 1970,
		        "PERSEN": 102.6042
		    },
		    {
		        "regional": "JAWA BARAT 1",
		        "TARGET": 2121,
		        "ACTUAL": 2018,
		        "PERSEN": 95.1438
		    },
		    {
		        "regional": "SULAWESI 1",
		        "TARGET": 3610,
		        "ACTUAL": 3333,
		        "PERSEN": 92.3269
		    },
		    {
		        "regional": "JAWA BARAT 3",
		        "TARGET": 2409,
		        "ACTUAL": 2218,
		        "PERSEN": 92.0714
		    },
		    {
		        "regional": "ACEH 2",
		        "TARGET": 828,
		        "ACTUAL": 759,
		        "PERSEN": 91.6667
		    },
		    {
		        "regional": "SUMATERA 4",
		        "TARGET": 1913,
		        "ACTUAL": 1693,
		        "PERSEN": 88.4997
		    },
		    {
		        "regional": "SULAWESI 5",
		        "TARGET": 2807,
		        "ACTUAL": 2464,
		        "PERSEN": 87.7805
		    },
		    {
		        "regional": "MAPA",
		        "TARGET": 1545,
		        "ACTUAL": 1323,
		        "PERSEN": 85.6311
		    },
		    {
		        "regional": "SUMATERA 6",
		        "TARGET": 1743,
		        "ACTUAL": 1342,
		        "PERSEN": 76.9937
		    },
		    {
		        "regional": "ACEH 1",
		        "TARGET": 1313,
		        "ACTUAL": 958,
		        "PERSEN": 72.9627
		    },
		    {
		        "regional": "SULAWESI 2",
		        "TARGET": 3764,
		        "ACTUAL": 2728,
		        "PERSEN": 72.4761
		    },
		    {
		        "regional": "SUMATERA 2",
		        "TARGET": 556,
		        "ACTUAL": 373,
		        "PERSEN": 67.0863
		    },
		    {
		        "regional": "JAWA TENGAH",
		        "TARGET": 3311,
		        "ACTUAL": 2189,
		        "PERSEN": 66.113
		    },
		    {
		        "regional": "SUMATERA 3",
		        "TARGET": 1567,
		        "ACTUAL": 980,
		        "PERSEN": 62.5399
		    },
		    {
		        "regional": "JAWA TIMUR",
		        "TARGET": 1971,
		        "ACTUAL": 1212,
		        "PERSEN": 61.4916
		    }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukCluRpMtd').DataTable({
        "data":[
		    {
		        "nmcluster": "JOGYA",
		        "TARGET": 2753523266,
		        "ACTUAL": 3396359265,
		        "PERSEN": 123.3
		    },
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TARGET": 8941036425,
		        "ACTUAL": 10146733760,
		        "PERSEN": 113.5
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TARGET": 18056771904,
		        "ACTUAL": 19944664386,
		        "PERSEN": 110.5
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TARGET": 19595434350,
		        "ACTUAL": 21394224736,
		        "PERSEN": 109.2
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TARGET": 11387254434,
		        "ACTUAL": 12210040823,
		        "PERSEN": 107.2
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TARGET": 4218524355,
		        "ACTUAL": 4502507625,
		        "PERSEN": 106.7
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TARGET": 26570650638,
		        "ACTUAL": 27153790186,
		        "PERSEN": 102.2
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TARGET": 4765487711,
		        "ACTUAL": 4757189227,
		        "PERSEN": 99.8
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TARGET": 11302919887,
		        "ACTUAL": 11246445040,
		        "PERSEN": 99.5
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TARGET": 10494343271,
		        "ACTUAL": 9817809952,
		        "PERSEN": 93.6
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TARGET": 3757309275,
		        "ACTUAL": 3508086380,
		        "PERSEN": 93.4
		    },
		    {
		        "nmcluster": "AMBON",
		        "TARGET": 14953540732,
		        "ACTUAL": 13666427355,
		        "PERSEN": 91.4
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TARGET": 8166811418,
		        "ACTUAL": 7437725292,
		        "PERSEN": 91.1
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TARGET": 13813173694,
		        "ACTUAL": 12199048708,
		        "PERSEN": 88.3
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TARGET": 7404714278,
		        "ACTUAL": 6452117008,
		        "PERSEN": 87.1
		    },
		    {
		        "nmcluster": "MANADO",
		        "TARGET": 11875075348,
		        "ACTUAL": 10194290029,
		        "PERSEN": 85.8
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TARGET": 9423149931,
		        "ACTUAL": 8049611047,
		        "PERSEN": 85.4
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TARGET": 8984554886,
		        "ACTUAL": 7153418767,
		        "PERSEN": 79.6
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TARGET": 3316400411,
		        "ACTUAL": 2639671814,
		        "PERSEN": 79.6
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TARGET": 6132848400,
		        "ACTUAL": 4840009210,
		        "PERSEN": 78.9
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TARGET": 11335483236,
		        "ACTUAL": 8738006131,
		        "PERSEN": 77.1
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TARGET": 8530899674,
		        "ACTUAL": 6388560519,
		        "PERSEN": 74.9
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TARGET": 8515519930,
		        "ACTUAL": 6322909296,
		        "PERSEN": 74.3
		    },
		    {
		        "nmcluster": "BUTON",
		        "TARGET": 7994713654,
		        "ACTUAL": 5749074226,
		        "PERSEN": 71.9
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TARGET": 5538288169,
		        "ACTUAL": 3943776778,
		        "PERSEN": 71.2
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TARGET": 5520663082,
		        "ACTUAL": 3894826090,
		        "PERSEN": 70.5
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TARGET": 7964511785,
		        "ACTUAL": 5579602888,
		        "PERSEN": 70.1
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TARGET": 8606174690,
		        "ACTUAL": 5957672391,
		        "PERSEN": 69.2
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TARGET": 4671829983,
		        "ACTUAL": 3208504191,
		        "PERSEN": 68.7
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TARGET": 6900262318,
		        "ACTUAL": 4586614443,
		        "PERSEN": 66.5
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TARGET": 3453133799,
		        "ACTUAL": 2207829162,
		        "PERSEN": 63.9
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TARGET": 4693806821,
		        "ACTUAL": 2961998744,
		        "PERSEN": 63.1
		    },
		    {
		        "nmcluster": "SOLO",
		        "TARGET": 5687234974,
		        "ACTUAL": 3504981208,
		        "PERSEN": 61.6
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TARGET": 2966829060,
		        "ACTUAL": 1575652000,
		        "PERSEN": 53.1
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TARGET": 3737760558,
		        "ACTUAL": 1908234168,
		        "PERSEN": 51.1
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TARGET": 3384448010,
		        "ACTUAL": 1624165389,
		        "PERSEN": 48
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TARGET": 7287088391,
		        "ACTUAL": 3172294790,
		        "PERSEN": 43.5
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TARGET": 3297382354,
		        "ACTUAL": 1350393926,
		        "PERSEN": 41
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TARGET": 4215537875,
		        "ACTUAL": 1704597141,
		        "PERSEN": 40.4
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableProdukCluKonMtd').DataTable({
        "data":[
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TARGET": 856,
		        "ACTUAL": 1030,
		        "PERSEN": 120.3271
		    },
		    {
		        "nmcluster": "JOGYA",
		        "TARGET": 415,
		        "ACTUAL": 459,
		        "PERSEN": 110.6024
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TARGET": 1310,
		        "ACTUAL": 1439,
		        "PERSEN": 109.8473
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TARGET": 971,
		        "ACTUAL": 1066,
		        "PERSEN": 109.7837
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TARGET": 866,
		        "ACTUAL": 924,
		        "PERSEN": 106.6975
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TARGET": 443,
		        "ACTUAL": 466,
		        "PERSEN": 105.1919
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TARGET": 1089,
		        "ACTUAL": 1144,
		        "PERSEN": 105.0505
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TARGET": 777,
		        "ACTUAL": 811,
		        "PERSEN": 104.3758
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TARGET": 1682,
		        "ACTUAL": 1717,
		        "PERSEN": 102.0809
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TARGET": 1655,
		        "ACTUAL": 1681,
		        "PERSEN": 101.571
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TARGET": 269,
		        "ACTUAL": 259,
		        "PERSEN": 96.2825
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TARGET": 572,
		        "ACTUAL": 550,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TARGET": 392,
		        "ACTUAL": 365,
		        "PERSEN": 93.1122
		    },
		    {
		        "nmcluster": "AMBON",
		        "TARGET": 1209,
		        "ACTUAL": 1113,
		        "PERSEN": 92.0596
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TARGET": 564,
		        "ACTUAL": 507,
		        "PERSEN": 89.8936
		    },
		    {
		        "nmcluster": "BUTON",
		        "TARGET": 610,
		        "ACTUAL": 531,
		        "PERSEN": 87.0492
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TARGET": 1032,
		        "ACTUAL": 874,
		        "PERSEN": 84.6899
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TARGET": 504,
		        "ACTUAL": 409,
		        "PERSEN": 81.1508
		    },
		    {
		        "nmcluster": "MANADO",
		        "TARGET": 844,
		        "ACTUAL": 683,
		        "PERSEN": 80.9242
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TARGET": 590,
		        "ACTUAL": 472,
		        "PERSEN": 80
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TARGET": 615,
		        "ACTUAL": 490,
		        "PERSEN": 79.6748
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TARGET": 370,
		        "ACTUAL": 290,
		        "PERSEN": 78.3784
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TARGET": 555,
		        "ACTUAL": 434,
		        "PERSEN": 78.1982
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TARGET": 1097,
		        "ACTUAL": 857,
		        "PERSEN": 78.1222
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TARGET": 729,
		        "ACTUAL": 559,
		        "PERSEN": 76.6804
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TARGET": 932,
		        "ACTUAL": 685,
		        "PERSEN": 73.4979
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TARGET": 399,
		        "ACTUAL": 293,
		        "PERSEN": 73.4336
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TARGET": 754,
		        "ACTUAL": 537,
		        "PERSEN": 71.2202
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TARGET": 525,
		        "ACTUAL": 364,
		        "PERSEN": 69.3333
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TARGET": 328,
		        "ACTUAL": 227,
		        "PERSEN": 69.2073
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TARGET": 555,
		        "ACTUAL": 369,
		        "PERSEN": 66.4865
		    },
		    {
		        "nmcluster": "SOLO",
		        "TARGET": 866,
		        "ACTUAL": 544,
		        "PERSEN": 62.8176
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TARGET": 336,
		        "ACTUAL": 210,
		        "PERSEN": 62.5
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TARGET": 260,
		        "ACTUAL": 138,
		        "PERSEN": 53.0769
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TARGET": 280,
		        "ACTUAL": 146,
		        "PERSEN": 52.1429
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TARGET": 446,
		        "ACTUAL": 230,
		        "PERSEN": 51.5695
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TARGET": 269,
		        "ACTUAL": 135,
		        "PERSEN": 50.1859
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TARGET": 1098,
		        "ACTUAL": 501,
		        "PERSEN": 45.6284
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TARGET": 496,
		        "ACTUAL": 209,
		        "PERSEN": 42.1371
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableProdukCabRpMtd').DataTable({
        "data":[
		    {
		        "nmcab": "BELINYU",
		        "TARGET": 1331938962,
		        "ACTUAL": 2976288123,
		        "PERSEN": 223.5
		    },
		    {
		        "nmcab": "MOROWALI",
		        "TARGET": 2512836744,
		        "ACTUAL": 5160639107,
		        "PERSEN": 205.4
		    },
		    {
		        "nmcab": "BELITUNG",
		        "TARGET": 2021143020,
		        "ACTUAL": 4123067659,
		        "PERSEN": 204
		    },
		    {
		        "nmcab": "PELABUHAN RATU",
		        "TARGET": 2267680094,
		        "ACTUAL": 4047904508,
		        "PERSEN": 178.5
		    },
		    {
		        "nmcab": "BUOL",
		        "TARGET": 1677323721,
		        "ACTUAL": 2905977099,
		        "PERSEN": 173.3
		    },
		    {
		        "nmcab": "LUWUK",
		        "TARGET": 2143997250,
		        "ACTUAL": 3505946903,
		        "PERSEN": 163.5
		    },
		    {
		        "nmcab": "DOMPU",
		        "TARGET": 432577494,
		        "ACTUAL": 703653768,
		        "PERSEN": 162.7
		    },
		    {
		        "nmcab": "BUNGKU",
		        "TARGET": 3662228764,
		        "ACTUAL": 5797744212,
		        "PERSEN": 158.3
		    },
		    {
		        "nmcab": "MAGELANG",
		        "TARGET": 958407528,
		        "ACTUAL": 1491488000,
		        "PERSEN": 155.6
		    },
		    {
		        "nmcab": "BERAU",
		        "TARGET": 2201563588,
		        "ACTUAL": 3417880159,
		        "PERSEN": 155.2
		    },
		    {
		        "nmcab": "BANGKA",
		        "TARGET": 3251627848,
		        "ACTUAL": 4990141799,
		        "PERSEN": 153.5
		    },
		    {
		        "nmcab": "BELTIM",
		        "TARGET": 1271938914,
		        "ACTUAL": 1949262398,
		        "PERSEN": 153.3
		    },
		    {
		        "nmcab": "UNAAHA",
		        "TARGET": 2302574613,
		        "ACTUAL": 3501370761,
		        "PERSEN": 152.1
		    },
		    {
		        "nmcab": "POSO",
		        "TARGET": 2144720976,
		        "ACTUAL": 3209990223,
		        "PERSEN": 149.7
		    },
		    {
		        "nmcab": "KENDARI",
		        "TARGET": 4639021904,
		        "ACTUAL": 6856937213,
		        "PERSEN": 147.8
		    },
		    {
		        "nmcab": "BARABAI",
		        "TARGET": 622503852,
		        "ACTUAL": 899521126,
		        "PERSEN": 144.5
		    },
		    {
		        "nmcab": "TOMPE",
		        "TARGET": 925886365,
		        "ACTUAL": 1297310351,
		        "PERSEN": 140.1
		    },
		    {
		        "nmcab": "KELAPA",
		        "TARGET": 1154387372,
		        "ACTUAL": 1603885706,
		        "PERSEN": 138.9
		    },
		    {
		        "nmcab": "SALAKAN",
		        "TARGET": 2143191146,
		        "ACTUAL": 2924834359,
		        "PERSEN": 136.5
		    },
		    {
		        "nmcab": "TOBOALI",
		        "TARGET": 1458377984,
		        "ACTUAL": 1976966134,
		        "PERSEN": 135.6
		    },
		    {
		        "nmcab": "KOBA",
		        "TARGET": 1050591831,
		        "ACTUAL": 1424113665,
		        "PERSEN": 135.6
		    },
		    {
		        "nmcab": "GORONTALO",
		        "TARGET": 5458846968,
		        "ACTUAL": 7259923666,
		        "PERSEN": 133
		    },
		    {
		        "nmcab": "PALU",
		        "TARGET": 8107678260,
		        "ACTUAL": 10707851771,
		        "PERSEN": 132.1
		    },
		    {
		        "nmcab": "BIREUEN",
		        "TARGET": 1687215096,
		        "ACTUAL": 2211562156,
		        "PERSEN": 131.1
		    },
		    {
		        "nmcab": "YOGYAKARTA",
		        "TARGET": 965378270,
		        "ACTUAL": 1250939265,
		        "PERSEN": 129.6
		    },
		    {
		        "nmcab": "CIMAHI",
		        "TARGET": 2485324332,
		        "ACTUAL": 3216432599,
		        "PERSEN": 129.4
		    },
		    {
		        "nmcab": "PANGANDARAN",
		        "TARGET": 1421690980,
		        "ACTUAL": 1825589961,
		        "PERSEN": 128.4
		    },
		    {
		        "nmcab": "SUMEDANG",
		        "TARGET": 1603107655,
		        "ACTUAL": 2057929918,
		        "PERSEN": 128.4
		    },
		    {
		        "nmcab": "PALU 2",
		        "TARGET": 5097631770,
		        "ACTUAL": 6535057492,
		        "PERSEN": 128.2
		    },
		    {
		        "nmcab": "CIAWI",
		        "TARGET": 985853930,
		        "ACTUAL": 1248802542,
		        "PERSEN": 126.7
		    },
		    {
		        "nmcab": "BANDUNG",
		        "TARGET": 1729092176,
		        "ACTUAL": 2181836051,
		        "PERSEN": 126.2
		    },
		    {
		        "nmcab": "TOLI TOLI",
		        "TARGET": 1712994096,
		        "ACTUAL": 2134184865,
		        "PERSEN": 124.6
		    },
		    {
		        "nmcab": "KOTA FAJAR",
		        "TARGET": 2397046295,
		        "ACTUAL": 2975633130,
		        "PERSEN": 124.1
		    },
		    {
		        "nmcab": "CILEUNGSI",
		        "TARGET": 3616072952,
		        "ACTUAL": 4346022154,
		        "PERSEN": 120.2
		    },
		    {
		        "nmcab": "JEBUS",
		        "TARGET": 981002722,
		        "ACTUAL": 1166863204,
		        "PERSEN": 118.9
		    },
		    {
		        "nmcab": "BEKASI",
		        "TARGET": 5952588440,
		        "ACTUAL": 7021953144,
		        "PERSEN": 118
		    },
		    {
		        "nmcab": "BATU LICIN",
		        "TARGET": 1781946480,
		        "ACTUAL": 2095054711,
		        "PERSEN": 117.6
		    },
		    {
		        "nmcab": "PARIGI",
		        "TARGET": 2251788508,
		        "ACTUAL": 2614552161,
		        "PERSEN": 116.1
		    },
		    {
		        "nmcab": "SUNGAI LIAT",
		        "TARGET": 1427891274,
		        "ACTUAL": 1653588678,
		        "PERSEN": 115.8
		    },
		    {
		        "nmcab": "MAKASSAR 3",
		        "TARGET": 6757861770,
		        "ACTUAL": 7814794132,
		        "PERSEN": 115.6
		    },
		    {
		        "nmcab": "MEULABOH",
		        "TARGET": 2725953120,
		        "ACTUAL": 3135707824,
		        "PERSEN": 115
		    },
		    {
		        "nmcab": "MALANG",
		        "TARGET": 1101275324,
		        "ACTUAL": 1265096960,
		        "PERSEN": 114.9
		    },
		    {
		        "nmcab": "PENDOLO",
		        "TARGET": 1165970243,
		        "ACTUAL": 1324237937,
		        "PERSEN": 113.6
		    },
		    {
		        "nmcab": "PURWAKARTA",
		        "TARGET": 2668732560,
		        "ACTUAL": 3030081884,
		        "PERSEN": 113.5
		    },
		    {
		        "nmcab": "KOTARAYA",
		        "TARGET": 1675919056,
		        "ACTUAL": 1898522875,
		        "PERSEN": 113.3
		    },
		    {
		        "nmcab": "MANOKWARI",
		        "TARGET": 2019705888,
		        "ACTUAL": 2267820079,
		        "PERSEN": 112.3
		    },
		    {
		        "nmcab": "SANGATTA",
		        "TARGET": 1969910288,
		        "ACTUAL": 2208522549,
		        "PERSEN": 112.1
		    },
		    {
		        "nmcab": "MASOHI",
		        "TARGET": 2186869786,
		        "ACTUAL": 2437154096,
		        "PERSEN": 111.4
		    },
		    {
		        "nmcab": "TOILI",
		        "TARGET": 1989914680,
		        "ACTUAL": 2199518569,
		        "PERSEN": 110.5
		    },
		    {
		        "nmcab": "BOEPINANG",
		        "TARGET": 1378428696,
		        "ACTUAL": 1521221878,
		        "PERSEN": 110.4
		    },
		    {
		        "nmcab": "TANGGEUNG",
		        "TARGET": 1348932046,
		        "ACTUAL": 1473114244,
		        "PERSEN": 109.2
		    },
		    {
		        "nmcab": "PRINGSEWU",
		        "TARGET": 1198666278,
		        "ACTUAL": 1298932176,
		        "PERSEN": 108.4
		    },
		    {
		        "nmcab": "MENTOK",
		        "TARGET": 1180750550,
		        "ACTUAL": 1270301933,
		        "PERSEN": 107.6
		    },
		    {
		        "nmcab": "CIREBON",
		        "TARGET": 2197528456,
		        "ACTUAL": 2316962312,
		        "PERSEN": 105.4
		    },
		    {
		        "nmcab": "CIANJUR",
		        "TARGET": 2422464564,
		        "ACTUAL": 2509086124,
		        "PERSEN": 103.6
		    },
		    {
		        "nmcab": "GOWA 2",
		        "TARGET": 3793621444,
		        "ACTUAL": 3893886536,
		        "PERSEN": 102.6
		    },
		    {
		        "nmcab": "SEMARANG",
		        "TARGET": 2054482112,
		        "ACTUAL": 2096424348,
		        "PERSEN": 102
		    },
		    {
		        "nmcab": "JAILOLO",
		        "TARGET": 3978047664,
		        "ACTUAL": 4052782699,
		        "PERSEN": 101.9
		    },
		    {
		        "nmcab": "GOWA",
		        "TARGET": 4396791668,
		        "ACTUAL": 4458072584,
		        "PERSEN": 101.4
		    },
		    {
		        "nmcab": "PALANGKARAYA",
		        "TARGET": 1691347748,
		        "ACTUAL": 1714698759,
		        "PERSEN": 101.4
		    },
		    {
		        "nmcab": "PENAJAM",
		        "TARGET": 992168712,
		        "ACTUAL": 1002049683,
		        "PERSEN": 101
		    },
		    {
		        "nmcab": "BOGOR",
		        "TARGET": 2915677316,
		        "ACTUAL": 2942763785,
		        "PERSEN": 100.9
		    },
		    {
		        "nmcab": "SAMARINDA",
		        "TARGET": 2537307862,
		        "ACTUAL": 2551151255,
		        "PERSEN": 100.5
		    },
		    {
		        "nmcab": "TAKALAR",
		        "TARGET": 3402523356,
		        "ACTUAL": 3389437902,
		        "PERSEN": 99.6
		    },
		    {
		        "nmcab": "WAISARISSA",
		        "TARGET": 1321364230,
		        "ACTUAL": 1313513790,
		        "PERSEN": 99.4
		    },
		    {
		        "nmcab": "BAYUNG LENCIR",
		        "TARGET": 2714384020,
		        "ACTUAL": 2686324565,
		        "PERSEN": 99
		    },
		    {
		        "nmcab": "SUBANG",
		        "TARGET": 1229418932,
		        "ACTUAL": 1214343775,
		        "PERSEN": 98.8
		    },
		    {
		        "nmcab": "MAKASSAR 2",
		        "TARGET": 5297180544,
		        "ACTUAL": 5171657478,
		        "PERSEN": 97.6
		    },
		    {
		        "nmcab": "AMBON",
		        "TARGET": 6005945008,
		        "ACTUAL": 5852737246,
		        "PERSEN": 97.4
		    },
		    {
		        "nmcab": "CIBINONG",
		        "TARGET": 2966193076,
		        "ACTUAL": 2889490049,
		        "PERSEN": 97.4
		    },
		    {
		        "nmcab": "PINRANG",
		        "TARGET": 3606209566,
		        "ACTUAL": 3508280713,
		        "PERSEN": 97.3
		    },
		    {
		        "nmcab": "TENTENA",
		        "TARGET": 1483119899,
		        "ACTUAL": 1435348932,
		        "PERSEN": 96.8
		    },
		    {
		        "nmcab": "KARAWANG",
		        "TARGET": 4702812846,
		        "ACTUAL": 4539334032,
		        "PERSEN": 96.5
		    },
		    {
		        "nmcab": "KOTABARU",
		        "TARGET": 1204600937,
		        "ACTUAL": 1160860179,
		        "PERSEN": 96.4
		    },
		    {
		        "nmcab": "BITUNG",
		        "TARGET": 3298504840,
		        "ACTUAL": 3171858685,
		        "PERSEN": 96.2
		    },
		    {
		        "nmcab": "PATROL",
		        "TARGET": 1797764680,
		        "ACTUAL": 1720998347,
		        "PERSEN": 95.7
		    },
		    {
		        "nmcab": "SUNGAI LILIN",
		        "TARGET": 2400035875,
		        "ACTUAL": 2292238182,
		        "PERSEN": 95.5
		    },
		    {
		        "nmcab": "TERNATE",
		        "TARGET": 3617590444,
		        "ACTUAL": 3448533154,
		        "PERSEN": 95.3
		    },
		    {
		        "nmcab": "TUAL",
		        "TARGET": 1227985616,
		        "ACTUAL": 1157685803,
		        "PERSEN": 94.3
		    },
		    {
		        "nmcab": "MAKALE",
		        "TARGET": 2569714200,
		        "ACTUAL": 2412722702,
		        "PERSEN": 93.9
		    },
		    {
		        "nmcab": "PUNGGALUKU",
		        "TARGET": 1680047641,
		        "ACTUAL": 1573829068,
		        "PERSEN": 93.7
		    },
		    {
		        "nmcab": "TANAH GROGOT",
		        "TARGET": 1442986213,
		        "ACTUAL": 1349417426,
		        "PERSEN": 93.5
		    },
		    {
		        "nmcab": "PASANGKAYU",
		        "TARGET": 2731508244,
		        "ACTUAL": 2550652106,
		        "PERSEN": 93.4
		    },
		    {
		        "nmcab": "MOROTAI",
		        "TARGET": 290388727,
		        "ACTUAL": 270559944,
		        "PERSEN": 93.2
		    },
		    {
		        "nmcab": "JAMPANG",
		        "TARGET": 1014582018,
		        "ACTUAL": 943235923,
		        "PERSEN": 93
		    },
		    {
		        "nmcab": "BELOPA",
		        "TARGET": 2712388240,
		        "ACTUAL": 2515108850,
		        "PERSEN": 92.7
		    },
		    {
		        "nmcab": "RATAHAN",
		        "TARGET": 2458758216,
		        "ACTUAL": 2278276082,
		        "PERSEN": 92.7
		    },
		    {
		        "nmcab": "CIKARANG",
		        "TARGET": 2655227552,
		        "ACTUAL": 2456833522,
		        "PERSEN": 92.5
		    },
		    {
		        "nmcab": "DONGGALA",
		        "TARGET": 2261211802,
		        "ACTUAL": 2088839315,
		        "PERSEN": 92.4
		    },
		    {
		        "nmcab": "BACAN",
		        "TARGET": 670391985,
		        "ACTUAL": 618895853,
		        "PERSEN": 92.3
		    },
		    {
		        "nmcab": "LAHAT",
		        "TARGET": 3025093226,
		        "ACTUAL": 2790445067,
		        "PERSEN": 92.2
		    },
		    {
		        "nmcab": "MAKASSAR",
		        "TARGET": 6325195212,
		        "ACTUAL": 5815379456,
		        "PERSEN": 91.9
		    },
		    {
		        "nmcab": "BANJARMASIN",
		        "TARGET": 4182718864,
		        "ACTUAL": 3843964630,
		        "PERSEN": 91.9
		    },
		    {
		        "nmcab": "SRAGEN",
		        "TARGET": 656424293,
		        "ACTUAL": 600295000,
		        "PERSEN": 91.4
		    },
		    {
		        "nmcab": "KASIPUTE",
		        "TARGET": 1501706316,
		        "ACTUAL": 1368945529,
		        "PERSEN": 91.2
		    },
		    {
		        "nmcab": "PALEMBANG",
		        "TARGET": 4403319482,
		        "ACTUAL": 4010516457,
		        "PERSEN": 91.1
		    },
		    {
		        "nmcab": "PEMATANG SIANTAR",
		        "TARGET": 2178411994,
		        "ACTUAL": 1974303057,
		        "PERSEN": 90.6
		    },
		    {
		        "nmcab": "RAWAJITU",
		        "TARGET": 1061072311,
		        "ACTUAL": 960896087,
		        "PERSEN": 90.6
		    },
		    {
		        "nmcab": "TANGERANG",
		        "TARGET": 2823851686,
		        "ACTUAL": 2555972644,
		        "PERSEN": 90.5
		    },
		    {
		        "nmcab": "ENDE",
		        "TARGET": 364572610,
		        "ACTUAL": 329006178,
		        "PERSEN": 90.2
		    },
		    {
		        "nmcab": "PANGKALANBUN",
		        "TARGET": 535659865,
		        "ACTUAL": 481416075,
		        "PERSEN": 89.9
		    },
		    {
		        "nmcab": "MASBAGIK",
		        "TARGET": 1249071498,
		        "ACTUAL": 1121504300,
		        "PERSEN": 89.8
		    },
		    {
		        "nmcab": "MAROS",
		        "TARGET": 3605025304,
		        "ACTUAL": 3227784101,
		        "PERSEN": 89.5
		    },
		    {
		        "nmcab": "KOTOBARU",
		        "TARGET": 1771139445,
		        "ACTUAL": 1582549743,
		        "PERSEN": 89.4
		    },
		    {
		        "nmcab": "PANGKEP",
		        "TARGET": 2088042094,
		        "ACTUAL": 1863149213,
		        "PERSEN": 89.2
		    },
		    {
		        "nmcab": "LUBUKBASUNG",
		        "TARGET": 1253721844,
		        "ACTUAL": 1116880347,
		        "PERSEN": 89.1
		    },
		    {
		        "nmcab": "KUNINGAN",
		        "TARGET": 1501058068,
		        "ACTUAL": 1324231167,
		        "PERSEN": 88.2
		    },
		    {
		        "nmcab": "ALUE BILIE",
		        "TARGET": 1035185976,
		        "ACTUAL": 907817385,
		        "PERSEN": 87.7
		    },
		    {
		        "nmcab": "KOLAKA",
		        "TARGET": 4000074944,
		        "ACTUAL": 3494429953,
		        "PERSEN": 87.4
		    },
		    {
		        "nmcab": "JATIBARANG",
		        "TARGET": 2059951402,
		        "ACTUAL": 1795955200,
		        "PERSEN": 87.2
		    },
		    {
		        "nmcab": "TOMOHON",
		        "TARGET": 812841138,
		        "ACTUAL": 706520106,
		        "PERSEN": 86.9
		    },
		    {
		        "nmcab": "BANJARAN",
		        "TARGET": 1810338362,
		        "ACTUAL": 1571589195,
		        "PERSEN": 86.8
		    },
		    {
		        "nmcab": "JEMBER",
		        "TARGET": 1236114969,
		        "ACTUAL": 1069580244,
		        "PERSEN": 86.5
		    },
		    {
		        "nmcab": "TAKENGON",
		        "TARGET": 1967840596,
		        "ACTUAL": 1695461129,
		        "PERSEN": 86.2
		    },
		    {
		        "nmcab": "TARAKAN",
		        "TARGET": 1148729044,
		        "ACTUAL": 989227157,
		        "PERSEN": 86.1
		    },
		    {
		        "nmcab": "SAMARINDA SEBERANG",
		        "TARGET": 1360349144,
		        "ACTUAL": 1171441108,
		        "PERSEN": 86.1
		    },
		    {
		        "nmcab": "BOROKO",
		        "TARGET": 831828464,
		        "ACTUAL": 712494950,
		        "PERSEN": 85.7
		    },
		    {
		        "nmcab": "SIMPANG PEMATANG",
		        "TARGET": 1121759089,
		        "ACTUAL": 960639374,
		        "PERSEN": 85.6
		    },
		    {
		        "nmcab": "AMPANA",
		        "TARGET": 1792484619,
		        "ACTUAL": 1532629261,
		        "PERSEN": 85.5
		    },
		    {
		        "nmcab": "UJUNG BERUNG",
		        "TARGET": 1313173900,
		        "ACTUAL": 1118945997,
		        "PERSEN": 85.2
		    },
		    {
		        "nmcab": "MANADO",
		        "TARGET": 3884876640,
		        "ACTUAL": 3299372906,
		        "PERSEN": 84.9
		    },
		    {
		        "nmcab": "TOBELO",
		        "TARGET": 1772151494,
		        "ACTUAL": 1503658237,
		        "PERSEN": 84.8
		    },
		    {
		        "nmcab": "PARE-PARE",
		        "TARGET": 3397738250,
		        "ACTUAL": 2880494995,
		        "PERSEN": 84.8
		    },
		    {
		        "nmcab": "KADIPATEN",
		        "TARGET": 1708621733,
		        "ACTUAL": 1445319151,
		        "PERSEN": 84.6
		    },
		    {
		        "nmcab": "SIGLI",
		        "TARGET": 1347929656,
		        "ACTUAL": 1135465361,
		        "PERSEN": 84.2
		    },
		    {
		        "nmcab": "MOLIBAGU",
		        "TARGET": 661181927,
		        "ACTUAL": 555785723,
		        "PERSEN": 84.1
		    },
		    {
		        "nmcab": "MUARA TEWEH",
		        "TARGET": 2006662653,
		        "ACTUAL": 1682414054,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "BLANG PIDIE",
		        "TARGET": 1821478060,
		        "ACTUAL": 1526874495,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "TALAUD",
		        "TARGET": 1086086296,
		        "ACTUAL": 909848564,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "PALOPO",
		        "TARGET": 4557880764,
		        "ACTUAL": 3817937928,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "BOYOLALI",
		        "TARGET": 923440422,
		        "ACTUAL": 767556658,
		        "PERSEN": 83.1
		    },
		    {
		        "nmcab": "PARUNGKUDA",
		        "TARGET": 2243345040,
		        "ACTUAL": 1858167230,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcab": "MUARA ENIM",
		        "TARGET": 1464765154,
		        "ACTUAL": 1212765921,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcab": "SAMPIT",
		        "TARGET": 2027799281,
		        "ACTUAL": 1675123311,
		        "PERSEN": 82.6
		    },
		    {
		        "nmcab": "GARUT",
		        "TARGET": 2324798602,
		        "ACTUAL": 1908720795,
		        "PERSEN": 82.1
		    },
		    {
		        "nmcab": "BONE",
		        "TARGET": 3016861836,
		        "ACTUAL": 2476741786,
		        "PERSEN": 82.1
		    },
		    {
		        "nmcab": "BALIKPAPAN",
		        "TARGET": 2032983824,
		        "ACTUAL": 1665689418,
		        "PERSEN": 81.9
		    },
		    {
		        "nmcab": "LHOKSEUMAWE",
		        "TARGET": 2599270760,
		        "ACTUAL": 2129388066,
		        "PERSEN": 81.9
		    },
		    {
		        "nmcab": "MARTAPURA KAL",
		        "TARGET": 1798887864,
		        "ACTUAL": 1471212235,
		        "PERSEN": 81.8
		    },
		    {
		        "nmcab": "LABUAN BAJO",
		        "TARGET": 551062030,
		        "ACTUAL": 449366609,
		        "PERSEN": 81.5
		    },
		    {
		        "nmcab": "BAWEN",
		        "TARGET": 1314689800,
		        "ACTUAL": 1068759200,
		        "PERSEN": 81.3
		    },
		    {
		        "nmcab": "TANJUNG",
		        "TARGET": 1177546595,
		        "ACTUAL": 952050770,
		        "PERSEN": 80.9
		    },
		    {
		        "nmcab": "WAY KANAN",
		        "TARGET": 974063199,
		        "ACTUAL": 785035731,
		        "PERSEN": 80.6
		    },
		    {
		        "nmcab": "BELITANG",
		        "TARGET": 838515028,
		        "ACTUAL": 675420334,
		        "PERSEN": 80.5
		    },
		    {
		        "nmcab": "SUMBAWA",
		        "TARGET": 510942340,
		        "ACTUAL": 408842000,
		        "PERSEN": 80
		    },
		    {
		        "nmcab": "PONTIANAK",
		        "TARGET": 493936376,
		        "ACTUAL": 394950630,
		        "PERSEN": 80
		    },
		    {
		        "nmcab": "JENEPONTO",
		        "TARGET": 3461705452,
		        "ACTUAL": 2753693744,
		        "PERSEN": 79.5
		    },
		    {
		        "nmcab": "LAMPUNG",
		        "TARGET": 3527318068,
		        "ACTUAL": 2797098140,
		        "PERSEN": 79.3
		    },
		    {
		        "nmcab": "TANJUNG BINTANG",
		        "TARGET": 930544189,
		        "ACTUAL": 736208717,
		        "PERSEN": 79.1
		    },
		    {
		        "nmcab": "RAHA",
		        "TARGET": 2180073882,
		        "ACTUAL": 1723944406,
		        "PERSEN": 79.1
		    },
		    {
		        "nmcab": "WONOSARI",
		        "TARGET": 829737468,
		        "ACTUAL": 653932000,
		        "PERSEN": 78.8
		    },
		    {
		        "nmcab": "BETUNG",
		        "TARGET": 2147481302,
		        "ACTUAL": 1690218481,
		        "PERSEN": 78.7
		    },
		    {
		        "nmcab": "BANGKALA",
		        "TARGET": 2462590994,
		        "ACTUAL": 1932648058,
		        "PERSEN": 78.5
		    },
		    {
		        "nmcab": "TUGUMULYO",
		        "TARGET": 1034916068,
		        "ACTUAL": 799664232,
		        "PERSEN": 77.3
		    },
		    {
		        "nmcab": "BENGKULU",
		        "TARGET": 845615256,
		        "ACTUAL": 646314692,
		        "PERSEN": 76.4
		    },
		    {
		        "nmcab": "RUTENG",
		        "TARGET": 649083303,
		        "ACTUAL": 495713525,
		        "PERSEN": 76.4
		    },
		    {
		        "nmcab": "KUALA SIMPANG",
		        "TARGET": 2926444136,
		        "ACTUAL": 2195064457,
		        "PERSEN": 75
		    },
		    {
		        "nmcab": "PROBOLINGGO",
		        "TARGET": 733475978,
		        "ACTUAL": 546782750,
		        "PERSEN": 74.5
		    },
		    {
		        "nmcab": "IDIE",
		        "TARGET": 2889238680,
		        "ACTUAL": 2150136597,
		        "PERSEN": 74.4
		    },
		    {
		        "nmcab": "TUNGKAL",
		        "TARGET": 509342925,
		        "ACTUAL": 376905349,
		        "PERSEN": 74
		    },
		    {
		        "nmcab": "UJUNG GADING",
		        "TARGET": 1741103932,
		        "ACTUAL": 1282784006,
		        "PERSEN": 73.7
		    },
		    {
		        "nmcab": "BUTON",
		        "TARGET": 4324916192,
		        "ACTUAL": 3184562745,
		        "PERSEN": 73.6
		    },
		    {
		        "nmcab": "NAMLEA",
		        "TARGET": 3058328748,
		        "ACTUAL": 2249884655,
		        "PERSEN": 73.6
		    },
		    {
		        "nmcab": "BABAT TOMAN",
		        "TARGET": 1256641094,
		        "ACTUAL": 920428369,
		        "PERSEN": 73.2
		    },
		    {
		        "nmcab": "MASAMBA",
		        "TARGET": 3016204616,
		        "ACTUAL": 2192362780,
		        "PERSEN": 72.7
		    },
		    {
		        "nmcab": "TORAJA",
		        "TARGET": 4081662372,
		        "ACTUAL": 2957696252,
		        "PERSEN": 72.5
		    },
		    {
		        "nmcab": "BANJAR",
		        "TARGET": 1386003036,
		        "ACTUAL": 1002053343,
		        "PERSEN": 72.3
		    },
		    {
		        "nmcab": "TEGAL",
		        "TARGET": 1060763305,
		        "ACTUAL": 765160291,
		        "PERSEN": 72.1
		    },
		    {
		        "nmcab": "BLITAR",
		        "TARGET": 1318570280,
		        "ACTUAL": 949898354,
		        "PERSEN": 72
		    },
		    {
		        "nmcab": "LADONGI",
		        "TARGET": 1451505780,
		        "ACTUAL": 1036256492,
		        "PERSEN": 71.4
		    },
		    {
		        "nmcab": "TOPPOYO",
		        "TARGET": 2847800304,
		        "ACTUAL": 2027419163,
		        "PERSEN": 71.2
		    },
		    {
		        "nmcab": "PANTON LABU",
		        "TARGET": 884347030,
		        "ACTUAL": 628891706,
		        "PERSEN": 71.1
		    },
		    {
		        "nmcab": "NAGAN",
		        "TARGET": 1004348615,
		        "ACTUAL": 713664018,
		        "PERSEN": 71.1
		    },
		    {
		        "nmcab": "TASIKMALAYA",
		        "TARGET": 2048464870,
		        "ACTUAL": 1452558651,
		        "PERSEN": 70.9
		    },
		    {
		        "nmcab": "KOTA AGUNG",
		        "TARGET": 777655023,
		        "ACTUAL": 550819548,
		        "PERSEN": 70.8
		    },
		    {
		        "nmcab": "ARGA MAKMUR",
		        "TARGET": 1244032719,
		        "ACTUAL": 879992281,
		        "PERSEN": 70.7
		    },
		    {
		        "nmcab": "KALIANDA",
		        "TARGET": 1622061697,
		        "ACTUAL": 1145452850,
		        "PERSEN": 70.6
		    },
		    {
		        "nmcab": "PADANG",
		        "TARGET": 1334194344,
		        "ACTUAL": 935374956,
		        "PERSEN": 70.1
		    },
		    {
		        "nmcab": "MALILI",
		        "TARGET": 3178466994,
		        "ACTUAL": 2217166947,
		        "PERSEN": 69.8
		    },
		    {
		        "nmcab": "BUNTA",
		        "TARGET": 1938512472,
		        "ACTUAL": 1350312930,
		        "PERSEN": 69.7
		    },
		    {
		        "nmcab": "SERANG",
		        "TARGET": 2186573192,
		        "ACTUAL": 1501538862,
		        "PERSEN": 68.7
		    },
		    {
		        "nmcab": "SORONG",
		        "TARGET": 1479958635,
		        "ACTUAL": 1012747039,
		        "PERSEN": 68.4
		    },
		    {
		        "nmcab": "TULANG BAWANG",
		        "TARGET": 1209957650,
		        "ACTUAL": 822935746,
		        "PERSEN": 68
		    },
		    {
		        "nmcab": "SIAU",
		        "TARGET": 842363104,
		        "ACTUAL": 567352073,
		        "PERSEN": 67.4
		    },
		    {
		        "nmcab": "BANTAENG",
		        "TARGET": 2036008875,
		        "ACTUAL": 1371228975,
		        "PERSEN": 67.3
		    },
		    {
		        "nmcab": "PLEIHARI",
		        "TARGET": 883938890,
		        "ACTUAL": 594840762,
		        "PERSEN": 67.3
		    },
		    {
		        "nmcab": "ACEH",
		        "TARGET": 3022345600,
		        "ACTUAL": 2031938630,
		        "PERSEN": 67.2
		    },
		    {
		        "nmcab": "INDRALAYA",
		        "TARGET": 913899040,
		        "ACTUAL": 613697477,
		        "PERSEN": 67.2
		    },
		    {
		        "nmcab": "MARISA",
		        "TARGET": 2378924644,
		        "ACTUAL": 1595151616,
		        "PERSEN": 67.1
		    },
		    {
		        "nmcab": "KAPUAS",
		        "TARGET": 367211677,
		        "ACTUAL": 245813285,
		        "PERSEN": 66.9
		    },
		    {
		        "nmcab": "MANGKUTANA",
		        "TARGET": 2665915050,
		        "ACTUAL": 1784081096,
		        "PERSEN": 66.9
		    },
		    {
		        "nmcab": "BARRU",
		        "TARGET": 2189955704,
		        "ACTUAL": 1458681623,
		        "PERSEN": 66.6
		    },
		    {
		        "nmcab": "BALARAJA",
		        "TARGET": 1834123472,
		        "ACTUAL": 1219677794,
		        "PERSEN": 66.5
		    },
		    {
		        "nmcab": "SUKABUMI",
		        "TARGET": 2090250672,
		        "ACTUAL": 1378532794,
		        "PERSEN": 66
		    },
		    {
		        "nmcab": "CURUP",
		        "TARGET": 776639436,
		        "ACTUAL": 510756807,
		        "PERSEN": 65.8
		    },
		    {
		        "nmcab": "WAY JEPARA",
		        "TARGET": 1060499699,
		        "ACTUAL": 696877088,
		        "PERSEN": 65.7
		    },
		    {
		        "nmcab": "BANGKO",
		        "TARGET": 1307096921,
		        "ACTUAL": 854789642,
		        "PERSEN": 65.4
		    },
		    {
		        "nmcab": "SIJUNGJUNG",
		        "TARGET": 1515092576,
		        "ACTUAL": 985634246,
		        "PERSEN": 65.1
		    },
		    {
		        "nmcab": "BULUKUMBA",
		        "TARGET": 3319834076,
		        "ACTUAL": 2151000869,
		        "PERSEN": 64.8
		    },
		    {
		        "nmcab": "PARIAMAN",
		        "TARGET": 845919665,
		        "ACTUAL": 543278803,
		        "PERSEN": 64.2
		    },
		    {
		        "nmcab": "SINJAI",
		        "TARGET": 1724126736,
		        "ACTUAL": 1107223725,
		        "PERSEN": 64.2
		    },
		    {
		        "nmcab": "GRESIK",
		        "TARGET": 1062030964,
		        "ACTUAL": 678062000,
		        "PERSEN": 63.8
		    },
		    {
		        "nmcab": "ULEE GLEE",
		        "TARGET": 1150387826,
		        "ACTUAL": 727422099,
		        "PERSEN": 63.2
		    },
		    {
		        "nmcab": "CILEDUG",
		        "TARGET": 1670971580,
		        "ACTUAL": 1045719996,
		        "PERSEN": 62.6
		    },
		    {
		        "nmcab": "MAJENE",
		        "TARGET": 1742231824,
		        "ACTUAL": 1052694026,
		        "PERSEN": 60.4
		    },
		    {
		        "nmcab": "BATU SANGKAR",
		        "TARGET": 1273749882,
		        "ACTUAL": 763455502,
		        "PERSEN": 59.9
		    },
		    {
		        "nmcab": "BINJAI",
		        "TARGET": 1598881168,
		        "ACTUAL": 942189156,
		        "PERSEN": 58.9
		    },
		    {
		        "nmcab": "KAYU AGUNG",
		        "TARGET": 1793905268,
		        "ACTUAL": 1054120267,
		        "PERSEN": 58.8
		    },
		    {
		        "nmcab": "ENREKANG",
		        "TARGET": 1665925089,
		        "ACTUAL": 975995510,
		        "PERSEN": 58.6
		    },
		    {
		        "nmcab": "BATURAJA",
		        "TARGET": 992209174,
		        "ACTUAL": 578591676,
		        "PERSEN": 58.3
		    },
		    {
		        "nmcab": "KOTABUMI",
		        "TARGET": 1030314835,
		        "ACTUAL": 599769630,
		        "PERSEN": 58.2
		    },
		    {
		        "nmcab": "PRABUMULIH",
		        "TARGET": 1185825160,
		        "ACTUAL": 689079966,
		        "PERSEN": 58.1
		    },
		    {
		        "nmcab": "METRO",
		        "TARGET": 1497354430,
		        "ACTUAL": 869446884,
		        "PERSEN": 58.1
		    },
		    {
		        "nmcab": "DAYA MURNI",
		        "TARGET": 929139424,
		        "ACTUAL": 537899134,
		        "PERSEN": 57.9
		    },
		    {
		        "nmcab": "TENGGARONG",
		        "TARGET": 1789211323,
		        "ACTUAL": 1028206382,
		        "PERSEN": 57.5
		    },
		    {
		        "nmcab": "MADIUN",
		        "TARGET": 926101188,
		        "ACTUAL": 530466500,
		        "PERSEN": 57.3
		    },
		    {
		        "nmcab": "BOALEMO",
		        "TARGET": 1972137884,
		        "ACTUAL": 1123089085,
		        "PERSEN": 56.9
		    },
		    {
		        "nmcab": "SAUMLAKI",
		        "TARGET": 1153047344,
		        "ACTUAL": 655451765,
		        "PERSEN": 56.8
		    },
		    {
		        "nmcab": "EREKE",
		        "TARGET": 1489723580,
		        "ACTUAL": 840567075,
		        "PERSEN": 56.4
		    },
		    {
		        "nmcab": "PARUNG",
		        "TARGET": 2231936612,
		        "ACTUAL": 1254723684,
		        "PERSEN": 56.2
		    },
		    {
		        "nmcab": "SIDRAP",
		        "TARGET": 3625671148,
		        "ACTUAL": 2035568961,
		        "PERSEN": 56.1
		    },
		    {
		        "nmcab": "TEMANGGUNG",
		        "TARGET": 2057074176,
		        "ACTUAL": 1149509400,
		        "PERSEN": 55.9
		    },
		    {
		        "nmcab": "SOLO",
		        "TARGET": 1349848005,
		        "ACTUAL": 748056000,
		        "PERSEN": 55.4
		    },
		    {
		        "nmcab": "SOPPENG",
		        "TARGET": 1618179272,
		        "ACTUAL": 892165714,
		        "PERSEN": 55.1
		    },
		    {
		        "nmcab": "PATI",
		        "TARGET": 900865891,
		        "ACTUAL": 492988371,
		        "PERSEN": 54.7
		    },
		    {
		        "nmcab": "PURWOKERTO",
		        "TARGET": 1131547539,
		        "ACTUAL": 617932100,
		        "PERSEN": 54.6
		    },
		    {
		        "nmcab": "MEDAN",
		        "TARGET": 2672793324,
		        "ACTUAL": 1442176474,
		        "PERSEN": 54
		    },
		    {
		        "nmcab": "LASUSUA",
		        "TARGET": 1103412010,
		        "ACTUAL": 591673492,
		        "PERSEN": 53.6
		    },
		    {
		        "nmcab": "TAHUNA",
		        "TARGET": 1556153980,
		        "ACTUAL": 827418184,
		        "PERSEN": 53.2
		    },
		    {
		        "nmcab": "KOTAMOBAGU",
		        "TARGET": 1420094514,
		        "ACTUAL": 738262250,
		        "PERSEN": 52
		    },
		    {
		        "nmcab": "PEKALONGAN",
		        "TARGET": 802047292,
		        "ACTUAL": 416677000,
		        "PERSEN": 52
		    },
		    {
		        "nmcab": "LEUWILIANG",
		        "TARGET": 3221676232,
		        "ACTUAL": 1651028613,
		        "PERSEN": 51.2
		    },
		    {
		        "nmcab": "KARANGANYAR",
		        "TARGET": 1381318943,
		        "ACTUAL": 704879550,
		        "PERSEN": 51
		    },
		    {
		        "nmcab": "SEKAYU",
		        "TARGET": 904607640,
		        "ACTUAL": 460401450,
		        "PERSEN": 50.9
		    },
		    {
		        "nmcab": "CILACAP",
		        "TARGET": 1230195036,
		        "ACTUAL": 618864754,
		        "PERSEN": 50.3
		    },
		    {
		        "nmcab": "PASAMAN",
		        "TARGET": 1078861434,
		        "ACTUAL": 541854684,
		        "PERSEN": 50.2
		    },
		    {
		        "nmcab": "SURABAYA",
		        "TARGET": 1234687666,
		        "ACTUAL": 618920500,
		        "PERSEN": 50.1
		    },
		    {
		        "nmcab": "WONOGIRI",
		        "TARGET": 1376203311,
		        "ACTUAL": 684194000,
		        "PERSEN": 49.7
		    },
		    {
		        "nmcab": "MALINO",
		        "TARGET": 952229315,
		        "ACTUAL": 463686629,
		        "PERSEN": 48.7
		    },
		    {
		        "nmcab": "JAMBI",
		        "TARGET": 1810619925,
		        "ACTUAL": 880436038,
		        "PERSEN": 48.6
		    },
		    {
		        "nmcab": "LANGSA ACEH",
		        "TARGET": 1264481939,
		        "ACTUAL": 605510128,
		        "PERSEN": 47.9
		    },
		    {
		        "nmcab": "BUKITTINGGI",
		        "TARGET": 1281087526,
		        "ACTUAL": 609948466,
		        "PERSEN": 47.6
		    },
		    {
		        "nmcab": "TULUNGAGUNG",
		        "TARGET": 896554807,
		        "ACTUAL": 424676500,
		        "PERSEN": 47.4
		    },
		    {
		        "nmcab": "SOLOK",
		        "TARGET": 1385597962,
		        "ACTUAL": 640320202,
		        "PERSEN": 46.2
		    },
		    {
		        "nmcab": "KEDIRI",
		        "TARGET": 1327869026,
		        "ACTUAL": 600642426,
		        "PERSEN": 45.2
		    },
		    {
		        "nmcab": "PAYAKUMBUH",
		        "TARGET": 1182923150,
		        "ACTUAL": 534830200,
		        "PERSEN": 45.2
		    },
		    {
		        "nmcab": "SELAYAR",
		        "TARGET": 1905413612,
		        "ACTUAL": 853938730,
		        "PERSEN": 44.8
		    },
		    {
		        "nmcab": "POLMAS",
		        "TARGET": 2541192570,
		        "ACTUAL": 1116059296,
		        "PERSEN": 43.9
		    },
		    {
		        "nmcab": "SENGKANG",
		        "TARGET": 2883962752,
		        "ACTUAL": 1258466750,
		        "PERSEN": 43.6
		    },
		    {
		        "nmcab": "TEBO",
		        "TARGET": 1119131726,
		        "ACTUAL": 475000290,
		        "PERSEN": 42.4
		    },
		    {
		        "nmcab": "SABAK",
		        "TARGET": 864591390,
		        "ACTUAL": 366824002,
		        "PERSEN": 42.4
		    },
		    {
		        "nmcab": "MAMUJU",
		        "TARGET": 3016987400,
		        "ACTUAL": 1255684999,
		        "PERSEN": 41.6
		    },
		    {
		        "nmcab": "BOJONEGORO",
		        "TARGET": 670110430,
		        "ACTUAL": 278669500,
		        "PERSEN": 41.6
		    },
		    {
		        "nmcab": "PEKANBARU",
		        "TARGET": 2715141303,
		        "ACTUAL": 1118902434,
		        "PERSEN": 41.2
		    },
		    {
		        "nmcab": "BANDAR JAYA",
		        "TARGET": 1080979414,
		        "ACTUAL": 434797218,
		        "PERSEN": 40.2
		    },
		    {
		        "nmcab": "SIDOARJO",
		        "TARGET": 1483542852,
		        "ACTUAL": 591466168,
		        "PERSEN": 39.9
		    },
		    {
		        "nmcab": "MARTAPURA",
		        "TARGET": 555540868,
		        "ACTUAL": 206886560,
		        "PERSEN": 37.2
		    },
		    {
		        "nmcab": "LHOKSUKON",
		        "TARGET": 1150387826,
		        "ACTUAL": 415705657,
		        "PERSEN": 36.1
		    },
		    {
		        "nmcab": "RUMBIA",
		        "TARGET": 1080701236,
		        "ACTUAL": 383460089,
		        "PERSEN": 35.5
		    },
		    {
		        "nmcab": "LIWA",
		        "TARGET": 1022882271,
		        "ACTUAL": 356905294,
		        "PERSEN": 34.9
		    },
		    {
		        "nmcab": "LUBUK LINGGAU",
		        "TARGET": 1382741108,
		        "ACTUAL": 479903201,
		        "PERSEN": 34.7
		    },
		    {
		        "nmcab": "JAYAPURA",
		        "TARGET": 2038623646,
		        "ACTUAL": 663209660,
		        "PERSEN": 32.5
		    },
		    {
		        "nmcab": "BUNGO",
		        "TARGET": 1339851908,
		        "ACTUAL": 374807209,
		        "PERSEN": 28
		    },
		    {
		        "nmcab": "WONOSOBO",
		        "TARGET": 1902081340,
		        "ACTUAL": 521274636,
		        "PERSEN": 27.4
		    },
		    {
		        "nmcab": "KEBUMEN",
		        "TARGET": 966190300,
		        "ACTUAL": 264713900,
		        "PERSEN": 27.4
		    },
		    {
		        "nmcab": "MOJOKERTO",
		        "TARGET": 1043412140,
		        "ACTUAL": 219285000,
		        "PERSEN": 21
		    },
		    {
		        "nmcab": "SOROLANGON",
		        "TARGET": 449457320,
		        "ACTUAL": 0,
		        "PERSEN": 0
		    },
		    {
		        "nmcab": "MUARA BULIAN",
		        "TARGET": 199893770,
		        "ACTUAL": 0,
		        "PERSEN": 0
		    },
		    {
		        "nmcab": "PANGKALAN BRANDAN",
		        "TARGET": 0,
		        "ACTUAL": 0,
		        "PERSEN": null
		    },
		    {
		        "nmcab": "BULI",
		        "TARGET": 0,
		        "ACTUAL": 0,
		        "PERSEN": null
		    }
		],
        "columns": [
            { "data": "nmcab" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

	$('#tableProdukCabKonMtd').DataTable({
        "data":[
		    {
		        "nmcab": "DOMPU",
		        "TARGET": 51,
		        "ACTUAL": 95,
		        "PERSEN": 186.2745
		    },
		    {
		        "nmcab": "BARABAI",
		        "TARGET": 58,
		        "ACTUAL": 102,
		        "PERSEN": 175.8621
		    },
		    {
		        "nmcab": "MOROWALI",
		        "TARGET": 198,
		        "ACTUAL": 346,
		        "PERSEN": 174.7475
		    },
		    {
		        "nmcab": "BELINYU",
		        "TARGET": 86,
		        "ACTUAL": 150,
		        "PERSEN": 174.4186
		    },
		    {
		        "nmcab": "LUWUK",
		        "TARGET": 155,
		        "ACTUAL": 260,
		        "PERSEN": 167.7419
		    },
		    {
		        "nmcab": "BUOL",
		        "TARGET": 148,
		        "ACTUAL": 246,
		        "PERSEN": 166.2162
		    },
		    {
		        "nmcab": "BERAU",
		        "TARGET": 162,
		        "ACTUAL": 253,
		        "PERSEN": 156.1728
		    },
		    {
		        "nmcab": "PELABUHAN RATU",
		        "TARGET": 217,
		        "ACTUAL": 335,
		        "PERSEN": 154.3779
		    },
		    {
		        "nmcab": "PALU",
		        "TARGET": 463,
		        "ACTUAL": 689,
		        "PERSEN": 148.8121
		    },
		    {
		        "nmcab": "CIMAHI",
		        "TARGET": 235,
		        "ACTUAL": 349,
		        "PERSEN": 148.5106
		    },
		    {
		        "nmcab": "UNAAHA",
		        "TARGET": 159,
		        "ACTUAL": 230,
		        "PERSEN": 144.6541
		    },
		    {
		        "nmcab": "MAGELANG",
		        "TARGET": 145,
		        "ACTUAL": 209,
		        "PERSEN": 144.1379
		    },
		    {
		        "nmcab": "BELITUNG",
		        "TARGET": 140,
		        "ACTUAL": 201,
		        "PERSEN": 143.5714
		    },
		    {
		        "nmcab": "PALU 2",
		        "TARGET": 300,
		        "ACTUAL": 429,
		        "PERSEN": 143
		    },
		    {
		        "nmcab": "GORONTALO",
		        "TARGET": 400,
		        "ACTUAL": 567,
		        "PERSEN": 141.75
		    },
		    {
		        "nmcab": "BUNGKU",
		        "TARGET": 275,
		        "ACTUAL": 385,
		        "PERSEN": 140
		    },
		    {
		        "nmcab": "POSO",
		        "TARGET": 174,
		        "ACTUAL": 243,
		        "PERSEN": 139.6552
		    },
		    {
		        "nmcab": "KENDARI",
		        "TARGET": 307,
		        "ACTUAL": 418,
		        "PERSEN": 136.1564
		    },
		    {
		        "nmcab": "SALAKAN",
		        "TARGET": 191,
		        "ACTUAL": 252,
		        "PERSEN": 131.9372
		    },
		    {
		        "nmcab": "CIAWI",
		        "TARGET": 99,
		        "ACTUAL": 129,
		        "PERSEN": 130.303
		    },
		    {
		        "nmcab": "PANGANDARAN",
		        "TARGET": 129,
		        "ACTUAL": 167,
		        "PERSEN": 129.4574
		    },
		    {
		        "nmcab": "BANDUNG",
		        "TARGET": 168,
		        "ACTUAL": 215,
		        "PERSEN": 127.9762
		    },
		    {
		        "nmcab": "SUMEDANG",
		        "TARGET": 154,
		        "ACTUAL": 195,
		        "PERSEN": 126.6234
		    },
		    {
		        "nmcab": "BELTIM",
		        "TARGET": 79,
		        "ACTUAL": 100,
		        "PERSEN": 126.5823
		    },
		    {
		        "nmcab": "PATROL",
		        "TARGET": 179,
		        "ACTUAL": 221,
		        "PERSEN": 123.4637
		    },
		    {
		        "nmcab": "TOMPE",
		        "TARGET": 70,
		        "ACTUAL": 86,
		        "PERSEN": 122.8571
		    },
		    {
		        "nmcab": "CIREBON",
		        "TARGET": 193,
		        "ACTUAL": 236,
		        "PERSEN": 122.2798
		    },
		    {
		        "nmcab": "MAKASSAR 3",
		        "TARGET": 391,
		        "ACTUAL": 474,
		        "PERSEN": 121.2276
		    },
		    {
		        "nmcab": "BOGOR",
		        "TARGET": 260,
		        "ACTUAL": 309,
		        "PERSEN": 118.8462
		    },
		    {
		        "nmcab": "SUNGAI LILIN",
		        "TARGET": 149,
		        "ACTUAL": 176,
		        "PERSEN": 118.1208
		    },
		    {
		        "nmcab": "PALANGKARAYA",
		        "TARGET": 150,
		        "ACTUAL": 176,
		        "PERSEN": 117.3333
		    },
		    {
		        "nmcab": "SUBANG",
		        "TARGET": 116,
		        "ACTUAL": 136,
		        "PERSEN": 117.2414
		    },
		    {
		        "nmcab": "TOLI TOLI",
		        "TARGET": 137,
		        "ACTUAL": 160,
		        "PERSEN": 116.7883
		    },
		    {
		        "nmcab": "TANGGEUNG",
		        "TARGET": 123,
		        "ACTUAL": 143,
		        "PERSEN": 116.2602
		    },
		    {
		        "nmcab": "BATU LICIN",
		        "TARGET": 148,
		        "ACTUAL": 172,
		        "PERSEN": 116.2162
		    },
		    {
		        "nmcab": "MASOHI",
		        "TARGET": 198,
		        "ACTUAL": 230,
		        "PERSEN": 116.1616
		    },
		    {
		        "nmcab": "CIANJUR",
		        "TARGET": 237,
		        "ACTUAL": 275,
		        "PERSEN": 116.0338
		    },
		    {
		        "nmcab": "KOTARAYA",
		        "TARGET": 110,
		        "ACTUAL": 126,
		        "PERSEN": 114.5455
		    },
		    {
		        "nmcab": "PANGKALANBUN",
		        "TARGET": 50,
		        "ACTUAL": 57,
		        "PERSEN": 114
		    },
		    {
		        "nmcab": "PARIGI",
		        "TARGET": 158,
		        "ACTUAL": 179,
		        "PERSEN": 113.2911
		    },
		    {
		        "nmcab": "SANGATTA",
		        "TARGET": 136,
		        "ACTUAL": 154,
		        "PERSEN": 113.2353
		    },
		    {
		        "nmcab": "SAMARINDA SEBERANG",
		        "TARGET": 95,
		        "ACTUAL": 107,
		        "PERSEN": 112.6316
		    },
		    {
		        "nmcab": "BANGKA",
		        "TARGET": 231,
		        "ACTUAL": 260,
		        "PERSEN": 112.5541
		    },
		    {
		        "nmcab": "JEBUS",
		        "TARGET": 71,
		        "ACTUAL": 79,
		        "PERSEN": 111.2676
		    },
		    {
		        "nmcab": "TOBOALI",
		        "TARGET": 92,
		        "ACTUAL": 102,
		        "PERSEN": 110.8696
		    },
		    {
		        "nmcab": "MALANG",
		        "TARGET": 168,
		        "ACTUAL": 185,
		        "PERSEN": 110.119
		    },
		    {
		        "nmcab": "BOEPINANG",
		        "TARGET": 99,
		        "ACTUAL": 109,
		        "PERSEN": 110.101
		    },
		    {
		        "nmcab": "YOGYAKARTA",
		        "TARGET": 145,
		        "ACTUAL": 159,
		        "PERSEN": 109.6552
		    },
		    {
		        "nmcab": "PRINGSEWU",
		        "TARGET": 100,
		        "ACTUAL": 109,
		        "PERSEN": 109
		    },
		    {
		        "nmcab": "MEULABOH",
		        "TARGET": 225,
		        "ACTUAL": 245,
		        "PERSEN": 108.8889
		    },
		    {
		        "nmcab": "AMPANA",
		        "TARGET": 152,
		        "ACTUAL": 165,
		        "PERSEN": 108.5526
		    },
		    {
		        "nmcab": "PUNGGALUKU",
		        "TARGET": 120,
		        "ACTUAL": 130,
		        "PERSEN": 108.3333
		    },
		    {
		        "nmcab": "CILEUNGSI",
		        "TARGET": 297,
		        "ACTUAL": 319,
		        "PERSEN": 107.4074
		    },
		    {
		        "nmcab": "PENDOLO",
		        "TARGET": 98,
		        "ACTUAL": 105,
		        "PERSEN": 107.1429
		    },
		    {
		        "nmcab": "JATIBARANG",
		        "TARGET": 198,
		        "ACTUAL": 212,
		        "PERSEN": 107.0707
		    },
		    {
		        "nmcab": "BEKASI",
		        "TARGET": 479,
		        "ACTUAL": 512,
		        "PERSEN": 106.8894
		    },
		    {
		        "nmcab": "SAMARINDA",
		        "TARGET": 165,
		        "ACTUAL": 176,
		        "PERSEN": 106.6667
		    },
		    {
		        "nmcab": "AMBON",
		        "TARGET": 414,
		        "ACTUAL": 441,
		        "PERSEN": 106.5217
		    },
		    {
		        "nmcab": "TOILI",
		        "TARGET": 156,
		        "ACTUAL": 165,
		        "PERSEN": 105.7692
		    },
		    {
		        "nmcab": "KOTA FAJAR",
		        "TARGET": 145,
		        "ACTUAL": 153,
		        "PERSEN": 105.5172
		    },
		    {
		        "nmcab": "GOWA 2",
		        "TARGET": 252,
		        "ACTUAL": 265,
		        "PERSEN": 105.1587
		    },
		    {
		        "nmcab": "BANJARMASIN",
		        "TARGET": 357,
		        "ACTUAL": 375,
		        "PERSEN": 105.042
		    },
		    {
		        "nmcab": "PURWAKARTA",
		        "TARGET": 241,
		        "ACTUAL": 253,
		        "PERSEN": 104.9793
		    },
		    {
		        "nmcab": "BAYUNG LENCIR",
		        "TARGET": 171,
		        "ACTUAL": 179,
		        "PERSEN": 104.6784
		    },
		    {
		        "nmcab": "MUARA TEWEH",
		        "TARGET": 150,
		        "ACTUAL": 157,
		        "PERSEN": 104.6667
		    },
		    {
		        "nmcab": "ENDE",
		        "TARGET": 43,
		        "ACTUAL": 45,
		        "PERSEN": 104.6512
		    },
		    {
		        "nmcab": "RAWAJITU",
		        "TARGET": 91,
		        "ACTUAL": 95,
		        "PERSEN": 104.3956
		    },
		    {
		        "nmcab": "MUARA ENIM",
		        "TARGET": 98,
		        "ACTUAL": 102,
		        "PERSEN": 104.0816
		    },
		    {
		        "nmcab": "SAMPIT",
		        "TARGET": 151,
		        "ACTUAL": 156,
		        "PERSEN": 103.3113
		    },
		    {
		        "nmcab": "PALEMBANG",
		        "TARGET": 227,
		        "ACTUAL": 233,
		        "PERSEN": 102.6432
		    },
		    {
		        "nmcab": "RUTENG",
		        "TARGET": 77,
		        "ACTUAL": 79,
		        "PERSEN": 102.5974
		    },
		    {
		        "nmcab": "KOBA",
		        "TARGET": 79,
		        "ACTUAL": 81,
		        "PERSEN": 102.5316
		    },
		    {
		        "nmcab": "PANGKEP",
		        "TARGET": 137,
		        "ACTUAL": 140,
		        "PERSEN": 102.1898
		    },
		    {
		        "nmcab": "KOTABARU",
		        "TARGET": 98,
		        "ACTUAL": 100,
		        "PERSEN": 102.0408
		    },
		    {
		        "nmcab": "KASIPUTE",
		        "TARGET": 109,
		        "ACTUAL": 111,
		        "PERSEN": 101.8349
		    },
		    {
		        "nmcab": "BIREUEN",
		        "TARGET": 136,
		        "ACTUAL": 138,
		        "PERSEN": 101.4706
		    },
		    {
		        "nmcab": "MAROS",
		        "TARGET": 227,
		        "ACTUAL": 229,
		        "PERSEN": 100.8811
		    },
		    {
		        "nmcab": "GARUT",
		        "TARGET": 224,
		        "ACTUAL": 225,
		        "PERSEN": 100.4464
		    },
		    {
		        "nmcab": "SUNGAI LIAT",
		        "TARGET": 97,
		        "ACTUAL": 97,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "BENGKULU",
		        "TARGET": 55,
		        "ACTUAL": 55,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "TAKALAR",
		        "TARGET": 247,
		        "ACTUAL": 247,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "PENAJAM",
		        "TARGET": 70,
		        "ACTUAL": 70,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "KELAPA",
		        "TARGET": 91,
		        "ACTUAL": 91,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "KOLAKA",
		        "TARGET": 307,
		        "ACTUAL": 306,
		        "PERSEN": 99.6743
		    },
		    {
		        "nmcab": "TUGUMULYO",
		        "TARGET": 93,
		        "ACTUAL": 92,
		        "PERSEN": 98.9247
		    },
		    {
		        "nmcab": "MARTAPURA KAL",
		        "TARGET": 157,
		        "ACTUAL": 155,
		        "PERSEN": 98.7261
		    },
		    {
		        "nmcab": "GOWA",
		        "TARGET": 304,
		        "ACTUAL": 300,
		        "PERSEN": 98.6842
		    },
		    {
		        "nmcab": "RAHA",
		        "TARGET": 172,
		        "ACTUAL": 167,
		        "PERSEN": 97.093
		    },
		    {
		        "nmcab": "BOROKO",
		        "TARGET": 62,
		        "ACTUAL": 60,
		        "PERSEN": 96.7742
		    },
		    {
		        "nmcab": "SUMBAWA",
		        "TARGET": 60,
		        "ACTUAL": 58,
		        "PERSEN": 96.6667
		    },
		    {
		        "nmcab": "TARAKAN",
		        "TARGET": 86,
		        "ACTUAL": 83,
		        "PERSEN": 96.5116
		    },
		    {
		        "nmcab": "TENTENA",
		        "TARGET": 133,
		        "ACTUAL": 128,
		        "PERSEN": 96.2406
		    },
		    {
		        "nmcab": "TANJUNG BINTANG",
		        "TARGET": 78,
		        "ACTUAL": 75,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcab": "RATAHAN",
		        "TARGET": 182,
		        "ACTUAL": 175,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcab": "CIBINONG",
		        "TARGET": 281,
		        "ACTUAL": 270,
		        "PERSEN": 96.0854
		    },
		    {
		        "nmcab": "PONTIANAK",
		        "TARGET": 48,
		        "ACTUAL": 46,
		        "PERSEN": 95.8333
		    },
		    {
		        "nmcab": "KADIPATEN",
		        "TARGET": 149,
		        "ACTUAL": 142,
		        "PERSEN": 95.302
		    },
		    {
		        "nmcab": "MAKASSAR",
		        "TARGET": 380,
		        "ACTUAL": 362,
		        "PERSEN": 95.2632
		    },
		    {
		        "nmcab": "TANJUNG",
		        "TARGET": 95,
		        "ACTUAL": 90,
		        "PERSEN": 94.7368
		    },
		    {
		        "nmcab": "MOLIBAGU",
		        "TARGET": 53,
		        "ACTUAL": 50,
		        "PERSEN": 94.3396
		    }
		],
        "columns": [
            { "data": "nmcab" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

	$('#tableParetoCabRpMtd').DataTable({
        "data":[
		    {
		        "jenis": "PARETO",
		        "TARGET": 238382999558,
		        "ACTUAL": 226415422500,
		        "PERSEN": 95
		    },
		    {
		        "jenis": "NON PARETO",
		        "TARGET": 276808397775,
		        "ACTUAL": 235462506756,
		        "PERSEN": 85.1
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableParetoCabKonMtd').DataTable({
        "data":[
		    {
		        "jenis": "PARETO",
		        "TARGET": 18298,
		        "ACTUAL": 17551,
		        "PERSEN": 95.9
		    },
		    {
		        "jenis": "NON PARETO",
		        "TARGET": 23058,
		        "ACTUAL": 19644,
		        "PERSEN": 85.2
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukRpYtd').DataTable({
        "data":[
		    {
		        "nama_produk": "RETENTION",
		        "TARGET": 114774130425,
		        "ACTUAL": 123060134751,
		        "PERSEN": 107.2
		    },
		    {
		        "nama_produk": "AISI",
		        "TARGET": 234483028650,
		        "ACTUAL": 226135833166,
		        "PERSEN": 96.4
		    },
		    {
		        "nama_produk": "KPM",
		        "TARGET": 165934238258,
		        "ACTUAL": 112681961339,
		        "PERSEN": 67.9
		    }
		],
        "columns": [
            { "data": "nama_produk" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukKonYtd').DataTable({
        "data":[
		    {
		        "nama_produk": "AISI",
		        "TARGET": 9328,
		        "ACTUAL": 10141,
		        "PERSEN": 108.7
		    },
		    {
		        "nama_produk": "RETENTION",
		        "TARGET": 12722,
		        "ACTUAL": 13041,
		        "PERSEN": 102.5
		    },
		    {
		        "nama_produk": "KPM",
		        "TARGET": 19306,
		        "ACTUAL": 14013,
		        "PERSEN": 72.6
		    }
		],
        "columns": [
            { "data": "nama_produk" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukRegRpYtd').DataTable({
        "data":[
		  {
		    "regional": "SUMATERA5",
		    "TARGET": 15129650477,
		    "ACTUAL": 23134479299,
		    "PERSEN": 152.9
		  },
		  {
		    "regional": "SULAWESI3",
		    "TARGET": 44687410371,
		    "ACTUAL": 58623498362,
		    "PERSEN": 131.2
		  },
		  {
		    "regional": "ACEH2",
		    "TARGET": 10951852662,
		    "ACTUAL": 10955157981,
		    "PERSEN": 100
		  },
		  {
		    "regional": "JAWABARAT2",
		    "TARGET": 27602191114,
		    "ACTUAL": 27402269004,
		    "PERSEN": 99.3
		  },
		  {
		    "regional": "KALIMANTAN2",
		    "TARGET": 15969146374,
		    "ACTUAL": 15778535767,
		    "PERSEN": 98.8
		  },
		  {
		    "regional": "SULAWESI4",
		    "TARGET": 26051485558,
		    "ACTUAL": 25693738612,
		    "PERSEN": 98.6
		  },
		  {
		    "regional": "JAWABARAT3",
		    "TARGET": 28110954280,
		    "ACTUAL": 27717134032,
		    "PERSEN": 98.6
		  },
		  {
		    "regional": "NUSATENGGARA",
		    "TARGET": 3757309275,
		    "ACTUAL": 3508086380,
		    "PERSEN": 93.4
		  },
		  {
		    "regional": "JAWABARAT1",
		    "TARGET": 22722737670,
		    "ACTUAL": 20948046954,
		    "PERSEN": 92.2
		  },
		  {
		    "regional": "KALIMANTAN1",
		    "TARGET": 18280824706,
		    "ACTUAL": 16816969897,
		    "PERSEN": 92
		  },
		  {
		    "regional": "SULAWESI5",
		    "TARGET": 36991168929,
		    "ACTUAL": 33639783777,
		    "PERSEN": 90.9
		  },
		  {
		    "regional": "SULAWESI1",
		    "TARGET": 54545012288,
		    "ACTUAL": 48744323918,
		    "PERSEN": 89.4
		  },
		  {
		    "regional": "MAPA",
		    "TARGET": 20491828901,
		    "ACTUAL": 17610204133,
		    "PERSEN": 85.9
		  },
		  {
		    "regional": "SUMATERA4",
		    "TARGET": 29880166918,
		    "ACTUAL": 23197765985,
		    "PERSEN": 77.6
		  },
		  {
		    "regional": "ACEH1",
		    "TARGET": 18922048549,
		    "ACTUAL": 14231084857,
		    "PERSEN": 75.2
		  },
		  {
		    "regional": "SULAWESI2",
		    "TARGET": 54649594359,
		    "ACTUAL": 38909240411,
		    "PERSEN": 71.2
		  },
		  {
		    "regional": "SUMATERA6",
		    "TARGET": 20124968813,
		    "ACTUAL": 13937173706,
		    "PERSEN": 69.3
		  },
		  {
		    "regional": "JAWATENGAH",
		    "TARGET": 21860695031,
		    "ACTUAL": 14913644473,
		    "PERSEN": 68.2
		  },
		  {
		    "regional": "SUMATERA2",
		    "TARGET": 9165227789,
		    "ACTUAL": 5477571121,
		    "PERSEN": 59.8
		  },
		  {
		    "regional": "JAWATIMUR",
		    "TARGET": 13033745624,
		    "ACTUAL": 7773546902,
		    "PERSEN": 59.6
		  },
		  {
		    "regional": "SUMATERA3",
		    "TARGET": 22263377645,
		    "ACTUAL": 12865673685,
		    "PERSEN": 57.8
		  }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukRegKonYtd').DataTable({
        "data":[
		    {
		        "regional": "SULAWESI 3",
		        "TARGET": 3248,
		        "ACTUAL": 4258,
		        "PERSEN": 131.0961
		    },
		    {
		        "regional": "SUMATERA 5",
		        "TARGET": 1060,
		        "ACTUAL": 1237,
		        "PERSEN": 116.6981
		    },
		    {
		        "regional": "JAWA BARAT 2",
		        "TARGET": 2604,
		        "ACTUAL": 2907,
		        "PERSEN": 111.6359
		    },
		    {
		        "regional": "KALIMANTAN 1",
		        "TARGET": 1511,
		        "ACTUAL": 1613,
		        "PERSEN": 106.7505
		    },
		    {
		        "regional": "NUSA TENGGARA",
		        "TARGET": 443,
		        "ACTUAL": 466,
		        "PERSEN": 105.1919
		    },
		    {
		        "regional": "KALIMANTAN 2",
		        "TARGET": 1112,
		        "ACTUAL": 1154,
		        "PERSEN": 103.777
		    },
		    {
		        "regional": "SULAWESI 4",
		        "TARGET": 1920,
		        "ACTUAL": 1970,
		        "PERSEN": 102.6042
		    },
		    {
		        "regional": "JAWA BARAT 1",
		        "TARGET": 2121,
		        "ACTUAL": 2018,
		        "PERSEN": 95.1438
		    },
		    {
		        "regional": "SULAWESI 1",
		        "TARGET": 3610,
		        "ACTUAL": 3333,
		        "PERSEN": 92.3269
		    },
		    {
		        "regional": "JAWA BARAT 3",
		        "TARGET": 2409,
		        "ACTUAL": 2218,
		        "PERSEN": 92.0714
		    },
		    {
		        "regional": "ACEH 2",
		        "TARGET": 828,
		        "ACTUAL": 759,
		        "PERSEN": 91.6667
		    },
		    {
		        "regional": "SUMATERA 4",
		        "TARGET": 1913,
		        "ACTUAL": 1693,
		        "PERSEN": 88.4997
		    },
		    {
		        "regional": "SULAWESI 5",
		        "TARGET": 2807,
		        "ACTUAL": 2464,
		        "PERSEN": 87.7805
		    },
		    {
		        "regional": "MAPA",
		        "TARGET": 1545,
		        "ACTUAL": 1323,
		        "PERSEN": 85.6311
		    },
		    {
		        "regional": "SUMATERA 6",
		        "TARGET": 1743,
		        "ACTUAL": 1342,
		        "PERSEN": 76.9937
		    },
		    {
		        "regional": "ACEH 1",
		        "TARGET": 1313,
		        "ACTUAL": 958,
		        "PERSEN": 72.9627
		    },
		    {
		        "regional": "SULAWESI 2",
		        "TARGET": 3764,
		        "ACTUAL": 2728,
		        "PERSEN": 72.4761
		    },
		    {
		        "regional": "SUMATERA 2",
		        "TARGET": 556,
		        "ACTUAL": 373,
		        "PERSEN": 67.0863
		    },
		    {
		        "regional": "JAWA TENGAH",
		        "TARGET": 3311,
		        "ACTUAL": 2189,
		        "PERSEN": 66.113
		    },
		    {
		        "regional": "SUMATERA 3",
		        "TARGET": 1567,
		        "ACTUAL": 980,
		        "PERSEN": 62.5399
		    },
		    {
		        "regional": "JAWA TIMUR",
		        "TARGET": 1971,
		        "ACTUAL": 1212,
		        "PERSEN": 61.4916
		    }
		],
        "columns": [
            { "data": "regional" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukCluRpYtd').DataTable({
        "data":[
		    {
		        "nmcluster": "JOGYA",
		        "TARGET": 2753523266,
		        "ACTUAL": 3396359265,
		        "PERSEN": 123.3
		    },
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TARGET": 8941036425,
		        "ACTUAL": 10146733760,
		        "PERSEN": 113.5
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TARGET": 18056771904,
		        "ACTUAL": 19944664386,
		        "PERSEN": 110.5
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TARGET": 19595434350,
		        "ACTUAL": 21394224736,
		        "PERSEN": 109.2
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TARGET": 11387254434,
		        "ACTUAL": 12210040823,
		        "PERSEN": 107.2
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TARGET": 4218524355,
		        "ACTUAL": 4502507625,
		        "PERSEN": 106.7
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TARGET": 26570650638,
		        "ACTUAL": 27153790186,
		        "PERSEN": 102.2
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TARGET": 4765487711,
		        "ACTUAL": 4757189227,
		        "PERSEN": 99.8
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TARGET": 11302919887,
		        "ACTUAL": 11246445040,
		        "PERSEN": 99.5
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TARGET": 10494343271,
		        "ACTUAL": 9817809952,
		        "PERSEN": 93.6
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TARGET": 3757309275,
		        "ACTUAL": 3508086380,
		        "PERSEN": 93.4
		    },
		    {
		        "nmcluster": "AMBON",
		        "TARGET": 14953540732,
		        "ACTUAL": 13666427355,
		        "PERSEN": 91.4
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TARGET": 8166811418,
		        "ACTUAL": 7437725292,
		        "PERSEN": 91.1
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TARGET": 13813173694,
		        "ACTUAL": 12199048708,
		        "PERSEN": 88.3
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TARGET": 7404714278,
		        "ACTUAL": 6452117008,
		        "PERSEN": 87.1
		    },
		    {
		        "nmcluster": "MANADO",
		        "TARGET": 11875075348,
		        "ACTUAL": 10194290029,
		        "PERSEN": 85.8
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TARGET": 9423149931,
		        "ACTUAL": 8049611047,
		        "PERSEN": 85.4
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TARGET": 8984554886,
		        "ACTUAL": 7153418767,
		        "PERSEN": 79.6
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TARGET": 3316400411,
		        "ACTUAL": 2639671814,
		        "PERSEN": 79.6
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TARGET": 6132848400,
		        "ACTUAL": 4840009210,
		        "PERSEN": 78.9
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TARGET": 11335483236,
		        "ACTUAL": 8738006131,
		        "PERSEN": 77.1
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TARGET": 8530899674,
		        "ACTUAL": 6388560519,
		        "PERSEN": 74.9
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TARGET": 8515519930,
		        "ACTUAL": 6322909296,
		        "PERSEN": 74.3
		    },
		    {
		        "nmcluster": "BUTON",
		        "TARGET": 7994713654,
		        "ACTUAL": 5749074226,
		        "PERSEN": 71.9
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TARGET": 5538288169,
		        "ACTUAL": 3943776778,
		        "PERSEN": 71.2
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TARGET": 5520663082,
		        "ACTUAL": 3894826090,
		        "PERSEN": 70.5
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TARGET": 7964511785,
		        "ACTUAL": 5579602888,
		        "PERSEN": 70.1
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TARGET": 8606174690,
		        "ACTUAL": 5957672391,
		        "PERSEN": 69.2
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TARGET": 4671829983,
		        "ACTUAL": 3208504191,
		        "PERSEN": 68.7
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TARGET": 6900262318,
		        "ACTUAL": 4586614443,
		        "PERSEN": 66.5
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TARGET": 3453133799,
		        "ACTUAL": 2207829162,
		        "PERSEN": 63.9
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TARGET": 4693806821,
		        "ACTUAL": 2961998744,
		        "PERSEN": 63.1
		    },
		    {
		        "nmcluster": "SOLO",
		        "TARGET": 5687234974,
		        "ACTUAL": 3504981208,
		        "PERSEN": 61.6
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TARGET": 2966829060,
		        "ACTUAL": 1575652000,
		        "PERSEN": 53.1
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TARGET": 3737760558,
		        "ACTUAL": 1908234168,
		        "PERSEN": 51.1
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TARGET": 3384448010,
		        "ACTUAL": 1624165389,
		        "PERSEN": 48
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TARGET": 7287088391,
		        "ACTUAL": 3172294790,
		        "PERSEN": 43.5
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TARGET": 3297382354,
		        "ACTUAL": 1350393926,
		        "PERSEN": 41
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TARGET": 4215537875,
		        "ACTUAL": 1704597141,
		        "PERSEN": 40.4
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableProdukCluKonYtd').DataTable({
        "data":[
		    {
		        "nmcluster": "BANDUNG RAYA",
		        "TARGET": 856,
		        "ACTUAL": 1030,
		        "PERSEN": 120.3271
		    },
		    {
		        "nmcluster": "JOGYA",
		        "TARGET": 415,
		        "ACTUAL": 459,
		        "PERSEN": 110.6024
		    },
		    {
		        "nmcluster": "KENDARI",
		        "TARGET": 1310,
		        "ACTUAL": 1439,
		        "PERSEN": 109.8473
		    },
		    {
		        "nmcluster": "PANTURA RAYA",
		        "TARGET": 971,
		        "ACTUAL": 1066,
		        "PERSEN": 109.7837
		    },
		    {
		        "nmcluster": "GORONTALO",
		        "TARGET": 866,
		        "ACTUAL": 924,
		        "PERSEN": 106.6975
		    },
		    {
		        "nmcluster": "NUSRA",
		        "TARGET": 443,
		        "ACTUAL": 466,
		        "PERSEN": 105.1919
		    },
		    {
		        "nmcluster": "SUKABUMI RAYA",
		        "TARGET": 1089,
		        "ACTUAL": 1144,
		        "PERSEN": 105.0505
		    },
		    {
		        "nmcluster": "PRIANGAN RAYA",
		        "TARGET": 777,
		        "ACTUAL": 811,
		        "PERSEN": 104.3758
		    },
		    {
		        "nmcluster": "MAKASSAR",
		        "TARGET": 1682,
		        "ACTUAL": 1717,
		        "PERSEN": 102.0809
		    },
		    {
		        "nmcluster": "BEKASI RAYA",
		        "TARGET": 1655,
		        "ACTUAL": 1681,
		        "PERSEN": 101.571
		    },
		    {
		        "nmcluster": "ACEH BARAT 2",
		        "TARGET": 269,
		        "ACTUAL": 259,
		        "PERSEN": 96.2825
		    },
		    {
		        "nmcluster": "SUMSEL ATAS",
		        "TARGET": 572,
		        "ACTUAL": 550,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcluster": "ACEH BARAT 1",
		        "TARGET": 392,
		        "ACTUAL": 365,
		        "PERSEN": 93.1122
		    },
		    {
		        "nmcluster": "AMBON",
		        "TARGET": 1209,
		        "ACTUAL": 1113,
		        "PERSEN": 92.0596
		    },
		    {
		        "nmcluster": "SUMSEL RAYA",
		        "TARGET": 564,
		        "ACTUAL": 507,
		        "PERSEN": 89.8936
		    },
		    {
		        "nmcluster": "BUTON",
		        "TARGET": 610,
		        "ACTUAL": 531,
		        "PERSEN": 87.0492
		    },
		    {
		        "nmcluster": "BOGOR RAYA",
		        "TARGET": 1032,
		        "ACTUAL": 874,
		        "PERSEN": 84.6899
		    },
		    {
		        "nmcluster": "MALANG RAYA",
		        "TARGET": 504,
		        "ACTUAL": 409,
		        "PERSEN": 81.1508
		    },
		    {
		        "nmcluster": "MANADO",
		        "TARGET": 844,
		        "ACTUAL": 683,
		        "PERSEN": 80.9242
		    },
		    {
		        "nmcluster": "SUMSEL BAWAH",
		        "TARGET": 590,
		        "ACTUAL": 472,
		        "PERSEN": 80
		    },
		    {
		        "nmcluster": "LAMPUNG TENGAH",
		        "TARGET": 615,
		        "ACTUAL": 490,
		        "PERSEN": 79.6748
		    },
		    {
		        "nmcluster": "ACEH RAYA",
		        "TARGET": 370,
		        "ACTUAL": 290,
		        "PERSEN": 78.3784
		    },
		    {
		        "nmcluster": "ACEH UTARA",
		        "TARGET": 555,
		        "ACTUAL": 434,
		        "PERSEN": 78.1982
		    },
		    {
		        "nmcluster": "MALUKU UTARA",
		        "TARGET": 1097,
		        "ACTUAL": 857,
		        "PERSEN": 78.1222
		    },
		    {
		        "nmcluster": "LAMPUNG RAYA",
		        "TARGET": 729,
		        "ACTUAL": 559,
		        "PERSEN": 76.6804
		    },
		    {
		        "nmcluster": "SEMARANG",
		        "TARGET": 932,
		        "ACTUAL": 685,
		        "PERSEN": 73.4979
		    },
		    {
		        "nmcluster": "LAMPUNG TIMUR",
		        "TARGET": 399,
		        "ACTUAL": 293,
		        "PERSEN": 73.4336
		    },
		    {
		        "nmcluster": "TANGERANG RAYA",
		        "TARGET": 754,
		        "ACTUAL": 537,
		        "PERSEN": 71.2202
		    },
		    {
		        "nmcluster": "SIDOARJO RAYA",
		        "TARGET": 525,
		        "ACTUAL": 364,
		        "PERSEN": 69.3333
		    },
		    {
		        "nmcluster": "SUMBAR UTARA",
		        "TARGET": 328,
		        "ACTUAL": 227,
		        "PERSEN": 69.2073
		    },
		    {
		        "nmcluster": "ACEH TIMUR",
		        "TARGET": 555,
		        "ACTUAL": 369,
		        "PERSEN": 66.4865
		    },
		    {
		        "nmcluster": "SOLO",
		        "TARGET": 866,
		        "ACTUAL": 544,
		        "PERSEN": 62.8176
		    },
		    {
		        "nmcluster": "PAPUA",
		        "TARGET": 336,
		        "ACTUAL": 210,
		        "PERSEN": 62.5
		    },
		    {
		        "nmcluster": "JAMBI ATAS",
		        "TARGET": 260,
		        "ACTUAL": 138,
		        "PERSEN": 53.0769
		    },
		    {
		        "nmcluster": "JAMBI BAWAH",
		        "TARGET": 280,
		        "ACTUAL": 146,
		        "PERSEN": 52.1429
		    },
		    {
		        "nmcluster": "SURABAYA RAYA",
		        "TARGET": 446,
		        "ACTUAL": 230,
		        "PERSEN": 51.5695
		    },
		    {
		        "nmcluster": "SUMBAR TENGAH",
		        "TARGET": 269,
		        "ACTUAL": 135,
		        "PERSEN": 50.1859
		    },
		    {
		        "nmcluster": "WONOSOBO",
		        "TARGET": 1098,
		        "ACTUAL": 501,
		        "PERSEN": 45.6284
		    },
		    {
		        "nmcluster": "KEDIRI RAYA",
		        "TARGET": 496,
		        "ACTUAL": 209,
		        "PERSEN": 42.1371
		    }
		],
        "columns": [
            { "data": "nmcluster" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

	$('#tableProdukCabRpYtd').DataTable({
        "data":[
		    {
		        "nmcab": "BELINYU",
		        "TARGET": 1331938962,
		        "ACTUAL": 2976288123,
		        "PERSEN": 223.5
		    },
		    {
		        "nmcab": "MOROWALI",
		        "TARGET": 2512836744,
		        "ACTUAL": 5160639107,
		        "PERSEN": 205.4
		    },
		    {
		        "nmcab": "BELITUNG",
		        "TARGET": 2021143020,
		        "ACTUAL": 4123067659,
		        "PERSEN": 204
		    },
		    {
		        "nmcab": "PELABUHAN RATU",
		        "TARGET": 2267680094,
		        "ACTUAL": 4047904508,
		        "PERSEN": 178.5
		    },
		    {
		        "nmcab": "BUOL",
		        "TARGET": 1677323721,
		        "ACTUAL": 2905977099,
		        "PERSEN": 173.3
		    },
		    {
		        "nmcab": "LUWUK",
		        "TARGET": 2143997250,
		        "ACTUAL": 3505946903,
		        "PERSEN": 163.5
		    },
		    {
		        "nmcab": "DOMPU",
		        "TARGET": 432577494,
		        "ACTUAL": 703653768,
		        "PERSEN": 162.7
		    },
		    {
		        "nmcab": "BUNGKU",
		        "TARGET": 3662228764,
		        "ACTUAL": 5797744212,
		        "PERSEN": 158.3
		    },
		    {
		        "nmcab": "MAGELANG",
		        "TARGET": 958407528,
		        "ACTUAL": 1491488000,
		        "PERSEN": 155.6
		    },
		    {
		        "nmcab": "BERAU",
		        "TARGET": 2201563588,
		        "ACTUAL": 3417880159,
		        "PERSEN": 155.2
		    },
		    {
		        "nmcab": "BANGKA",
		        "TARGET": 3251627848,
		        "ACTUAL": 4990141799,
		        "PERSEN": 153.5
		    },
		    {
		        "nmcab": "BELTIM",
		        "TARGET": 1271938914,
		        "ACTUAL": 1949262398,
		        "PERSEN": 153.3
		    },
		    {
		        "nmcab": "UNAAHA",
		        "TARGET": 2302574613,
		        "ACTUAL": 3501370761,
		        "PERSEN": 152.1
		    },
		    {
		        "nmcab": "POSO",
		        "TARGET": 2144720976,
		        "ACTUAL": 3209990223,
		        "PERSEN": 149.7
		    },
		    {
		        "nmcab": "KENDARI",
		        "TARGET": 4639021904,
		        "ACTUAL": 6856937213,
		        "PERSEN": 147.8
		    },
		    {
		        "nmcab": "BARABAI",
		        "TARGET": 622503852,
		        "ACTUAL": 899521126,
		        "PERSEN": 144.5
		    },
		    {
		        "nmcab": "TOMPE",
		        "TARGET": 925886365,
		        "ACTUAL": 1297310351,
		        "PERSEN": 140.1
		    },
		    {
		        "nmcab": "KELAPA",
		        "TARGET": 1154387372,
		        "ACTUAL": 1603885706,
		        "PERSEN": 138.9
		    },
		    {
		        "nmcab": "SALAKAN",
		        "TARGET": 2143191146,
		        "ACTUAL": 2924834359,
		        "PERSEN": 136.5
		    },
		    {
		        "nmcab": "TOBOALI",
		        "TARGET": 1458377984,
		        "ACTUAL": 1976966134,
		        "PERSEN": 135.6
		    },
		    {
		        "nmcab": "KOBA",
		        "TARGET": 1050591831,
		        "ACTUAL": 1424113665,
		        "PERSEN": 135.6
		    },
		    {
		        "nmcab": "GORONTALO",
		        "TARGET": 5458846968,
		        "ACTUAL": 7259923666,
		        "PERSEN": 133
		    },
		    {
		        "nmcab": "PALU",
		        "TARGET": 8107678260,
		        "ACTUAL": 10707851771,
		        "PERSEN": 132.1
		    },
		    {
		        "nmcab": "BIREUEN",
		        "TARGET": 1687215096,
		        "ACTUAL": 2211562156,
		        "PERSEN": 131.1
		    },
		    {
		        "nmcab": "YOGYAKARTA",
		        "TARGET": 965378270,
		        "ACTUAL": 1250939265,
		        "PERSEN": 129.6
		    },
		    {
		        "nmcab": "CIMAHI",
		        "TARGET": 2485324332,
		        "ACTUAL": 3216432599,
		        "PERSEN": 129.4
		    },
		    {
		        "nmcab": "PANGANDARAN",
		        "TARGET": 1421690980,
		        "ACTUAL": 1825589961,
		        "PERSEN": 128.4
		    },
		    {
		        "nmcab": "SUMEDANG",
		        "TARGET": 1603107655,
		        "ACTUAL": 2057929918,
		        "PERSEN": 128.4
		    },
		    {
		        "nmcab": "PALU 2",
		        "TARGET": 5097631770,
		        "ACTUAL": 6535057492,
		        "PERSEN": 128.2
		    },
		    {
		        "nmcab": "CIAWI",
		        "TARGET": 985853930,
		        "ACTUAL": 1248802542,
		        "PERSEN": 126.7
		    },
		    {
		        "nmcab": "BANDUNG",
		        "TARGET": 1729092176,
		        "ACTUAL": 2181836051,
		        "PERSEN": 126.2
		    },
		    {
		        "nmcab": "TOLI TOLI",
		        "TARGET": 1712994096,
		        "ACTUAL": 2134184865,
		        "PERSEN": 124.6
		    },
		    {
		        "nmcab": "KOTA FAJAR",
		        "TARGET": 2397046295,
		        "ACTUAL": 2975633130,
		        "PERSEN": 124.1
		    },
		    {
		        "nmcab": "CILEUNGSI",
		        "TARGET": 3616072952,
		        "ACTUAL": 4346022154,
		        "PERSEN": 120.2
		    },
		    {
		        "nmcab": "JEBUS",
		        "TARGET": 981002722,
		        "ACTUAL": 1166863204,
		        "PERSEN": 118.9
		    },
		    {
		        "nmcab": "BEKASI",
		        "TARGET": 5952588440,
		        "ACTUAL": 7021953144,
		        "PERSEN": 118
		    },
		    {
		        "nmcab": "BATU LICIN",
		        "TARGET": 1781946480,
		        "ACTUAL": 2095054711,
		        "PERSEN": 117.6
		    },
		    {
		        "nmcab": "PARIGI",
		        "TARGET": 2251788508,
		        "ACTUAL": 2614552161,
		        "PERSEN": 116.1
		    },
		    {
		        "nmcab": "SUNGAI LIAT",
		        "TARGET": 1427891274,
		        "ACTUAL": 1653588678,
		        "PERSEN": 115.8
		    },
		    {
		        "nmcab": "MAKASSAR 3",
		        "TARGET": 6757861770,
		        "ACTUAL": 7814794132,
		        "PERSEN": 115.6
		    },
		    {
		        "nmcab": "MEULABOH",
		        "TARGET": 2725953120,
		        "ACTUAL": 3135707824,
		        "PERSEN": 115
		    },
		    {
		        "nmcab": "MALANG",
		        "TARGET": 1101275324,
		        "ACTUAL": 1265096960,
		        "PERSEN": 114.9
		    },
		    {
		        "nmcab": "PENDOLO",
		        "TARGET": 1165970243,
		        "ACTUAL": 1324237937,
		        "PERSEN": 113.6
		    },
		    {
		        "nmcab": "PURWAKARTA",
		        "TARGET": 2668732560,
		        "ACTUAL": 3030081884,
		        "PERSEN": 113.5
		    },
		    {
		        "nmcab": "KOTARAYA",
		        "TARGET": 1675919056,
		        "ACTUAL": 1898522875,
		        "PERSEN": 113.3
		    },
		    {
		        "nmcab": "MANOKWARI",
		        "TARGET": 2019705888,
		        "ACTUAL": 2267820079,
		        "PERSEN": 112.3
		    },
		    {
		        "nmcab": "SANGATTA",
		        "TARGET": 1969910288,
		        "ACTUAL": 2208522549,
		        "PERSEN": 112.1
		    },
		    {
		        "nmcab": "MASOHI",
		        "TARGET": 2186869786,
		        "ACTUAL": 2437154096,
		        "PERSEN": 111.4
		    },
		    {
		        "nmcab": "TOILI",
		        "TARGET": 1989914680,
		        "ACTUAL": 2199518569,
		        "PERSEN": 110.5
		    },
		    {
		        "nmcab": "BOEPINANG",
		        "TARGET": 1378428696,
		        "ACTUAL": 1521221878,
		        "PERSEN": 110.4
		    },
		    {
		        "nmcab": "TANGGEUNG",
		        "TARGET": 1348932046,
		        "ACTUAL": 1473114244,
		        "PERSEN": 109.2
		    },
		    {
		        "nmcab": "PRINGSEWU",
		        "TARGET": 1198666278,
		        "ACTUAL": 1298932176,
		        "PERSEN": 108.4
		    },
		    {
		        "nmcab": "MENTOK",
		        "TARGET": 1180750550,
		        "ACTUAL": 1270301933,
		        "PERSEN": 107.6
		    },
		    {
		        "nmcab": "CIREBON",
		        "TARGET": 2197528456,
		        "ACTUAL": 2316962312,
		        "PERSEN": 105.4
		    },
		    {
		        "nmcab": "CIANJUR",
		        "TARGET": 2422464564,
		        "ACTUAL": 2509086124,
		        "PERSEN": 103.6
		    },
		    {
		        "nmcab": "GOWA 2",
		        "TARGET": 3793621444,
		        "ACTUAL": 3893886536,
		        "PERSEN": 102.6
		    },
		    {
		        "nmcab": "SEMARANG",
		        "TARGET": 2054482112,
		        "ACTUAL": 2096424348,
		        "PERSEN": 102
		    },
		    {
		        "nmcab": "JAILOLO",
		        "TARGET": 3978047664,
		        "ACTUAL": 4052782699,
		        "PERSEN": 101.9
		    },
		    {
		        "nmcab": "GOWA",
		        "TARGET": 4396791668,
		        "ACTUAL": 4458072584,
		        "PERSEN": 101.4
		    },
		    {
		        "nmcab": "PALANGKARAYA",
		        "TARGET": 1691347748,
		        "ACTUAL": 1714698759,
		        "PERSEN": 101.4
		    },
		    {
		        "nmcab": "PENAJAM",
		        "TARGET": 992168712,
		        "ACTUAL": 1002049683,
		        "PERSEN": 101
		    },
		    {
		        "nmcab": "BOGOR",
		        "TARGET": 2915677316,
		        "ACTUAL": 2942763785,
		        "PERSEN": 100.9
		    },
		    {
		        "nmcab": "SAMARINDA",
		        "TARGET": 2537307862,
		        "ACTUAL": 2551151255,
		        "PERSEN": 100.5
		    },
		    {
		        "nmcab": "TAKALAR",
		        "TARGET": 3402523356,
		        "ACTUAL": 3389437902,
		        "PERSEN": 99.6
		    },
		    {
		        "nmcab": "WAISARISSA",
		        "TARGET": 1321364230,
		        "ACTUAL": 1313513790,
		        "PERSEN": 99.4
		    },
		    {
		        "nmcab": "BAYUNG LENCIR",
		        "TARGET": 2714384020,
		        "ACTUAL": 2686324565,
		        "PERSEN": 99
		    },
		    {
		        "nmcab": "SUBANG",
		        "TARGET": 1229418932,
		        "ACTUAL": 1214343775,
		        "PERSEN": 98.8
		    },
		    {
		        "nmcab": "MAKASSAR 2",
		        "TARGET": 5297180544,
		        "ACTUAL": 5171657478,
		        "PERSEN": 97.6
		    },
		    {
		        "nmcab": "AMBON",
		        "TARGET": 6005945008,
		        "ACTUAL": 5852737246,
		        "PERSEN": 97.4
		    },
		    {
		        "nmcab": "CIBINONG",
		        "TARGET": 2966193076,
		        "ACTUAL": 2889490049,
		        "PERSEN": 97.4
		    },
		    {
		        "nmcab": "PINRANG",
		        "TARGET": 3606209566,
		        "ACTUAL": 3508280713,
		        "PERSEN": 97.3
		    },
		    {
		        "nmcab": "TENTENA",
		        "TARGET": 1483119899,
		        "ACTUAL": 1435348932,
		        "PERSEN": 96.8
		    },
		    {
		        "nmcab": "KARAWANG",
		        "TARGET": 4702812846,
		        "ACTUAL": 4539334032,
		        "PERSEN": 96.5
		    },
		    {
		        "nmcab": "KOTABARU",
		        "TARGET": 1204600937,
		        "ACTUAL": 1160860179,
		        "PERSEN": 96.4
		    },
		    {
		        "nmcab": "BITUNG",
		        "TARGET": 3298504840,
		        "ACTUAL": 3171858685,
		        "PERSEN": 96.2
		    },
		    {
		        "nmcab": "PATROL",
		        "TARGET": 1797764680,
		        "ACTUAL": 1720998347,
		        "PERSEN": 95.7
		    },
		    {
		        "nmcab": "SUNGAI LILIN",
		        "TARGET": 2400035875,
		        "ACTUAL": 2292238182,
		        "PERSEN": 95.5
		    },
		    {
		        "nmcab": "TERNATE",
		        "TARGET": 3617590444,
		        "ACTUAL": 3448533154,
		        "PERSEN": 95.3
		    },
		    {
		        "nmcab": "TUAL",
		        "TARGET": 1227985616,
		        "ACTUAL": 1157685803,
		        "PERSEN": 94.3
		    },
		    {
		        "nmcab": "MAKALE",
		        "TARGET": 2569714200,
		        "ACTUAL": 2412722702,
		        "PERSEN": 93.9
		    },
		    {
		        "nmcab": "PUNGGALUKU",
		        "TARGET": 1680047641,
		        "ACTUAL": 1573829068,
		        "PERSEN": 93.7
		    },
		    {
		        "nmcab": "TANAH GROGOT",
		        "TARGET": 1442986213,
		        "ACTUAL": 1349417426,
		        "PERSEN": 93.5
		    },
		    {
		        "nmcab": "PASANGKAYU",
		        "TARGET": 2731508244,
		        "ACTUAL": 2550652106,
		        "PERSEN": 93.4
		    },
		    {
		        "nmcab": "MOROTAI",
		        "TARGET": 290388727,
		        "ACTUAL": 270559944,
		        "PERSEN": 93.2
		    },
		    {
		        "nmcab": "JAMPANG",
		        "TARGET": 1014582018,
		        "ACTUAL": 943235923,
		        "PERSEN": 93
		    },
		    {
		        "nmcab": "BELOPA",
		        "TARGET": 2712388240,
		        "ACTUAL": 2515108850,
		        "PERSEN": 92.7
		    },
		    {
		        "nmcab": "RATAHAN",
		        "TARGET": 2458758216,
		        "ACTUAL": 2278276082,
		        "PERSEN": 92.7
		    },
		    {
		        "nmcab": "CIKARANG",
		        "TARGET": 2655227552,
		        "ACTUAL": 2456833522,
		        "PERSEN": 92.5
		    },
		    {
		        "nmcab": "DONGGALA",
		        "TARGET": 2261211802,
		        "ACTUAL": 2088839315,
		        "PERSEN": 92.4
		    },
		    {
		        "nmcab": "BACAN",
		        "TARGET": 670391985,
		        "ACTUAL": 618895853,
		        "PERSEN": 92.3
		    },
		    {
		        "nmcab": "LAHAT",
		        "TARGET": 3025093226,
		        "ACTUAL": 2790445067,
		        "PERSEN": 92.2
		    },
		    {
		        "nmcab": "MAKASSAR",
		        "TARGET": 6325195212,
		        "ACTUAL": 5815379456,
		        "PERSEN": 91.9
		    },
		    {
		        "nmcab": "BANJARMASIN",
		        "TARGET": 4182718864,
		        "ACTUAL": 3843964630,
		        "PERSEN": 91.9
		    },
		    {
		        "nmcab": "SRAGEN",
		        "TARGET": 656424293,
		        "ACTUAL": 600295000,
		        "PERSEN": 91.4
		    },
		    {
		        "nmcab": "KASIPUTE",
		        "TARGET": 1501706316,
		        "ACTUAL": 1368945529,
		        "PERSEN": 91.2
		    },
		    {
		        "nmcab": "PALEMBANG",
		        "TARGET": 4403319482,
		        "ACTUAL": 4010516457,
		        "PERSEN": 91.1
		    },
		    {
		        "nmcab": "PEMATANG SIANTAR",
		        "TARGET": 2178411994,
		        "ACTUAL": 1974303057,
		        "PERSEN": 90.6
		    },
		    {
		        "nmcab": "RAWAJITU",
		        "TARGET": 1061072311,
		        "ACTUAL": 960896087,
		        "PERSEN": 90.6
		    },
		    {
		        "nmcab": "TANGERANG",
		        "TARGET": 2823851686,
		        "ACTUAL": 2555972644,
		        "PERSEN": 90.5
		    },
		    {
		        "nmcab": "ENDE",
		        "TARGET": 364572610,
		        "ACTUAL": 329006178,
		        "PERSEN": 90.2
		    },
		    {
		        "nmcab": "PANGKALANBUN",
		        "TARGET": 535659865,
		        "ACTUAL": 481416075,
		        "PERSEN": 89.9
		    },
		    {
		        "nmcab": "MASBAGIK",
		        "TARGET": 1249071498,
		        "ACTUAL": 1121504300,
		        "PERSEN": 89.8
		    },
		    {
		        "nmcab": "MAROS",
		        "TARGET": 3605025304,
		        "ACTUAL": 3227784101,
		        "PERSEN": 89.5
		    },
		    {
		        "nmcab": "KOTOBARU",
		        "TARGET": 1771139445,
		        "ACTUAL": 1582549743,
		        "PERSEN": 89.4
		    },
		    {
		        "nmcab": "PANGKEP",
		        "TARGET": 2088042094,
		        "ACTUAL": 1863149213,
		        "PERSEN": 89.2
		    },
		    {
		        "nmcab": "LUBUKBASUNG",
		        "TARGET": 1253721844,
		        "ACTUAL": 1116880347,
		        "PERSEN": 89.1
		    },
		    {
		        "nmcab": "KUNINGAN",
		        "TARGET": 1501058068,
		        "ACTUAL": 1324231167,
		        "PERSEN": 88.2
		    },
		    {
		        "nmcab": "ALUE BILIE",
		        "TARGET": 1035185976,
		        "ACTUAL": 907817385,
		        "PERSEN": 87.7
		    },
		    {
		        "nmcab": "KOLAKA",
		        "TARGET": 4000074944,
		        "ACTUAL": 3494429953,
		        "PERSEN": 87.4
		    },
		    {
		        "nmcab": "JATIBARANG",
		        "TARGET": 2059951402,
		        "ACTUAL": 1795955200,
		        "PERSEN": 87.2
		    },
		    {
		        "nmcab": "TOMOHON",
		        "TARGET": 812841138,
		        "ACTUAL": 706520106,
		        "PERSEN": 86.9
		    },
		    {
		        "nmcab": "BANJARAN",
		        "TARGET": 1810338362,
		        "ACTUAL": 1571589195,
		        "PERSEN": 86.8
		    },
		    {
		        "nmcab": "JEMBER",
		        "TARGET": 1236114969,
		        "ACTUAL": 1069580244,
		        "PERSEN": 86.5
		    },
		    {
		        "nmcab": "TAKENGON",
		        "TARGET": 1967840596,
		        "ACTUAL": 1695461129,
		        "PERSEN": 86.2
		    },
		    {
		        "nmcab": "TARAKAN",
		        "TARGET": 1148729044,
		        "ACTUAL": 989227157,
		        "PERSEN": 86.1
		    },
		    {
		        "nmcab": "SAMARINDA SEBERANG",
		        "TARGET": 1360349144,
		        "ACTUAL": 1171441108,
		        "PERSEN": 86.1
		    },
		    {
		        "nmcab": "BOROKO",
		        "TARGET": 831828464,
		        "ACTUAL": 712494950,
		        "PERSEN": 85.7
		    },
		    {
		        "nmcab": "SIMPANG PEMATANG",
		        "TARGET": 1121759089,
		        "ACTUAL": 960639374,
		        "PERSEN": 85.6
		    },
		    {
		        "nmcab": "AMPANA",
		        "TARGET": 1792484619,
		        "ACTUAL": 1532629261,
		        "PERSEN": 85.5
		    },
		    {
		        "nmcab": "UJUNG BERUNG",
		        "TARGET": 1313173900,
		        "ACTUAL": 1118945997,
		        "PERSEN": 85.2
		    },
		    {
		        "nmcab": "MANADO",
		        "TARGET": 3884876640,
		        "ACTUAL": 3299372906,
		        "PERSEN": 84.9
		    },
		    {
		        "nmcab": "TOBELO",
		        "TARGET": 1772151494,
		        "ACTUAL": 1503658237,
		        "PERSEN": 84.8
		    },
		    {
		        "nmcab": "PARE-PARE",
		        "TARGET": 3397738250,
		        "ACTUAL": 2880494995,
		        "PERSEN": 84.8
		    },
		    {
		        "nmcab": "KADIPATEN",
		        "TARGET": 1708621733,
		        "ACTUAL": 1445319151,
		        "PERSEN": 84.6
		    },
		    {
		        "nmcab": "SIGLI",
		        "TARGET": 1347929656,
		        "ACTUAL": 1135465361,
		        "PERSEN": 84.2
		    },
		    {
		        "nmcab": "MOLIBAGU",
		        "TARGET": 661181927,
		        "ACTUAL": 555785723,
		        "PERSEN": 84.1
		    },
		    {
		        "nmcab": "MUARA TEWEH",
		        "TARGET": 2006662653,
		        "ACTUAL": 1682414054,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "BLANG PIDIE",
		        "TARGET": 1821478060,
		        "ACTUAL": 1526874495,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "TALAUD",
		        "TARGET": 1086086296,
		        "ACTUAL": 909848564,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "PALOPO",
		        "TARGET": 4557880764,
		        "ACTUAL": 3817937928,
		        "PERSEN": 83.8
		    },
		    {
		        "nmcab": "BOYOLALI",
		        "TARGET": 923440422,
		        "ACTUAL": 767556658,
		        "PERSEN": 83.1
		    },
		    {
		        "nmcab": "PARUNGKUDA",
		        "TARGET": 2243345040,
		        "ACTUAL": 1858167230,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcab": "MUARA ENIM",
		        "TARGET": 1464765154,
		        "ACTUAL": 1212765921,
		        "PERSEN": 82.8
		    },
		    {
		        "nmcab": "SAMPIT",
		        "TARGET": 2027799281,
		        "ACTUAL": 1675123311,
		        "PERSEN": 82.6
		    },
		    {
		        "nmcab": "GARUT",
		        "TARGET": 2324798602,
		        "ACTUAL": 1908720795,
		        "PERSEN": 82.1
		    },
		    {
		        "nmcab": "BONE",
		        "TARGET": 3016861836,
		        "ACTUAL": 2476741786,
		        "PERSEN": 82.1
		    },
		    {
		        "nmcab": "BALIKPAPAN",
		        "TARGET": 2032983824,
		        "ACTUAL": 1665689418,
		        "PERSEN": 81.9
		    },
		    {
		        "nmcab": "LHOKSEUMAWE",
		        "TARGET": 2599270760,
		        "ACTUAL": 2129388066,
		        "PERSEN": 81.9
		    },
		    {
		        "nmcab": "MARTAPURA KAL",
		        "TARGET": 1798887864,
		        "ACTUAL": 1471212235,
		        "PERSEN": 81.8
		    },
		    {
		        "nmcab": "LABUAN BAJO",
		        "TARGET": 551062030,
		        "ACTUAL": 449366609,
		        "PERSEN": 81.5
		    },
		    {
		        "nmcab": "BAWEN",
		        "TARGET": 1314689800,
		        "ACTUAL": 1068759200,
		        "PERSEN": 81.3
		    },
		    {
		        "nmcab": "TANJUNG",
		        "TARGET": 1177546595,
		        "ACTUAL": 952050770,
		        "PERSEN": 80.9
		    },
		    {
		        "nmcab": "WAY KANAN",
		        "TARGET": 974063199,
		        "ACTUAL": 785035731,
		        "PERSEN": 80.6
		    },
		    {
		        "nmcab": "BELITANG",
		        "TARGET": 838515028,
		        "ACTUAL": 675420334,
		        "PERSEN": 80.5
		    },
		    {
		        "nmcab": "SUMBAWA",
		        "TARGET": 510942340,
		        "ACTUAL": 408842000,
		        "PERSEN": 80
		    },
		    {
		        "nmcab": "PONTIANAK",
		        "TARGET": 493936376,
		        "ACTUAL": 394950630,
		        "PERSEN": 80
		    },
		    {
		        "nmcab": "JENEPONTO",
		        "TARGET": 3461705452,
		        "ACTUAL": 2753693744,
		        "PERSEN": 79.5
		    },
		    {
		        "nmcab": "LAMPUNG",
		        "TARGET": 3527318068,
		        "ACTUAL": 2797098140,
		        "PERSEN": 79.3
		    },
		    {
		        "nmcab": "TANJUNG BINTANG",
		        "TARGET": 930544189,
		        "ACTUAL": 736208717,
		        "PERSEN": 79.1
		    },
		    {
		        "nmcab": "RAHA",
		        "TARGET": 2180073882,
		        "ACTUAL": 1723944406,
		        "PERSEN": 79.1
		    },
		    {
		        "nmcab": "WONOSARI",
		        "TARGET": 829737468,
		        "ACTUAL": 653932000,
		        "PERSEN": 78.8
		    },
		    {
		        "nmcab": "BETUNG",
		        "TARGET": 2147481302,
		        "ACTUAL": 1690218481,
		        "PERSEN": 78.7
		    },
		    {
		        "nmcab": "BANGKALA",
		        "TARGET": 2462590994,
		        "ACTUAL": 1932648058,
		        "PERSEN": 78.5
		    },
		    {
		        "nmcab": "TUGUMULYO",
		        "TARGET": 1034916068,
		        "ACTUAL": 799664232,
		        "PERSEN": 77.3
		    },
		    {
		        "nmcab": "BENGKULU",
		        "TARGET": 845615256,
		        "ACTUAL": 646314692,
		        "PERSEN": 76.4
		    },
		    {
		        "nmcab": "RUTENG",
		        "TARGET": 649083303,
		        "ACTUAL": 495713525,
		        "PERSEN": 76.4
		    },
		    {
		        "nmcab": "KUALA SIMPANG",
		        "TARGET": 2926444136,
		        "ACTUAL": 2195064457,
		        "PERSEN": 75
		    },
		    {
		        "nmcab": "PROBOLINGGO",
		        "TARGET": 733475978,
		        "ACTUAL": 546782750,
		        "PERSEN": 74.5
		    },
		    {
		        "nmcab": "IDIE",
		        "TARGET": 2889238680,
		        "ACTUAL": 2150136597,
		        "PERSEN": 74.4
		    },
		    {
		        "nmcab": "TUNGKAL",
		        "TARGET": 509342925,
		        "ACTUAL": 376905349,
		        "PERSEN": 74
		    },
		    {
		        "nmcab": "UJUNG GADING",
		        "TARGET": 1741103932,
		        "ACTUAL": 1282784006,
		        "PERSEN": 73.7
		    },
		    {
		        "nmcab": "BUTON",
		        "TARGET": 4324916192,
		        "ACTUAL": 3184562745,
		        "PERSEN": 73.6
		    },
		    {
		        "nmcab": "NAMLEA",
		        "TARGET": 3058328748,
		        "ACTUAL": 2249884655,
		        "PERSEN": 73.6
		    },
		    {
		        "nmcab": "BABAT TOMAN",
		        "TARGET": 1256641094,
		        "ACTUAL": 920428369,
		        "PERSEN": 73.2
		    },
		    {
		        "nmcab": "MASAMBA",
		        "TARGET": 3016204616,
		        "ACTUAL": 2192362780,
		        "PERSEN": 72.7
		    },
		    {
		        "nmcab": "TORAJA",
		        "TARGET": 4081662372,
		        "ACTUAL": 2957696252,
		        "PERSEN": 72.5
		    },
		    {
		        "nmcab": "BANJAR",
		        "TARGET": 1386003036,
		        "ACTUAL": 1002053343,
		        "PERSEN": 72.3
		    },
		    {
		        "nmcab": "TEGAL",
		        "TARGET": 1060763305,
		        "ACTUAL": 765160291,
		        "PERSEN": 72.1
		    },
		    {
		        "nmcab": "BLITAR",
		        "TARGET": 1318570280,
		        "ACTUAL": 949898354,
		        "PERSEN": 72
		    },
		    {
		        "nmcab": "LADONGI",
		        "TARGET": 1451505780,
		        "ACTUAL": 1036256492,
		        "PERSEN": 71.4
		    },
		    {
		        "nmcab": "TOPPOYO",
		        "TARGET": 2847800304,
		        "ACTUAL": 2027419163,
		        "PERSEN": 71.2
		    },
		    {
		        "nmcab": "PANTON LABU",
		        "TARGET": 884347030,
		        "ACTUAL": 628891706,
		        "PERSEN": 71.1
		    },
		    {
		        "nmcab": "NAGAN",
		        "TARGET": 1004348615,
		        "ACTUAL": 713664018,
		        "PERSEN": 71.1
		    },
		    {
		        "nmcab": "TASIKMALAYA",
		        "TARGET": 2048464870,
		        "ACTUAL": 1452558651,
		        "PERSEN": 70.9
		    },
		    {
		        "nmcab": "KOTA AGUNG",
		        "TARGET": 777655023,
		        "ACTUAL": 550819548,
		        "PERSEN": 70.8
		    },
		    {
		        "nmcab": "ARGA MAKMUR",
		        "TARGET": 1244032719,
		        "ACTUAL": 879992281,
		        "PERSEN": 70.7
		    },
		    {
		        "nmcab": "KALIANDA",
		        "TARGET": 1622061697,
		        "ACTUAL": 1145452850,
		        "PERSEN": 70.6
		    },
		    {
		        "nmcab": "PADANG",
		        "TARGET": 1334194344,
		        "ACTUAL": 935374956,
		        "PERSEN": 70.1
		    },
		    {
		        "nmcab": "MALILI",
		        "TARGET": 3178466994,
		        "ACTUAL": 2217166947,
		        "PERSEN": 69.8
		    },
		    {
		        "nmcab": "BUNTA",
		        "TARGET": 1938512472,
		        "ACTUAL": 1350312930,
		        "PERSEN": 69.7
		    },
		    {
		        "nmcab": "SERANG",
		        "TARGET": 2186573192,
		        "ACTUAL": 1501538862,
		        "PERSEN": 68.7
		    },
		    {
		        "nmcab": "SORONG",
		        "TARGET": 1479958635,
		        "ACTUAL": 1012747039,
		        "PERSEN": 68.4
		    },
		    {
		        "nmcab": "TULANG BAWANG",
		        "TARGET": 1209957650,
		        "ACTUAL": 822935746,
		        "PERSEN": 68
		    },
		    {
		        "nmcab": "SIAU",
		        "TARGET": 842363104,
		        "ACTUAL": 567352073,
		        "PERSEN": 67.4
		    },
		    {
		        "nmcab": "BANTAENG",
		        "TARGET": 2036008875,
		        "ACTUAL": 1371228975,
		        "PERSEN": 67.3
		    },
		    {
		        "nmcab": "PLEIHARI",
		        "TARGET": 883938890,
		        "ACTUAL": 594840762,
		        "PERSEN": 67.3
		    },
		    {
		        "nmcab": "ACEH",
		        "TARGET": 3022345600,
		        "ACTUAL": 2031938630,
		        "PERSEN": 67.2
		    },
		    {
		        "nmcab": "INDRALAYA",
		        "TARGET": 913899040,
		        "ACTUAL": 613697477,
		        "PERSEN": 67.2
		    },
		    {
		        "nmcab": "MARISA",
		        "TARGET": 2378924644,
		        "ACTUAL": 1595151616,
		        "PERSEN": 67.1
		    },
		    {
		        "nmcab": "KAPUAS",
		        "TARGET": 367211677,
		        "ACTUAL": 245813285,
		        "PERSEN": 66.9
		    },
		    {
		        "nmcab": "MANGKUTANA",
		        "TARGET": 2665915050,
		        "ACTUAL": 1784081096,
		        "PERSEN": 66.9
		    },
		    {
		        "nmcab": "BARRU",
		        "TARGET": 2189955704,
		        "ACTUAL": 1458681623,
		        "PERSEN": 66.6
		    },
		    {
		        "nmcab": "BALARAJA",
		        "TARGET": 1834123472,
		        "ACTUAL": 1219677794,
		        "PERSEN": 66.5
		    },
		    {
		        "nmcab": "SUKABUMI",
		        "TARGET": 2090250672,
		        "ACTUAL": 1378532794,
		        "PERSEN": 66
		    },
		    {
		        "nmcab": "CURUP",
		        "TARGET": 776639436,
		        "ACTUAL": 510756807,
		        "PERSEN": 65.8
		    },
		    {
		        "nmcab": "WAY JEPARA",
		        "TARGET": 1060499699,
		        "ACTUAL": 696877088,
		        "PERSEN": 65.7
		    },
		    {
		        "nmcab": "BANGKO",
		        "TARGET": 1307096921,
		        "ACTUAL": 854789642,
		        "PERSEN": 65.4
		    },
		    {
		        "nmcab": "SIJUNGJUNG",
		        "TARGET": 1515092576,
		        "ACTUAL": 985634246,
		        "PERSEN": 65.1
		    },
		    {
		        "nmcab": "BULUKUMBA",
		        "TARGET": 3319834076,
		        "ACTUAL": 2151000869,
		        "PERSEN": 64.8
		    },
		    {
		        "nmcab": "PARIAMAN",
		        "TARGET": 845919665,
		        "ACTUAL": 543278803,
		        "PERSEN": 64.2
		    },
		    {
		        "nmcab": "SINJAI",
		        "TARGET": 1724126736,
		        "ACTUAL": 1107223725,
		        "PERSEN": 64.2
		    },
		    {
		        "nmcab": "GRESIK",
		        "TARGET": 1062030964,
		        "ACTUAL": 678062000,
		        "PERSEN": 63.8
		    },
		    {
		        "nmcab": "ULEE GLEE",
		        "TARGET": 1150387826,
		        "ACTUAL": 727422099,
		        "PERSEN": 63.2
		    },
		    {
		        "nmcab": "CILEDUG",
		        "TARGET": 1670971580,
		        "ACTUAL": 1045719996,
		        "PERSEN": 62.6
		    },
		    {
		        "nmcab": "MAJENE",
		        "TARGET": 1742231824,
		        "ACTUAL": 1052694026,
		        "PERSEN": 60.4
		    },
		    {
		        "nmcab": "BATU SANGKAR",
		        "TARGET": 1273749882,
		        "ACTUAL": 763455502,
		        "PERSEN": 59.9
		    },
		    {
		        "nmcab": "BINJAI",
		        "TARGET": 1598881168,
		        "ACTUAL": 942189156,
		        "PERSEN": 58.9
		    },
		    {
		        "nmcab": "KAYU AGUNG",
		        "TARGET": 1793905268,
		        "ACTUAL": 1054120267,
		        "PERSEN": 58.8
		    },
		    {
		        "nmcab": "ENREKANG",
		        "TARGET": 1665925089,
		        "ACTUAL": 975995510,
		        "PERSEN": 58.6
		    },
		    {
		        "nmcab": "BATURAJA",
		        "TARGET": 992209174,
		        "ACTUAL": 578591676,
		        "PERSEN": 58.3
		    },
		    {
		        "nmcab": "KOTABUMI",
		        "TARGET": 1030314835,
		        "ACTUAL": 599769630,
		        "PERSEN": 58.2
		    },
		    {
		        "nmcab": "PRABUMULIH",
		        "TARGET": 1185825160,
		        "ACTUAL": 689079966,
		        "PERSEN": 58.1
		    },
		    {
		        "nmcab": "METRO",
		        "TARGET": 1497354430,
		        "ACTUAL": 869446884,
		        "PERSEN": 58.1
		    },
		    {
		        "nmcab": "DAYA MURNI",
		        "TARGET": 929139424,
		        "ACTUAL": 537899134,
		        "PERSEN": 57.9
		    },
		    {
		        "nmcab": "TENGGARONG",
		        "TARGET": 1789211323,
		        "ACTUAL": 1028206382,
		        "PERSEN": 57.5
		    },
		    {
		        "nmcab": "MADIUN",
		        "TARGET": 926101188,
		        "ACTUAL": 530466500,
		        "PERSEN": 57.3
		    },
		    {
		        "nmcab": "BOALEMO",
		        "TARGET": 1972137884,
		        "ACTUAL": 1123089085,
		        "PERSEN": 56.9
		    },
		    {
		        "nmcab": "SAUMLAKI",
		        "TARGET": 1153047344,
		        "ACTUAL": 655451765,
		        "PERSEN": 56.8
		    },
		    {
		        "nmcab": "EREKE",
		        "TARGET": 1489723580,
		        "ACTUAL": 840567075,
		        "PERSEN": 56.4
		    },
		    {
		        "nmcab": "PARUNG",
		        "TARGET": 2231936612,
		        "ACTUAL": 1254723684,
		        "PERSEN": 56.2
		    },
		    {
		        "nmcab": "SIDRAP",
		        "TARGET": 3625671148,
		        "ACTUAL": 2035568961,
		        "PERSEN": 56.1
		    },
		    {
		        "nmcab": "TEMANGGUNG",
		        "TARGET": 2057074176,
		        "ACTUAL": 1149509400,
		        "PERSEN": 55.9
		    },
		    {
		        "nmcab": "SOLO",
		        "TARGET": 1349848005,
		        "ACTUAL": 748056000,
		        "PERSEN": 55.4
		    },
		    {
		        "nmcab": "SOPPENG",
		        "TARGET": 1618179272,
		        "ACTUAL": 892165714,
		        "PERSEN": 55.1
		    },
		    {
		        "nmcab": "PATI",
		        "TARGET": 900865891,
		        "ACTUAL": 492988371,
		        "PERSEN": 54.7
		    },
		    {
		        "nmcab": "PURWOKERTO",
		        "TARGET": 1131547539,
		        "ACTUAL": 617932100,
		        "PERSEN": 54.6
		    },
		    {
		        "nmcab": "MEDAN",
		        "TARGET": 2672793324,
		        "ACTUAL": 1442176474,
		        "PERSEN": 54
		    },
		    {
		        "nmcab": "LASUSUA",
		        "TARGET": 1103412010,
		        "ACTUAL": 591673492,
		        "PERSEN": 53.6
		    },
		    {
		        "nmcab": "TAHUNA",
		        "TARGET": 1556153980,
		        "ACTUAL": 827418184,
		        "PERSEN": 53.2
		    },
		    {
		        "nmcab": "KOTAMOBAGU",
		        "TARGET": 1420094514,
		        "ACTUAL": 738262250,
		        "PERSEN": 52
		    },
		    {
		        "nmcab": "PEKALONGAN",
		        "TARGET": 802047292,
		        "ACTUAL": 416677000,
		        "PERSEN": 52
		    },
		    {
		        "nmcab": "LEUWILIANG",
		        "TARGET": 3221676232,
		        "ACTUAL": 1651028613,
		        "PERSEN": 51.2
		    },
		    {
		        "nmcab": "KARANGANYAR",
		        "TARGET": 1381318943,
		        "ACTUAL": 704879550,
		        "PERSEN": 51
		    },
		    {
		        "nmcab": "SEKAYU",
		        "TARGET": 904607640,
		        "ACTUAL": 460401450,
		        "PERSEN": 50.9
		    },
		    {
		        "nmcab": "CILACAP",
		        "TARGET": 1230195036,
		        "ACTUAL": 618864754,
		        "PERSEN": 50.3
		    },
		    {
		        "nmcab": "PASAMAN",
		        "TARGET": 1078861434,
		        "ACTUAL": 541854684,
		        "PERSEN": 50.2
		    },
		    {
		        "nmcab": "SURABAYA",
		        "TARGET": 1234687666,
		        "ACTUAL": 618920500,
		        "PERSEN": 50.1
		    },
		    {
		        "nmcab": "WONOGIRI",
		        "TARGET": 1376203311,
		        "ACTUAL": 684194000,
		        "PERSEN": 49.7
		    },
		    {
		        "nmcab": "MALINO",
		        "TARGET": 952229315,
		        "ACTUAL": 463686629,
		        "PERSEN": 48.7
		    },
		    {
		        "nmcab": "JAMBI",
		        "TARGET": 1810619925,
		        "ACTUAL": 880436038,
		        "PERSEN": 48.6
		    },
		    {
		        "nmcab": "LANGSA ACEH",
		        "TARGET": 1264481939,
		        "ACTUAL": 605510128,
		        "PERSEN": 47.9
		    },
		    {
		        "nmcab": "BUKITTINGGI",
		        "TARGET": 1281087526,
		        "ACTUAL": 609948466,
		        "PERSEN": 47.6
		    },
		    {
		        "nmcab": "TULUNGAGUNG",
		        "TARGET": 896554807,
		        "ACTUAL": 424676500,
		        "PERSEN": 47.4
		    },
		    {
		        "nmcab": "SOLOK",
		        "TARGET": 1385597962,
		        "ACTUAL": 640320202,
		        "PERSEN": 46.2
		    },
		    {
		        "nmcab": "KEDIRI",
		        "TARGET": 1327869026,
		        "ACTUAL": 600642426,
		        "PERSEN": 45.2
		    },
		    {
		        "nmcab": "PAYAKUMBUH",
		        "TARGET": 1182923150,
		        "ACTUAL": 534830200,
		        "PERSEN": 45.2
		    },
		    {
		        "nmcab": "SELAYAR",
		        "TARGET": 1905413612,
		        "ACTUAL": 853938730,
		        "PERSEN": 44.8
		    },
		    {
		        "nmcab": "POLMAS",
		        "TARGET": 2541192570,
		        "ACTUAL": 1116059296,
		        "PERSEN": 43.9
		    },
		    {
		        "nmcab": "SENGKANG",
		        "TARGET": 2883962752,
		        "ACTUAL": 1258466750,
		        "PERSEN": 43.6
		    },
		    {
		        "nmcab": "TEBO",
		        "TARGET": 1119131726,
		        "ACTUAL": 475000290,
		        "PERSEN": 42.4
		    },
		    {
		        "nmcab": "SABAK",
		        "TARGET": 864591390,
		        "ACTUAL": 366824002,
		        "PERSEN": 42.4
		    },
		    {
		        "nmcab": "MAMUJU",
		        "TARGET": 3016987400,
		        "ACTUAL": 1255684999,
		        "PERSEN": 41.6
		    },
		    {
		        "nmcab": "BOJONEGORO",
		        "TARGET": 670110430,
		        "ACTUAL": 278669500,
		        "PERSEN": 41.6
		    },
		    {
		        "nmcab": "PEKANBARU",
		        "TARGET": 2715141303,
		        "ACTUAL": 1118902434,
		        "PERSEN": 41.2
		    },
		    {
		        "nmcab": "BANDAR JAYA",
		        "TARGET": 1080979414,
		        "ACTUAL": 434797218,
		        "PERSEN": 40.2
		    },
		    {
		        "nmcab": "SIDOARJO",
		        "TARGET": 1483542852,
		        "ACTUAL": 591466168,
		        "PERSEN": 39.9
		    },
		    {
		        "nmcab": "MARTAPURA",
		        "TARGET": 555540868,
		        "ACTUAL": 206886560,
		        "PERSEN": 37.2
		    },
		    {
		        "nmcab": "LHOKSUKON",
		        "TARGET": 1150387826,
		        "ACTUAL": 415705657,
		        "PERSEN": 36.1
		    },
		    {
		        "nmcab": "RUMBIA",
		        "TARGET": 1080701236,
		        "ACTUAL": 383460089,
		        "PERSEN": 35.5
		    },
		    {
		        "nmcab": "LIWA",
		        "TARGET": 1022882271,
		        "ACTUAL": 356905294,
		        "PERSEN": 34.9
		    },
		    {
		        "nmcab": "LUBUK LINGGAU",
		        "TARGET": 1382741108,
		        "ACTUAL": 479903201,
		        "PERSEN": 34.7
		    },
		    {
		        "nmcab": "JAYAPURA",
		        "TARGET": 2038623646,
		        "ACTUAL": 663209660,
		        "PERSEN": 32.5
		    },
		    {
		        "nmcab": "BUNGO",
		        "TARGET": 1339851908,
		        "ACTUAL": 374807209,
		        "PERSEN": 28
		    },
		    {
		        "nmcab": "WONOSOBO",
		        "TARGET": 1902081340,
		        "ACTUAL": 521274636,
		        "PERSEN": 27.4
		    },
		    {
		        "nmcab": "KEBUMEN",
		        "TARGET": 966190300,
		        "ACTUAL": 264713900,
		        "PERSEN": 27.4
		    },
		    {
		        "nmcab": "MOJOKERTO",
		        "TARGET": 1043412140,
		        "ACTUAL": 219285000,
		        "PERSEN": 21
		    },
		    {
		        "nmcab": "SOROLANGON",
		        "TARGET": 449457320,
		        "ACTUAL": 0,
		        "PERSEN": 0
		    },
		    {
		        "nmcab": "MUARA BULIAN",
		        "TARGET": 199893770,
		        "ACTUAL": 0,
		        "PERSEN": 0
		    },
		    {
		        "nmcab": "PANGKALAN BRANDAN",
		        "TARGET": 0,
		        "ACTUAL": 0,
		        "PERSEN": null
		    },
		    {
		        "nmcab": "BULI",
		        "TARGET": 0,
		        "ACTUAL": 0,
		        "PERSEN": null
		    }
		],
        "columns": [
            { "data": "nmcab" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

	$('#tableProdukCabKonYtd').DataTable({
        "data":[
		    {
		        "nmcab": "DOMPU",
		        "TARGET": 51,
		        "ACTUAL": 95,
		        "PERSEN": 186.2745
		    },
		    {
		        "nmcab": "BARABAI",
		        "TARGET": 58,
		        "ACTUAL": 102,
		        "PERSEN": 175.8621
		    },
		    {
		        "nmcab": "MOROWALI",
		        "TARGET": 198,
		        "ACTUAL": 346,
		        "PERSEN": 174.7475
		    },
		    {
		        "nmcab": "BELINYU",
		        "TARGET": 86,
		        "ACTUAL": 150,
		        "PERSEN": 174.4186
		    },
		    {
		        "nmcab": "LUWUK",
		        "TARGET": 155,
		        "ACTUAL": 260,
		        "PERSEN": 167.7419
		    },
		    {
		        "nmcab": "BUOL",
		        "TARGET": 148,
		        "ACTUAL": 246,
		        "PERSEN": 166.2162
		    },
		    {
		        "nmcab": "BERAU",
		        "TARGET": 162,
		        "ACTUAL": 253,
		        "PERSEN": 156.1728
		    },
		    {
		        "nmcab": "PELABUHAN RATU",
		        "TARGET": 217,
		        "ACTUAL": 335,
		        "PERSEN": 154.3779
		    },
		    {
		        "nmcab": "PALU",
		        "TARGET": 463,
		        "ACTUAL": 689,
		        "PERSEN": 148.8121
		    },
		    {
		        "nmcab": "CIMAHI",
		        "TARGET": 235,
		        "ACTUAL": 349,
		        "PERSEN": 148.5106
		    },
		    {
		        "nmcab": "UNAAHA",
		        "TARGET": 159,
		        "ACTUAL": 230,
		        "PERSEN": 144.6541
		    },
		    {
		        "nmcab": "MAGELANG",
		        "TARGET": 145,
		        "ACTUAL": 209,
		        "PERSEN": 144.1379
		    },
		    {
		        "nmcab": "BELITUNG",
		        "TARGET": 140,
		        "ACTUAL": 201,
		        "PERSEN": 143.5714
		    },
		    {
		        "nmcab": "PALU 2",
		        "TARGET": 300,
		        "ACTUAL": 429,
		        "PERSEN": 143
		    },
		    {
		        "nmcab": "GORONTALO",
		        "TARGET": 400,
		        "ACTUAL": 567,
		        "PERSEN": 141.75
		    },
		    {
		        "nmcab": "BUNGKU",
		        "TARGET": 275,
		        "ACTUAL": 385,
		        "PERSEN": 140
		    },
		    {
		        "nmcab": "POSO",
		        "TARGET": 174,
		        "ACTUAL": 243,
		        "PERSEN": 139.6552
		    },
		    {
		        "nmcab": "KENDARI",
		        "TARGET": 307,
		        "ACTUAL": 418,
		        "PERSEN": 136.1564
		    },
		    {
		        "nmcab": "SALAKAN",
		        "TARGET": 191,
		        "ACTUAL": 252,
		        "PERSEN": 131.9372
		    },
		    {
		        "nmcab": "CIAWI",
		        "TARGET": 99,
		        "ACTUAL": 129,
		        "PERSEN": 130.303
		    },
		    {
		        "nmcab": "PANGANDARAN",
		        "TARGET": 129,
		        "ACTUAL": 167,
		        "PERSEN": 129.4574
		    },
		    {
		        "nmcab": "BANDUNG",
		        "TARGET": 168,
		        "ACTUAL": 215,
		        "PERSEN": 127.9762
		    },
		    {
		        "nmcab": "SUMEDANG",
		        "TARGET": 154,
		        "ACTUAL": 195,
		        "PERSEN": 126.6234
		    },
		    {
		        "nmcab": "BELTIM",
		        "TARGET": 79,
		        "ACTUAL": 100,
		        "PERSEN": 126.5823
		    },
		    {
		        "nmcab": "PATROL",
		        "TARGET": 179,
		        "ACTUAL": 221,
		        "PERSEN": 123.4637
		    },
		    {
		        "nmcab": "TOMPE",
		        "TARGET": 70,
		        "ACTUAL": 86,
		        "PERSEN": 122.8571
		    },
		    {
		        "nmcab": "CIREBON",
		        "TARGET": 193,
		        "ACTUAL": 236,
		        "PERSEN": 122.2798
		    },
		    {
		        "nmcab": "MAKASSAR 3",
		        "TARGET": 391,
		        "ACTUAL": 474,
		        "PERSEN": 121.2276
		    },
		    {
		        "nmcab": "BOGOR",
		        "TARGET": 260,
		        "ACTUAL": 309,
		        "PERSEN": 118.8462
		    },
		    {
		        "nmcab": "SUNGAI LILIN",
		        "TARGET": 149,
		        "ACTUAL": 176,
		        "PERSEN": 118.1208
		    },
		    {
		        "nmcab": "PALANGKARAYA",
		        "TARGET": 150,
		        "ACTUAL": 176,
		        "PERSEN": 117.3333
		    },
		    {
		        "nmcab": "SUBANG",
		        "TARGET": 116,
		        "ACTUAL": 136,
		        "PERSEN": 117.2414
		    },
		    {
		        "nmcab": "TOLI TOLI",
		        "TARGET": 137,
		        "ACTUAL": 160,
		        "PERSEN": 116.7883
		    },
		    {
		        "nmcab": "TANGGEUNG",
		        "TARGET": 123,
		        "ACTUAL": 143,
		        "PERSEN": 116.2602
		    },
		    {
		        "nmcab": "BATU LICIN",
		        "TARGET": 148,
		        "ACTUAL": 172,
		        "PERSEN": 116.2162
		    },
		    {
		        "nmcab": "MASOHI",
		        "TARGET": 198,
		        "ACTUAL": 230,
		        "PERSEN": 116.1616
		    },
		    {
		        "nmcab": "CIANJUR",
		        "TARGET": 237,
		        "ACTUAL": 275,
		        "PERSEN": 116.0338
		    },
		    {
		        "nmcab": "KOTARAYA",
		        "TARGET": 110,
		        "ACTUAL": 126,
		        "PERSEN": 114.5455
		    },
		    {
		        "nmcab": "PANGKALANBUN",
		        "TARGET": 50,
		        "ACTUAL": 57,
		        "PERSEN": 114
		    },
		    {
		        "nmcab": "PARIGI",
		        "TARGET": 158,
		        "ACTUAL": 179,
		        "PERSEN": 113.2911
		    },
		    {
		        "nmcab": "SANGATTA",
		        "TARGET": 136,
		        "ACTUAL": 154,
		        "PERSEN": 113.2353
		    },
		    {
		        "nmcab": "SAMARINDA SEBERANG",
		        "TARGET": 95,
		        "ACTUAL": 107,
		        "PERSEN": 112.6316
		    },
		    {
		        "nmcab": "BANGKA",
		        "TARGET": 231,
		        "ACTUAL": 260,
		        "PERSEN": 112.5541
		    },
		    {
		        "nmcab": "JEBUS",
		        "TARGET": 71,
		        "ACTUAL": 79,
		        "PERSEN": 111.2676
		    },
		    {
		        "nmcab": "TOBOALI",
		        "TARGET": 92,
		        "ACTUAL": 102,
		        "PERSEN": 110.8696
		    },
		    {
		        "nmcab": "MALANG",
		        "TARGET": 168,
		        "ACTUAL": 185,
		        "PERSEN": 110.119
		    },
		    {
		        "nmcab": "BOEPINANG",
		        "TARGET": 99,
		        "ACTUAL": 109,
		        "PERSEN": 110.101
		    },
		    {
		        "nmcab": "YOGYAKARTA",
		        "TARGET": 145,
		        "ACTUAL": 159,
		        "PERSEN": 109.6552
		    },
		    {
		        "nmcab": "PRINGSEWU",
		        "TARGET": 100,
		        "ACTUAL": 109,
		        "PERSEN": 109
		    },
		    {
		        "nmcab": "MEULABOH",
		        "TARGET": 225,
		        "ACTUAL": 245,
		        "PERSEN": 108.8889
		    },
		    {
		        "nmcab": "AMPANA",
		        "TARGET": 152,
		        "ACTUAL": 165,
		        "PERSEN": 108.5526
		    },
		    {
		        "nmcab": "PUNGGALUKU",
		        "TARGET": 120,
		        "ACTUAL": 130,
		        "PERSEN": 108.3333
		    },
		    {
		        "nmcab": "CILEUNGSI",
		        "TARGET": 297,
		        "ACTUAL": 319,
		        "PERSEN": 107.4074
		    },
		    {
		        "nmcab": "PENDOLO",
		        "TARGET": 98,
		        "ACTUAL": 105,
		        "PERSEN": 107.1429
		    },
		    {
		        "nmcab": "JATIBARANG",
		        "TARGET": 198,
		        "ACTUAL": 212,
		        "PERSEN": 107.0707
		    },
		    {
		        "nmcab": "BEKASI",
		        "TARGET": 479,
		        "ACTUAL": 512,
		        "PERSEN": 106.8894
		    },
		    {
		        "nmcab": "SAMARINDA",
		        "TARGET": 165,
		        "ACTUAL": 176,
		        "PERSEN": 106.6667
		    },
		    {
		        "nmcab": "AMBON",
		        "TARGET": 414,
		        "ACTUAL": 441,
		        "PERSEN": 106.5217
		    },
		    {
		        "nmcab": "TOILI",
		        "TARGET": 156,
		        "ACTUAL": 165,
		        "PERSEN": 105.7692
		    },
		    {
		        "nmcab": "KOTA FAJAR",
		        "TARGET": 145,
		        "ACTUAL": 153,
		        "PERSEN": 105.5172
		    },
		    {
		        "nmcab": "GOWA 2",
		        "TARGET": 252,
		        "ACTUAL": 265,
		        "PERSEN": 105.1587
		    },
		    {
		        "nmcab": "BANJARMASIN",
		        "TARGET": 357,
		        "ACTUAL": 375,
		        "PERSEN": 105.042
		    },
		    {
		        "nmcab": "PURWAKARTA",
		        "TARGET": 241,
		        "ACTUAL": 253,
		        "PERSEN": 104.9793
		    },
		    {
		        "nmcab": "BAYUNG LENCIR",
		        "TARGET": 171,
		        "ACTUAL": 179,
		        "PERSEN": 104.6784
		    },
		    {
		        "nmcab": "MUARA TEWEH",
		        "TARGET": 150,
		        "ACTUAL": 157,
		        "PERSEN": 104.6667
		    },
		    {
		        "nmcab": "ENDE",
		        "TARGET": 43,
		        "ACTUAL": 45,
		        "PERSEN": 104.6512
		    },
		    {
		        "nmcab": "RAWAJITU",
		        "TARGET": 91,
		        "ACTUAL": 95,
		        "PERSEN": 104.3956
		    },
		    {
		        "nmcab": "MUARA ENIM",
		        "TARGET": 98,
		        "ACTUAL": 102,
		        "PERSEN": 104.0816
		    },
		    {
		        "nmcab": "SAMPIT",
		        "TARGET": 151,
		        "ACTUAL": 156,
		        "PERSEN": 103.3113
		    },
		    {
		        "nmcab": "PALEMBANG",
		        "TARGET": 227,
		        "ACTUAL": 233,
		        "PERSEN": 102.6432
		    },
		    {
		        "nmcab": "RUTENG",
		        "TARGET": 77,
		        "ACTUAL": 79,
		        "PERSEN": 102.5974
		    },
		    {
		        "nmcab": "KOBA",
		        "TARGET": 79,
		        "ACTUAL": 81,
		        "PERSEN": 102.5316
		    },
		    {
		        "nmcab": "PANGKEP",
		        "TARGET": 137,
		        "ACTUAL": 140,
		        "PERSEN": 102.1898
		    },
		    {
		        "nmcab": "KOTABARU",
		        "TARGET": 98,
		        "ACTUAL": 100,
		        "PERSEN": 102.0408
		    },
		    {
		        "nmcab": "KASIPUTE",
		        "TARGET": 109,
		        "ACTUAL": 111,
		        "PERSEN": 101.8349
		    },
		    {
		        "nmcab": "BIREUEN",
		        "TARGET": 136,
		        "ACTUAL": 138,
		        "PERSEN": 101.4706
		    },
		    {
		        "nmcab": "MAROS",
		        "TARGET": 227,
		        "ACTUAL": 229,
		        "PERSEN": 100.8811
		    },
		    {
		        "nmcab": "GARUT",
		        "TARGET": 224,
		        "ACTUAL": 225,
		        "PERSEN": 100.4464
		    },
		    {
		        "nmcab": "SUNGAI LIAT",
		        "TARGET": 97,
		        "ACTUAL": 97,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "BENGKULU",
		        "TARGET": 55,
		        "ACTUAL": 55,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "TAKALAR",
		        "TARGET": 247,
		        "ACTUAL": 247,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "PENAJAM",
		        "TARGET": 70,
		        "ACTUAL": 70,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "KELAPA",
		        "TARGET": 91,
		        "ACTUAL": 91,
		        "PERSEN": 100
		    },
		    {
		        "nmcab": "KOLAKA",
		        "TARGET": 307,
		        "ACTUAL": 306,
		        "PERSEN": 99.6743
		    },
		    {
		        "nmcab": "TUGUMULYO",
		        "TARGET": 93,
		        "ACTUAL": 92,
		        "PERSEN": 98.9247
		    },
		    {
		        "nmcab": "MARTAPURA KAL",
		        "TARGET": 157,
		        "ACTUAL": 155,
		        "PERSEN": 98.7261
		    },
		    {
		        "nmcab": "GOWA",
		        "TARGET": 304,
		        "ACTUAL": 300,
		        "PERSEN": 98.6842
		    },
		    {
		        "nmcab": "RAHA",
		        "TARGET": 172,
		        "ACTUAL": 167,
		        "PERSEN": 97.093
		    },
		    {
		        "nmcab": "BOROKO",
		        "TARGET": 62,
		        "ACTUAL": 60,
		        "PERSEN": 96.7742
		    },
		    {
		        "nmcab": "SUMBAWA",
		        "TARGET": 60,
		        "ACTUAL": 58,
		        "PERSEN": 96.6667
		    },
		    {
		        "nmcab": "TARAKAN",
		        "TARGET": 86,
		        "ACTUAL": 83,
		        "PERSEN": 96.5116
		    },
		    {
		        "nmcab": "TENTENA",
		        "TARGET": 133,
		        "ACTUAL": 128,
		        "PERSEN": 96.2406
		    },
		    {
		        "nmcab": "TANJUNG BINTANG",
		        "TARGET": 78,
		        "ACTUAL": 75,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcab": "RATAHAN",
		        "TARGET": 182,
		        "ACTUAL": 175,
		        "PERSEN": 96.1538
		    },
		    {
		        "nmcab": "CIBINONG",
		        "TARGET": 281,
		        "ACTUAL": 270,
		        "PERSEN": 96.0854
		    },
		    {
		        "nmcab": "PONTIANAK",
		        "TARGET": 48,
		        "ACTUAL": 46,
		        "PERSEN": 95.8333
		    },
		    {
		        "nmcab": "KADIPATEN",
		        "TARGET": 149,
		        "ACTUAL": 142,
		        "PERSEN": 95.302
		    },
		    {
		        "nmcab": "MAKASSAR",
		        "TARGET": 380,
		        "ACTUAL": 362,
		        "PERSEN": 95.2632
		    },
		    {
		        "nmcab": "TANJUNG",
		        "TARGET": 95,
		        "ACTUAL": 90,
		        "PERSEN": 94.7368
		    },
		    {
		        "nmcab": "MOLIBAGU",
		        "TARGET": 53,
		        "ACTUAL": 50,
		        "PERSEN": 94.3396
		    }
		],
        "columns": [
            { "data": "nmcab" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":120,
        "searching":false,
        "info":false
    });

	$('#tableParetoCabRpYtd').DataTable({
        "data":[
		    {
		        "jenis": "PARETO",
		        "TARGET": 238382999558,
		        "ACTUAL": 226415422500,
		        "PERSEN": 95
		    },
		    {
		        "jenis": "NON PARETO",
		        "TARGET": 276808397775,
		        "ACTUAL": 235462506756,
		        "PERSEN": 85.1
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableParetoCabKonYtd').DataTable({
        "data":[
		    {
		        "jenis": "PARETO",
		        "TARGET": 18298,
		        "ACTUAL": 17551,
		        "PERSEN": 95.9
		    },
		    {
		        "jenis": "NON PARETO",
		        "TARGET": 23058,
		        "ACTUAL": 19644,
		        "PERSEN": 85.2
		    }
		],
        "columns": [
            { "data": "jenis" },
            { "data": "TARGET", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ACTUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "PERSEN", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableCrr').DataTable({
        "data":[
		    {
		        "periode_lunas": null,
		        "konsumen": "0",
		        "ro": "0",
		        "crr": null
		    },
		    {
		        "periode_lunas": "M-0 NORMAL",
		        "konsumen": "11,638",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-0 DIPERCEPAT 1-3 Bln",
		        "konsumen": "7,006",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-0 DIPERCEPAT 4-6 Bln",
		        "konsumen": "3,197",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-0 TOTAL",
		        "konsumen": "21,841",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-1",
		        "konsumen": "26,594",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-2",
		        "konsumen": "25,786",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "M-3",
		        "konsumen": "25,325",
		        "ro": "0",
		        "crr": "0.00"
		    },
		    {
		        "periode_lunas": "TOTAL",
		        "konsumen": "99,546",
		        "ro": "0",
		        "crr": "0.00"
		    }
		],
        "columns": [
            { "data": "periode_lunas" },
            { "data": "konsumen", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "ro", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "crr", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableContactRate').DataTable({
        "data":[
		    {
		        "ket": "TOTAL DATA",
		        "jml_kons": 88311,
		        "persen": 100
		    },
		    {
		        "ket": "DIFOLLOW UP",
		        "jml_kons": 30254,
		        "persen": 34.2585
		    },
		    {
		        "ket": "APLIKASI",
		        "jml_kons": 4678,
		        "persen": 15.4624
		    },
		    {
		        "ket": "BOOKING",
		        "jml_kons": 202,
		        "persen": 4.3181
		    }
		],
        "columns": [
            { "data": "ket" },
            { "data": "jml_kons", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "persen", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProgramMkt').DataTable({
        "data":[
		    {
		        "nm_prog_mkt": "REGULAR",
		        "total_kons": 29607,
		        "total_rp": 398722751399
		    },
		    {
		        "nm_prog_mkt": "REGULER",
		        "total_kons": 3661,
		        "total_rp": 24778122978
		    },
		    {
		        "nm_prog_mkt": "MANDALA TOP UP",
		        "total_kons": 3084,
		        "total_rp": 33507963304
		    },
		    {
		        "nm_prog_mkt": "MANSYUR",
		        "total_kons": 437,
		        "total_rp": 3668426537
		    },
		    {
		        "nm_prog_mkt": "PENCAIRAN < 3 JT INDOTIM",
		        "total_kons": 381,
		        "total_rp": 1002793120
		    },
		    {
		        "nm_prog_mkt": "MANTUL TENANT",
		        "total_kons": 12,
		        "total_rp": 97238800
		    },
		    {
		        "nm_prog_mkt": "PENCAIRAN MULTIGUNA < RP 3 JT",
		        "total_kons": 11,
		        "total_rp": 20208000
		    },
		    {
		        "nm_prog_mkt": "MAPAN",
		        "total_kons": 8,
		        "total_rp": 191317049
		    },
		    {
		        "nm_prog_mkt": null,
		        "total_kons": 6,
		        "total_rp": 94901647
		    },
		    {
		        "nm_prog_mkt": "HADIAH LANGSUNG SEMBAKO / MODAL TANI",
		        "total_kons": 4,
		        "total_rp": 45239500
		    },
		    {
		        "nm_prog_mkt": "DP 0",
		        "total_kons": 4,
		        "total_rp": 99522010
		    },
		    {
		        "nm_prog_mkt": "PAMERAN BERSAMA DEALER",
		        "total_kons": 1,
		        "total_rp": 26080655
		    }
		],
        "columns": [
            { "data": "nm_prog_mkt" },
            { "data": "total_kons", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "total_rp", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1,2],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableProdukProgramMkt').DataTable({
        "data":[
		    {
		        "nama_produk": "AISI",
		        "nm_prog_mkt": null,
		        "total_kons": 3,
		        "total_rp": 70654647
		    },
		    {
		        "nama_produk": "AISI",
		        "nm_prog_mkt": "DP 0",
		        "total_kons": 4,
		        "total_rp": 99522010
		    },
		    {
		        "nama_produk": "AISI",
		        "nm_prog_mkt": "MAPAN",
		        "total_kons": 8,
		        "total_rp": 191317049
		    },
		    {
		        "nama_produk": "AISI",
		        "nm_prog_mkt": "PAMERAN BERSAMA DEALER",
		        "total_kons": 1,
		        "total_rp": 26080655
		    },
		    {
		        "nama_produk": "AISI",
		        "nm_prog_mkt": "REGULAR",
		        "total_kons": 10125,
		        "total_rp": 225746587925
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": null,
		        "total_kons": 2,
		        "total_rp": 12691000
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "HADIAH LANGSUNG SEMBAKO / MODAL TANI",
		        "total_kons": 2,
		        "total_rp": 22472000
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "MANTUL TENANT",
		        "total_kons": 12,
		        "total_rp": 97238800
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "PENCAIRAN < 3 JT INDOTIM",
		        "total_kons": 217,
		        "total_rp": 560563548
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "PENCAIRAN MULTIGUNA < RP 3 JT",
		        "total_kons": 11,
		        "total_rp": 20208000
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "REGULAR",
		        "total_kons": 11525,
		        "total_rp": 97442491481
		    },
		    {
		        "nama_produk": "KPM",
		        "nm_prog_mkt": "REGULER",
		        "total_kons": 2265,
		        "total_rp": 14908023500
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": null,
		        "total_kons": 1,
		        "total_rp": 11556000
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "HADIAH LANGSUNG SEMBAKO / MODAL TANI",
		        "total_kons": 2,
		        "total_rp": 22767500
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "MANDALA TOP UP",
		        "total_kons": 3084,
		        "total_rp": 33507963304
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "MANSYUR",
		        "total_kons": 437,
		        "total_rp": 3668426537
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "PENCAIRAN < 3 JT INDOTIM",
		        "total_kons": 164,
		        "total_rp": 442229572
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "REGULAR",
		        "total_kons": 7957,
		        "total_rp": 75533671993
		    },
		    {
		        "nama_produk": "RETENTION",
		        "nm_prog_mkt": "REGULER",
		        "total_kons": 1396,
		        "total_rp": 9870099478
		    }
		],
        "columns": [
            { "data": "nama_produk" },
            { "data": "nm_prog_mkt" },
            { "data": "total_kons", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "total_rp", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [2,3],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });

    $('#tableDealerTop').DataTable({
        "data":[
		    {
		        "nmvendor": "ANUGERAH PERDANA 5 - KEMIRI",
		        "rata2": 180
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA 2 - SUPRATMAN",
		        "rata2": 142
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA 4 - YOS SUDARSO",
		        "rata2": 136
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA 7 - PALU SELATAN",
		        "rata2": 135
		    },
		    {
		        "nmvendor": "YAMAHA JAYA - PALOPO",
		        "rata2": 108
		    },
		    {
		        "nmvendor": "MERDEKA MOTOR - BEKASI",
		        "rata2": 107
		    },
		    {
		        "nmvendor": "SINAR AGUNG MOTOR - MAKASSAR",
		        "rata2": 94
		    },
		    {
		        "nmvendor": "SARANA NIAGA MEGAHKERTA - PASAR INPRES",
		        "rata2": 91
		    },
		    {
		        "nmvendor": "BERKAT JAYA MOTOR - BUNGKU",
		        "rata2": 88
		    },
		    {
		        "nmvendor": "SUMBER BARU MOTOR - PINRANG",
		        "rata2": 81
		    },
		    {
		        "nmvendor": "ANUGERAH UTAMA - GORONTALO",
		        "rata2": 81
		    },
		    {
		        "nmvendor": "MANDALA MOTOR - SAMRATULANGI MAMUJU",
		        "rata2": 75
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - BELINYU",
		        "rata2": 75
		    },
		    {
		        "nmvendor": "TRIDJAYA MAJU SUKSES",
		        "rata2": 73
		    },
		    {
		        "nmvendor": "SUMBER JADI - SUNGAI LIAT",
		        "rata2": 72
		    },
		    {
		        "nmvendor": "HONDA MOTOR 88 - BIREUEN",
		        "rata2": 68
		    },
		    {
		        "nmvendor": "MANDALA MOTOR II - PASANGKAYU",
		        "rata2": 66
		    },
		    {
		        "nmvendor": "WIRA JAYA MOTOR - MAKASSAR",
		        "rata2": 65
		    },
		    {
		        "nmvendor": "MAKMUR MOTOR - BUNGKU",
		        "rata2": 65
		    },
		    {
		        "nmvendor": "TIMUR JAYA MOTOR - MAKASSAR",
		        "rata2": 65
		    },
		    {
		        "nmvendor": "MINA SPN MOTOR - UJUNG GADING",
		        "rata2": 63
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - SUNGAI LIAT",
		        "rata2": 62
		    },
		    {
		        "nmvendor": "TRIDJAYA MULIA SUKSES",
		        "rata2": 62
		    },
		    {
		        "nmvendor": "ALFA SCORFII - SABULUSSALAM",
		        "rata2": 60
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - TAKALAR",
		        "rata2": 60
		    },
		    {
		        "nmvendor": "ASIA SURYA PERKASA - PUSAT",
		        "rata2": 59
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - TERNATE",
		        "rata2": 59
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - PLAJU",
		        "rata2": 59
		    },
		    {
		        "nmvendor": "METRO JAYA MANDIRI - POSO",
		        "rata2": 58
		    },
		    {
		        "nmvendor": "ANUGRAH ABADI - MALILI",
		        "rata2": 58
		    },
		    {
		        "nmvendor": "ASIA SURYA PERKASA - TOBOALI",
		        "rata2": 57
		    },
		    {
		        "nmvendor": "BINTANG KHARISMA JAYA - PALOPO",
		        "rata2": 56
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - DAYA",
		        "rata2": 54
		    },
		    {
		        "nmvendor": "IFMI MOTOR - MERTASARI",
		        "rata2": 53
		    },
		    {
		        "nmvendor": "CV MARISKO PERKASA",
		        "rata2": 53
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - SUNGAI LILIN",
		        "rata2": 53
		    },
		    {
		        "nmvendor": "HONDA PRIMA - KUALA SIMPANG",
		        "rata2": 51
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - KENDARI",
		        "rata2": 51
		    },
		    {
		        "nmvendor": "PACIFIC MOTOR - CIKARANG",
		        "rata2": 50
		    },
		    {
		        "nmvendor": "CV. BIMA MOTOR - TOLITOLI",
		        "rata2": 49
		    },
		    {
		        "nmvendor": "TEKNIK - PEMATANGSIANGTAR",
		        "rata2": 49
		    },
		    {
		        "nmvendor": "ALFA SCORPII - SUSOH",
		        "rata2": 49
		    },
		    {
		        "nmvendor": "ASIA SURYA PERKASA - TANJUNG PANDAN",
		        "rata2": 48
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - ANTANG",
		        "rata2": 47
		    },
		    {
		        "nmvendor": "JAYA ABADI PROSPERO - BULUKUMBA",
		        "rata2": 47
		    },
		    {
		        "nmvendor": "AYAM JANTAN",
		        "rata2": 45
		    },
		    {
		        "nmvendor": "BERKAT JAYA MOTOR - BETELEME",
		        "rata2": 44
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - SUDIA",
		        "rata2": 43
		    },
		    {
		        "nmvendor": "IWAN RAYA MOTOR - DONGGALA",
		        "rata2": 43
		    },
		    {
		        "nmvendor": "GOWATA SAKTI MOTOR - POROS",
		        "rata2": 42
		    },
		    {
		        "nmvendor": "RAYA MOTOR - PARE-PARE",
		        "rata2": 42
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - KONAWE",
		        "rata2": 42
		    },
		    {
		        "nmvendor": "SURYA PRIMA - TANAH BUMBU",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "DHARMA MAKMUR BERSAMA - CIANGSANA",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "SUMBER JADI - BELTIM",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - PUNGGALUKU",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - SIDRAP",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "HARAPAN - LUBUKBASUNG",
		        "rata2": 40
		    },
		    {
		        "nmvendor": "WIRATAMA MULTI PRIMA",
		        "rata2": 38
		    },
		    {
		        "nmvendor": "MAKMUR MOTOR - POSO",
		        "rata2": 37
		    },
		    {
		        "nmvendor": "AMBON SAKTI MOTOR - YOS SUDARSO",
		        "rata2": 37
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA - SYARIF MANSUR",
		        "rata2": 37
		    },
		    {
		        "nmvendor": "AKAI JAYA MOTOR - HASANUDDIN",
		        "rata2": 37
		    },
		    {
		        "nmvendor": "CAMPION HONDA MOTOR - BANDASAKTI",
		        "rata2": 37
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - KM.14",
		        "rata2": 36
		    },
		    {
		        "nmvendor": "MAJU UNAAHA",
		        "rata2": 36
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - PANGKEP",
		        "rata2": 36
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - TANA TORAJA MAKALE",
		        "rata2": 36
		    },
		    {
		        "nmvendor": "SINAR ALAM PRATAMA - MAKASSAR",
		        "rata2": 36
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - BONE",
		        "rata2": 35
		    },
		    {
		        "nmvendor": "MITRA ANEKA MOTOR - BAUBAU",
		        "rata2": 35
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - KENDARI",
		        "rata2": 35
		    },
		    {
		        "nmvendor": "CIPTA REZEKI BERSAMA - PEUREULAK",
		        "rata2": 35
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - PINRANG",
		        "rata2": 34
		    },
		    {
		        "nmvendor": "ASIA SURYA PERKASA - MENTOK",
		        "rata2": 34
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - PALOPO",
		        "rata2": 34
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - LAMOKATO",
		        "rata2": 33
		    },
		    {
		        "nmvendor": "CV. BIMA MOTOR - BUOL",
		        "rata2": 33
		    },
		    {
		        "nmvendor": "ASTRA SORONG 2",
		        "rata2": 33
		    },
		    {
		        "nmvendor": "MURNI MOTOR - CIBINONG",
		        "rata2": 33
		    },
		    {
		        "nmvendor": "IFMI MOTOR - MEPANGA",
		        "rata2": 33
		    },
		    {
		        "nmvendor": "CITRA SELARAS - BAU-BAU",
		        "rata2": 32
		    },
		    {
		        "nmvendor": "LIBRA MOTOR - A.YANI",
		        "rata2": 32
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - PANGKAL PINANG",
		        "rata2": 31
		    },
		    {
		        "nmvendor": "GAMMA EKA SENTOSA",
		        "rata2": 31
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - LAHAT",
		        "rata2": 31
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA 1 - MONGINSIDI",
		        "rata2": 31
		    },
		    {
		        "nmvendor": "PACIFIC MOTOR - SUBANG ",
		        "rata2": 31
		    },
		    {
		        "nmvendor": "DARMA MOTOR - MAKASSAR",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - PANGKALAN BALAI",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - TAKALAR",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "AMBON SAKTI MOTOR - NAMLEA",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA - TOILI",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "SUMBER JADI - KELAPA KAMPIT",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - PANCIRO",
		        "rata2": 30
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - PANGKEP 2",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "HASJRAT ABADI - PRAMUKA",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "DARMA MAKMUR SENTOSA",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "DAYA ANUGRAH MANDIRI - PINRANG",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - DAYA",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "ANUGERAH PERDANA - LUWUK",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "PANCARAN MOTOR",
		        "rata2": 29
		    },
		    {
		        "nmvendor": "SENTOSA JAYA MOTOR - BANTAENG",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "BINTANG MULIA JAYA - LAHAT",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "SERAM ABADI MOTOR, CV",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "SINAR UTAMA - BERAU",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "ANEKA MOTOR - NAMLEA",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - GOWA",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "IFMI MOTOR - LAMBUNU",
		        "rata2": 28
		    },
		    {
		        "nmvendor": "MAJU - KOTA",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "CEMPAKA MOTOR - KILIRAN JAO",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "SUMBER JADI - BELITUNG",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "DHINO MOTOR - PALU",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - SIMPANG KATIS",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "PRIMA NUSANTARA - MEDAN - B.ACEH",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "TALA MOTOR - MAKASSAR",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "CEMPAKA MOTOR - KOTO BARU",
		        "rata2": 27
		    },
		    {
		        "nmvendor": "DINAMIK PUTRA PERKASA - SEKAYU",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "MITRA PINASTHITA MUSTIKA MOTOR",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "CAPELLA DINAMIK NUSANTARA - ALUE BILIE",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "CV.MUTIARA MOTOR - LUWUK",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "SUMBER PURNAMA SAKTI - SUNGAI LILIN",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "TELADAN BARU MOTOR - SAMPIT",
		        "rata2": 26
		    },
		    {
		        "nmvendor": "ASTRA HONDA MOTOR - WONOMULYO",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "ASTRA HONDA - SUKABUMI",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - PALOPO",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "SUMBER JADI - GANTUNG",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "ANUGERAH MULIA - TOMOHON UTARA",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "SURYA PRATAMA - MUARA TEWEH",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "MAJU - MARTANDU",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "MAJU - KASIPUTE BOEPINANG",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "CEMPAKA MOTOR - SIJUNJUNG",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - MAROS",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "RAYA MOTOR II - SOPPENG",
		        "rata2": 25
		    },
		    {
		        "nmvendor": "ALFA SCORPII  LHOKSEUMAWE",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "ASTRA MOTOR PASAR SENTRAL",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - MESJID RAYA",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - TOBOALI",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "PACIFIC MOTOR II - BEKASI",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - PALOPO",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - SENTRAL YAMAHA",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "MEGA MOTOR - CITEPUS",
		        "rata2": 24
		    },
		    {
		        "nmvendor": "AKAI JAYA MOTOR - MAESA",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "CITRA SELARAS - EREKE",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "SUMBER JADI - PANGKAL PINANG",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - MANOKWARI",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - BELITUNG",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "HASJRAT ABADI - UNAAHA",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "FAJAR MANDIRI - SERANG",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - PALOPO",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "SURACO JAYA ABADI MOTOR - BELOPA",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - PAYUNG",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "WAHANA ARTHA RITELINDO - GORONTALO",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - KELAPA",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - MAMUJU",
		        "rata2": 23
		    },
		    {
		        "nmvendor": "ANUGRAH MOTOR HONDA",
		        "rata2": 22
		    },
		    {
		        "nmvendor": "CEMPAKA MOTOR - MUARO KALABAN",
		        "rata2": 22
		    },
		    {
		        "nmvendor": "PT SINAR SURI",
		        "rata2": 22
		    },
		    {
		        "nmvendor": "ULEE KARENG RAYA MOTOR - ACEH",
		        "rata2": 22
		    },
		    {
		        "nmvendor": "SABANG RAYA - SABAK",
		        "rata2": 21
		    },
		    {
		        "nmvendor": "SUMBER JADI - MENTOK",
		        "rata2": 21
		    },
		    {
		        "nmvendor": "MURNI MOTOR - CILEUNGSI",
		        "rata2": 21
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - JEBUS",
		        "rata2": 21
		    },
		    {
		        "nmvendor": "CIPTA REZEKI BERSAMA - IDI",
		        "rata2": 21
		    },
		    {
		        "nmvendor": "SUMBER JADI  TOBOALI II",
		        "rata2": 20
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO SANGATTA",
		        "rata2": 20
		    },
		    {
		        "nmvendor": "LAMBARONA SAKTI - LAMBARO",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL  ARGA MAKMUR",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "CITRA MANDIRI MOTORINDO - SERANG",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "SUMBER JADI - QQ SIMPANG KATIS",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "ALFA SCORPII  MEULABOH",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "SRIJAYA MOTOR - SIGLI",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "MURNI MOTOR - SILIWANGI",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "ANEKA TEKNIK",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "SAUDARA MOTOR SOLOK",
		        "rata2": 19
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - SANGATTA",
		        "rata2": 18
		    },
		    {
		        "nmvendor": "HAYATI PRATAMA MANDIRI-PASAMAN",
		        "rata2": 18
		    },
		    {
		        "nmvendor": "LESTARI MOTORINDO - PELEMBANG",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "SURYA MITRA SEJATI - BANJARMASIN",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "SUMBER JADI - JEBUS",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "BURSA MOTOR - KUALA SIMPANG",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "NUSA JAYA MOTOR - QQ SUMBER JADI",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - KOBA",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO TANAH GROGOT",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "THAMRIN BERSAUDARA - BABAT TOMAN",
		        "rata2": 17
		    },
		    {
		        "nmvendor": "ARMADA TUNASJAYA ABADI - PALANGKARAYA",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "SEJAHTERA MULYA MOTOR - CIREBON",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "THAMRIN BERSAUDARA - TANJUNG ENIM",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "TOKO BUNDA",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "TRIO MOTOR - MUARA TEWEH 2",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "MAAR MOTOR - MEUREUDU",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "CAPELLA DINAMIK NUSANTARA - TAKENGON",
		        "rata2": 16
		    },
		    {
		        "nmvendor": "SUMBER JAYA ABADI",
		        "rata2": 15
		    },
		    {
		        "nmvendor": "ASPACINDO KEDATON MOTOR - PEKANBARU",
		        "rata2": 15
		    },
		    {
		        "nmvendor": "JAYAMANDIRI GEMASEJATI - PURWAKARTA",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "TOKO PAYUNG AGUNG - BLANG PIDIE",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "NAFRIYA ABADI MOTOR",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "SRIJAYA MOTOR - ULEE GLEE",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "LESTARI MOTOR - CILEUNGSI",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO LOA JANAN",
		        "rata2": 14
		    },
		    {
		        "nmvendor": "PUTRA LANGKAT - BINJAI",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "AGUNG PRIMA MOTOR - SUBULUSSALAM",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "TRIO MOTOR - KOTABARU",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "SUMBER JADI - QQ DENY MOTOR",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "PANCA MOTOR - SUNGAI LILI PASAR",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "SURYA PRIMA - PELAIHARI",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "LAUTAN TEDUH INTERNIAGA - KEDATON",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "UTAMA MOTOR",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "SABANG RAYA MOTOR - SULTAN AGUNG",
		        "rata2": 13
		    },
		    {
		        "nmvendor": "SUMBER JADI - QQ KK MOTOR",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - TANJUNG PANDAN",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "PATRIA ANUGRAH SENTOSA - PANGKALPINANG",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "TJAHAJA BARU - PASAMAN",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "CAPELLA DINAMIK NUSANTARA - SIGLI",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "SABANG RAYA - SP.KAWAT",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "BINTANG MULIA JAYA - SEKAYU",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "LAUTAN TEDUH INTERNIAGA - PAKUAN RATU",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "MEDAN BARU",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "BUNDA MOTOR",
		        "rata2": 12
		    },
		    {
		        "nmvendor": "ASTRA INTERNATIONAL - BASUKI RAHMAT",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "SATRIO BIRO MOTOR",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "LAUTAN TEDUH INTERNIAGA - TIRTAYASA",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - CIBADAK",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "ANUGERAH KENCANA MOTOR - BABAT TOMAN",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "DELIMA MOTOR I - S.PARMAN",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "RESTU MOTOR - LHOKSUKON",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "CAPELLA DINAMIK NUSANTARA - PEUNAYONG",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "ALFA SCORPII - BIREUEN",
		        "rata2": 11
		    },
		    {
		        "nmvendor": "DAYA MOTOR - AW SYARANIE",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "SENTRAL MOTOR - KILIRAN JAO",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "PUTERA MERDEKA - CIBUBUR",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "ASTRA INTERNASIONAL - LUBUK LINGGAU",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "PANCA MOTOR - PAMENANG",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "ALFA SCORFII - LAMBARO",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "SABANG RAYA MOTOR - BANGKO",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "NETRAL JAYA MOTOR - PANGANDARAN",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "MAJU JAYA PRIMA - CUT NYAK DHIEN",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "KARUNIA MOTOR - BUKITTINGGI",
		        "rata2": 10
		    },
		    {
		        "nmvendor": "TRIDJAYA MOTOR -SUBANG",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "EKA SURYA WIJAYA",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "RODA MITRA LESTARI",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "SERBA MULIA ABADI BALIKPAPAN",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "DUTA MOTOR",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "AGUNG JAYA BERSAMA - TASIKMALAYA",
		        "rata2": 9
		    },
		    {
		        "nmvendor": "RAMAYANA MITRA SEJAHTERA",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "SETIA ABADI MITRA MOTOR",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "SAPTA WAHANA MOTOR",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "CAHAYA INDAH MOTOR-PALANGKARAYA",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - TENGGARONG",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "BAHANA CAHAYA SEJATI  -PARUNG KUDA",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "MM MOTOR",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "TRIO MOTOR - MUARA TEWEH",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "KARYA PERDANA - INDRAMAYU",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "SURYA PRIMA - TANJUNG",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "SURYA PRIMA - VETERAN",
		        "rata2": 8
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - AGUS SALIM",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "DAYA MOTOR - PENAJAM",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - PANGANDARAN",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "PUTERA MOTOR - CIKANDE",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO PENAJAM",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "BEKY SRI REJEKI",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "BUDIANA MOTOR - SAMPIT",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "TRIO MOTOR TANJUNG",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - JATIBARANG",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "RAMARAYO PERDANA - SUMEDANG",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "TRIO MOTOR BATULICIN",
		        "rata2": 7
		    },
		    {
		        "nmvendor": "WIJAYA ADIPUTRA SENTOSA",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - MUARA WAHAU",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "BAMEGA MOTOR",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "PLASA KREASINDO MOTOR - BEKASI",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "RAMARAYO PERDANA - CIREBON",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "MAWAR MOTOR - INDRAMAYU",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "ARMADA TUNAS JAYA ABADI - TENGGARONG",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "DETA - SUKABUMI",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "ARMADA TUNAS JAYA ABADI - KAPUAS",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - BONTANG",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "TUNAS SAKTI MOTOR - TANGERANG",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "NAMBO MOTORINDO JAYA",
		        "rata2": 6
		    },
		    {
		        "nmvendor": "SUMBER REJEKI - SUMEDANG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "GUNA MOTOR - KD. HALANG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "PERDANA MAKMUR",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "SURYA PRIMA - BARABAI",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO LAMBUNG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "BANGUN CIPTA BAHANA - TANGERANG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "PRIHATIN MOTOR - NAROGONG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "METRO UTAMA MOTOR",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "DAYA MOTOR - TANJUNG",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "BUANA MOTOR - BANJARMASIN",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - GROGOT",
		        "rata2": 5
		    },
		    {
		        "nmvendor": "TRIO MOTOR - SAMPIT",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - CIBEUREUM",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - BERAU",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "JAYA PERKASA MOTOR - CIAMIS",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "STSJ - SENTRAL YAMAHA - SAMARINDA",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "METRO JAYA MOTOR",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SINAR ABADI - CIREBON",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SURYA PRIMA - PRAMUKA",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SUMBER BAHAGIA WAHANA - BINTARA",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - BALIKPAPAN",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - CIBINONG",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SURYA PRIMA - S.PARMAN",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "DAYA ANUGERAH MANDIRI - BALIKPAPAN",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "MATAHARI LANGGENG JAYA - BEKASI",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SURYA PRATAMA - PALANGKARAYA",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "MUAS MANDIRI MOTOR - CILEUNGSI",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "CV. TM. MOTOR",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - TARAKAN",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "MERDEKA MOTOR - CIKARANG",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "VICTORY MOTOR - SERANG",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "UTAMA MOTOR - BANJARMASIN",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "YAMAHA - SUBANG",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "SURYA PRIMA - SENTRAL",
		        "rata2": 4
		    },
		    {
		        "nmvendor": "AS PUTRA RAHMAT - CIREBON",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "DELIMA MOTOR - SUTOYO",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SINAR UTAMA - SANGATTA",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "HARAPAN MOTOR - PAMARICAN",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - TENGGARONG",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SUMBER BERLIAN MOTOR - TASIKMALAYA",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "KUMALA MOTOR - PALANGKARAYA",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SURYA HIDUP BARU - PASER",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "DWI PUTRA ANUGRAH PERKASA - CIMAHI",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "ASTRA MOTOR SIMPANG PAIT",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "HARAPAN UTAMA PENAJAM",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "BAHANA - CIREBON",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "HAUR KUNING RAHMAT - BANJARBARU",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "NETRAL JAYA MOTOR - BANJAR",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "CAHAYA INDAH LESTARI - KOTABARU",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "PLAZA MOTOR",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "ANUGERAH MOTOR",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - KUNINGAN",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SURYA PRIMA  BALANGAN",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SURYA TERANG - HANDIL",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "BAHANA CAHAYA SEJATI - CIAMIS",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "SURYA TERANG - SEPINGGAN",
		        "rata2": 3
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - CIKAMPEK",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SURYA TIMUR SAKTI JATIM - BUNG TOMO",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "DETA - ARJAWINANGUN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "TRIO MOTOR PANGKALAN BUN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "BINTANG REJEKI MOTOR - CIREBON",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "CAHAYA INDAH LESTARI - BATULICIN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SURYA PRIMA - AMUNTAI",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "VICTORY CIPTA MAKMUR - NAROGONG",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SINAR UTAMA - HIDAYATULLAH",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "KING JAYA  MOTOR - CIANJUR",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SSM KAWASAKI BERAU",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "KAWANSAKTI ADHISEJAHTERA - CIKUPA",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SAMEKARINDO INDAH - JUANDA",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "PUTERA MOTOR - PONDOK UNGU",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "MITRA YAMAHA",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "GRAHA PRAWIRA DANISWARA - BEKASI",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - KADRIE OENING",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SINAR UTAMA - A. YANI",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - ASIA AFRIKA",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "DAYA MOTOR - KANDANGAN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "BANGUN CIPTA BAHANA - MARGAHAYU BEKASI",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "ARI PERSADA MOTOR",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "BINTANG NIAGA JAYA - CIBINONG",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SURYA PRIMA - GAMBUT",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "MUTIARA MOTOR - KADIPATEN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SUMBER JAYA SAKTI - TARAKAN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "MULYA PATROL MOTOR - INDRAMAYU",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SERBA MULIA AUTO - TENGGARONG",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "PUTERA MOTOR - UJUNG MENTENG",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SURYA TIMUR SAKTI JATIM - SUTOMO MOTOR",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SUMBER BERLIAN MOTOR - RAYA PANGANDARAN",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "DAYA MOTOR - SANGATTA",
		        "rata2": 2
		    },
		    {
		        "nmvendor": "SUBUR PLUS - BY PASS",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA PRIMA - CEMPAKA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - BOJONG GEDE",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA PRIMA - KERTAK HANYAR",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "PUTERA CIKARANG",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA TERANG - RAPAK",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "BEKASI MOTOR - BEKASI",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "UTAMA MEGAH SENTOSA BERSAUDARA - PALANGKARAYA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "PERMATA MOTOR - JATIBARANG",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SSM KAWASAKI SANGATTA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "PUTERA KARYA CILEDUG",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SSM KAWASAKI TANAH GROGOT",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "PUTERA SAMUDERA MOTOR - JOGLO",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "ASTRA MOTOR PENAJAM",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA TIMUR SAKTI JATIM - ISTANA MOTOR",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "BAHANA CAHAYA SEJATI - TANGGEUNG",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "ANUGERAH - BARABAI",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - KOPO",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SENTOSA ABADI MOTOR",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "ANTAR PUTRA - MAJALAYA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA MITRA SANTOSA - MARTAPURA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "RAMARAYO PERDANA - BOGOR",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SURYA MITRA SANTOSA - LANDASAN ULIN",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "MEKAR MOTOR - BOGOR",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SSM KAWASAKI TENGGARONG",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "JAYA MANDIRI GEMA SEJATI - SUKASARI",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "TUNAS DWIPA MATRA - SAMARINDA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "PERMATA MOTOR - INDRAMAYU",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SINAR UTAMA - TRIKORA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "BAHANA MOTOR - GARUT",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "TRIO MOTOR KAPUAS - KAPUAS",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SEJAHTERA SAHABAT UTAMA - BALARAJA",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "ASTRA MOTOR - A.YANI",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "SINAR SURYA SAKTI",
		        "rata2": 1
		    },
		    {
		        "nmvendor": "BOROBUDUR KENCANA MULIA",
		        "rata2": 0
		    },
		    {
		        "nmvendor": "KELIMUTU ABADI MOTOR",
		        "rata2": 0
		    }
		],
        "columns": [
            { "data": "nmvendor" },
            { "data": "rata2", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [1],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":210,
        "searching":false,
        "info":false
    });

	$('#tableProduktivitas').DataTable({
        "data":[
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "ADPO",
		        "PENJUAL": 1,
		        "KONSUMEN": 2,
		        "KONSUMEN_PENJUAL": 2,
		        "RUPIAH": 24249000,
		        "RUPIAH_PENJUAL": 24249000
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "BSS",
		        "PENJUAL": 33,
		        "KONSUMEN": 98,
		        "KONSUMEN_PENJUAL": 2.9697,
		        "RUPIAH": 755584288,
		        "RUPIAH_PENJUAL": 22896493.575757574
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "COLS",
		        "PENJUAL": 71,
		        "KONSUMEN": 165,
		        "KONSUMEN_PENJUAL": 2.3239,
		        "RUPIAH": 1372147877,
		        "RUPIAH_PENJUAL": 19326026.436619718
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "CRO",
		        "PENJUAL": 13,
		        "KONSUMEN": 33,
		        "KONSUMEN_PENJUAL": 2.5385,
		        "RUPIAH": 271140508,
		        "RUPIAH_PENJUAL": 20856962.153846152
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "KMAX",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 5243132,
		        "RUPIAH_PENJUAL": 5243132
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "KWIL",
		        "PENJUAL": 5,
		        "KONSUMEN": 8,
		        "KONSUMEN_PENJUAL": 1.6,
		        "RUPIAH": 47612935,
		        "RUPIAH_PENJUAL": 9522587
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "MAGNET",
		        "PENJUAL": 553,
		        "KONSUMEN": 1258,
		        "KONSUMEN_PENJUAL": 2.2749,
		        "RUPIAH": 10567990167,
		        "RUPIAH_PENJUAL": 19110289.63291139
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "MAX",
		        "PENJUAL": 417,
		        "KONSUMEN": 2307,
		        "KONSUMEN_PENJUAL": 5.5324,
		        "RUPIAH": 18901460433,
		        "RUPIAH_PENJUAL": 45327243.24460432
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "null",
		        "PENJUAL": 17,
		        "KONSUMEN": 22,
		        "KONSUMEN_PENJUAL": 1.2941,
		        "RUPIAH": 273088695,
		        "RUPIAH_PENJUAL": 16064040.88235294
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "ROS",
		        "PENJUAL": 74,
		        "KONSUMEN": 770,
		        "KONSUMEN_PENJUAL": 10.4054,
		        "RUPIAH": 5756136274,
		        "RUPIAH_PENJUAL": 77785625.32432432
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "SVRS",
		        "PENJUAL": 24,
		        "KONSUMEN": 53,
		        "KONSUMEN_PENJUAL": 2.2083,
		        "RUPIAH": 432172213,
		        "RUPIAH_PENJUAL": 18007175.541666668
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "KPM",
		        "kdjab": "TAKS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 6964000,
		        "RUPIAH_PENJUAL": 6964000
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "BSS",
		        "PENJUAL": 33,
		        "KONSUMEN": 152,
		        "KONSUMEN_PENJUAL": 4.6061,
		        "RUPIAH": 1449872833,
		        "RUPIAH_PENJUAL": 43935540.39393939
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "COLS",
		        "PENJUAL": 85,
		        "KONSUMEN": 221,
		        "KONSUMEN_PENJUAL": 2.6,
		        "RUPIAH": 2049442937,
		        "RUPIAH_PENJUAL": 24111093.37647059
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "CRO",
		        "PENJUAL": 226,
		        "KONSUMEN": 4817,
		        "KONSUMEN_PENJUAL": 21.3142,
		        "RUPIAH": 49241240108,
		        "RUPIAH_PENJUAL": 217881593.39823008
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "CRS",
		        "PENJUAL": 4,
		        "KONSUMEN": 40,
		        "KONSUMEN_PENJUAL": 10,
		        "RUPIAH": 305348785,
		        "RUPIAH_PENJUAL": 76337196.25
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "KWIL",
		        "PENJUAL": 11,
		        "KONSUMEN": 22,
		        "KONSUMEN_PENJUAL": 2,
		        "RUPIAH": 212198913,
		        "RUPIAH_PENJUAL": 19290810.272727273
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "MAGNET",
		        "PENJUAL": 6,
		        "KONSUMEN": 6,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 62425415,
		        "RUPIAH_PENJUAL": 10404235.833333334
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "MAX",
		        "PENJUAL": 3,
		        "KONSUMEN": 3,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 25840000,
		        "RUPIAH_PENJUAL": 8613333.333333334
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "ROS",
		        "PENJUAL": 3,
		        "KONSUMEN": 9,
		        "KONSUMEN_PENJUAL": 3,
		        "RUPIAH": 95438903,
		        "RUPIAH_PENJUAL": 31812967.666666668
		    },
		    {
		        "wilayah": "INDOTIM",
		        "produk": "RETENTION",
		        "kdjab": "SVRS",
		        "PENJUAL": 27,
		        "KONSUMEN": 56,
		        "KONSUMEN_PENJUAL": 2.0741,
		        "RUPIAH": 507025557,
		        "RUPIAH_PENJUAL": 18778724.333333332
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "KPM",
		        "kdjab": "MAGNET",
		        "PENJUAL": 617,
		        "KONSUMEN": 2799,
		        "KONSUMEN_PENJUAL": 4.5365,
		        "RUPIAH": 23927757770,
		        "RUPIAH_PENJUAL": 38780806.75850891
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "KPM",
		        "kdjab": "MAX",
		        "PENJUAL": 163,
		        "KONSUMEN": 754,
		        "KONSUMEN_PENJUAL": 4.6258,
		        "RUPIAH": 6326428900,
		        "RUPIAH_PENJUAL": 38812447.2392638
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "KPM",
		        "kdjab": "null",
		        "PENJUAL": 16,
		        "KONSUMEN": 105,
		        "KONSUMEN_PENJUAL": 6.5625,
		        "RUPIAH": 957112000,
		        "RUPIAH_PENJUAL": 59819500
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "KPM",
		        "kdjab": "ROS",
		        "PENJUAL": 29,
		        "KONSUMEN": 159,
		        "KONSUMEN_PENJUAL": 5.4828,
		        "RUPIAH": 1167223000,
		        "RUPIAH_PENJUAL": 40249068.96551724
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "RETENTION",
		        "kdjab": "CRO",
		        "PENJUAL": 106,
		        "KONSUMEN": 2463,
		        "KONSUMEN_PENJUAL": 23.2358,
		        "RUPIAH": 26565633851,
		        "RUPIAH_PENJUAL": 250619187.2735849
		    },
		    {
		        "wilayah": "JAWA 1",
		        "produk": "RETENTION",
		        "kdjab": "KWIL",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 8340500,
		        "RUPIAH_PENJUAL": 8340500
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "KPM",
		        "kdjab": "COLS",
		        "PENJUAL": 3,
		        "KONSUMEN": 4,
		        "KONSUMEN_PENJUAL": 1.3333,
		        "RUPIAH": 21957000,
		        "RUPIAH_PENJUAL": 7319000
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "KPM",
		        "kdjab": "MAGNET",
		        "PENJUAL": 49,
		        "KONSUMEN": 204,
		        "KONSUMEN_PENJUAL": 4.1633,
		        "RUPIAH": 1483663008,
		        "RUPIAH_PENJUAL": 30278836.897959184
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "KPM",
		        "kdjab": "MAX",
		        "PENJUAL": 690,
		        "KONSUMEN": 3275,
		        "KONSUMEN_PENJUAL": 4.7464,
		        "RUPIAH": 19627010600,
		        "RUPIAH_PENJUAL": 28444942.898550726
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "KPM",
		        "kdjab": "ROS",
		        "PENJUAL": 17,
		        "KONSUMEN": 67,
		        "KONSUMEN_PENJUAL": 3.9412,
		        "RUPIAH": 445374350,
		        "RUPIAH_PENJUAL": 26198491.17647059
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "KPM",
		        "kdjab": "SVRS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 11157500,
		        "RUPIAH_PENJUAL": 11157500
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "RETENTION",
		        "kdjab": "COLS",
		        "PENJUAL": 5,
		        "KONSUMEN": 23,
		        "KONSUMEN_PENJUAL": 4.6,
		        "RUPIAH": 154482500,
		        "RUPIAH_PENJUAL": 30896500
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "RETENTION",
		        "kdjab": "CRO",
		        "PENJUAL": 65,
		        "KONSUMEN": 1534,
		        "KONSUMEN_PENJUAL": 23.6,
		        "RUPIAH": 11138821875,
		        "RUPIAH_PENJUAL": 171366490.3846154
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "RETENTION",
		        "kdjab": "ROS",
		        "PENJUAL": 5,
		        "KONSUMEN": 57,
		        "KONSUMEN_PENJUAL": 11.4,
		        "RUPIAH": 366922150,
		        "RUPIAH_PENJUAL": 73384430
		    },
		    {
		        "wilayah": "JAWA 2",
		        "produk": "RETENTION",
		        "kdjab": "SVRS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 5920000,
		        "RUPIAH_PENJUAL": 5920000
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "KPM",
		        "kdjab": "CRO",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 8645000,
		        "RUPIAH_PENJUAL": 8645000
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "KPM",
		        "kdjab": "FOS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 10256500,
		        "RUPIAH_PENJUAL": 10256500
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "KPM",
		        "kdjab": "MAGNET",
		        "PENJUAL": 75,
		        "KONSUMEN": 246,
		        "KONSUMEN_PENJUAL": 3.28,
		        "RUPIAH": 2198377403,
		        "RUPIAH_PENJUAL": 29311698.706666667
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "KPM",
		        "kdjab": "MAX",
		        "PENJUAL": 103,
		        "KONSUMEN": 574,
		        "KONSUMEN_PENJUAL": 5.5728,
		        "RUPIAH": 4086406445,
		        "RUPIAH_PENJUAL": 39673848.98058253
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "KPM",
		        "kdjab": "ROS",
		        "PENJUAL": 26,
		        "KONSUMEN": 215,
		        "KONSUMEN_PENJUAL": 8.2692,
		        "RUPIAH": 1656911432,
		        "RUPIAH_PENJUAL": 63727362.76923077
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "RETENTION",
		        "kdjab": "CRO",
		        "PENJUAL": 33,
		        "KONSUMEN": 824,
		        "KONSUMEN_PENJUAL": 24.9697,
		        "RUPIAH": 8005200084,
		        "RUPIAH_PENJUAL": 242581820.72727272
		    },
		    {
		        "wilayah": "KALIMANTAN",
		        "produk": "RETENTION",
		        "kdjab": "ROS",
		        "PENJUAL": 7,
		        "KONSUMEN": 47,
		        "KONSUMEN_PENJUAL": 6.7143,
		        "RUPIAH": 410858405,
		        "RUPIAH_PENJUAL": 58694057.85714286
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "BSS",
		        "PENJUAL": 4,
		        "KONSUMEN": 21,
		        "KONSUMEN_PENJUAL": 5.25,
		        "RUPIAH": 120879000,
		        "RUPIAH_PENJUAL": 30219750
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "COLS",
		        "PENJUAL": 21,
		        "KONSUMEN": 74,
		        "KONSUMEN_PENJUAL": 3.5238,
		        "RUPIAH": 506179500,
		        "RUPIAH_PENJUAL": 24103785.714285713
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "CRO",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 12282000,
		        "RUPIAH_PENJUAL": 12282000
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "MAGNET",
		        "PENJUAL": 351,
		        "KONSUMEN": 992,
		        "KONSUMEN_PENJUAL": 2.8262,
		        "RUPIAH": 8526272250,
		        "RUPIAH_PENJUAL": 24291373.931623932
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "MAX",
		        "PENJUAL": 272,
		        "KONSUMEN": 769,
		        "KONSUMEN_PENJUAL": 2.8272,
		        "RUPIAH": 5781845201,
		        "RUPIAH_PENJUAL": 21256783.82720588
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "null",
		        "PENJUAL": 5,
		        "KONSUMEN": 15,
		        "KONSUMEN_PENJUAL": 3,
		        "RUPIAH": 151278250,
		        "RUPIAH_PENJUAL": 30255650
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "ROS",
		        "PENJUAL": 65,
		        "KONSUMEN": 315,
		        "KONSUMEN_PENJUAL": 4.8462,
		        "RUPIAH": 2288611850,
		        "RUPIAH_PENJUAL": 35209413.07692308
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "KPM",
		        "kdjab": "SVRS",
		        "PENJUAL": 2,
		        "KONSUMEN": 3,
		        "KONSUMEN_PENJUAL": 1.5,
		        "RUPIAH": 13547000,
		        "RUPIAH_PENJUAL": 6773500
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "BSS",
		        "PENJUAL": 11,
		        "KONSUMEN": 49,
		        "KONSUMEN_PENJUAL": 4.4545,
		        "RUPIAH": 404331279,
		        "RUPIAH_PENJUAL": 36757389
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "COLS",
		        "PENJUAL": 26,
		        "KONSUMEN": 76,
		        "KONSUMEN_PENJUAL": 2.9231,
		        "RUPIAH": 623479677,
		        "RUPIAH_PENJUAL": 23979987.576923076
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "CRO",
		        "PENJUAL": 123,
		        "KONSUMEN": 1607,
		        "KONSUMEN_PENJUAL": 13.065,
		        "RUPIAH": 14741470816,
		        "RUPIAH_PENJUAL": 119849356.22764228
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "FOS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 5693615,
		        "RUPIAH_PENJUAL": 5693615
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "ROS",
		        "PENJUAL": 8,
		        "KONSUMEN": 38,
		        "KONSUMEN_PENJUAL": 4.75,
		        "RUPIAH": 313271165,
		        "RUPIAH_PENJUAL": 39158895.625
		    },
		    {
		        "wilayah": "SUMATERA",
		        "produk": "RETENTION",
		        "kdjab": "SVRS",
		        "PENJUAL": 1,
		        "KONSUMEN": 1,
		        "KONSUMEN_PENJUAL": 1,
		        "RUPIAH": 9380500,
		        "RUPIAH_PENJUAL": 9380500
		    }
		],
        "columns": [
            { "data": "wilayah" },
            { "data": "produk" },
            { "data": "kdjab" },
            { "data": "PENJUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "KONSUMEN", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "KONSUMEN_PENJUAL", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUPIAH", render: function ( data, type, row ) { return formatPrice(data); } },
            { "data": "RUPIAH_PENJUAL", render: function ( data, type, row ) { return formatPrice(data); } },
        ],
        "columnDefs": [{
            "targets": [3,4,5,6,7],
            "className": "text-right"
        }],
        "paging":false,
        "sorting":false,
        "scrollY":240,
        "searching":false,
        "info":false
    });
});
</script>

<script type="text/javascript">
    "use strict";

$(document).ready(function () {

  var echartElemBar1 = document.getElementById('echartBar1');

  if (echartElemBar1) {
    var echartBar1 = echarts.init(echartElemBar1);
    echartBar1.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target', 'Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [462298041246, 23595716327, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [514991503375, 488642080892, 549748423263, 627621432418, 561325138769, 552131678881, 573981322354, 585752353175, 590294502407, 579667057086, 607228911965, 627459045830],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [89.76,4.82,0,0,0,0,0,0,0,0,0,0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar1.resize();
      }, 500);
    });
  }

  var echartElemBar2 = document.getElementById('echartBar2');

  if (echartElemBar2) {
    var echartBar2 = echarts.init(echartElemBar2);
    echartBar2.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Actual', 'Target', 'Persen']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Konsumen',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      },
      {
        type: 'value',
        name: '%',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Actual',
        data: [37219, 2394, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Target',
        data: [41341, 40121, 44426, 49107, 44976, 44878, 46498, 47370, 47765, 46712, 49172, 50442],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Persen',
        yAxisIndex: 1,
        data: [90.02, 5.96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'line',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar2.resize();
      }, 500);
    });
  }

  var echartElemBar3 = document.getElementById('echartBar3');

  if (echartElemBar3) {
    var echartBar3 = echarts.init(echartElemBar3);
    echartBar3.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Aisi', 'KPM', 'Retention']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Rupiah',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Aisi',
        data: [96.48, 2.03, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'KPM',
        data: [68.19, 5.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Retention',
        data: [107.21, 8.66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar3.resize();
      }, 500);
    });
  }

  var echartElemBar4 = document.getElementById('echartBar4');

  if (echartElemBar4) {
    var echartBar4 = echarts.init(echartElemBar4);
    echartBar4.setOption({
      legend: {
        borderRadius: 0,
        orient: 'horizontal',
        x: 'right',
        data: ['Aisi', 'KPM', 'Retention']
      },
      grid: {
        left: '8px',
        right: '8px',
        bottom: '0',
        containLabel: true
      },
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)'
      },
      xAxis: [{
        type: 'category',
        data: ['01','02','03','04','05','06','07','08','09','10','11','12'],
        axisTick: {
          alignWithLabel: true
        },
        splitLine: {
          show: false
        },
        axisLine: {
          show: true
        }
      }],
      yAxis: [{
        type: 'value',
        name: 'Konsumen',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          interval: 'auto'
        }
      }],
      series: [{
        name: 'Aisi',
        data: [108.77, 2.27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#0168c1'
        },
        type: 'bar',
        barGap: 0,
        color: '#bcbbdd',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'KPM',
        data: [72.74, 6.03, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }, {
        name: 'Retention',
        data: [102.50, 8.24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        label: {
          show: false,
          color: '#639'
        },
        type: 'bar',
        color: '#7569b3',
        smooth: true,
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: -2,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartBar4.resize();
      }, 500);
    });
  }

  var echartElemPie1 = document.getElementById('echartPie1');

  if (echartElemPie1) {
    var echartPie1 = echarts.init(echartElemPie1);
    echartPie1.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['40%','70%'],
        data: [{
		        "name": "M-0 DIPERCEPAT 1-3 Bln",
		        "value": 0
		    },
		    {
		        "name": "M-3",
		        "value": 0
		    },
		    {
		        "name": "M-0 DIPERCEPAT 4-6 Bln",
		        "value": 0
		    },
		    {
		        "name": "M-0 NORMAL",
		        "value": 0
		    },
		    {
		        "name": "M-1",
		        "value": 0
		    },
		    {
		        "name": null,
		        "value": 0
		    },
		    {
		        "name": "M-2",
		        "value": 0
		    }],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie1.resize();
      }, 500);
    });
  } 

  var echartElemPie2 = document.getElementById('echartPie2');

  if (echartElemPie2) {
    var echartPie2 = echarts.init(echartElemPie2);
    echartPie2.setOption({
      color: ['#c13018', '#f36e12', '#ebcb37', '#a1b968', '#0d94bc', '#135bba'],
      tooltip: {
        show: true,
        backgroundColor: 'rgba(0, 0, 0, .8)',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['40%','70%'],
        data: [
		    {
		        "name": "NON name",
		        "value": 11059
		    },
		    {
		        "name": "AKTIF",
		        "value": 849
		    },
		    {
		        "name": "PRODUKTIF",
		        "value": 833
		    },
		    {
		        "name": "PRIORITAS",
		        "value": 779
		    }
		],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            formatter: "{b} \n{c} ({d}%)"
          }
        }
      }]
    });
    $(window).on('resize', function () {
      setTimeout(function () {
        echartPie2.resize();
      }, 500);
    });
  } 
});
</script>