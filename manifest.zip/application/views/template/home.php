<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2">Home</h1>
    </div>

    <div class="separator-breadcrumb border-top"></div>

    <div class="row" style="
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;">
    	<img src="<?php echo base_url();?>assets/images/logo/png/manifest-logo.png" alt="" style="width:25%; height:25%;">
	</div>

</div>