<!DOCTYPE html>
<html lang="en" dir="">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Mandala Financial System</title>

    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/png/manifest-logo-only.png" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/bootstrap/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/themes/lite-blue.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/perfect-scrollbar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/sweetalert2.min.css" />
</head>

<body class="text-left">
    <div class="app-admin-wrap layout-sidebar-large">
        <div class="main-header">
            <div class="logo">
                <img src="<?php echo base_url();?>assets/images/logo/png/manifest-logo-only.png" alt="">
            </div>
            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <div style="margin: auto"></div>
            <div class="header-part-right">
                <!-- Full screen toggle -->
                <i class="i-Full-Screen header-icon d-none d-sm-inline-block" data-fullscreen></i>
                <!-- Grid menu Dropdown -->
                <!-- Notification -->
                <div class="dropdown">
                    <div class="badge-top-container" role="button" id="dropdownNotification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="badge badge-primary">3</span>
                        <i class="i-Bell text-muted header-icon"></i>
                    </div>
                    <!-- Notification dropdown -->
                    <div class="dropdown-menu dropdown-menu-right notification-dropdown rtl-ps-none" aria-labelledby="dropdownNotification" data-perfect-scrollbar data-suppress-scroll-x="true">
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Speach-Bubble-6 text-primary mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>Judul</span>
                                    <span class="badge badge-pill badge-primary ml-1 mr-1">new</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">Jam</span>
                                </p>
                                <p class="text-small text-muted m-0">Deskripsi</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Notificaiton End -->
                <!-- User avatar dropdown -->
                <div class="dropdown">
                    <div class="user col align-self-end">
                        <img src="<?php echo base_url();?>assets/images/user_blank.png" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                            <div class="dropdown-header">
                                <i class="i-Lock-User mr-1"></i> <?php echo $this->session->userdata('nmuser')?>
                            </div>
                            <a class="dropdown-item" href="<?php echo base_url();?>user/profile">Account settings</a>
                            <a class="dropdown-item" href="<?php echo base_url();?>logout">Sign out</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="side-content-wrap">
            <?php 
                $head = array_filter($list_menu,function($filter1){ return ($filter1['type'] == 1);});
            ?>

                <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">

                    <?php foreach($head as $key1 => $value1):?>
                        <ul class="navigation-left">
                            <li class="nav-item" data-item="<?php echo $value1['nodeid']?>">
                                <a class="nav-item-hold" href="#">
                                    <?php if($value1['icon'] != '-' || $value1['icon'] != '' || $value1['icon'] != null):?>
                                    <i class="nav-icon <?php echo $value1['icon'];?>"></i>
                                    <?php endif;?>
                                    <span class="nav-text"><?php echo $value1['name']; ?></span>
                                </a>
                                <div class="triangle"></div>
                            </li>
                        </ul>
                    <?php endforeach;?>

                </div>
                <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">

                    <?php foreach($head as $key2 => $value2):?>
                        <?php 
                            $nodeid = $value2['nodeid'];
                            $child = array_filter($list_menu,function($filter2) use ($nodeid) { return ($filter2['parentid'] == $nodeid);});
                        ?>
                        <ul class="childNav" data-parent="<?php echo $value2['nodeid'];?>">
                            <?php foreach($child as $key3 => $value3):?>
                                <?php if($value3['type'] == 2):?>
                                    <li class="nav-item">
                                        <a onclick="openView('<?php echo $value3['url'];?>')">
                                            <?php if($value3['icon'] != '-' || $value3['icon'] != '' || $value3['icon'] != null):?>
                                            <i class="nav-icon <?php echo $value3['icon'];?>"></i>
                                            <?php endif;?>
                                            <span class="item-name"><?php echo $value3['name'];?></span>
                                        </a>
                                    </li>
                                <?php endif;?>

                                <?php if($value3['type'] == 3):?>
                                    <?php 
                                        $nodeidsub = $value3['nodeid'];
                                        $childsub = array_filter($list_menu,function($filter3) use ($nodeidsub) { return ($filter3['parentid'] == $nodeidsub) && ($filter3['type'] == 4);});
                                    ?>
                                    <li class="nav-item dropdown-sidemenu">
                                        <a href="">
                                            <?php if($value3['icon'] != '-' || $value3['icon'] != '' || $value3['icon'] != null):?>
                                            <i class="nav-icon <?php echo $value3['icon'];?>"></i>
                                            <?php endif;?>
                                            <span class="item-name"><?php echo $value3['name'];?></span>
                                            <i class="dd-arrow i-Arrow-Down"></i>
                                        </a>
                                        <ul class="submenu">
                                            <?php foreach($childsub as $key4 => $value4):?>
                                                <li><a onclick="openView('<?php echo $value4['url'];?>')"><?php echo $value4['name'];?></a></li>
                                            <?php endforeach;?>
                                        </ul>
                                    </li>
                                <?php endif;?>
                            <?php endforeach;?>
                        </ul>
                    <?php endforeach;?>

                </div>
                
            <div class="sidebar-overlay"></div>
        </div>
        
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div id="konten">
                
            </div>
            <!-- Footer Start -->
            <div class="flex-grow-1"></div>
            <div class="app-footer">
                <div class="footer-bottom d-flex flex-column flex-sm-row align-items-center">
                    <div class="d-flex align-items-center"> 
                        <img class="logo" src="<?php echo base_url();?>assets/images/logo/logo-mandala.png" alt="" style="width:10%;height:10%;min-width:180px;min-height:35px;">
                        

                        <span class="flex-grow-1"></span>
                        <div>
                            <p class="m-0">&copy; 2022 PT. Mandala Multifinance Tbk.</p>
                            <p class="m-0">All rights reserved</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Fotter end -->
        </div>
    </div>
</body>
<script src="<?php echo base_url();?>assets/js/plugins/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/script.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts/sidebar.large.script.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/sweetalert2.min.js"></script>
<script type="text/javascript">

    $(document).ready(function(){
        openView('home/homePage');
    })

    function openView(url) {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url();?>'+url,
            data: '',
            beforeSend: function (data) {
                swal({
                  title: 'Loading...',
                  text: '',
                  showConfirmButton: false
                });
                swal.showLoading();
            },
            error: function (data) {
                swal.close();
            },
            success: function (data) {
                swal.close();
                $('#konten').html(data);
            }
        })
    }


    const intval = setInterval(function() {
       check_session();
    }, 60000) // 1 menit
    var idleTime = 0;

    $(document).ready(function () {
        //Increment the idle time counter every minute.
        var idleInterval = setInterval(timerIncrement, 1000); // 1 minute
        <?php $waktu = time() + 25200; ?>
        <?php $expired = 3600; ?>
        
        //Zero the idle timer on mouse movement.
        $(this).mousemove(function (e) {
            idleTime = 0;
            <?php $this->session->set_userdata('timeout',$waktu + $expired);?>
        });

        $(this).keypress(function (e) {
            idleTime = 0;
            <?php $this->session->set_userdata('timeout',$waktu + $expired); ?>
        });

        $(this).mousedown(function (e) {
            idleTime = 0;
            <?php $this->session->set_userdata('timeout',$waktu + $expired); ?>
        });

        function timerIncrement() {
            idleTime = idleTime + 1;
            if (idleTime > 1800) { // 30 minutes
                clearInterval(idleInterval)

                $.ajax({
                    type : 'POST',
                    url : '<?php echo base_url();?>clear_session',
                    data : '',
                    success:function(data) {
                        if(data){
                            swal({
                              type: 'info',
                              title: 'Manifest',
                              text: 'Session anda telah habis, harap login ulang !',
                              buttonsStyling: false,
                              confirmButtonClass: 'btn btn-lg btn-info'
                            }).then(function(){
                                window.location.replace('<?php echo base_url();?>auth')
                            });
                        }
                    }
                })
                
            }
        }
    });

    function check_session(){
        $.ajax({
            type : 'POST',
            url : '<?php echo base_url();?>session_check',
            data : '',
            success:function(data) {
                var obj = JSON.parse(data);
                if(obj[0]){
                    swal({
                      type: 'info',
                      title: 'Manifest',
                      text: 'Session anda telah habis, harap login ulang !',
                      buttonsStyling: false,
                      confirmButtonClass: 'btn btn-lg btn-info'
                    }).then(function(){
                        window.location.replace('<?php echo base_url();?>auth')
                    });
                }
            }
        })
    }

</script>

</html>